import os
from flask import Flask
from flask_login import LoginManager
from .utils import load_config, DB_PATH, UPLOAD_FOLDER, BACKUP_DIR
from .database import db, Admin

login_manager = LoginManager()

def create_app():
    app = Flask(__name__)
    
    # 1. Config
    system_config = load_config()
    app.secret_key = 'smartlibrarykey'
    app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{DB_PATH}'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
    app.config['DEFAULT_BORROW_DAYS'] = system_config.get('default_borrow_days', 14)
    
    # Ensure dirs exist
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
    os.makedirs(BACKUP_DIR, exist_ok=True)

    # 2. Init Extensions
    db.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'
    login_manager.login_message_category = 'warning'

    @login_manager.user_loader
    def load_user(user_id):
        return Admin.query.get(int(user_id))

    # 3. Register Blueprints
    from .routes import main as main_blueprint
    from .auth import auth as auth_blueprint
    
    app.register_blueprint(main_blueprint)
    app.register_blueprint(auth_blueprint, url_prefix='/auth')

    # 4. Create Tables
    with app.app_context():
        db.create_all()
        # Create default admin if missing
        if not Admin.query.first():
            from .utils import hash_pw
            db.session.add(Admin(username='admin', password=hash_pw('admin123')))
            db.session.commit()
            print("Default admin created.")

    return app