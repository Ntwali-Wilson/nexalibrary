import threading
import webbrowser
import os
from app import create_app

PORT = 5000
HOST = "0.0.0.0"
START_URL = f"http://{HOST}:{PORT}/auth/login"

app = create_app()

if __name__ == "__main__":
    print(f"🚀 Starting Library System at {START_URL}...")
    
    # Open browser automatically
    threading.Timer(1.5, lambda: webbrowser.open(START_URL)).start()
    
    # Run App
    app.run(host=HOST, port=PORT, debug=True, use_reloader=False)