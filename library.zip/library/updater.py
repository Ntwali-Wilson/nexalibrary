import os
import shutil
import zipfile
import requests
import sys
import time

def perform_update(zip_url, app_dir, backup_dir):
    temp_dir = "temp_update_extract"
    zip_path = "update.zip"
    
    # 1. Wait for Flask to release file locks
    print("Waiting for server to shut down...")
    time.sleep(3) 

    # 2. Create Backup
    timestamp = time.strftime("%Y%m%d-%H%M%S")
    backup_path = os.path.join(backup_dir, f"app_backup_{timestamp}")
    try:
        if os.path.exists(app_dir):
            shutil.copytree(app_dir, backup_path, ignore=shutil.ignore_patterns('backups', 'instance', '__pycache__', '.git'))
            print(f"Backup created at: {backup_path}")
    except Exception as e:
        print(f"Backup failed: {e}")
        return False

    try:
        # 3. Download
        print(f"Downloading update from {zip_url}...")
        r = requests.get(zip_url, stream=True, timeout=30)
        r.raise_for_status()
        with open(zip_path, 'wb') as f:
            for chunk in r.iter_content(chunk_size=8192):
                f.write(chunk)

        # 4. Integrity Check (Requested Functionality)
        if not zipfile.is_zipfile(zip_path):
            print("Error: The downloaded file is not a valid zip archive (likely an HTML error page).")
            return False

        # 5. Extract
        if os.path.exists(temp_dir): shutil.rmtree(temp_dir)
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(temp_dir)

        # 6. Handle GitHub Nested Folders
        # GitHub zips often put everything inside a folder like 'repo-main/'
        inner_items = os.listdir(temp_dir)
        source_path = temp_dir
        if len(inner_items) == 1 and os.path.isdir(os.path.join(temp_dir, inner_items[0])):
            source_path = os.path.join(temp_dir, inner_items[0])

        # 7. SWAP (Handles new/added files automatically)
        print("Applying update...")
        for item in os.listdir(source_path):
            s = os.path.join(source_path, item)
            d = os.path.join(app_dir, item)
            
            # Protect essential local data
            if item in ['uploads','config.json', 'backups', '.env', 'library.db']:
                continue

            if os.path.isdir(s):
                if os.path.exists(d): shutil.rmtree(d)
                shutil.copytree(s, d)
            else:
                shutil.copy2(s, d)

        # 8. Clean up
        shutil.rmtree(temp_dir)
        os.remove(zip_path)
        print("Update successful!")
        return True

    except Exception as e:
        print(f"Update failed: {e}")
        # --- ROLLBACK LOGIC ---
        if os.path.exists(backup_path):
            print("Initiating automatic rollback...")
            shutil.rmtree(app_dir)
            shutil.copytree(backup_path, app_dir)
        return False

if __name__ == "__main__":
    if len(sys.argv) > 3:
        success = perform_update(sys.argv[1], sys.argv[2], sys.argv[3])
        if success:
            # Restart the app (Replace 'run.py' with your main entry file)
            os.execv(sys.executable, ['python', 'run.py'])