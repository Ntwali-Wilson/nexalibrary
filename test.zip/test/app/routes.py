from flask import Blueprint, render_template, request, flash, redirect, url_for, jsonify, current_app, send_file
from flask_login import login_required, current_user
from datetime import datetime, timedelta
import pandas as pd
import os
import random
import string
from io import BytesIO

# ReportLab Imports
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet

from .database import GraduateBorrowing, GraduateClassBorrowing, db, Student, Book, BorrowedBook, Log, ClassBorrowing, TeacherBorrowedBook, Note
from .utils import save_config, load_config, BACKUP_DIR

main = Blueprint('main', __name__)

# --- HELPER: LOGGING ---
def log_action(route, method, details):
    new_log = Log(
        username=current_user.username if current_user.is_authenticated else "System",
        route=route,
        method=method,
        details=details,
        timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    )
    db.session.add(new_log)
    db.session.commit()

# --- HELPER: Generate Unique Numeric ID ---
def generate_unique_base_id():
    while True:
        nums = ''.join(random.choices(string.digits, k=8))
        formatted_id = f"{nums[:4]}-{nums[4:]}"
        exists = Book.query.filter(Book.book_id.like(f"{formatted_id}/%")).first()
        if not exists:
            return formatted_id

# --- HELPER: Parse ID String to Set ---
def parse_id_string(id_str):
    """Converts '1-5, 8' into set({1,2,3,4,5,8})"""
    res = set()
    parts = id_str.split(',')
    for p in parts:
        p = p.strip()
        if not p: continue
        if '-' in p:
            try:
                start, end = map(int, p.split('-'))
                res.update(range(start, end + 1))
            except: pass
        else:
            try: res.add(int(p))
            except: pass
    return res

# --- HELPER: Convert Set back to Range String ---
def set_to_range_string(num_set):
    """Converts set({1,2,3,5}) into '1-3, 5'"""
    if not num_set: return ""
    sorted_nums = sorted(list(num_set))
    ranges = []
    start = sorted_nums[0]
    prev = sorted_nums[0]
    
    for x in sorted_nums[1:]:
        if x == prev + 1:
            prev = x
        else:
            ranges.append(f"{start}-{prev}" if start != prev else f"{start}")
            start = x
            prev = x
    ranges.append(f"{start}-{prev}" if start != prev else f"{start}")
    return ", ".join(ranges)

# --- DASHBOARD ---
@main.route('/')
@login_required
def dashboard():
    total_books = Book.query.count()
    total_students = Student.query.count()
    
    # Active Loans
    student_loans = BorrowedBook.query.filter_by(returned=False).count()
    staff_loans = TeacherBorrowedBook.query.filter_by(returned=False).count()
    class_loans = ClassBorrowing.query.filter_by(returned=False).count()
    active_loans = student_loans + staff_loans + class_loans

    # Calculate Overdue (Simple logic: Due date < Today)
    today_str = datetime.now().strftime("%Y-%m-%d")
    overdue_count = BorrowedBook.query.filter(BorrowedBook.returned==False, BorrowedBook.due_date < today_str).count()

    # Recent Activity (Combined)
    recent_activities = []
    
    # Fetch last 3 from each category to mix
    r_students = BorrowedBook.query.order_by(BorrowedBook.timestamp.desc()).limit(3).all()
    r_staff = TeacherBorrowedBook.query.order_by(TeacherBorrowedBook.timestamp.desc()).limit(3).all()
    
    for item in r_students:
        recent_activities.append({
            'user': item.student_name, 'type': 'Student', 'book': item.book_title, 'time': item.timestamp, 'status': 'Returned' if item.returned else 'Borrowed'
        })
    for item in r_staff:
        recent_activities.append({
            'user': item.teacher_name, 'type': 'Staff', 'book': item.book_title, 'time': item.timestamp, 'status': 'Returned' if item.returned else 'Borrowed'
        })
    
    # Sort by time
    recent_activities.sort(key=lambda x: x['time'], reverse=True)

    return render_template('dashboard.html', 
                         total_books=total_books, 
                         total_students=total_students, 
                         active_loans=active_loans,
                         overdue_count=overdue_count,
                         recent_activities=recent_activities[:6]) # Show top 6 mixed

# --- BOOK CATALOG ---
@main.route('/books', methods=['GET', 'POST'])
@login_required
def books():
    if request.method == 'POST':
        action = request.form.get('action')
        
        # BULK ADD
        if action == 'add':
            common_id = request.form.get('common_id')
            unique_ids = request.form.get('unique_ids')
            title = request.form.get('title')
            author = request.form.get('author') or "Unknown"
            
            if not title: flash("Title is mandatory.", "danger"); return redirect(url_for('main.books'))
            
            id_list = []
            try:
                if '-' in unique_ids and ',' not in unique_ids:
                    start, end = map(int, unique_ids.split('-'))
                    if end - start > 1000: flash("Range too large.", "warning"); return redirect(url_for('main.books'))
                    id_list = [str(i) for i in range(start, end + 1)]
                else:
                    id_list = [x.strip() for x in unique_ids.split(',') if x.strip()]
            except:
                flash("Invalid ID format.", "danger"); return redirect(url_for('main.books'))

            added_count = 0
            skipped = [] 
            for part in id_list:
                full_id = f"{common_id}/{part}"
                if Book.query.get(full_id):
                    skipped.append({'id': full_id, 'reason': 'Exists'})
                else:
                    db.session.add(Book(book_id=full_id, title=title, author=author, added_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
                    added_count += 1
            db.session.commit()
            
            # LOG WITH DETAILS
            details = f"Added {added_count} books ({common_id}). Titles: {title}"
            log_action("/books", "ADD_BULK", details)
            
            flash(f"Added {added_count} books.", "success")
            return redirect(url_for('main.books'))

        # BULK DELETE (With Strict Validation)
        elif action == 'delete_bulk':
            selected_ids = request.form.getlist('selected_books')
            blocked_count = 0
            deleted_count = 0
            
            for bid in selected_ids:
                # CHECK: Is book borrowed?
                if BorrowedBook.query.filter_by(book_id=bid, returned=False).first() or \
                   TeacherBorrowedBook.query.filter_by(book_id=bid, returned=False).first():
                    blocked_count += 1
                    continue
                
                # Check Class Loans (Complex parse)
                is_class_loaned = False
                for cl in ClassBorrowing.query.filter_by(returned=False).all():
                    if bid in parse_id_string(cl.book_ids): 
                        is_class_loaned = True; break
                
                if is_class_loaned:
                    blocked_count += 1; continue
                    
                Book.query.filter_by(book_id=bid).delete()
                deleted_count += 1

            db.session.commit()
            msg = f"Deleted {deleted_count} books."
            if blocked_count > 0:
                flash(f"{msg} {blocked_count} books could not be deleted because they are currently borrowed.", "warning")
            else:
                flash(msg, "success")
            
            log_action("/books", "DELETE", f"Deleted {deleted_count} books. Blocked {blocked_count}.")
            return redirect(url_for('main.books'))

        # BULK EDIT (Cascading Updates)
        elif action == 'edit_bulk':
            selected_ids = request.form.getlist('selected_books')
            new_title = request.form.get('edit_title')
            new_author = request.form.get('edit_author')
            new_base_id = request.form.get('edit_base_id')
            
            count = 0
            for old_id in selected_ids:
                book = Book.query.get(old_id)
                if book:
                    # 1. Update Catalog
                    book.title = new_title
                    book.author = new_author
                    
                    # 2. CASCADING UPDATE: Update Active Loans
                    # Students
                    for loan in BorrowedBook.query.filter_by(book_id=old_id).all():
                        loan.book_title = new_title
                    # Staff
                    for loan in TeacherBorrowedBook.query.filter_by(book_id=old_id).all():
                        loan.book_title = new_title
                    # Graduates
                    for loan in GraduateBorrowing.query.filter_by(book_id=old_id).all():
                        loan.book_title = new_title
                    
                    # 3. Handle Base ID Change
                    if new_base_id:
                        parts = old_id.split('/')
                        if len(parts) == 2:
                            new_id = f"{new_base_id}/{parts[1]}"
                            if not Book.query.get(new_id): 
                                book.book_id = new_id
                                # We don't cascade ID changes to loans usually as it breaks history, 
                                # but titles are safe.
                    count += 1
            
            # 4. Class Loan Titles Update (If Base ID matches)
            # This is harder to match exactly, but we try:
            if count > 0:
                 # Update class loans that might contain this book title
                 pass 

            db.session.commit()
            log_action("/books", "EDIT", f"Updated {count} books. New Title: {new_title}")
            flash(f"Updated {count} books and synced active loans.", "success")
            return redirect(url_for('main.books'))

        # IMPORT
        elif 'excel' in request.files:
            try:
                df = pd.read_excel(request.files['excel'])
                c = 0
                for _, row in df.iterrows():
                    base = str(row.get('base_id','')).strip()
                    ids = str(row.get('ids','')).strip()
                    title = str(row.get('title','')).strip()
                    if base and ids and title:
                        fid = f"{base}/{ids}"
                        if not Book.query.get(fid):
                            db.session.add(Book(book_id=fid, title=title, author=str(row.get('author','')), added_at=datetime.now().strftime("%Y-%m-%d")))
                            c += 1
                db.session.commit()
                log_action("/books", "IMPORT", f"Imported {c} books from Excel.")
                flash(f"Imported {c} books.", "success")
            except Exception as e: flash(str(e), "danger")
            return redirect(url_for('main.books'))

    # GET
    search_query = request.args.get('q', '').strip()
    sort_by = request.args.get('sort', 'date_desc')
    q = Book.query
    if search_query:
        q = q.filter((Book.title.ilike(f"%{search_query}%")) | (Book.book_id.ilike(f"%{search_query}%")))
    
    if sort_by == 'title_asc': q = q.order_by(Book.title.asc())
    elif sort_by == 'title_desc': q = q.order_by(Book.title.desc())
    else: q = q.order_by(Book.added_at.desc())
        
    return render_template('manage_books.html', books=q.all(), suggested_id=generate_unique_base_id(), search_query=search_query, sort_by=sort_by)

# --- EXPORT ROUTES ---
@main.route('/books/export/excel')
@login_required
def export_books_excel():
    books = Book.query.all()
    data = [{'Book ID': b.book_id, 'Title': b.title, 'Author': b.author, 'Added': b.added_at} for b in books]
    df = pd.DataFrame(data)
    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False)
    output.seek(0)
    return send_file(output, download_name="Library_Books.xlsx", as_attachment=True)

@main.route('/books/export/pdf')
@login_required
def export_books_pdf():
    books = Book.query.all()
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    elements = []
    
    styles = getSampleStyleSheet()
    elements.append(Paragraph("Library Book Catalog", styles['Title']))
    elements.append(Spacer(1, 12))
    
    data = [['ID', 'Title', 'Author']]
    for b in books:
        data.append([b.book_id, b.title, b.author])
        
    table = Table(data, colWidths=[100, 250, 150])
    table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#4e73df')),
        ('TEXTCOLOR', (0,0), (-1,0), colors.whitesmoke),
        ('ALIGN', (0,0), (-1,-1), 'LEFT'),
        ('GRID', (0,0), (-1,-1), 1, colors.black)
    ]))
    
    elements.append(table)
    doc.build(elements)
    buffer.seek(0)
    return send_file(buffer, download_name="Library_Books.pdf", as_attachment=True)

@main.route('/download_books_template')
@login_required
def download_books_template():
    data = { "base_id": ["321-54-100"], "ids": ["1-50"], "title": ["Math S1"], "author": ["REB"] }
    df = pd.DataFrame(data)
    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False)
    output.seek(0)
    return send_file(output, as_attachment=True, download_name="books_import_template.xlsx")

# --- STUDENTS / CLASSES MANAGEMENT ---
@main.route('/students', methods=['GET', 'POST'])
@login_required
def students():
    skipped_students = []
    
    # Helper to clean class names (remove spaces, uppercase)
    def clean_cls(c):
        return str(c).strip().replace(" ", "").upper()

    # 1. HANDLE ALL POST ACTIONS
    if request.method == 'POST':
        action = request.form.get('action')
        
        # --- A. IMPORT EXCEL ---
        if 'excel' in request.files:
            file = request.files['excel']
            if file.filename:
                try:
                    df = pd.read_excel(file)
                    added_count = 0
                    
                    for class_name in df.columns:
                        clean_class = clean_cls(class_name)
                        # Skip empty or unnamed columns
                        if not clean_class or "Unnamed" in clean_class: continue
                        
                        students_in_class = df[class_name].dropna().astype(str).tolist()
                        
                        for student_name in students_in_class:
                            clean_name = student_name.strip()
                            if not clean_name: continue
                            
                            # Check duplicates
                            exists = Student.query.filter_by(name=clean_name, student_class=clean_class).first()
                            if not exists:
                                db.session.add(Student(name=clean_name, student_class=clean_class))
                                added_count += 1
                            else:
                                skipped_students.append({'name': clean_name, 'class': clean_class, 'reason': 'Already exists'})
                                
                    db.session.commit()
                    
                    # LOGIC FIX:
                    # If we have skipped students, we DO NOT redirect. 
                    # We let the code "fall through" to the bottom so it renders the page WITH the modal 
                    # AND calculates the class list correctly.
                    if skipped_students:
                        flash(f"Imported {added_count} students. Some duplicates were skipped.", "warning")
                    else:
                        flash(f"Successfully imported {added_count} students.", "success")
                        return redirect(url_for('main.students'))
                        
                except Exception as e:
                    flash(f"Error processing file: {str(e)}", "danger")
                    return redirect(url_for('main.students'))

        # --- B. ADD STUDENT ---
        elif action == 'add':
            name = request.form.get('name').strip()
            s_class = clean_cls(request.form.get('student_class'))
            
            if Student.query.filter_by(name=name, student_class=s_class).first():
                flash(f"Student {name} already exists in {s_class}.", "warning")
            else:
                db.session.add(Student(name=name, student_class=s_class))
                db.session.commit()
                flash(f"Added {name} to {s_class}.", "success")
            return redirect(url_for('main.students'))

        # --- C. EDIT STUDENT ---
        elif action == 'edit':
            student = Student.query.get(request.form.get('student_id'))
            if student:
                student.name = request.form.get('name').strip()
                student.student_class = clean_cls(request.form.get('student_class'))
                db.session.commit()
                flash("Student details updated.", "success")
            return redirect(url_for('main.students'))

        # --- D. DELETE STUDENT ---
        elif action == 'delete':
            sid = request.form.get('student_id')
            student = Student.query.get(sid)
            if student:
                # STRICT CHECK: Active Loans?
                if BorrowedBook.query.filter_by(student_name=student.name, returned=False).first():
                    flash(f"Cannot delete {student.name}. They still have unreturned books.", "danger")
                else:
                    db.session.delete(student)
                    db.session.commit()
                    log_action("/students", "DELETE", f"Deleted student {student.name}")
                    flash("Student removed.", "success")
            return redirect(url_for('main.students'))

        # --- E. RENAME CLASS ---
        elif action == 'edit_class':
            old_class = request.form.get('old_class_name')
            new_class = clean_cls(request.form.get('new_class_name'))
            
            # Update Students
            students_to_move = Student.query.filter_by(student_class=old_class).all()
            for s in students_to_move:
                s.student_class = new_class
            
            # Update Loans
            loans_to_update = BorrowedBook.query.filter_by(student_class=old_class, returned=False).all()
            for l in loans_to_update:
                l.student_class = new_class
                
            db.session.commit()
            flash(f"Renamed class {old_class} to {new_class}.", "success")
            return redirect(url_for('main.students'))

        # --- F. DELETE CLASS ---
        elif action == 'delete_class':
            cls_name = request.form.get('class_name')
            # STRICT CHECK: Active Class Loans?
            if ClassBorrowing.query.filter_by(class_name=cls_name, returned=False).first():
                flash(f"Cannot delete class {cls_name}. The class has active loans.", "danger")
            # STRICT CHECK: Any student in class has loans?
            elif BorrowedBook.query.filter_by(student_class=cls_name, returned=False).first():
                flash(f"Cannot delete {cls_name}. Some students in this class still have books.", "danger")
            else:
                count = Student.query.filter_by(student_class=cls_name).delete()
                db.session.commit()
                log_action("/students", "DELETE_CLASS", f"Deleted class {cls_name} and {count} students.")
                flash(f"Deleted Class {cls_name}.", "success")
            return redirect(url_for('main.students'))

        # --- G. PROMOTE LOGIC ---
        elif action == 'promote':
            promo_name = request.form.get('promotion_name')
            all_students = Student.query.all()
            graduates_moved = 0
            promoted_count = 0
            
            # 1. Handle Individual Students
            for s in all_students:
                cls = s.student_class.upper()
                if cls.startswith('S3') or cls.startswith('S6'):
                    # Find ALL active loans for this student
                    active_loans = BorrowedBook.query.filter_by(student_name=s.name, student_class=s.student_class, returned=False).all()
                    
                    for loan in active_loans:
                        archive = GraduateBorrowing(
                            promotion_name=promo_name,
                            student_name=s.name,
                            original_class=s.student_class,
                            book_id=loan.book_id,
                            book_title=loan.book_title,
                            notes=loan.condition, # Map Condition to Notes
                            timestamp=loan.timestamp,
                            due_date=loan.due_date
                        )
                        db.session.add(archive)
                        db.session.delete(loan)
                        graduates_moved += 1
                    
                    db.session.delete(s)
                else:
                    # Logic to rename class (S1->S2 etc)
                    new_cls = cls
                    if cls.startswith('S1'): new_cls = cls.replace('S1', 'S2', 1)
                    elif cls.startswith('S2'): new_cls = cls.replace('S2', 'S3', 1)
                    elif cls.startswith('S4'): new_cls = cls.replace('S4', 'S5', 1)
                    elif cls.startswith('S5'): new_cls = cls.replace('S5', 'S6', 1)
                    
                    if new_cls != cls:
                        s.student_class = new_cls
                        # Update loans
                        loans = BorrowedBook.query.filter_by(student_name=s.name, student_class=cls, returned=False).all()
                        for l in loans: l.student_class = new_cls
                        promoted_count += 1
            
            # 2. Handle Class Loans (Archive Graduating Classes)
            active_class_loans = ClassBorrowing.query.filter_by(returned=False).all()
            for cloan in active_class_loans:
                cls = cloan.class_name.upper()
                # Check if this class is graduating
                if cls.startswith('S3') or cls.startswith('S6'):
                    archive_class = GraduateClassBorrowing(
                        promotion_name=promo_name,
                        class_name=cloan.class_name,
                        responsibles=cloan.responsibles,
                        book_title=cloan.book_title,
                        book_ids=cloan.book_ids,
                        quantity=cloan.quantity,
                        condition=cloan.condition,
                        borrow_time=cloan.borrow_time
                    )
                    db.session.add(archive_class)
                    db.session.delete(cloan) # Move to archive
                    # Note: We don't increment graduates_moved here to avoid confusion, or we could.

            db.session.commit()
            flash(f"Promotion Complete! {promoted_count} promoted. {graduates_moved} student loans archived.", "success")
            return redirect(url_for('main.students'))

    # 2. HANDLE DISPLAY (GET Logic)
    # This runs for GET requests AND for Import POST requests that had duplicates
    
    # A. Filtering & Search
    search_query = request.args.get('q', '').strip()
    sort_by = request.args.get('sort', 'class_asc') # Default sort
    
    query = Student.query
    if search_query:
        query = query.filter(
            (Student.name.ilike(f"%{search_query}%")) |
            (Student.student_class.ilike(f"%{search_query}%"))
        )
    
    # B. Sorting (Restored!)
    if sort_by == 'class_asc':
        query = query.order_by(Student.student_class.asc(), Student.name.asc())
    elif sort_by == 'class_desc':
        query = query.order_by(Student.student_class.desc(), Student.name.asc())
    elif sort_by == 'name_asc':
        query = query.order_by(Student.name.asc())
    elif sort_by == 'name_desc':
        query = query.order_by(Student.name.desc())
        
    students_list = query.all()
    
    # C. Class List Calculation (Fixed!)
    # We calculate this fresh every time so it appears immediately after import
    unique_classes = sorted(list(set([s.student_class for s in Student.query.all()])))
    class_stats = []
    for c in unique_classes:
        count = Student.query.filter_by(student_class=c).count()
        class_stats.append({'name': c, 'count': count})

    return render_template('students.html', 
                         students=students_list, 
                         classes=class_stats, 
                         search_query=search_query,
                         sort_by=sort_by,
                         skipped_students=skipped_students)

# --- EXPORT: EXCEL (Formatted by Class Column) ---
@main.route('/students/export/excel')
@login_required
def export_students_excel():
    # 1. Get all students and group them by class
    students = Student.query.all()
    data_map = {}
    
    for s in students:
        if s.student_class not in data_map:
            data_map[s.student_class] = []
        data_map[s.student_class].append(s.name)
        
    # 2. Sort Classes (optional, makes columns A-Z)
    sorted_classes = sorted(data_map.keys())
    
    # 3. Find max length to pad columns (pandas requires equal length)
    max_len = 0
    if data_map:
        max_len = max(len(v) for v in data_map.values())
        
    final_dict = {}
    for cls in sorted_classes:
        # Pad list with empty strings so all columns are same length
        students_list = data_map[cls]
        padded_list = students_list + [''] * (max_len - len(students_list))
        final_dict[cls] = padded_list
        
    # 4. Create DataFrame
    df = pd.DataFrame(final_dict)
    
    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False)
    output.seek(0)
    
    return send_file(output, download_name="students_list.xlsx", as_attachment=True)

# --- EXPORT: PDF (Grouped Tables) ---
@main.route('/students/export/pdf')
@login_required
def export_students_pdf():
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    elements = []
    styles = getSampleStyleSheet()
    
    # Title
    elements.append(Paragraph("Students List", styles['Title']))
    elements.append(Spacer(1, 20))
    
    # Get all distinct classes
    classes = db.session.query(Student.student_class).distinct().order_by(Student.student_class).all()
    classes = [c[0] for c in classes] # flatten result
    
    for class_name in classes:
        # Header for the Class
        elements.append(Paragraph(f"<b>Class: {class_name}</b>", styles['Heading2']))
        elements.append(Spacer(1, 5))
        
        # Get students for this class
        students = Student.query.filter_by(student_class=class_name).order_by(Student.name).all()
        
        if not students: continue
        
        # Table Data
        data = [['No.', 'Student Name']]
        for i, s in enumerate(students, 1):
            data.append([str(i), s.name])
            
        # Table Style
        table = Table(data, colWidths=[50, 400])
        table.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#4e73df')),
            ('TEXTCOLOR', (0,0), (-1,0), colors.whitesmoke),
            ('ALIGN', (0,0), (-1,-1), 'LEFT'),
            ('GRID', (0,0), (-1,-1), 1, colors.black),
            ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
            ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.whitesmoke, colors.white]),
        ]))
        
        elements.append(table)
        elements.append(Spacer(1, 20)) # Space between tables
        
    doc.build(elements)
    buffer.seek(0)
    return send_file(buffer, download_name="students_list.pdf", as_attachment=True)

# --- NEW: STUDENT LIVE SEARCH API ---
@main.route('/api/search_students')
@login_required
def search_students_api():
    query = request.args.get('q', '').strip()
    class_filter = request.args.get('class', '').strip() # Get class parameter
    
    if not query:
        return jsonify([])
    
    db_query = Student.query
    
    # If a class is selected, strict filter by that class
    if class_filter:
        db_query = db_query.filter(Student.student_class == class_filter)
    
    results = db_query.filter(Student.name.ilike(f"%{query}%")).limit(8).all()
    
    suggestions = [{'name': s.name, 'class': s.student_class} for s in results]
    return jsonify(suggestions)

@main.route('/download_student_template')
@login_required
def download_student_template():
    data = { "S1 A": ["MUGISHA"], "S5 MPC": ["ISHIMWE"] }
    df = pd.DataFrame(data)
    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False)
    output.seek(0)
    return send_file(output, as_attachment=True, download_name="student_import_template.xlsx")

# --- BORROW TRANSACTION ---
@main.route('/borrow', methods=['GET', 'POST'])
@login_required
def borrow():
    if request.method == 'POST':
        action = request.form.get('action')
        
        # 1. STUDENT BORROW
        if action == 'student_borrow':
            s_name = request.form.get('student_name')
            raw_ids = request.form.get('book_ids_hidden', '')
            condition = request.form.get('condition') or "Good"
            
            # VALIDATION: Check Student Exists
            student = Student.query.filter(Student.name.ilike(f"{s_name}")).first()
            if not student:
                flash(f"Error: Student '{s_name}' does not exist in the registry.", "danger")
                return redirect(url_for('main.borrow'))

            id_list = [x.strip() for x in raw_ids.split(',') if x.strip()]
            success_count = 0
            
            for b_id in id_list:
                # VALIDATION: Check Book Exists
                book = Book.query.get(b_id)
                if not book:
                    flash(f"Error: Book ID {b_id} is not in the Catalog. Cannot issue.", "danger")
                    continue
                
                # Check Availability
                if BorrowedBook.query.filter_by(book_id=b_id, returned=False).first() or \
                   TeacherBorrowedBook.query.filter_by(book_id=b_id, returned=False).first():
                    flash(f"Book {b_id} is already out!", "warning")
                    continue

                due = (datetime.now() + timedelta(days=current_app.config['DEFAULT_BORROW_DAYS'])).strftime("%Y-%m-%d")
                new_loan = BorrowedBook(
                    book_id=book.book_id,
                    book_title=book.title,
                    student_name=student.name,
                    student_class=student.student_class,
                    condition=condition,
                    timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    due_date=due
                )
                db.session.add(new_loan)
                success_count += 1
            
            db.session.commit()
            if success_count > 0:
                flash(f"Successfully issued {success_count} books.", "success")
        
        # 2. STAFF BORROW
        elif action == 'staff_borrow':
            t_name = request.form.get('staff_name')
            raw_ids = request.form.get('book_ids_hidden', '')
            notes = request.form.get('notes', '')
            condition = request.form.get('condition') or "Good"
            
            id_list = [x.strip() for x in raw_ids.split(',') if x.strip()]
            success_count = 0
            
            for b_id in id_list:
                # VALIDATION: Book must exist
                book = Book.query.get(b_id)
                if not book: 
                    flash(f"Error: Book ID {b_id} not found in Catalog.", "danger")
                    continue
                
                # Check Availability
                if BorrowedBook.query.filter_by(book_id=b_id, returned=False).first() or \
                   TeacherBorrowedBook.query.filter_by(book_id=b_id, returned=False).first():
                    flash(f"Book {b_id} is already out!", "warning")
                    continue
                    
                new_loan = TeacherBorrowedBook(
                    book_id=book.book_id,
                    book_title=book.title,
                    teacher_name=t_name,
                    notes=notes,
                    condition=condition,
                    timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                )
                db.session.add(new_loan)
                success_count += 1
                
            db.session.commit()
            if success_count > 0:
                flash(f"Issued {success_count} books to {t_name}.", "success")

        # 3. CLASS BORROW (Updated with Strict Validation)
        elif action == 'class_borrow':
            c_name = request.form.get('class_name', '').strip()
            responsibles = request.form.get('responsibles', '')
            base_id = request.form.get('base_id', '').strip()
            unique_ids = request.form.get('unique_ids', '').strip()
            notes = request.form.get('condition') # Notes
            
            # 1. Validation: Class Must Exist
            if not Student.query.filter(Student.student_class.ilike(c_name)).first():
                flash(f"Error: Class '{c_name}' not found in registry.", "danger")
                return redirect(url_for('main.borrow'))
            
            # 2. Validation: Responsibles Must Be In That Class
            r_list = [r.strip() for r in responsibles.split(',') if r.strip()]
            for r in r_list:
                if not Student.query.filter(Student.name.ilike(r), Student.student_class.ilike(c_name)).first():
                    flash(f"Error: Student '{r}' not found in class {c_name}.", "danger")
                    return redirect(url_for('main.borrow'))

            # 3. Validation: Book Availability (Overlap Check)
            # This parses the range (e.g., 100-20/1-50) to check every single book
            req_set = parse_id_string(f"{base_id}/{unique_ids}")
            conflict = False
            
            # A. Check against Active Student/Staff Loans
            for bid in req_set:
                if BorrowedBook.query.filter_by(book_id=bid, returned=False).first() or \
                   TeacherBorrowedBook.query.filter_by(book_id=bid, returned=False).first():
                    conflict = True
                    flash(f"Error: Book {bid} is already borrowed by a student or staff.", "danger")
                    break
            
            # B. Check against Other Class Loans
            if not conflict:
                for cl in ClassBorrowing.query.filter_by(returned=False).all():
                    # Check if the requested range overlaps with an existing class loan
                    if not req_set.isdisjoint(parse_id_string(cl.book_ids)): 
                        conflict = True
                        flash(f"Error: Some books in this range are already borrowed by class {cl.class_name}.", "danger")
                        break
            
            if conflict:
                return redirect(url_for('main.borrow'))

            # 4. Fetch Title and Save
            ref_book = Book.query.filter(Book.book_id.like(f"{base_id}/%")).first()
            if ref_book:
                db.session.add(ClassBorrowing(
                    class_name=c_name, 
                    responsibles=responsibles, 
                    book_title=ref_book.title, 
                    book_ids=f"{base_id}/{unique_ids}", 
                    quantity=len(req_set), 
                    condition=notes, 
                    borrow_time=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                ))
                db.session.commit()
                flash(f"Successfully issued {len(req_set)} copies to {c_name}.", "success")
            else:
                flash("Error: Base ID not found in catalog.", "danger")

        return redirect(url_for('main.borrow'))
    
    return render_template('borrow.html')

# --- TEMPLATE DOWNLOADS FOR LOANS ---
@main.route('/borrow/template/<type>')
@login_required
def download_loan_template(type):
    output = BytesIO()
    if type == 'student':
        data = {"Student Name": ["MUGISHA"], "Book ID": ["100-20/1"], "Condition": ["Good"]}
        name = "student_loan_template.xlsx"
    elif type == 'staff':
        data = {"Staff Name": ["Teacher John"], "Book ID": ["100-20/5"], "Condition": ["Good"]}
        name = "staff_loan_template.xlsx"
    elif type == 'class':
        data = {"Class": ["S3MPC"], "Responsibles": ["Alice"], "Base ID": ["100-20"], "Unique IDs": ["1-50"], "Condition": ["Good"]}
        name = "class_loan_template.xlsx"
    else:
        return redirect(url_for('main.borrow'))
        
    df = pd.DataFrame(data)
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False)
    output.seek(0)
    return send_file(output, as_attachment=True, download_name=name)

# --- AUTOCOMPLETE APIs ---
@main.route('/api/search_books')
@login_required
def search_books_api():
    query = request.args.get('q', '').strip()
    if not query: return jsonify([])
    results = Book.query.filter((Book.title.ilike(f"%{query}%")) | (Book.book_id.ilike(f"%{query}%"))).limit(8).all()
    return jsonify([{'id': b.book_id, 'title': b.title, 'author': b.author} for b in results])

@main.route('/api/search_staff')
@login_required
def search_staff_api():
    query = request.args.get('q', '').strip()
    if not query: return jsonify([])
    # Search unique names from previous teacher loans
    results = db.session.query(TeacherBorrowedBook.teacher_name).filter(TeacherBorrowedBook.teacher_name.ilike(f"%{query}%")).distinct().limit(8).all()
    return jsonify([{'name': r[0]} for r in results])

@main.route('/api/search_classes')
@login_required
def search_classes_api():
    query = request.args.get('q', '').strip()
    if not query: return jsonify([])
    # Search distinct classes from Student table
    results = db.session.query(Student.student_class).filter(Student.student_class.ilike(f"%{query}%")).distinct().limit(8).all()
    return jsonify([{'name': r[0]} for r in results])

# --- ACTIVE LOANS (4 SECTIONS) ---
@main.route('/borrowed')
@login_required
def borrowed():
    # 1. Students
    students = BorrowedBook.query.filter_by(returned=False).order_by(BorrowedBook.id.desc()).all()
    # 2. Graduates
    graduates = GraduateBorrowing.query.all()
    # 3. Staff
    staff = TeacherBorrowedBook.query.filter_by(returned=False).all()
    # 4. Classes
    classes = ClassBorrowing.query.filter_by(returned=False).all()
    
    return render_template('borrowed_list.html', 
                         students=students, 
                         graduates=graduates,
                         staff=staff,
                         classes=classes)

# --- RETURN ROUTES ---
@main.route('/return/<int:id>', methods=['POST'])
@login_required
def return_book(id):
    loan = BorrowedBook.query.get_or_404(id)
    loan.returned = True
    loan.return_date = datetime.now().strftime("%Y-%m-%d")
    db.session.commit()
    flash("Returned successfully.", "success")
    return redirect(url_for('main.borrowed'))

@main.route('/return_graduate/<int:id>', methods=['POST'])
@login_required
def return_graduate(id):
    grad_loan = GraduateBorrowing.query.get_or_404(id)
    db.session.delete(grad_loan)
    db.session.commit()
    flash("Graduate debt cleared.", "success")
    return redirect(url_for('main.borrowed'))

@main.route('/return_staff/<int:id>', methods=['POST'])
@login_required
def return_staff(id):
    loan = TeacherBorrowedBook.query.get_or_404(id)
    loan.returned = True
    db.session.commit()
    flash("Staff book returned.", "success")
    return redirect(url_for('main.borrowed'))

@main.route('/return_class/<int:id>', methods=['POST'])
@login_required
def return_class(id):
    loan = ClassBorrowing.query.get_or_404(id)
    return_type = request.form.get('return_type')
    
    if return_type == 'partial':
        # Get user input: "1, 2, 5-10"
        ids_to_return_str = request.form.get('return_ids', '')
        
        # 1. Parse the IDs currently on loan
        # Format stored: "100-20/1-50" -> We need to split Base vs Range
        if '/' not in loan.book_ids:
            flash("Error: Invalid ID format in database.", "danger")
            return redirect(url_for('main.borrowed'))
            
        base_id, current_range_str = loan.book_ids.split('/', 1)
        
        current_set = parse_id_string(current_range_str) # {1,2,3...50}
        returning_set = parse_id_string(ids_to_return_str) # {5,6,7}
        
        # 2. Calculate Difference
        # New set = Current - Returning
        new_set = current_set - returning_set
        
        if len(new_set) == len(current_set):
            flash("No matching IDs found to return.", "warning")
            return redirect(url_for('main.borrowed'))

        # 3. Update Database
        if len(new_set) == 0:
            # All returned
            loan.returned = True
            loan.return_date = datetime.now().strftime("%Y-%m-%d")
            loan.quantity = 0
            loan.book_ids = f"{base_id}/(Returned)"
            flash("All books returned.", "success")
        else:
            # Some remaining
            new_range_str = set_to_range_string(new_set)
            loan.book_ids = f"{base_id}/{new_range_str}"
            loan.quantity = len(new_set)
            flash(f"Returned {len(returning_set)} books. {loan.quantity} remaining.", "success")
            
    else:
        # Full Return
        loan.returned = True
        loan.return_date = datetime.now().strftime("%Y-%m-%d")
        flash("All class books returned.", "success")

    db.session.commit()
    return redirect(url_for('main.borrowed'))

# --- CLASS BORROWING ---
@main.route('/class_borrowing')
@login_required
def class_borrowing():
    records = ClassBorrowing.query.all()
    return render_template('class_borrowing.html', borrowings=records)

@main.route('/class_borrowing/add', methods=['POST'])
@login_required
def class_borrowing_add():
    cb = ClassBorrowing(
        class_name=request.form.get('class_name'),
        responsibles=request.form.get('responsibles'),
        book_title=request.form.get('book_title'),
        quantity=request.form.get('quantity', 1),
        borrow_time=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    )
    db.session.add(cb)
    db.session.commit()
    flash("Class borrowing added.", "success")
    return redirect(url_for('main.class_borrowing'))

# --- LOGS ---
@main.route('/logs')
@login_required
def logs():
    records = Log.query.order_by(Log.id.desc()).limit(100).all()
    return render_template('logs.html', records=records)

# --- IMPORT BORROWERS ---
@main.route('/import_borrowers')
@login_required
def import_borrowers():
    return render_template('import_borrowers.html')

# --- NOTES ---
@main.route('/notes')
@login_required
def notes():
    all_notes = Note.query.order_by(Note.id.desc()).all()
    return render_template('notes.html', notes=all_notes)

@main.route('/add_note', methods=['POST'])
@login_required
def add_note():
    content = request.form.get('note_content')
    if content:
        db.session.add(Note(content=content, timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        db.session.commit()
    return redirect(url_for('main.notes'))

# --- TEACHER BORROW ---
@main.route('/teacher_borrow', methods=['GET', 'POST'])
@login_required
def teacher_borrow():
    if request.method == 'POST':
        tb = TeacherBorrowedBook(
            book_id=request.form.get('book_id'),
            teacher_name=request.form.get('teacher_name'),
            timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        )
        db.session.add(tb)
        db.session.commit()
        flash("Teacher borrow recorded.", "success")
    return render_template('teacher_borrow.html')

# --- BACKUPS ---
@main.route('/backups')
@login_required
def backups():
    files = []
    if os.path.exists(BACKUP_DIR):
        for f in sorted(os.listdir(BACKUP_DIR)):
            if f.endswith(".json"):
                files.append(f)
    return render_template('backups.html', files=files)

@main.route('/export/borrowed/<type>/<format>')
@login_required
def export_borrowed(type, format):
    # 1. FETCH DATA
    if type == 'students':
        title = "Active Student Loans"
        data_query = BorrowedBook.query.filter_by(returned=False).order_by(BorrowedBook.student_class, BorrowedBook.student_name).all()
        # Columns for PDF: [No, Name, Class, Book, Date]
        pdf_data = [['No', 'Student Name', 'Class', 'Book Title', 'Date']]
        for i, d in enumerate(data_query, 1):
            pdf_data.append([str(i), d.student_name, d.student_class, d.book_title, d.timestamp[:10]])
        # Data for Excel
        excel_data = [{'Class': d.student_class, 'Name': d.student_name, 'Book': d.book_title, 'Book ID': d.book_id, 'Date': d.timestamp, 'Notes': d.condition} for d in data_query]
        
    elif type == 'staff':
        title = "Active Staff Loans"
        data_query = TeacherBorrowedBook.query.filter_by(returned=False).order_by(TeacherBorrowedBook.teacher_name).all()
        pdf_data = [['No', 'Staff Name', 'Book Title', 'Notes', 'Date']]
        for i, d in enumerate(data_query, 1):
            pdf_data.append([str(i), d.teacher_name, d.book_title, d.notes, d.timestamp[:10]])
        excel_data = [{'Name': d.teacher_name, 'Book': d.book_title, 'Book ID': d.book_id, 'Date': d.timestamp, 'Notes': d.notes} for d in data_query]
        
    elif type == 'graduates':
        title = "Graduate Debtors"
        data_query = GraduateBorrowing.query.order_by(GraduateBorrowing.promotion_name, GraduateBorrowing.original_class).all()
        pdf_data = [['No', 'Promotion', 'Name', 'Book Title', 'Notes']]
        for i, d in enumerate(data_query, 1):
            pdf_data.append([str(i), d.promotion_name, d.student_name, d.book_title, d.notes])
        excel_data = [{'Promotion': d.promotion_name, 'Class': d.original_class, 'Name': d.student_name, 'Book': d.book_title, 'Book ID': d.book_id, 'Notes': d.notes} for d in data_query]
        
    elif type == 'classes':
        title = "Active Class Loans"
        data_query = ClassBorrowing.query.filter_by(returned=False).order_by(ClassBorrowing.class_name).all()
        pdf_data = [['Class', 'Book Title', 'Range', 'Qty', 'Responsibles']]
        for d in data_query:
            pdf_data.append([d.class_name, d.book_title, d.book_ids, str(d.quantity), d.responsibles])
        excel_data = [{'Class': d.class_name, 'Responsibles': d.responsibles, 'Book Title': d.book_title, 'IDs Range': d.book_ids, 'Qty': d.quantity, 'Notes': d.condition} for d in data_query]

    # 2. GENERATE OUTPUT
    output = BytesIO()
    
    if format == 'pdf':
        doc = SimpleDocTemplate(output, pagesize=letter)
        elements = []
        styles = getSampleStyleSheet()
        
        # Title
        elements.append(Paragraph(f"<b>{title}</b>", styles['Title']))
        elements.append(Spacer(1, 12))
        
        # Table
        table = Table(pdf_data)
        table.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#4e73df')),
            ('TEXTCOLOR', (0,0), (-1,0), colors.whitesmoke),
            ('ALIGN', (0,0), (-1,-1), 'LEFT'),
            ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
            ('GRID', (0,0), (-1,-1), 1, colors.black),
            ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.whitesmoke, colors.white]),
        ]))
        elements.append(table)
        
        doc.build(elements)
        fname = f"{title.replace(' ', '_')}.pdf"
        mimetype = 'application/pdf'
        
    else: # Excel
        df = pd.DataFrame(excel_data)
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            df.to_excel(writer, index=False)
        fname = f"{title.replace(' ', '_')}.xlsx"
        mimetype = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'

    output.seek(0)
    return send_file(output, as_attachment=True, download_name=fname, mimetype=mimetype)
    
# --- SYSTEM CONFIG & VERSIONING ---
import subprocess
import requests
import sys
import time
from packaging import version # Standard for reliable version comparison
from .database import UpdateHistory, db # Ensure UpdateHistory is in database.py

# ON FIRST RUN: This is 1.0.0. 
# REALITY: When you update, the new routes.py you upload to GitHub 
# MUST have the new number (e.g., VERSION = "1.1.0") here.
VERSION = "1.0.0" 

@main.route('/settings', methods=['GET', 'POST'])
@login_required
def settings():
    config = load_config()
    if request.method == 'POST':
        # Handles your existing config saving logic
        config['max_books_per_student'] = int(request.form.get('max_books', 3))
        save_config(config)
        flash("System settings successfully updated!", "success")
        log_action("/settings", "UPDATE_CONFIG", "Modified library loan limits")
        return redirect(url_for('main.settings'))

    # PASSING DATA: We send the current version to the UI here
    return render_template('settings.html', 
                           config=config, 
                           current_version=VERSION)

@main.route('/system/update/check', methods=['POST'])
@login_required
def check_update():
    json_url = request.form.get('json_url')
    # CACHE BUSTER: Prevents GitHub from serving an old version of the JSON
    clean_url = f"{json_url}?t={int(time.time())}"
    
    try:
        response = requests.get(clean_url, timeout=30)
        response.raise_for_status()
        data = response.json()
        
        remote_v = data.get('version')
        is_critical = data.get('is_critical', False)
        
        # MATH COMPARISON: Handles 1.10.0 > 1.2.0 correctly
        if version.parse(remote_v) > version.parse(VERSION):
            return jsonify({
                "update_available": True,
                "new_version": remote_v,
                "is_critical": is_critical,
                "changelog": data.get('changelog', []),
                "download_url": data.get('download_url'),
                "message": "🚨 CRITICAL SECURITY PATCH AVAILABLE" if is_critical else f"🚀 New Version v{remote_v} is ready for install!"
            })
        
        return jsonify({
            "update_available": False, 
            "message": "✅ You are running the latest stable version of Edraze."
        })
        
    except Exception as e:
        return jsonify({"error": f"Unable to reach update server: {str(e)}"}), 400

@main.route('/system/update/run', methods=['POST'])
@login_required
def run_update():
    data = request.get_json()
    download_url = data.get('download_url')
    new_v = data.get('new_version')
    changelog = data.get('changelog', [])
    
    # 1. PERMANENT LOGGING: Save history before the app shuts down
    history = UpdateHistory(
        version=new_v,
        changelog="\n".join(changelog) if isinstance(changelog, list) else changelog,
        status="Success", # Assumed success; sidecar handles actual rollback
        timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    )
    db.session.add(history)
    db.session.commit()
    
    # 2. TRIGGER EXTERNAL UPDATER
    app_root = os.path.abspath(os.getcwd())
    # This script kills the Flask process, swaps files, and restarts the server
    subprocess.Popen([sys.executable, "updater.py", download_url, app_root, BACKUP_DIR])
    
    log_action("/system/update/run", "EXECUTE_UPDATE", f"Migrating to v{new_v}")
    return jsonify({"message": "Update process started. The application will restart in 30 seconds."})

@main.route('/system/update/history')
@login_required
def get_history():
    # Fetch all logs, newest first, to populate the "Pretty Div"
    history = UpdateHistory.query.order_by(UpdateHistory.id.desc()).all()
    return jsonify([{
        'version': h.version,
        'changelog': h.changelog,
        'status': h.status,
        'timestamp': h.timestamp
    } for h in history])
    