"""
TCP LAN Sync Server - Mother PC
Replaces Bluetooth. Works over Wi-Fi or Ethernet (same switch = same subnet).
Auto-announces presence via mDNS so Child PCs find the Mother automatically.
"""

import socket
import threading
import json
import time
import random
import logging
from datetime import datetime

# ─── CONFIG ───────────────────────────────────────────────────────────────────
TCP_PORT       = 9000
SERVICE_NAME   = "LibrarySyncMother"
BUFFER_SIZE    = 65536
TIMEOUT        = 30.0   # seconds before we kill a dead connection
MAX_CLIENTS    = 5      # max simultaneous child connections

logger = logging.getLogger("tcp_sync")

# ─── SHARED STATUS (same shape as old bt_status so routes need minimal changes) ─
sync_status = {
    "state":       "idle",   # idle / waiting / authenticating / syncing / done / error
    "otp":         None,
    "last_result": None,
    "server_ip":   None,
    "clients":     []        # list of connected child labels
}

_server_thread  = None
_mDNS_thread    = None
_server_socket  = None
_status_lock    = threading.Lock()

# ─── OTP ──────────────────────────────────────────────────────────────────────
def generate_otp():
    return str(random.randint(100000, 999999))

# ─── NETWORK HELPERS ──────────────────────────────────────────────────────────
def get_local_ip():
    """Returns this machine's LAN IP (not 127.0.0.1)."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        try:
            fallback_ip = socket.gethostbyname(socket.gethostname())
            return fallback_ip or "0.0.0.0"
        except Exception:
            return "0.0.0.0"

def recv_all(sock):
    """Read until <END> marker. Handles large payloads."""
    data = b""
    try:
        while True:
            chunk = sock.recv(BUFFER_SIZE)
            if not chunk:
                break
            data += chunk
            if b"<END>" in data:
                break
    except socket.timeout:
        pass
    if not data:
        return None
    return data.replace(b"<END>", b"").decode("utf-8")

def send_json(sock, payload):
    message = json.dumps(payload).encode("utf-8") + b"<END>"
    total = 0
    while total < len(message):
        sent = sock.send(message[total:])
        if sent == 0:
            raise RuntimeError("Socket broken during send")
        total += sent

# ─── mDNS ANNOUNCER (pure UDP broadcast — no zeroconf library needed) ─────────
def _announce_loop():
    """
    Broadcasts a simple UDP beacon every 3 seconds so Child PCs can find
    Mother without anyone typing an IP address.
    """
    BROADCAST_PORT = 9001
    beacon = json.dumps({
        "service": SERVICE_NAME,
        "ip":      sync_status["server_ip"],
        "port":    TCP_PORT
    }).encode()

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    sock.settimeout(1)

    while sync_status["state"] != "idle":
        try:
            sock.sendto(beacon, ("<broadcast>", BROADCAST_PORT))
        except Exception:
            pass
        time.sleep(3)
    sock.close()
    logger.info("[TCP SERVER] mDNS announcer stopped.")

# ─── CLIENT HANDLER ───────────────────────────────────────────────────────────
def _handle_client(conn, addr, current_otp, flask_app):
    """Runs in its own thread for each connected Child PC."""
    child_label = f"{addr[0]}:{addr[1]}"
    logger.info(f"[TCP SERVER] Connection from {child_label}")

    with _status_lock:
        sync_status["state"] = "authenticating"
        sync_status["clients"].append(child_label)

    try:
        conn.settimeout(TIMEOUT)

        # ── 1. RECEIVE payload ─────────────────────────────────────────────
        raw = recv_all(conn)
        if not raw:
            send_json(conn, {"status": "error", "message": "Empty payload."})
            return

        try:
            request = json.loads(raw)
        except json.JSONDecodeError:
            send_json(conn, {"status": "error", "message": "Malformed JSON."})
            return

        # ── 2. AUTHENTICATE via OTP ────────────────────────────────────────
        client_otp = str(request.get("otp", ""))
        if client_otp != current_otp:
            send_json(conn, {"status": "error", "message": "Invalid OTP. Sync rejected."})
            logger.warning(f"[TCP SERVER] OTP mismatch from {child_label}")
            return

        # ── 3. PROCESS changes ────────────────────────────────────────────
        with _status_lock:
            sync_status["state"] = "syncing"

        device_id    = request.get("device_id", child_label)
        device_label = request.get("device_label", "Child PC")   # e.g. "Assistant Librarian"
        changes      = request.get("changes", [])

        # Stamp each change with who performed it
        for ch in changes:
            if "performed_by" not in ch:
                ch["performed_by"] = device_label
            ch["source_device"] = device_id

        # Import here to avoid circular import; flask_app gives us the context
        with flask_app.app_context():
            from sync_engine import process_changes
            results = process_changes(changes, device_id, device_label)

        # ── 4. RESPOND ────────────────────────────────────────────────────
        send_json(conn, {"status": "ok", "results": results})

        with _status_lock:
            sync_status["state"]       = "done"
            sync_status["last_result"] = {
                "device":    device_label,
                "ip":        addr[0],
                "changes":   len(changes),
                "results":   results,
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
            sync_status["otp"] = None   # Void OTP immediately after use

        logger.info(f"[TCP SERVER] Sync complete from {device_label} ({addr[0]}): {len(changes)} changes")

    except Exception as e:
        logger.error(f"[TCP SERVER] Error handling {child_label}: {e}")
        with _status_lock:
            sync_status["state"]       = "error"
            sync_status["last_result"] = str(e)
        try:
            send_json(conn, {"status": "error", "message": str(e)})
        except Exception:
            pass
    finally:
        conn.close()
        with _status_lock:
            if child_label in sync_status["clients"]:
                sync_status["clients"].remove(child_label)

# ─── SERVER MAIN LOOP ─────────────────────────────────────────────────────────
def _server_loop(flask_app):
    global _server_socket

    local_ip = get_local_ip()
    with _status_lock:
        sync_status["server_ip"] = local_ip

    try:
        _server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        _server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        _server_socket.bind(("0.0.0.0", TCP_PORT))
        _server_socket.listen(MAX_CLIENTS)
        _server_socket.settimeout(1.0)   # allows clean shutdown

        logger.info(f"[TCP SERVER] Listening on {local_ip}:{TCP_PORT}")

        with _status_lock:
            sync_status["state"] = "waiting"

        # Start mDNS announcer
        global _mDNS_thread
        _mDNS_thread = threading.Thread(target=_announce_loop, daemon=True)
        _mDNS_thread.start()

        current_otp = generate_otp()
        with _status_lock:
            sync_status["otp"] = current_otp

        while True:
            try:
                conn, addr = _server_socket.accept()
            except socket.timeout:
                # Check if we should stop
                if sync_status["state"] == "idle":
                    break
                continue

            t = threading.Thread(
                target=_handle_client,
                args=(conn, addr, current_otp, flask_app),
                daemon=True
            )
            t.start()

            # Regenerate OTP after each successful use (done in handler)
            # For a new session, generate fresh OTP
            current_otp = generate_otp()
            with _status_lock:
                sync_status["otp"] = current_otp

    except Exception as e:
        logger.error(f"[TCP SERVER] Fatal: {e}")
        with _status_lock:
            sync_status["state"]       = "error"
            sync_status["last_result"] = str(e)
    finally:
        if _server_socket:
            try:
                _server_socket.close()
            except Exception:
                pass

# ─── PUBLIC API (mirrors bt_manager interface) ─────────────────────────────────
def start_tcp_server(flask_app):
    """Start the TCP sync server in a background thread."""
    global _server_thread

    with _status_lock:
        if sync_status["state"] in ("waiting", "authenticating", "syncing"):
            logger.warning("[TCP SERVER] Already running, ignoring start request.")
            return

    _server_thread = threading.Thread(
        target=_server_loop,
        args=(flask_app,),
        daemon=True
    )
    _server_thread.start()

def stop_tcp_server():
    """Gracefully stop the server."""
    global _server_socket
    with _status_lock:
        sync_status["state"] = "idle"
        sync_status["otp"]   = None
    if _server_socket:
        try:
            _server_socket.close()
        except Exception:
            pass

def get_status():
    with _status_lock:
        return dict(sync_status)

def reset_status():
    with _status_lock:
        sync_status["state"]       = "idle"
        sync_status["otp"]         = None
        sync_status["last_result"] = None
        sync_status["clients"]     = []
