import os
import socket
import sys

try:
    from dotenv import load_dotenv
except ImportError:  # pragma: no cover - optional in packaged builds
    load_dotenv = None

if load_dotenv:
    load_dotenv()

try:
    from supabase import create_client
except ImportError:  # pragma: no cover - optional in local dev
    create_client = None

try:
    from app import create_app
    from app.utils import load_config
except ImportError as exc:
    print(f"Import error: {exc}", file=sys.stderr)
    sys.exit(1)


def build_supabase_client(url, key):
    if not create_client or not url or not key:
        return None
    try:
        return create_client(url, key)
    except Exception as exc:
        print(f"Supabase client initialization failed: {exc}", file=sys.stderr)
        return None


def discover_local_ip():
    try:
        probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        probe.connect(("8.8.8.8", 80))
        ip_address = probe.getsockname()[0]
        probe.close()
        return ip_address
    except Exception:
        try:
            return socket.gethostbyname(socket.gethostname())
        except Exception:
            return "0.0.0.0"


if __name__ == "__main__":
    try:
        app = create_app()
        config = load_config()

        supabase_url = os.getenv("SUPABASE_URL") or app.config.get("SUPABASE_URL", "")
        supabase_service_key = (
            os.getenv("SUPABASE_SERVICE_ROLE_KEY")
            or os.getenv("SUPABASE_SERVICE_KEY")
            or app.config.get("SUPABASE_KEY", "")
        )
        supabase_client = build_supabase_client(supabase_url, supabase_service_key)

        if supabase_client:
            with app.app_context():
                sync_service = app.extensions.get("sync_service")
                if sync_service:
                    sync_service.supabase = supabase_client

        role = config.get("role")
        if role in ("major", "minor"):
            import peer_sync

            peer_sync.start(
                role,
                app,
                sync_interval=int(config.get("sync_interval", 5) or 5),
            )

        host = "0.0.0.0"
        port = 5000
        local_ip = discover_local_ip()

        print(f"Library System running on http://{host}:{port}")
        print(f"Accessible on this network at http://{local_ip}:{port}")

        app.run(
            host=host,
            port=port,
            debug=False,
            use_reloader=False,
            threaded=True,
        )
    except Exception as exc:
        print(f"Fatal error: {exc}", file=sys.stderr)
        sys.exit(1)
