from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from datetime import datetime

db = SQLAlchemy()

# 1. Admin
class Admin(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)

# 2. Students
class Student(db.Model):
    __tablename__ = 'students'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    student_class = db.Column("class", db.String(20)) 
    combination = db.Column(db.String(50))

# 3. Books (Catalog)
class Book(db.Model):
    __tablename__ = 'bookstable'
    book_id = db.Column(db.String(50), primary_key=True)
    title = db.Column(db.String(200))
    author = db.Column(db.String(100))
    added_at = db.Column(db.String(50)) 

# 4. Borrowed Books (Transactions)
class BorrowedBook(db.Model):
    __tablename__ = 'borrowed_books'
    id = db.Column(db.Integer, primary_key=True)
    book_id = db.Column(db.String(50))
    book_title = db.Column(db.String(200))
    student_name = db.Column(db.String(100))
    student_class = db.Column(db.String(20))
    notes = db.Column(db.Text)
    condition = db.Column(db.String(50)) 
    timestamp = db.Column(db.String(50))
    due_date = db.Column(db.String(20))
    return_date = db.Column(db.String(20))
    returned = db.Column(db.Boolean, default=False)

# 5. Logs 
class Log(db.Model):
    __tablename__ = 'logs'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80))
    route = db.Column(db.String(50))   
    method = db.Column(db.String(10))  
    details = db.Column(db.String(300))
    timestamp = db.Column(db.String(50))

# 6. Class Borrowing
class ClassBorrowing(db.Model):
    __tablename__ = 'class_borrowing'
    id = db.Column(db.Integer, primary_key=True)
    class_name = db.Column(db.String(20))
    responsibles = db.Column(db.String(200))
    book_title = db.Column(db.String(200))
    book_ids = db.Column(db.String(200)) 
    quantity = db.Column(db.Integer, default=1)
    condition = db.Column(db.String(50)) # Acts as Notes
    borrow_time = db.Column(db.String(50))
    return_date = db.Column(db.String(20))
    returned = db.Column(db.Boolean, default=False)

# 7. Graduates Archive (Students)
class GraduateBorrowing(db.Model):
    __tablename__ = 'graduates_borrowed_books'
    id = db.Column(db.Integer, primary_key=True)
    promotion_name = db.Column(db.String(50))
    student_name = db.Column(db.String(100))
    original_class = db.Column(db.String(20))
    book_id = db.Column(db.String(50))
    book_title = db.Column(db.String(200))
    notes = db.Column(db.Text) # NEW: Added Notes
    timestamp = db.Column(db.String(50))
    due_date = db.Column(db.String(20))
    contact = db.Column(db.String(50), nullable=True)

# 8. NEW: Graduates Archive (Classes)
class GraduateClassBorrowing(db.Model):
    __tablename__ = 'graduates_class_borrowing'
    id = db.Column(db.Integer, primary_key=True)
    promotion_name = db.Column(db.String(50))
    class_name = db.Column(db.String(20))
    responsibles = db.Column(db.String(200))
    book_title = db.Column(db.String(200))
    book_ids = db.Column(db.String(200)) 
    quantity = db.Column(db.Integer)
    condition = db.Column(db.String(50))
    borrow_time = db.Column(db.String(50))

# 9. Teacher Borrowing
class TeacherBorrowedBook(db.Model):
    __tablename__ = 'teacher_borrowed_books'
    id = db.Column(db.Integer, primary_key=True)
    book_id = db.Column(db.String(50))
    book_title = db.Column(db.String(200))
    teacher_name = db.Column(db.String(100))
    notes = db.Column(db.Text)
    condition = db.Column(db.String(50))
    timestamp = db.Column(db.String(50))
    returned = db.Column(db.Boolean, default=False)

# 10. Notes
class Note(db.Model):
    __tablename__ = 'notes'
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.Text)
    timestamp = db.Column(db.String(50))
    
class UpdateHistory(db.Model):
    __tablename__ = 'update_history'
    id = db.Column(db.Integer, primary_key=True)
    version = db.Column(db.String(20))
    changelog = db.Column(db.Text) # Stores the list of changes
    status = db.Column(db.String(20)) # 'Success', 'Failed', or 'Rolled Back'
    timestamp = db.Column(db.String(50))