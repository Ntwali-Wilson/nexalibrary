from flask import Blueprint, render_template, redirect, url_for, flash, request, session
from flask_login import login_user, logout_user, login_required, current_user
from .database import db, Admin, Log
from .utils import hash_pw, load_config, save_config
from datetime import datetime

auth = Blueprint('auth', __name__)

@auth.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))
        
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        # Check against DB
        admin = Admin.query.filter_by(username=username).first()
        
        if admin and admin.password == hash_pw(password):
            login_user(admin)
            session['admin'] = username # Keep for legacy compatibility
            return redirect(url_for('main.dashboard'))
        else:
            flash('Invalid username or password!', 'danger')
            
    return render_template('login.html')

@auth.route('/logout')
@login_required
def logout():
    logout_user()
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('auth.login'))

@auth.route('/setup', methods=['GET', 'POST'])
def setup():
    # Only allow if no admin exists or if logged in
    if Admin.query.first() and not current_user.is_authenticated:
        return redirect(url_for('auth.login'))
        
    if request.method == 'POST':
        user = request.form.get("username")
        pw = request.form.get("password")
        confirm_pw = request.form.get("confirm_password")
        
        if pw != confirm_pw:
            flash("Passwords do not match!", "danger")
            return render_template("setup.html")
            
        hashed = hash_pw(pw)
        
        admin = Admin.query.first()
        if admin:
            admin.username = user
            admin.password = hashed
        else:
            new_admin = Admin(id=1, username=user, password=hashed)
            db.session.add(new_admin)
            
        db.session.commit()
        
        # Update config.json too
        config = load_config()
        config['admin_username'] = user
        config['admin_password'] = hashed
        save_config(config)
        
        flash("Admin credentials updated.", "success")
        return redirect(url_for('auth.login'))
        
    return render_template('setup.html')