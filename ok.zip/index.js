const { app, BrowserWindow } = require("electron");
const { spawn } = require("child_process");
const path = require("path");
const http = require("http");

let flaskProcess;
let mainWindow;

// Helper to find the correct path for the Python executable
function getPythonPath() {
  if (app.isPackaged) {
    // Path when running from the installed .exe
    return path.join(process.resourcesPath, "resources", "python", "run.exe");
  }
  // Path when you are testing on your computer
  return path.join(__dirname, "resources", "python", "run.exe");
}

function waitForFlask(url, callback) {
  const check = () => {
    http
      .get(url, () => callback())
      .on("error", () => setTimeout(check, 500));
  };
  check();
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1100,
    height: 750,
    // Use the logo from your 'build' or root folder
    icon: path.join(__dirname, "logo.ico") 
  });

  mainWindow.setMenu(null);
  mainWindow.loadURL("http://127.0.0.1:5000/auth/login");
}

app.whenReady().then(() => {
  const pyPath = getPythonPath();

  // Launch the bundled run.exe instead of calling 'python'
  flaskProcess = spawn(pyPath, [], {
    windowsHide: true // This prevents a black cmd window from popping up
  });

  flaskProcess.stdout.on("data", d => console.log(d.toString()));
  flaskProcess.stderr.on("data", d => console.error(d.toString()));

  waitForFlask("http://127.0.0.1:5000", createWindow);
});

// IMPORTANT: Ensure the Python process is killed when the app closes
app.on("window-all-closed", () => {
  if (flaskProcess) {
    flaskProcess.kill();
  }
  if (process.platform !== "darwin") {
    app.quit();
  }
});