import json
from datetime import UTC, datetime

from flask_login import UserMixin
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()


def utc_now():
    return datetime.now(UTC).replace(tzinfo=None)


class SyncTrackedMixin:
    updated_at = db.Column(db.DateTime, default=utc_now, onupdate=utc_now, nullable=False)
    deleted = db.Column(db.Boolean, default=False, nullable=False)
    sync_status = db.Column(db.String(20), default='pending', nullable=False)
    school_id = db.Column(db.Integer, db.ForeignKey('schools.id'), nullable=True, index=True)


class School(db.Model):
    __tablename__ = 'schools'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    slug = db.Column(db.String(120), unique=True, nullable=False)
    contact_email = db.Column(db.String(120), nullable=True)
    contact_phone = db.Column(db.String(50), nullable=True)
    status = db.Column(db.String(20), default='active', nullable=False)
    created_at = db.Column(db.DateTime, default=utc_now, nullable=False)
    updated_at = db.Column(db.DateTime, default=utc_now, onupdate=utc_now, nullable=False)
    deleted = db.Column(db.Boolean, default=False, nullable=False)


# 1. Admin (acts as librarian in the current app)
class Admin(UserMixin, SyncTrackedMixin, db.Model):
    __tablename__ = 'admin'

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(20), default='admin', nullable=False)

    # Recovery Emails
    email1 = db.Column(db.String(120), nullable=True)
    email2 = db.Column(db.String(120), nullable=True)
    email3 = db.Column(db.String(120), nullable=True)

    profile_image = db.Column(db.String(120), default='default_profile.png')
    recovery_codes = db.Column(db.Text, nullable=True)

    # Security Questions
    question1 = db.Column(db.String(200), nullable=True)
    answer1 = db.Column(db.String(200), nullable=True)
    question2 = db.Column(db.String(200), nullable=True)
    answer2 = db.Column(db.String(200), nullable=True)
    question3 = db.Column(db.String(200), nullable=True)
    answer3 = db.Column(db.String(200), nullable=True)


# 2. Students (members)
class Student(SyncTrackedMixin, db.Model):
    __tablename__ = 'students'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    student_class = db.Column("class", db.String(20))
    combination = db.Column(db.String(50))


# 3. Books
class Book(SyncTrackedMixin, db.Model):
    __tablename__ = 'bookstable'

    book_id = db.Column(db.String(50), primary_key=True)
    title = db.Column(db.String(200))
    author = db.Column(db.String(100))
    category = db.Column(db.String(100), default="Uncategorized")
    added_at = db.Column(db.String(50))


# 4. Borrowed Books (checkouts)
class BorrowedBook(SyncTrackedMixin, db.Model):
    __tablename__ = 'borrowed_books'

    id = db.Column(db.Integer, primary_key=True)
    book_id = db.Column(db.String(50))
    book_title = db.Column(db.String(200))
    student_name = db.Column(db.String(100))
    student_class = db.Column(db.String(20))
    notes = db.Column(db.Text)
    condition = db.Column(db.String(50))
    timestamp = db.Column(db.String(50))
    due_date = db.Column(db.String(20))
    return_date = db.Column(db.String(20))
    returned = db.Column(db.Boolean, default=False)
    performed_by = db.Column(db.String(100), nullable=True)


# 5. Logs
class Log(SyncTrackedMixin, db.Model):
    __tablename__ = 'logs'

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80))
    route = db.Column(db.String(255))
    method = db.Column(db.String(20))
    status_code = db.Column(db.Integer, default=200)
    details = db.Column(db.String(300))
    timestamp = db.Column(db.String(50))
    created_at = db.Column(db.DateTime, default=utc_now, nullable=False)


# 6. Class Borrowing
class ClassBorrowing(SyncTrackedMixin, db.Model):
    __tablename__ = 'class_borrowing'

    id = db.Column(db.Integer, primary_key=True)
    class_name = db.Column(db.String(20))
    responsibles = db.Column(db.String(200))
    book_title = db.Column(db.String(200))
    book_ids = db.Column(db.String(200))
    quantity = db.Column(db.Integer, default=1)
    condition = db.Column(db.String(50))
    borrow_time = db.Column(db.String(50))
    return_date = db.Column(db.String(20))
    returned = db.Column(db.Boolean, default=False)


# 7. Graduates Archive (Students)
class GraduateBorrowing(SyncTrackedMixin, db.Model):
    __tablename__ = 'graduates_borrowed_books'

    id = db.Column(db.Integer, primary_key=True)
    promotion_name = db.Column(db.String(50))
    student_name = db.Column(db.String(100))
    original_class = db.Column(db.String(20))
    book_id = db.Column(db.String(50))
    book_title = db.Column(db.String(200))
    notes = db.Column(db.Text)
    timestamp = db.Column(db.String(50))
    due_date = db.Column(db.String(20))
    contact = db.Column(db.String(50), nullable=True)


# 8. Graduates Archive (Classes)
class GraduateClassBorrowing(SyncTrackedMixin, db.Model):
    __tablename__ = 'graduates_class_borrowing'

    id = db.Column(db.Integer, primary_key=True)
    promotion_name = db.Column(db.String(50))
    class_name = db.Column(db.String(20))
    responsibles = db.Column(db.String(200))
    book_title = db.Column(db.String(200))
    book_ids = db.Column(db.String(200))
    quantity = db.Column(db.Integer)
    condition = db.Column(db.String(50))
    borrow_time = db.Column(db.String(50))


# 9. Teacher Borrowing
class TeacherBorrowedBook(SyncTrackedMixin, db.Model):
    __tablename__ = 'teacher_borrowed_books'

    id = db.Column(db.Integer, primary_key=True)
    book_id = db.Column(db.String(50))
    book_title = db.Column(db.String(200))
    teacher_name = db.Column(db.String(100))
    notes = db.Column(db.Text)
    condition = db.Column(db.String(50))
    timestamp = db.Column(db.String(50))
    returned = db.Column(db.Boolean, default=False)


# 10. Notes
class Note(SyncTrackedMixin, db.Model):
    __tablename__ = 'notes'

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(255), nullable=True)
    content = db.Column(db.Text)
    timestamp = db.Column(db.String(50))


# 11. Update History
class UpdateHistory(SyncTrackedMixin, db.Model):
    __tablename__ = 'update_history'

    id = db.Column(db.Integer, primary_key=True)
    version = db.Column(db.String(20))
    changelog = db.Column(db.Text)
    status = db.Column(db.String(20))
    timestamp = db.Column(db.String(50))


# 12. Book Issues (Returned books with damage/repair cost etc.)
class BookIssue(SyncTrackedMixin, db.Model):
    __tablename__ = 'book_issues'

    id = db.Column(db.Integer, primary_key=True)
    loan_id = db.Column(db.Integer, nullable=False)
    loan_type = db.Column(db.String(50))  # 'student' | 'staff' | 'class'
    issue_description = db.Column(db.Text, nullable=False)
    repair_cost = db.Column(db.Float, default=0.0)
    status = db.Column(db.String(20), default="Pending")  # Pending | Resolved
    created_at = db.Column(db.String(50), default=lambda: datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

    def __repr__(self):
        return f'<Issue {self.id}>'


class PeerSyncLog(db.Model):
    __tablename__ = 'sync_logs'

    id = db.Column(db.Integer, primary_key=True)
    change_id = db.Column(db.String(100), unique=True)
    device_id = db.Column(db.String(50))
    device_label = db.Column(db.String(100), nullable=True)
    performed_by = db.Column(db.String(100), nullable=True)
    action = db.Column(db.String(50))
    status = db.Column(db.String(20))
    error = db.Column(db.String(300))
    timestamp = db.Column(db.String(50))


class PeerSyncQueue(db.Model):
    __tablename__ = 'peer_sync_queue'

    id = db.Column(db.Integer, primary_key=True)
    change_id = db.Column(db.String(100), unique=True, nullable=False)
    action = db.Column(db.String(20), nullable=False)
    table_name = db.Column(db.String(50), nullable=False)
    record_id = db.Column(db.String(100))
    payload = db.Column(db.Text)
    performed_by = db.Column(db.String(100))
    timestamp = db.Column(db.String(50))
    delivered = db.Column(db.Boolean, default=False)


class PeerSession(db.Model):
    __tablename__ = 'peer_sessions'

    id = db.Column(db.Integer, primary_key=True)
    device_id = db.Column(db.String(100), unique=True, nullable=False)
    token = db.Column(db.String(100))
    label = db.Column(db.String(100))
    trusted = db.Column(db.Boolean, default=True)
    last_seen = db.Column(db.String(50))


SyncLog = PeerSyncLog


class SyncMetadata(db.Model):
    __tablename__ = 'sync_metadata'

    id = db.Column(db.Integer, primary_key=True)
    device_id = db.Column(db.String(100), unique=True, nullable=False)
    school_id = db.Column(db.Integer, db.ForeignKey('schools.id'), nullable=False, index=True)
    last_upload_at = db.Column(db.DateTime, nullable=True)
    last_download_at = db.Column(db.DateTime, nullable=True)
    last_synced_at = db.Column(db.DateTime, nullable=True)
    last_error = db.Column(db.Text, nullable=True)
    pending_operations = db.Column(db.Integer, default=0, nullable=False)
    updated_at = db.Column(db.DateTime, default=utc_now, onupdate=utc_now, nullable=False)


class SyncQueue(db.Model):
    __tablename__ = 'sync_queue'

    id = db.Column(db.Integer, primary_key=True)
    operation_id = db.Column(db.String(36), unique=True, nullable=False)
    school_id = db.Column(db.Integer, db.ForeignKey('schools.id'), nullable=False, index=True)
    device_id = db.Column(db.String(100), nullable=False, index=True)
    entity_type = db.Column(db.String(50), nullable=False)
    entity_id = db.Column(db.String(100), nullable=False)
    operation = db.Column(db.String(20), nullable=False)
    status = db.Column(db.String(20), default='pending', nullable=False)
    payload = db.Column(db.Text, nullable=False, default='{}')
    record_updated_at = db.Column(db.DateTime, nullable=False, default=utc_now)
    attempt_count = db.Column(db.Integer, default=0, nullable=False)
    next_retry_at = db.Column(db.DateTime, nullable=True)
    last_error = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=utc_now, nullable=False)
    processed_at = db.Column(db.DateTime, nullable=True)
    updated_at = db.Column(db.DateTime, default=utc_now, onupdate=utc_now, nullable=False)

    def set_payload(self, value):
        self.payload = json.dumps(value or {}, default=str)

    def get_payload(self):
        try:
            return json.loads(self.payload or '{}')
        except json.JSONDecodeError:
            return {}


class SyncConflict(db.Model):
    __tablename__ = 'sync_conflicts'

    id = db.Column(db.Integer, primary_key=True)
    school_id = db.Column(db.Integer, db.ForeignKey('schools.id'), nullable=False, index=True)
    entity_type = db.Column(db.String(50), nullable=False)
    entity_id = db.Column(db.String(100), nullable=False)
    local_payload = db.Column(db.Text, nullable=False)
    remote_payload = db.Column(db.Text, nullable=False)
    resolved_payload = db.Column(db.Text, nullable=True)
    local_updated_at = db.Column(db.DateTime, nullable=True)
    remote_updated_at = db.Column(db.DateTime, nullable=True)
    resolution = db.Column(db.String(20), default='pending', nullable=False)
    created_at = db.Column(db.DateTime, default=utc_now, nullable=False)
    resolved_at = db.Column(db.DateTime, nullable=True)
    updated_at = db.Column(db.DateTime, default=utc_now, onupdate=utc_now, nullable=False)

    def set_versions(self, local_payload, remote_payload, resolved_payload=None):
        self.local_payload = json.dumps(local_payload or {}, default=str)
        self.remote_payload = json.dumps(remote_payload or {}, default=str)
        self.resolved_payload = json.dumps(resolved_payload, default=str) if resolved_payload is not None else None

    def get_local_payload(self):
        try:
            return json.loads(self.local_payload or '{}')
        except json.JSONDecodeError:
            return {}

    def get_remote_payload(self):
        try:
            return json.loads(self.remote_payload or '{}')
        except json.JSONDecodeError:
            return {}

    def get_resolved_payload(self):
        if not self.resolved_payload:
            return None
        try:
            return json.loads(self.resolved_payload)
        except json.JSONDecodeError:
            return None
