import json
import uuid
from datetime import UTC, datetime, timedelta

from flask import current_app

from .database import (
    Admin,
    Book,
    BorrowedBook,
    ClassBorrowing,
    Log,
    School,
    Student,
    SyncConflict,
    SyncMetadata,
    SyncQueue,
    TeacherBorrowedBook,
    db,
)
from .utils import load_config

# ── Supabase import (optional dependency) ──────────────────────────────────
try:
    from supabase import create_client, Client
except ImportError:  # pragma: no cover - optional in local dev
    create_client = None
    Client = None
# ───────────────────────────────────────────────────────────────────────────


def utc_now():
    return datetime.now(UTC).replace(tzinfo=None)


class SyncService:
    DEFAULT_REMOTE_SCHEMA = "public"

    ENTITY_CONFIG = {
        "books": {
            "model": Book,
            "table": "bookstable",
            "pk": "book_id",
            "on_conflict": "school_id,book_id",
            "exclude_columns": ["added_at"],
        },
        "members": {
            "model": Student,
            "table": "students",
            "pk": "id",
            "on_conflict": "school_id,id",
            "exclude_columns": ["combination"],
        },
        "checkouts": {
            "model": BorrowedBook,
            "table": "borrowed_books",
            "pk": "id",
            "on_conflict": "school_id,id",
            "exclude_columns": ["performed_by"],
        },
        "staff_checkouts": {
            "model": TeacherBorrowedBook,
            "table": "teacher_borrowed_books",
            "pk": "id",
            "on_conflict": "school_id,id",
        },
        "class_checkouts": {
            "model": ClassBorrowing,
            "table": "class_borrowing",
            "pk": "id",
            "on_conflict": "school_id,id",
        },
        "librarians": {
            "model": Admin,
            "table": "admin",
            "pk": "id",
            "on_conflict": "school_id,id",
            "exclude_columns": [
                "email1",
                "email2",
                "email3",
                "profile_image",
                "recovery_codes",
                "question1",
                "answer1",
                "question2",
                "answer2",
                "question3",
                "answer3",
            ],
        },
        "logs": {
            "model": Log,
            "table": "logs",
            "schema": "public",
            "pk": "id",
            "on_conflict": "id",
            "remote_school_column": None,
            "supports_sync_status": False,
            "download_enabled": False,
            "remote_columns": [
                "id",
                "timestamp",
                "route",
                "username",
                "status_code",
            ],
        },
        "schools": {
            "model": School,
            "table": "schools",
            "schema": "public",
            "pk": "id",
            "on_conflict": "id",
            "remote_school_column": None,
            "supports_sync_status": False,
        },
    }

    def __init__(self, app=None):
        self.supabase = None
        if app is not None:
            self.init_app(app)

    def init_app(self, app):
        config = load_config()
        app.config["SUPABASE_URL"] = config.get("supabase_url", app.config.get("SUPABASE_URL", ""))
        app.config["SUPABASE_KEY"] = (
            config.get("supabase_service_role_key")
            or config.get("supabase_key", app.config.get("SUPABASE_KEY", ""))
        )
        app.config["SUPABASE_ANON_KEY"] = config.get("supabase_key", app.config.get("SUPABASE_ANON_KEY", ""))
        app.config["DEVICE_ID"] = config.get("device_id", app.config.get("DEVICE_ID", "desktop-device"))
        app.config["SYNC_BATCH_SIZE"] = int(config.get("sync_batch_size", app.config.get("SYNC_BATCH_SIZE", 100)) or 100)
        app.config["SYNC_MIN_INTERVAL_SECONDS"] = int(
            config.get("sync_min_interval_seconds", app.config.get("SYNC_MIN_INTERVAL_SECONDS", 20)) or 20
        )
        self.supabase = self._build_client(
            app.config.get("SUPABASE_URL", ""),
            app.config.get("SUPABASE_KEY", ""),
        )
        app.extensions["sync_service"] = self

    def _build_client(self, url, key):
        if not create_client or not url or not key:
            return None
        try:
            return create_client(url, key)
        except Exception as exc:
            try:
                current_app.logger.warning("Supabase client initialization failed: %s", exc)
            except RuntimeError:
                pass
            return None

    def is_configured(self):
        return self.supabase is not None

    def _remote_school_column(self, entity_type):
        config = self.ENTITY_CONFIG.get(entity_type, {})
        return config.get("remote_school_column", "school_id")

    def _entity_schema(self, entity_type):
        config = self.ENTITY_CONFIG.get(entity_type, {})
        return config.get("schema", self.DEFAULT_REMOTE_SCHEMA)

    def _supports_sync_status(self, entity_type):
        config = self.ENTITY_CONFIG.get(entity_type, {})
        return config.get("supports_sync_status", True)

    def _downloads_enabled(self, entity_type):
        config = self.ENTITY_CONFIG.get(entity_type, {})
        return config.get("download_enabled", True)

    def should_upload_now(self, school_id=None):
        metadata = self.get_metadata(school_id=school_id)
        min_interval_seconds = max(0, int(current_app.config.get("SYNC_MIN_INTERVAL_SECONDS", 20) or 0))
        if min_interval_seconds == 0 or not metadata.last_upload_at:
            return True
        return (utc_now() - metadata.last_upload_at) >= timedelta(seconds=min_interval_seconds)

    def _resolve_target_school_id(self, school_id=None, metadata=None):
        if school_id is not None:
            return school_id
        if metadata and metadata.school_id is not None:
            return metadata.school_id
        return self._default_school_id()

    def _table_client(self, table_name, schema=None):
        schema_name = schema or self.DEFAULT_REMOTE_SCHEMA
        return self.supabase.schema(schema_name).table(table_name)

    def _log_supabase_debug(self, message):
        print(message)
        try:
            current_app.logger.info(message)
        except RuntimeError:
            pass

    def _sanitize_remote_payload(self, entity_type, payload):
        safe_payload = dict(payload or {})
        config = self.ENTITY_CONFIG.get(entity_type, {})
        allowed_columns = config.get("remote_columns")
        if allowed_columns:
            safe_payload = {key: value for key, value in safe_payload.items() if key in allowed_columns}
        return safe_payload

    def _retry_delay_seconds(self, attempt_count):
        max_delay = max(30, int(current_app.config.get("SYNC_RETRY_MAX_SECONDS", 300) or 300))
        return min(max_delay, 2 ** min(attempt_count, 8))

    def _is_transient_error(self, error):
        message = str(error or "").lower()
        transient_markers = [
            "winerror 10054",
            "connection reset",
            "connectionreseterror",
            "temporarily unavailable",
            "timed out",
            "timeout",
            "network",
        ]
        return any(marker in message for marker in transient_markers)

    def queue_change(
        self,
        entity_type,
        entity_id,
        operation,
        payload,
        school_id,
        device_id=None,
        record_updated_at=None,
        operation_id=None,
    ):
        resolved_device_id = device_id or current_app.config.get("DEVICE_ID", "desktop-device")
        resolved_entity_id = str(entity_id)
        queue_item = None

        if operation_id:
            queue_item = SyncQueue.query.filter_by(operation_id=operation_id).first()

        if queue_item is None:
            # Reuse a pending entry for the same record so repeated edits do not spam inserts.
            queue_item = (
                SyncQueue.query.filter_by(
                    school_id=school_id,
                    entity_type=entity_type,
                    entity_id=resolved_entity_id,
                )
                .filter(SyncQueue.status.in_(["pending", "failed"]))
                .order_by(SyncQueue.updated_at.desc())
                .first()
            )

        if queue_item is None:
            queue_item = SyncQueue(
                operation_id=operation_id or str(uuid.uuid4()),
                school_id=school_id,
                device_id=resolved_device_id,
                entity_type=entity_type,
                entity_id=resolved_entity_id,
                operation=operation,
                status="pending",
                record_updated_at=self._parse_datetime(record_updated_at) or utc_now(),
            )
            db.session.add(queue_item)
        else:
            queue_item.school_id = school_id
            queue_item.device_id = resolved_device_id
            queue_item.operation = operation
            queue_item.status = "pending"
            queue_item.record_updated_at = self._parse_datetime(record_updated_at) or utc_now()
            queue_item.next_retry_at = None
            queue_item.last_error = None
            queue_item.updated_at = utc_now()

        queue_item.set_payload(payload)
        return queue_item

    def serialize_record(self, entity_type, record):
        if entity_type not in self.ENTITY_CONFIG:
            raise KeyError(f"Unsupported entity type: {entity_type}")

        data = {}
        config = self.ENTITY_CONFIG[entity_type]
        exclude_columns = config.get("exclude_columns", [])
        
        for attr in record.__mapper__.column_attrs:
            column = attr.columns[0]
            if column.name in exclude_columns:
                continue
            value = getattr(record, attr.key)
            data[column.name] = self._serialize_value(value)
        return data

    def upload_pending_changes(self, school_id=None, limit=None):
        metadata = self.get_metadata(school_id=school_id)
        target_school_id = self._resolve_target_school_id(school_id, metadata)
        batch_size = limit or current_app.config.get("SYNC_BATCH_SIZE", 100)
        summary = {"uploaded": 0, "failed": 0, "conflicts": 0, "skipped": 0}

        if not self.is_configured():
            metadata.last_error = "Supabase is not configured."
            db.session.commit()
            return summary

        now = utc_now()
        pending_items = (
            SyncQueue.query.filter(SyncQueue.school_id == target_school_id)
            .filter(SyncQueue.status.in_(["pending", "failed"]))
            .filter(
                (SyncQueue.next_retry_at.is_(None))
                | (SyncQueue.next_retry_at <= now)
            )
            .order_by(SyncQueue.created_at.asc())
            .limit(batch_size)
            .all()
        )

        for item in pending_items:
            try:
                payload = item.get_payload()
                exclude_columns = self.ENTITY_CONFIG.get(item.entity_type, {}).get("exclude_columns", [])
                for col in exclude_columns:
                    payload.pop(col, None)
                remote_school_col = self._remote_school_column(item.entity_type)
                if remote_school_col:
                    payload.setdefault(remote_school_col, item.school_id)
                elif not self._supports_sync_status(item.entity_type):
                    payload.pop("school_id", None)

                if self._supports_sync_status(item.entity_type):
                    payload.setdefault("sync_status", "pending")
                else:
                    payload.pop("sync_status", None)

                payload = self._sanitize_remote_payload(item.entity_type, payload)

                remote_record = self._fetch_remote_record(
                    item.entity_type,
                    item.school_id,
                    item.entity_id,
                )
                local_updated_at = self._parse_datetime(
                    payload.get("updated_at") or item.record_updated_at
                )
                remote_updated_at = self._parse_datetime(
                    remote_record.get("updated_at") if remote_record else None
                )

                if remote_record and self._payloads_differ(payload, remote_record):
                    winner = self._pick_winner(local_updated_at, remote_updated_at)
                    self._store_conflict(
                        item.school_id,
                        item.entity_type,
                        item.entity_id,
                        payload,
                        remote_record,
                        local_updated_at,
                        remote_updated_at,
                        winner,
                    )
                    if winner == "remote":
                        self._apply_remote_record(item.entity_type, remote_record, force=True)
                        item.status = "conflict"
                        item.processed_at = utc_now()
                        item.last_error = "Remote version newer; local change preserved in sync_conflicts."
                        summary["conflicts"] += 1
                        db.session.commit()
                        continue

                if self._supports_sync_status(item.entity_type):
                    payload["sync_status"] = "synced"
                self._upsert_remote(item.entity_type, payload)
                self._mark_local_synced(item.entity_type, payload)

                item.status = "synced"
                item.last_error = None
                item.processed_at = utc_now()
                item.updated_at = utc_now()
                metadata.last_upload_at = utc_now()
                metadata.last_synced_at = utc_now()
                metadata.last_error = None
                summary["uploaded"] += 1
                db.session.commit()

            except Exception as exc:  # pragma: no cover - network/runtime dependent
                db.session.rollback()
                error_message = str(exc)
                if self._is_transient_error(exc):
                    error_message = f"Transient sync error: {error_message}"
                self._log_supabase_debug(
                    f"[SyncService] Upload failed for entity={item.entity_type} "
                    f"entity_id={item.entity_id} school_id={item.school_id}: {error_message!r}"
                )

                # FIX: use db.session.get() instead of deprecated .query.get()
                item = db.session.get(SyncQueue, item.id)
                metadata = self.get_metadata(school_id=target_school_id)

                item.status = "failed"
                item.attempt_count = (item.attempt_count or 0) + 1
                item.last_error = error_message
                item.next_retry_at = utc_now() + timedelta(seconds=self._retry_delay_seconds(item.attempt_count))
                item.updated_at = utc_now()
                metadata.last_error = error_message
                summary["failed"] += 1
                db.session.commit()

        self._refresh_pending_count(target_school_id)
        return summary

    def download_remote_changes(self, school_id=None, limit=250):
        metadata = self.get_metadata(school_id=school_id)
        target_school_id = self._resolve_target_school_id(school_id, metadata)
        summary = {"downloaded": 0, "conflicts": 0}

        if not self.is_configured():
            metadata.last_error = "Supabase is not configured."
            db.session.commit()
            return summary

        since = metadata.last_download_at

        for entity_type in self.ENTITY_CONFIG:
            if not self._downloads_enabled(entity_type):
                continue
            if entity_type == "schools":
                rows = self._download_school_rows(school_id=target_school_id, limit=limit)
            else:
                rows = self._download_entity_rows(
                    entity_type,
                    target_school_id,
                    since=since,
                    limit=limit,
                )

            for row in rows:
                result = self._apply_remote_record(entity_type, row)
                summary["downloaded"] += int(result["applied"])
                summary["conflicts"] += int(result["conflict"])

        metadata.last_download_at = utc_now()
        metadata.last_synced_at = utc_now()
        metadata.last_error = None
        db.session.commit()
        return summary

    def resolve_conflict(self, conflict_id, resolution, merged_payload=None):
        conflict = SyncConflict.query.get_or_404(conflict_id)
        local_payload = conflict.get_local_payload()
        remote_payload = conflict.get_remote_payload()

        if resolution == "local":
            winner_payload = local_payload
        elif resolution == "remote":
            winner_payload = remote_payload
        elif resolution == "merged":
            winner_payload = merged_payload or {}
        else:
            raise ValueError("Resolution must be local, remote, or merged.")

        school_column = self._remote_school_column(conflict.entity_type)
        if school_column:
            winner_payload.setdefault(school_column, conflict.school_id)
        elif not self._supports_sync_status(conflict.entity_type):
            winner_payload.pop("school_id", None)

        if self._supports_sync_status(conflict.entity_type):
            winner_payload["sync_status"] = "synced"
        else:
            winner_payload.pop("sync_status", None)

        self._apply_remote_record(conflict.entity_type, winner_payload, force=True)
        if self.is_configured():
            self._upsert_remote(conflict.entity_type, winner_payload)

        conflict.resolution = resolution
        conflict.resolved_at = utc_now()
        conflict.set_versions(local_payload, remote_payload, winner_payload)
        db.session.commit()
        return {
            "id": conflict.id,
            "resolution": resolution,
            "entity_type": conflict.entity_type,
            "entity_id": conflict.entity_id,
        }

    def get_status(self, school_id=None):
        metadata = self.get_metadata(school_id=school_id)
        target_school_id = self._resolve_target_school_id(school_id, metadata)
        pending_count = self._refresh_pending_count(target_school_id)
        cloud_reachable = self.ping_remote()
        conflicts = (
            SyncConflict.query.filter_by(school_id=target_school_id, resolution="pending")
            .order_by(SyncConflict.created_at.desc())
            .limit(20)
            .all()
        )
        return {
            "configured": self.is_configured(),
            "cloud_reachable": cloud_reachable,
            "device_id": metadata.device_id,
            "school_id": target_school_id,
            "pending_count": pending_count,
            "last_upload_at": self._serialize_value(metadata.last_upload_at),
            "last_download_at": self._serialize_value(metadata.last_download_at),
            "last_synced_at": self._serialize_value(metadata.last_synced_at),
            "last_error": metadata.last_error,
            "conflicts": [
                {
                    "id": conflict.id,
                    "entity_type": conflict.entity_type,
                    "entity_id": conflict.entity_id,
                    "local": conflict.get_local_payload(),
                    "remote": conflict.get_remote_payload(),
                    "created_at": self._serialize_value(conflict.created_at),
                }
                for conflict in conflicts
            ],
        }

    def get_metadata(self, school_id=None):
        device_id = current_app.config.get("DEVICE_ID", "desktop-device")
        metadata = SyncMetadata.query.filter_by(device_id=device_id).first()

        if metadata:
            return metadata

        resolved_school_id = school_id or self._default_school_id()
        metadata = SyncMetadata(
            device_id=device_id,
            school_id=resolved_school_id,
            pending_operations=0,
        )
        db.session.add(metadata)
        db.session.commit()
        return metadata

    def _download_school_rows(self, school_id=None, limit=250):
        if not self.is_configured():
            return []
        query = self._table_client("schools", schema=self.DEFAULT_REMOTE_SCHEMA).select("*")
        if school_id is not None:
            query = query.eq("id", school_id)
        response = query.limit(limit).execute()
        return getattr(response, "data", None) or []

    def ping_remote(self):
        if not self.is_configured():
            return False
        try:
            self._table_client("schools", schema=self.DEFAULT_REMOTE_SCHEMA).select("id").limit(1).execute()
            return True
        except Exception:
            return False

    def _download_entity_rows(self, entity_type, school_id, since=None, limit=250):
        config = self.ENTITY_CONFIG[entity_type]
        school_column = self._remote_school_column(entity_type)
        query = (
            self._table_client(config["table"], schema=config.get("schema"))
            .select("*")
            .order("updated_at", desc=False)
            .limit(limit)
        )
        if school_column and school_id is not None:
            query = query.eq(school_column, school_id)
        if since:
            query = query.gte("updated_at", self._serialize_value(since))
        response = query.execute()
        return getattr(response, "data", None) or []

    def _fetch_remote_record(self, entity_type, school_id, entity_id):
        config = self.ENTITY_CONFIG[entity_type]
        school_column = self._remote_school_column(entity_type)
        
        search_id = entity_id
        if entity_type in ["books", "checkouts", "staff_checkouts"]:
            import hashlib
            search_id = int.from_bytes(hashlib.md5(str(entity_id).encode()).digest()[:8], 'little', signed=True)
            
        query = (
            self._table_client(config["table"], schema=config.get("schema"))
            .select("*")
        )
        if school_column and school_id is not None:
            query = query.eq(school_column, school_id)
        query = query.eq(config["pk"], search_id).limit(1)
        response = query.execute()
        data = getattr(response, "data", None) or []
        return data[0] if data else None

    def _upsert_remote(self, entity_type, payload):
        config = self.ENTITY_CONFIG[entity_type]
        
        # --- Schema Mismatch Workaround ---
        safe_payload = dict(payload)
        import hashlib
        def to_bigint(s):
            if not s: return None
            return int.from_bytes(hashlib.md5(str(s).encode()).digest()[:8], 'little', signed=True)
            
        if entity_type == "books" and "book_id" in safe_payload:
            safe_payload["isbn"] = str(safe_payload["book_id"])
            safe_payload["book_id"] = to_bigint(safe_payload["book_id"])
            
        if entity_type == "members" and "student_id" not in safe_payload:
            safe_payload["student_id"] = str(safe_payload.get("id", ""))
            
        if entity_type in ["checkouts", "staff_checkouts"] and "book_id" in safe_payload:
            safe_payload["status"] = str(safe_payload["book_id"])
            safe_payload["book_id"] = to_bigint(safe_payload["book_id"])
            
        if entity_type == "class_checkouts" and "book_ids" in safe_payload:
            safe_payload["class_name"] = str(safe_payload.get("class_name", "")) + "||" + str(safe_payload["book_ids"])
            safe_payload["book_id"] = to_bigint(safe_payload["book_ids"])
            safe_payload.pop("book_ids", None)
            
        if entity_type == "class_checkouts" and "responsibles" in safe_payload:
            safe_payload["quantity"] = safe_payload.get("quantity", 1)  # Ensure quantity is passed
            # Supabase class_borrowing doesn't have 'responsibles' or 'condition', ignoring or mapping if needed
            safe_payload.pop("responsibles", None)
            safe_payload.pop("condition", None)
            safe_payload.pop("book_title", None)

        if entity_type == "librarians":
            safe_payload = {
                "id": safe_payload.get("id"),
                "school_id": safe_payload.get("school_id"),
                "username": safe_payload.get("username"),
                "password": safe_payload.get("password"),
                "role": safe_payload.get("role", "librarian"),
                "updated_at": safe_payload.get("updated_at"),
                "deleted": safe_payload.get("deleted", False),
                "sync_status": safe_payload.get("sync_status", "pending"),
            }

        if not self._remote_school_column(entity_type):
            safe_payload.pop("school_id", None)
        if not self._supports_sync_status(entity_type):
            safe_payload.pop("sync_status", None)

        safe_payload = self._sanitize_remote_payload(entity_type, safe_payload)

        should_log = entity_type in {"schools", "librarians"}
        if should_log:
            self._log_supabase_debug(
                f"[SyncService] Connecting to Supabase... schema={self._entity_schema(entity_type)} "
                f"table={config['table']} entity={entity_type}"
            )
        if entity_type == "logs":
            print("LOG DATA SENT:", safe_payload)
        elif should_log:
            self._log_supabase_debug(f"[SyncService] Sending data... {safe_payload}")

        response = self._table_client(config["table"], schema=config.get("schema")).upsert(
            safe_payload,
            on_conflict=config["on_conflict"],
        ).execute()

        if response is None:
            raise RuntimeError(f"Supabase upsert returned no response for {entity_type}.")

        if should_log:
            self._log_supabase_debug(f"[SyncService] Response received: {response}")
        return response

    def _mark_local_synced(self, entity_type, payload):
        record = self._fetch_local_record(entity_type, payload)
        if record:
            if hasattr(record, "sync_status"):
                record.sync_status = "synced"
            if hasattr(record, "updated_at"):
                record.updated_at = self._parse_datetime(payload.get("updated_at")) or utc_now()

    def _fetch_local_record(self, entity_type, payload):
        config = self.ENTITY_CONFIG[entity_type]
        model = config["model"]
        pk = config["pk"]
        pk_value = payload.get(pk)
        school_id = payload.get("school_id")

        query = model.query
        if hasattr(model, "school_id") and school_id is not None:
            query = query.filter_by(school_id=school_id)
        return query.filter_by(**{pk: pk_value}).first()

    def _apply_remote_record(self, entity_type, payload, force=False):
        config = self.ENTITY_CONFIG[entity_type]
        model = config["model"]
        local_record = self._fetch_local_record(entity_type, payload)
        remote_updated_at = self._parse_datetime(payload.get("updated_at"))

        if local_record:
            local_payload = self.serialize_record(entity_type, local_record)
            local_updated_at = self._parse_datetime(local_payload.get("updated_at"))
            if (
                not force
                and getattr(local_record, "sync_status", None) == "pending"
                and self._payloads_differ(local_payload, payload)
            ):
                winner = self._pick_winner(local_updated_at, remote_updated_at)
                self._store_conflict(
                    payload.get("school_id"),
                    entity_type,
                    payload.get(config["pk"]),
                    local_payload,
                    payload,
                    local_updated_at,
                    remote_updated_at,
                    winner,
                )
                if winner == "local":
                    db.session.commit()
                    return {"applied": False, "conflict": True}

            for attr_key, value in self._payload_to_kwargs(model, payload).items():
                setattr(local_record, attr_key, value)
            if hasattr(local_record, "sync_status"):
                local_record.sync_status = "synced"
            db.session.commit()
            return {"applied": True, "conflict": False}

        if payload.get("deleted"):
            return {"applied": False, "conflict": False}

        record = model(**self._payload_to_kwargs(model, payload))
        if hasattr(record, "sync_status"):
            record.sync_status = "synced"
        db.session.add(record)
        db.session.commit()
        return {"applied": True, "conflict": False}

    def _payload_to_kwargs(self, model, payload):
        kwargs = {}
        for attr in model.__mapper__.column_attrs:
            column = attr.columns[0]
            if column.name not in payload:
                continue
            kwargs[attr.key] = self._deserialize_value(attr.key, payload[column.name])
        return kwargs

    def _store_conflict(
        self,
        school_id,
        entity_type,
        entity_id,
        local_payload,
        remote_payload,
        local_updated_at,
        remote_updated_at,
        winner,
    ):
        conflict = SyncConflict(
            school_id=school_id,
            entity_type=entity_type,
            entity_id=str(entity_id),
            local_updated_at=local_updated_at,
            remote_updated_at=remote_updated_at,
            resolution="pending",
        )
        conflict.set_versions(local_payload, remote_payload)
        db.session.add(conflict)

        # FIX: local_payload is a dict — use key check, not hasattr()
        if winner == "local" and "sync_status" in local_payload:
            local_payload["sync_status"] = "pending"

    def _refresh_pending_count(self, school_id):
        pending_count = (
            SyncQueue.query.filter(SyncQueue.school_id == school_id)
            .filter(SyncQueue.status.in_(["pending", "failed"]))
            .count()
        )
        device_id = current_app.config.get("DEVICE_ID")
        metadata = SyncMetadata.query.filter_by(device_id=device_id).first()
        if metadata:
            metadata.pending_operations = pending_count
            metadata.updated_at = utc_now()
            db.session.commit()
        return pending_count

    def _default_school_id(self):
        school = School.query.filter_by(deleted=False).order_by(School.id.asc()).first()
        if school:
            return school.id
        school = School(name="Default School", slug="default-school")
        db.session.add(school)
        db.session.commit()
        return school.id

    def _pick_winner(self, local_updated_at, remote_updated_at):
        if remote_updated_at and local_updated_at and remote_updated_at > local_updated_at:
            return "remote"
        return "local"

    def _payloads_differ(self, local_payload, remote_payload):
        return json.dumps(local_payload, sort_keys=True, default=str) != json.dumps(
            remote_payload,
            sort_keys=True,
            default=str,
        )

    def _serialize_value(self, value):
        if isinstance(value, datetime):
            return value.isoformat()
        return value

    def _deserialize_value(self, attr_key, value):
        if value is None:
            return None
        if attr_key.endswith("_at") or attr_key in {"updated_at", "last_seen_at"}:
            parsed = self._parse_datetime(value)
            return parsed or value
        return value

    def _parse_datetime(self, value):
        if isinstance(value, datetime):
            if value.tzinfo is not None:
                from datetime import timezone
                return value.astimezone(timezone.utc).replace(tzinfo=None)
            return value
        if not value:
            return None
        if isinstance(value, str):
            normalized = value.replace("Z", "+00:00")
            for fmt in (None, "%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
                try:
                    if fmt is None:
                        dt = datetime.fromisoformat(normalized)
                        if dt.tzinfo is not None:
                            from datetime import timezone
                            return dt.astimezone(timezone.utc).replace(tzinfo=None)
                        return dt
                    return datetime.strptime(normalized, fmt)
                except ValueError:
                    continue
        return None
