import os
from flask import Flask, redirect, request, url_for
from flask_login import LoginManager
from .utils import load_config, DB_PATH, UPLOAD_FOLDER, BACKUP_DIR
from .database import db, Admin, School
from .sync_service import SyncService

try:
    from flask_cors import CORS
except ImportError:  # pragma: no cover - optional in minimal environments
    CORS = None

login_manager = LoginManager()

def create_app(test_config=None):
    app = Flask(__name__)
    
    # 1. Config
    system_config = load_config()
    database_url = system_config.get('database_url') or os.getenv('DATABASE_URL') or f'sqlite:///{DB_PATH}'
    app.secret_key = os.getenv('FLASK_SECRET_KEY') or system_config.get('secret_key') or "strong_random_secret_key"
    app.config['SECRET_KEY'] = app.secret_key
    app.config['SQLALCHEMY_DATABASE_URI'] = database_url
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
    app.config['DEFAULT_BORROW_DAYS'] = system_config.get('default_borrow_days', 14)
    app.config['SUPABASE_URL'] = system_config.get('supabase_url', '')
    app.config['SUPABASE_KEY'] = system_config.get('supabase_service_role_key') or system_config.get('supabase_key', '')
    app.config['SUPABASE_ANON_KEY'] = system_config.get('supabase_key', '')
    app.config['MASTER_KEY'] = os.getenv('MASTER_KEY') or system_config.get('master_key', '')
    app.config['DEVICE_ID'] = system_config.get('device_id', 'desktop-device')
    app.config['SYNC_BATCH_SIZE'] = system_config.get('sync_batch_size', 100)
    app.config['SYNC_MIN_INTERVAL_SECONDS'] = system_config.get('sync_min_interval_seconds', 20)
    app.config['SYNC_POLL_INTERVAL_SECONDS'] = system_config.get('sync_poll_interval_seconds', 60)
    app.config['SYNC_RETRY_MAX_SECONDS'] = system_config.get('sync_retry_max_seconds', 300)
    app.config.update(
        SESSION_COOKIE_SECURE=False,
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
    )
    if test_config:
        app.config.update(test_config)
    
    # Ensure dirs exist
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
    os.makedirs(BACKUP_DIR, exist_ok=True)

    # 2. Init Extensions
    db.init_app(app)
    login_manager.init_app(app)
    login_manager.login_message_category = 'warning'
    if CORS:
        CORS(app, supports_credentials=True)
    SyncService(app)

    @login_manager.user_loader
    def load_user(user_id):
        return db.session.get(Admin, int(user_id))

    # 3. Register Blueprints
    from .routes import main as main_blueprint
    from .auth import auth as auth_blueprint, login as auth_login
    
    app.register_blueprint(main_blueprint)
    app.register_blueprint(auth_blueprint, url_prefix='/auth')
    app.add_url_rule('/login', endpoint='login_alias', view_func=auth_login, methods=['GET', 'POST'])
    login_manager.login_view = 'login_alias'

    @app.before_request
    def require_role_setup():
        if app.config.get("TESTING"):
            return
        exempt = {'main.role_wizard', 'main.role_wizard_save', 'static'}
        if request.endpoint in exempt:
            return
        cfg = load_config()
        if not cfg.get('role'):
            return redirect(url_for('main.role_wizard'))

    # 4. Create Tables
    with app.app_context():
        db.create_all()
        # Run additive migrations that don't require Alembic on the default local DB only.
        if app.config['SQLALCHEMY_DATABASE_URI'] == f'sqlite:///{DB_PATH}':
            try:
                from .utils import migrate_add_book_category, migrate_add_note_title, migrate_sync_schema
                migrate_add_book_category()
                migrate_add_note_title()
                migrate_sync_schema()
                db.session.remove()
                db.engine.dispose()
            except Exception:
                pass
        default_school = School.query.filter_by(deleted=False).order_by(School.id.asc()).first()
        if not default_school:
            default_school = School(
                name='Default School',
                slug='default-school',
                status='active',
            )
            db.session.add(default_school)
            db.session.commit()
        # Create default admin if missing
        if not Admin.query.first():
            from .utils import hash_pw
            db.session.add(
                Admin(
                    username='admin',
                    password=hash_pw('admin123'),
                    role='admin',
                    school_id=default_school.id if default_school else None,
                    sync_status='synced',
                )
            )
            db.session.commit()
            print("Default admin created.")

    return app
