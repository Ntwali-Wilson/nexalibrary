from flask import Blueprint, render_template, request, flash, redirect, url_for, jsonify, current_app, send_file
from flask_login import login_required, current_user
from datetime import UTC, datetime, timedelta
try:
    import pandas as pd
except ImportError:
    pd = None
import os
import random
import string
import secrets
import subprocess
import requests
import sys
import time
from packaging import version
from io import BytesIO
from werkzeug.utils import secure_filename
from flask import send_from_directory
from tcp_sync_server import (
    get_status as get_lan_sync_status,
    reset_status as reset_lan_sync_status,
    start_tcp_server,
    stop_tcp_server,
)

# ReportLab Imports
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet

from .database import (
    Admin,
    Book,
    BookIssue,
    BorrowedBook,
    ClassBorrowing,
    GraduateBorrowing,
    GraduateClassBorrowing,
    Log,
    Note,
    PeerSession,
    PeerSyncLog,
    School,
    Student,
    SyncConflict,
    SyncMetadata,
    SyncQueue,
    TeacherBorrowedBook,
    UpdateHistory,
    db,
)
from .utils import (
    BACKUP_DIR,
    UPLOAD_FOLDER,
    hash_pw,
    is_admin_role,
    load_config,
    normalize_role,
    role_label,
    save_config,
)

main = Blueprint('main', __name__)

VERSION = "1.0.0"

UPDATE_URL = "https://raw.githubusercontent.com/Ntwali-Wilson/nexalibrary/refs/heads/main/version.json"

# --- GLOBAL CONTEXT ---
# This allows {{ config.theme }} or {{ config.auto_lock_minutes }} to work in ALL templates
@main.app_context_processor
def inject_globals():
    return dict(
        current_version=VERSION,
        is_admin_role=is_admin_role,
        role_label=role_label,
        sys_config=load_config(),
    )

# --- HELPER: LOGGING ---
def log_action(route, method, details, status_code=200):
    try:
        now = datetime.now(UTC).replace(tzinfo=None)
        new_log = Log(
            username=current_user.username if current_user.is_authenticated else "System",
            route=(route or request.path or "system")[:255],
            method=(method or request.method or "SYSTEM")[:20],
            status_code=status_code or 200,
            details=details,
            timestamp=now.strftime("%Y-%m-%d %H:%M:%S"),
            created_at=now,
            school_id=get_current_school_id(),
            sync_status='pending',
            updated_at=now,
        )
        db.session.add(new_log)
        db.session.flush()
        queue_record_change('logs', new_log, operation='upsert')
        db.session.commit()
    except Exception as exc:
        db.session.rollback()
        current_app.logger.warning("Failed to save audit log: %s", exc)


def get_current_school_id():
    if current_user.is_authenticated and getattr(current_user, 'school_id', None):
        return current_user.school_id

    school = School.query.filter_by(deleted=False).order_by(School.id.asc()).first()
    return school.id if school else None


def school_query(model, include_deleted=False):
    query = model.query
    school_id = get_current_school_id()
    if hasattr(model, 'school_id') and school_id is not None:
        query = query.filter(model.school_id == school_id)
    if hasattr(model, 'deleted') and not include_deleted:
        query = query.filter(model.deleted == False)
    return query


def school_get(model, record_id, pk_name='id', include_deleted=False):
    query = school_query(model, include_deleted=include_deleted)
    return query.filter(getattr(model, pk_name) == record_id).first()


def school_get_or_404(model, record_id, pk_name='id', include_deleted=False):
    record = school_get(model, record_id, pk_name=pk_name, include_deleted=include_deleted)
    if record is None:
        from flask import abort
        abort(404)
    return record


def current_role(user=None):
    return normalize_role(getattr(user or current_user, 'role', 'admin'))


def is_admin(user=None):
    return current_role(user) == 'admin'


def can_manage_librarians(user=None):
    return is_admin(user)


def can_clear_logs(user=None):
    return is_admin(user)


def wants_json_response():
    if request.is_json:
        return True
    best = request.accept_mimetypes.best
    if not best:
        return False
    return request.accept_mimetypes[best] >= request.accept_mimetypes['text/html'] and best == 'application/json'


def serialize_librarian(librarian):
    return {
        "id": librarian.id,
        "username": librarian.username,
        "role": current_role(librarian),
        "role_label": role_label(librarian.role),
        "school_id": librarian.school_id,
        "email": librarian.email1 or librarian.email2 or librarian.email3,
        "deleted": bool(getattr(librarian, "deleted", False)),
    }


def admin_access_denied(message="Only an admin can access librarian management."):
    if wants_json_response():
        return jsonify({"success": False, "message": message}), 403
    flash(message, "danger")
    return redirect(url_for('main.profile'))


def get_sync_service():
    return current_app.extensions.get('sync_service')


def stamp_sync_fields(record, deleted=False):
    school_id = get_current_school_id()
    if hasattr(record, 'school_id') and not getattr(record, 'school_id', None):
        record.school_id = school_id
    if hasattr(record, 'updated_at'):
        record.updated_at = datetime.now(UTC).replace(tzinfo=None)
    if hasattr(record, 'sync_status'):
        record.sync_status = 'pending'
    if hasattr(record, 'deleted') and deleted:
        record.deleted = True
    return record


def queue_record_change(entity_type, record, operation='upsert', payload=None):
    sync_service = get_sync_service()
    if not sync_service:
        return None

    payload = payload or sync_service.serialize_record(entity_type, record)
    payload.setdefault('school_id', get_current_school_id())
    return sync_service.queue_change(
        entity_type=entity_type,
        entity_id=payload.get('book_id') or payload.get('id'),
        operation=operation,
        payload=payload,
        school_id=payload.get('school_id'),
        record_updated_at=payload.get('updated_at'),
    )


def safe_push_sync(limit=100, force=False):
    sync_service = get_sync_service()
    if not sync_service or not sync_service.is_configured():
        return
    try:
        school_id = get_current_school_id()
        if not force and not sync_service.should_upload_now(school_id=school_id):
            return
        sync_service.upload_pending_changes(
            school_id=school_id,
            limit=limit,
        )
    except Exception as exc:
        db.session.rollback()
        current_app.logger.warning("Deferred sync push failed: %s", exc)

# --- HELPER: Generate Unique Numeric ID ---
def generate_unique_base_id():
    while True:
        nums = ''.join(random.choices(string.digits, k=8))
        formatted_id = f"{nums[:4]}-{nums[4:]}"
        exists = Book.query.filter(Book.book_id.like(f"{formatted_id}/%")).first()
        if not exists:
            return formatted_id

# --- HELPER: Parse Range String to Set of Integers ---
def parse_range_to_set(range_str):
    """Converts '1-5, 8' into set({1, 2, 3, 4, 5, 8}) (Integers only)"""
    res = set()
    if not range_str: return res
    
    # Split by comma first
    parts = range_str.split(',')
    for p in parts:
        p = p.strip()
        if not p: continue
        if '-' in p:
            try:
                # Handle cases like "1 - 5" or "1-5"
                start, end = map(int, p.split('-'))
                if start > end: start, end = end, start
                res.update(range(start, end + 1))
            except: pass
        else:
            try: res.add(int(p))
            except: pass
    return res

# --- HELPER: CHECK IF BOOK IS BORROWED ---
def is_book_active(book_id, school_id=None):
    """Returns True if book is currently in any active loan table."""
    school_id = school_id or get_current_school_id()
    # 1. Student Loans
    if school_query(BorrowedBook).filter_by(book_id=book_id, returned=False).first(): return True
    # 2. Staff Loans
    if school_query(TeacherBorrowedBook).filter_by(book_id=book_id, returned=False).first(): return True
    # 3. Graduate Debtors (Archived but still owed)
    if school_query(GraduateBorrowing).filter_by(book_id=book_id).first(): return True
    
    # 4. Class Loans (Complex Check)
    # This is resource intensive but necessary for strict safety
    all_class_loans = school_query(ClassBorrowing).filter_by(returned=False).all()
    for cl in all_class_loans:
        # Check if book_id is in this class loan range
        # Format of cl.book_ids is "base/range" (e.g. "100-20/1-50")
        # Format of book_id is "base/id" (e.g. "100-20/5")
        try:
            cl_base, cl_range = cl.book_ids.split('/')
            b_base, b_num = book_id.split('/')
            
            if cl_base == b_base:
                # Parse range to see if number is included
                # We reuse a simplified logic here:
                for part in cl_range.split(','):
                    if '-' in part:
                        s, e = map(int, part.split('-'))
                        if s <= int(b_num) <= e: return True
                    elif int(part) == int(b_num): return True
        except:
            continue
            
    return False

# --- HELPER: Convert Set back to Range String ---
def set_to_range_string(num_set):
    """Converts set({1,2,3,5}) into '1-3, 5'"""
    if not num_set: return ""
    sorted_nums = sorted(list(num_set))
    ranges = []
    start = sorted_nums[0]
    prev = sorted_nums[0]
    
    for x in sorted_nums[1:]:
        if x == prev + 1:
            prev = x
        else:
            ranges.append(f"{start}-{prev}" if start != prev else f"{start}")
            start = x
            prev = x
    ranges.append(f"{start}-{prev}" if start != prev else f"{start}")
    return ", ".join(ranges)

# --- DASHBOARD ---
@main.route('/')
@login_required
def dashboard():
    books_q = school_query(Book)
    students_q = school_query(Student)
    student_loans_q = school_query(BorrowedBook)
    staff_loans_q = school_query(TeacherBorrowedBook)
    class_loans_q = school_query(ClassBorrowing)

    total_books = books_q.count()
    total_students = students_q.count()
    
    # Active Loans
    student_loans = student_loans_q.filter_by(returned=False).count()
    staff_loans = staff_loans_q.filter_by(returned=False).count()
    # Class loans should count the total quantity (e.g., a class borrowing 10 books counts as 10)
    class_loans = 0
    for cl in class_loans_q.filter_by(returned=False).all():
        try:
            class_loans += int(getattr(cl, 'quantity', 0) or 0)
        except:
            class_loans += 0
    active_loans = student_loans + staff_loans + class_loans

    # Calculate Overdue (Simple logic: Due date < Today)
    today_str = datetime.now().strftime("%Y-%m-%d")
    overdue_count = student_loans_q.filter(BorrowedBook.returned==False, BorrowedBook.due_date < today_str).count()

    # Recent Activity (Combined)
    recent_activities = []
    
    # Fetch last 3 from each category to mix
    r_students = student_loans_q.order_by(BorrowedBook.timestamp.desc()).limit(3).all()
    r_staff = staff_loans_q.order_by(TeacherBorrowedBook.timestamp.desc()).limit(3).all()
    
    for item in r_students:
        recent_activities.append({
            'user': item.student_name, 'type': 'Student', 'book': item.book_title, 'time': item.timestamp, 'status': 'Returned' if item.returned else 'Borrowed'
        })
    for item in r_staff:
        recent_activities.append({
            'user': item.teacher_name, 'type': 'Staff', 'book': item.book_title, 'time': item.timestamp, 'status': 'Returned' if item.returned else 'Borrowed'
        })
    
    # Sort by time
    recent_activities.sort(key=lambda x: x['time'], reverse=True)

    return render_template('dashboard.html', 
                         total_books=total_books, 
                         total_students=total_students, 
                         active_loans=active_loans,
                         overdue_count=overdue_count,
                         recent_activities=recent_activities[:6]) # Show top 6 mixed


@main.route('/admin')
@login_required
def admin_home():
    if not can_manage_librarians():
        return admin_access_denied()
    return redirect(url_for('main.admin_librarians'))

# --- ANALYTICS DASHBOARD ---
@main.route('/analytics')
@login_required
def analytics():
    school_id = get_current_school_id()
    school = db.session.get(School, school_id) if school_id else None
    books_q = school_query(Book)
    students_q = school_query(Student)
    librarians_q = school_query(Admin)
    student_loans_q = school_query(BorrowedBook)
    staff_loans_q = school_query(TeacherBorrowedBook)
    class_loans_q = school_query(ClassBorrowing)
    logs_q = school_query(Log)

    total_books = books_q.count()
    total_users = students_q.count()
    total_librarians = librarians_q.count()

    active_student_loans = student_loans_q.filter_by(returned=False).count()
    active_staff_loans = staff_loans_q.filter_by(returned=False).count()
    class_loans = class_loans_q.filter_by(returned=False).all()
    active_class_quantity = sum(int(getattr(item, 'quantity', 0) or 0) for item in class_loans)
    active_loans = active_student_loans + active_staff_loans + active_class_quantity
    available_books = max(total_books - active_loans, 0)

    total_borrowed = student_loans_q.count() + staff_loans_q.count()
    total_returns = student_loans_q.filter_by(returned=True).count() + staff_loans_q.filter_by(returned=True).count()
    return_rate = round((total_returns / total_borrowed) * 100, 1) if total_borrowed else 0
    avg_books = round(active_loans / total_users, 2) if total_users else 0

    today_str = datetime.now().strftime("%Y-%m-%d")
    overdue_count = student_loans_q.filter(BorrowedBook.returned == False, BorrowedBook.due_date < today_str).count()
    active_borrowers = (
        student_loans_q.with_entities(db.func.count(db.func.distinct(BorrowedBook.student_name))).filter(BorrowedBook.returned == False).scalar() or 0
    )
    overdue_percentage = round((overdue_count / active_borrowers) * 100, 1) if active_borrowers else 0

    top_books_rows = (
        student_loans_q.with_entities(BorrowedBook.book_title, db.func.count(BorrowedBook.id).label('total'))
        .group_by(BorrowedBook.book_title)
        .order_by(db.desc('total'), BorrowedBook.book_title.asc())
        .limit(5)
        .all()
    )
    least_books_rows = (
        student_loans_q.with_entities(BorrowedBook.book_title, db.func.count(BorrowedBook.id).label('total'))
        .group_by(BorrowedBook.book_title)
        .order_by(db.asc('total'), BorrowedBook.book_title.asc())
        .limit(5)
        .all()
    )
    top_classes_rows = (
        student_loans_q.with_entities(BorrowedBook.student_class, db.func.count(BorrowedBook.id).label('total'))
        .filter(BorrowedBook.returned == False)
        .group_by(BorrowedBook.student_class)
        .order_by(db.desc('total'))
        .limit(4)
        .all()
    )

    loan_mix = [
        {"label": "Student Loans", "count": active_student_loans, "tone": "primary"},
        {"label": "Staff Loans", "count": active_staff_loans, "tone": "success"},
        {"label": "Class Loans", "count": active_class_quantity, "tone": "warning"},
    ]
    loan_mix_total = sum(item["count"] for item in loan_mix) or 1
    for item in loan_mix:
        item["percentage"] = round((item["count"] / loan_mix_total) * 100, 1)

    day_counts = {}
    for offset in range(6, -1, -1):
        day = (datetime.now() - timedelta(days=offset)).strftime("%Y-%m-%d")
        day_counts[day] = 0

    recent_student_loans = student_loans_q.filter(BorrowedBook.timestamp >= min(day_counts.keys())).all()
    recent_staff_loans = staff_loans_q.filter(TeacherBorrowedBook.timestamp >= min(day_counts.keys())).all()
    recent_class_loans = class_loans_q.filter(ClassBorrowing.borrow_time >= min(day_counts.keys())).all()

    for loan in recent_student_loans:
        day = (loan.timestamp or '')[:10]
        if day in day_counts:
            day_counts[day] += 1
    for loan in recent_staff_loans:
        day = (loan.timestamp or '')[:10]
        if day in day_counts:
            day_counts[day] += 1
    for loan in recent_class_loans:
        day = (loan.borrow_time or '')[:10]
        if day in day_counts:
            day_counts[day] += int(getattr(loan, 'quantity', 0) or 0)

    peak_day = max(day_counts.values()) if day_counts else 1
    weekly_activity = [
        {
            "label": datetime.strptime(day, "%Y-%m-%d").strftime("%a"),
            "value": value,
            "height": max(18, round((value / peak_day) * 100)) if peak_day else 18,
        }
        for day, value in day_counts.items()
    ]

    recent_activity = logs_q.order_by(Log.id.desc()).limit(6).all()

    health_insights = []
    if overdue_count:
        health_insights.append(f"{overdue_count} student loan(s) are overdue and need follow-up.")
    else:
        health_insights.append("No overdue student loans right now.")

    if total_librarians > 1:
        health_insights.append(f"{total_librarians} librarians are attached to this school and share the same catalog.")
    else:
        health_insights.append("Add more librarians to enable true shared school operations.")

    if available_books < max(5, round(total_books * 0.1)):
        health_insights.append("Available stock is getting tight compared to active borrowing.")
    else:
        health_insights.append("Book availability looks healthy for the current borrowing pace.")

    dashboard_data = {
        "school": {
            "name": school.name if school else "Default School",
            "librarians": total_librarians,
        },
        "headline": {
            "total_books": total_books,
            "available_books": available_books,
            "total_users": total_users,
            "active_borrowers": active_borrowers,
            "return_rate": return_rate,
            "avg_books": avg_books,
        },
        "overdue": {"count": overdue_count, "percentage": overdue_percentage},
        "loan_mix": loan_mix,
        "weekly_activity": weekly_activity,
        "most_borrowed": [{"title": row[0] or "Unknown", "count": row[1]} for row in top_books_rows],
        "least_borrowed": [{"title": row[0] or "Unknown", "count": row[1]} for row in least_books_rows],
        "top_classes": [{"name": row[0] or "Unclassified", "count": row[1]} for row in top_classes_rows],
        "recent_activity": [
            {
                "username": item.username,
                "details": item.details,
                "timestamp": item.timestamp,
                "method": item.method,
            }
            for item in recent_activity
        ],
        "health_insights": health_insights,
    }

    return render_template('analytics.html', dashboard_data=dashboard_data)

# --- BOOK CATALOG ---
@main.route('/books', methods=['GET', 'POST'])
@login_required
def books():
    if request.method == 'POST':
        action = request.form.get('action')
        
        # BULK ADD
        if action == 'add':
            common_id = request.form.get('common_id')
            unique_ids = request.form.get('unique_ids')
            title = request.form.get('title')
            author = request.form.get('author') or "Unknown"
            category = request.form.get('category') or "Uncategorized"
            
            if not title: flash("Title is mandatory.", "danger"); return redirect(url_for('main.books'))
            
            id_list = []
            try:
                id_set = parse_range_to_set(unique_ids)
                if len(id_set) > 1000:
                    flash("Too many books selected (max 1000).", "warning")
                    return redirect(url_for('main.books'))
                id_list = [str(i) for i in sorted(id_set)]
            except:
                flash("Invalid ID format.", "danger"); return redirect(url_for('main.books'))

            added_count = 0
            skipped = []
            queued_books = []
            for part in id_list:
                full_id = f"{common_id}/{part}"
                if school_get(Book, full_id, pk_name='book_id'):
                    skipped.append({'id': full_id, 'reason': 'Exists'})
                else:
                    book = Book(
                        book_id=full_id,
                        title=title,
                        author=author,
                        category=category,
                        added_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    )
                    stamp_sync_fields(book)
                    db.session.add(book)
                    queued_books.append(book)
                    added_count += 1

            db.session.flush()
            for book in queued_books:
                queue_record_change('books', book, operation='upsert')
            db.session.commit()
            
            # LOG WITH DETAILS
            details = f"Added {added_count} books ({common_id}). Titles: {title}, Category: {category}"
            log_action("/books", "ADD_BULK", details)
            
            flash(f"Added {added_count} books.", "success")
            return redirect(url_for('main.books'))

        # BULK DELETE (UPDATED: Strict Protection)
        elif action == 'delete_bulk':
            selected_ids = request.form.getlist('selected_books')
            blocked_count = 0
            deleted_count = 0
            
            for bid in selected_ids:
                book = school_get(Book, bid, pk_name='book_id')
                if not book:
                    continue
                if is_book_active(bid):
                    blocked_count += 1
                    continue
                    
                stamp_sync_fields(book, deleted=True)
                queue_record_change('books', book, operation='delete')
                db.session.delete(book)
                deleted_count += 1

            db.session.commit()
            msg = f"Deleted {deleted_count} books."
            if blocked_count > 0:
                flash(f"{msg} {blocked_count} books were skipped because they are currently borrowed (Student, Staff, Class, or Graduate list).", "warning")
            else:
                flash(msg, "success")
            return redirect(url_for('main.books'))

        # BULK EDIT (UPDATED: Strict Protection)
        # BULK EDIT (UPDATED: Cascading Updates + Archives)
        elif action == 'edit_bulk':
            selected_ids = request.form.getlist('selected_books')
            new_title = request.form.get('edit_title')
            new_author = request.form.get('edit_author')
            new_category = request.form.get('edit_category')
            
            updated_count = 0
            
            for old_id in selected_ids:
                book = school_get(Book, old_id, pk_name='book_id')
                if book:
                    # 1. Update Book Registry
                    book.title = new_title
                    book.author = new_author
                    if new_category:
                        book.category = new_category
                    stamp_sync_fields(book)
                    
                    # 2. Update Active Individual Loans
                    BorrowedBook.query.filter_by(book_id=old_id).update({'book_title': new_title})
                    TeacherBorrowedBook.query.filter_by(book_id=old_id).update({'book_title': new_title})
                    GraduateBorrowing.query.filter_by(book_id=old_id).update({'book_title': new_title})
                    
                    # 3. Update Group Loans (Active & Archived)
                    # We extract the base ID (e.g., '100-20') to find the matching group loans
                    if '/' in old_id:
                        base_id = old_id.split('/')[0]
                        # Update Active Class Loans
                        ClassBorrowing.query.filter(ClassBorrowing.book_ids.like(f"{base_id}/%")).update({'book_title': new_title}, synchronize_session=False)
                        # Update Archived Class Loans (The Fix)
                        GraduateClassBorrowing.query.filter(GraduateClassBorrowing.book_ids.like(f"{base_id}/%")).update({'book_title': new_title}, synchronize_session=False)

                    updated_count += 1

                    queue_record_change('books', book, operation='upsert')
            
            db.session.commit()
            flash(f"Updated {updated_count} books and synced title changes to all active and archived loans.", "success")
            return redirect(url_for('main.books'))

        # IMPORT
        elif 'excel' in request.files:
            try:
                df = pd.read_excel(request.files['excel'])
                c = 0
                for _, row in df.iterrows():
                    base = str(row.get('base_id','')).strip()
                    ids_raw = str(row.get('ids','')).strip()
                    title = str(row.get('title','')).strip()
                    author = str(row.get('author','')).strip() or "Unknown"
                    category = str(row.get('category','')).strip() or "Uncategorized"
                    if base and ids_raw and title:
                        for single_id in parse_range_to_set(ids_raw):
                            fid = f"{base}/{single_id}"
                            if school_get(Book, fid, pk_name='book_id'):
                                continue
                            book = Book(
                                book_id=fid,
                                title=title,
                                author=author,
                                category=category,
                                added_at=datetime.now().strftime("%Y-%m-%d"),
                            )
                            stamp_sync_fields(book)
                            db.session.add(book)
                            db.session.flush()
                            queue_record_change('books', book, operation='upsert')
                            c += 1
                db.session.commit()
                log_action("/books", "IMPORT", f"Imported {c} books from Excel.")
                flash(f"Imported {c} books.", "success")
            except Exception as e: flash(str(e), "danger")
            return redirect(url_for('main.books'))

    # GET
    search_query = request.args.get('q', '').strip()
    category_filter = request.args.get('category_filter', '').strip()
    sort_by = request.args.get('sort', 'date_desc')
    q = school_query(Book)
    if search_query:
        q = q.filter((Book.title.ilike(f"%{search_query}%")) | (Book.book_id.ilike(f"%{search_query}%")))
    if category_filter:
        q = q.filter(Book.category == category_filter)
    
    if sort_by == 'title_asc': q = q.order_by(Book.title.asc())
    elif sort_by == 'title_desc': q = q.order_by(Book.title.desc())
    else: q = q.order_by(Book.added_at.desc())
        
    return render_template(
        'manage_books.html',
        books=q.all(),
        suggested_id=generate_unique_base_id(),
        search_query=search_query,
        category_filter=category_filter,
        sort_by=sort_by,
    )

# --- EXPORT ROUTES ---
@main.route('/books/export/excel')
@login_required
def export_books_excel():
    books = Book.query.all()
    data = [
        {
            'Book ID': b.book_id,
            'Title': b.title,
            'Author': b.author,
            'Category': b.category or 'Uncategorized',
            'Added': b.added_at,
        }
        for b in books
    ]
    df = pd.DataFrame(data)
    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False)
    output.seek(0)
    return send_file(output, download_name="Library_Books.xlsx", as_attachment=True)

@main.route('/books/export/pdf')
@login_required
def export_books_pdf():
    books = Book.query.all()
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    elements = []
    
    styles = getSampleStyleSheet()
    elements.append(Paragraph("Library Book Catalog", styles['Title']))
    elements.append(Spacer(1, 12))
    
    data = [['ID', 'Title', 'Author', 'Category']]
    for b in books:
        data.append([b.book_id, b.title, b.author, b.category or 'Uncategorized'])
        
    table = Table(data, colWidths=[95, 215, 120, 120])
    table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#4e73df')),
        ('TEXTCOLOR', (0,0), (-1,0), colors.whitesmoke),
        ('ALIGN', (0,0), (-1,-1), 'LEFT'),
        ('GRID', (0,0), (-1,-1), 1, colors.black)
    ]))
    
    elements.append(table)
    doc.build(elements)
    buffer.seek(0)
    return send_file(buffer, download_name="Library_Books.pdf", as_attachment=True)

@main.route('/download_books_template')
@login_required
def download_books_template():
    data = {
        "base_id": ["321-54-100"],
        "ids": ["1-50"],
        "title": ["Math S1"],
        "author": ["REB"],
        "category": ["Student Books"],
    }
    df = pd.DataFrame(data)
    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False)
    output.seek(0)
    return send_file(output, as_attachment=True, download_name="books_import_template.xlsx")

# --- STUDENTS / CLASSES MANAGEMENT ---
@main.route('/students', methods=['GET', 'POST'])
@login_required
def students():
    skipped_students = []
    
    # Helper to clean class names (remove spaces, uppercase)
    def clean_cls(c):
        return str(c).strip().replace(" ", "").upper()

    # 1. HANDLE ALL POST ACTIONS
    if request.method == 'POST':
        action = request.form.get('action')
        
        # --- A. IMPORT EXCEL ---
        if 'excel' in request.files:
            file = request.files['excel']
            if file.filename:
                try:
                    df = pd.read_excel(file)
                    added_count = 0
                    
                    for class_name in df.columns:
                        clean_class = clean_cls(class_name)
                        # Skip empty or unnamed columns
                        if not clean_class or "Unnamed" in clean_class: continue
                        
                        students_in_class = df[class_name].dropna().astype(str).tolist()
                        
                        for student_name in students_in_class:
                            clean_name = student_name.strip()
                            if not clean_name: continue
                            
                            # Check duplicates
                            exists = school_query(Student).filter_by(name=clean_name, student_class=clean_class).first()
                            if not exists:
                                student = Student(name=clean_name, student_class=clean_class)
                                stamp_sync_fields(student)
                                db.session.add(student)
                                db.session.flush()
                                queue_record_change('members', student, operation='upsert')
                                added_count += 1
                            else:
                                skipped_students.append({'name': clean_name, 'class': clean_class, 'reason': 'Already exists'})
                                
                    db.session.commit()
                    
                    # LOGIC FIX:
                    # If we have skipped students, we DO NOT redirect. 
                    # We let the code "fall through" to the bottom so it renders the page WITH the modal 
                    # AND calculates the class list correctly.
                    if skipped_students:
                        flash(f"Imported {added_count} students. Some duplicates were skipped.", "warning")
                    else:
                        flash(f"Successfully imported {added_count} students.", "success")
                        return redirect(url_for('main.students'))
                        
                except Exception as e:
                    flash(f"Error processing file: {str(e)}", "danger")
                    return redirect(url_for('main.students'))

        # --- B. ADD STUDENT ---
        elif action == 'add':
            name = request.form.get('name').strip()
            s_class = clean_cls(request.form.get('student_class'))
            
            if school_query(Student).filter_by(name=name, student_class=s_class).first():
                flash(f"Student {name} already exists in {s_class}.", "warning")
            else:
                student = Student(name=name, student_class=s_class)
                stamp_sync_fields(student)
                db.session.add(student)
                db.session.flush()
                queue_record_change('members', student, operation='upsert')
                db.session.commit()
                flash(f"Added {name} to {s_class}.", "success")
            return redirect(url_for('main.students'))

        # EDIT STUDENT (UPDATED: Strict Protection)
        elif action == 'edit':
            student = school_get(Student, request.form.get('student_id'))
            if student:
                old_name = student.name
                old_class = student.student_class
                new_name = request.form.get('name').strip()
                new_class = clean_cls(request.form.get('student_class'))

                # Update student record
                student.name = new_name
                student.student_class = new_class
                stamp_sync_fields(student)

                # Propagate changes to active and archived loan records
                BorrowedBook.query.filter_by(student_name=old_name).update({ 'student_name': new_name, 'student_class': new_class })
                GraduateBorrowing.query.filter_by(student_name=old_name).update({ 'student_name': new_name })

                # Also update responsibles in ClassBorrowing rows where this student is listed
                for cl in school_query(ClassBorrowing).filter(ClassBorrowing.responsibles.like(f"%{old_name}%")): 
                    try:
                        resp = cl.responsibles
                        updated = ", ".join([new_name if x.strip()==old_name else x for x in [r.strip() for r in resp.split(',')]])
                        cl.responsibles = updated
                    except:
                        continue

                queue_record_change('members', student, operation='upsert')
                db.session.commit()
                flash("Student details updated and propagated to borrow records.", "success")
            return redirect(url_for('main.students'))

        # DELETE STUDENT (UPDATED: Strict Protection)
        elif action == 'delete':
            sid = request.form.get('student_id')
            student = school_get(Student, sid)
            if student:
                # Check Student Loans
                if school_query(BorrowedBook).filter_by(student_name=student.name, returned=False).first():
                    flash(f"Cannot delete {student.name}. Active student loans exist.", "danger")
                # Check Graduate Debt (Unlikely if in student list, but possible if re-added)
                elif school_query(GraduateBorrowing).filter_by(student_name=student.name).first():
                    flash(f"Cannot delete {student.name}. They have archived debts.", "danger")
                else:
                    stamp_sync_fields(student, deleted=True)
                    queue_record_change('members', student, operation='delete')
                    db.session.delete(student)
                    db.session.commit()
                    flash("Student removed.", "success")
            return redirect(url_for('main.students'))

        # RENAME CLASS (UPDATED: Strict Protection)
        elif action == 'edit_class':
            old_class = request.form.get('old_class_name')
            new_class = clean_cls(request.form.get('new_class_name'))

            # Update students
            students_to_move = school_query(Student).filter_by(student_class=old_class).all()
            for s in students_to_move:
                s.student_class = new_class
                stamp_sync_fields(s)
                queue_record_change('members', s, operation='upsert')

            # Update borrowed book records for students
            school_query(BorrowedBook).filter_by(student_class=old_class).update({ 'student_class': new_class })

            # Update class borrowings that reference this class name
            for cl in school_query(ClassBorrowing).filter_by(class_name=old_class).all():
                cl.class_name = new_class

            # Update archived graduate class borrowings as well
            for gcl in school_query(GraduateClassBorrowing).filter_by(class_name=old_class).all():
                gcl.class_name = new_class

            db.session.commit()
            flash(f"Renamed class {old_class} to {new_class} and updated related loan records.", "success")
            return redirect(url_for('main.students'))

        # DELETE CLASS (UPDATED: Strict Protection)
        elif action == 'delete_class':
            cls_name = request.form.get('class_name')
            if ClassBorrowing.query.filter_by(class_name=cls_name, returned=False).first():
                flash(f"Cannot delete {cls_name}. Active class loans exist.", "danger")
            elif BorrowedBook.query.filter_by(student_class=cls_name, returned=False).first():
                flash(f"Cannot delete {cls_name}. Students in this class have active loans.", "danger")
            else:
                Student.query.filter_by(student_class=cls_name).delete()
                db.session.commit()
                flash(f"Deleted Class {cls_name}.", "success")
            return redirect(url_for('main.students'))

        # --- G. PROMOTE LOGIC ---
        elif action == 'promote':
            promo_name = request.form.get('promotion_name')
            
            # --- STEP 1: Handle Class Loans FIRST ---
            active_class_loans = ClassBorrowing.query.filter_by(returned=False).all()
            
            for cloan in active_class_loans:
                cls = cloan.class_name.upper()
                
                # Check if this class is graduating
                if cls.startswith('S3') or cls.startswith('S6'):
                    
                    # 1. Fetch Full Roster
                    all_members = Student.query.filter_by(student_class=cloan.class_name).all()
                    
                    if all_members:
                        full_roster_str = ", ".join([s.name for s in all_members])
                    else:
                        full_roster_str = cloan.responsibles # Fallback

                    # 2. FORMAT: "Monitor Name || Full Student List"
                    # This keeps the monitor separate for the table view
                    combined_responsibles = f"{cloan.responsibles}||{full_roster_str}"

                    archive_class = GraduateClassBorrowing(
                        promotion_name=promo_name,
                        class_name=cloan.class_name,
                        responsibles=combined_responsibles, # <--- SAVES BOTH
                        book_title=cloan.book_title,
                        book_ids=cloan.book_ids,
                        quantity=cloan.quantity,
                        condition=cloan.condition,
                        borrow_time=cloan.borrow_time
                    )
                    db.session.add(archive_class)
                    db.session.delete(cloan)
                
                # B. Handle Promotion for non-graduating classes (Rename S1->S2, etc.)
                else:
                    new_cls = cls
                    if cls.startswith('S1'): new_cls = cls.replace('S1', 'S2', 1)
                    elif cls.startswith('S2'): new_cls = cls.replace('S2', 'S3', 1)
                    elif cls.startswith('S4'): new_cls = cls.replace('S4', 'S5', 1)
                    elif cls.startswith('S5'): new_cls = cls.replace('S5', 'S6', 1)
                    
                    if new_cls != cls:
                        cloan.class_name = new_cls

            # --- STEP 2: Handle Individual Students (Promote or Delete) ---
            all_students = Student.query.all()
            graduates_moved = 0
            promoted_count = 0
            
            for s in all_students:
                cls = s.student_class.upper()
                
                # Graduating Students
                if cls.startswith('S3') or cls.startswith('S6'):
                    # Archive their active loans
                    active_loans = BorrowedBook.query.filter_by(student_name=s.name, student_class=s.student_class, returned=False).all()
                    
                    for loan in active_loans:
                        archive = GraduateBorrowing(
                            promotion_name=promo_name,
                            student_name=s.name,
                            original_class=s.student_class,
                            book_id=loan.book_id,
                            book_title=loan.book_title,
                            notes=loan.condition,
                            timestamp=loan.timestamp,
                            due_date=loan.due_date
                        )
                        db.session.add(archive)
                        db.session.delete(loan)
                        graduates_moved += 1
                    
                    # DELETE THE STUDENT (Now safe, as class roster is already saved)
                    db.session.delete(s)
                    
                # Promoting Students
                else:
                    new_cls = cls
                    if cls.startswith('S1'): new_cls = cls.replace('S1', 'S2', 1)
                    elif cls.startswith('S2'): new_cls = cls.replace('S2', 'S3', 1)
                    elif cls.startswith('S4'): new_cls = cls.replace('S4', 'S5', 1)
                    elif cls.startswith('S5'): new_cls = cls.replace('S5', 'S6', 1)
                    
                    if new_cls != cls:
                        s.student_class = new_cls
                        # Update their active loans
                        loans = BorrowedBook.query.filter_by(student_name=s.name, student_class=cls, returned=False).all()
                        for l in loans: l.student_class = new_cls
                        promoted_count += 1
            
            db.session.commit()
            flash(f"Promotion Complete! {promoted_count} promoted. {graduates_moved} student loans archived.", "success")
            return redirect(url_for('main.students'))

    # 2. HANDLE DISPLAY (GET Logic)
    # This runs for GET requests AND for Import POST requests that had duplicates
    
    # A. Filtering & Search
    search_query = request.args.get('q', '').strip()
    sort_by = request.args.get('sort', 'class_asc') # Default sort
    
    query = Student.query
    if search_query:
        query = query.filter(
            (Student.name.ilike(f"%{search_query}%")) |
            (Student.student_class.ilike(f"%{search_query}%"))
        )
    
    # B. Sorting (Restored!)
    if sort_by == 'class_asc':
        query = query.order_by(Student.student_class.asc(), Student.name.asc())
    elif sort_by == 'class_desc':
        query = query.order_by(Student.student_class.desc(), Student.name.asc())
    elif sort_by == 'name_asc':
        query = query.order_by(Student.name.asc())
    elif sort_by == 'name_desc':
        query = query.order_by(Student.name.desc())
        
    students_list = query.all()
    
    # C. Class List Calculation (Fixed!)
    # We calculate this fresh every time so it appears immediately after import
    unique_classes = sorted(list(set([s.student_class for s in Student.query.all()])))
    class_stats = []
    for c in unique_classes:
        count = Student.query.filter_by(student_class=c).count()
        class_stats.append({'name': c, 'count': count})

    return render_template('students.html', 
                         students=students_list, 
                         classes=class_stats, 
                         search_query=search_query,
                         sort_by=sort_by,
                         skipped_students=skipped_students)

# --- EXPORT: EXCEL (Formatted by Class Column) ---
@main.route('/students/export/excel')
@login_required
def export_students_excel():
    # 1. Get all students and group them by class
    students = Student.query.all()
    data_map = {}
    
    for s in students:
        if s.student_class not in data_map:
            data_map[s.student_class] = []
        data_map[s.student_class].append(s.name)
        
    # 2. Sort Classes (optional, makes columns A-Z)
    sorted_classes = sorted(data_map.keys())
    
    # 3. Find max length to pad columns (pandas requires equal length)
    max_len = 0
    if data_map:
        max_len = max(len(v) for v in data_map.values())
        
    final_dict = {}
    for cls in sorted_classes:
        # Pad list with empty strings so all columns are same length
        students_list = data_map[cls]
        padded_list = students_list + [''] * (max_len - len(students_list))
        final_dict[cls] = padded_list
        
    # 4. Create DataFrame
    df = pd.DataFrame(final_dict)
    
    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False)
    output.seek(0)
    
    return send_file(output, download_name="students_list.xlsx", as_attachment=True)

# --- EXPORT: PDF (Grouped Tables) ---
@main.route('/students/export/pdf')
@login_required
def export_students_pdf():
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    elements = []
    styles = getSampleStyleSheet()
    
    # Title
    elements.append(Paragraph("Students List", styles['Title']))
    elements.append(Spacer(1, 20))
    
    # Get all distinct classes
    classes = db.session.query(Student.student_class).distinct().order_by(Student.student_class).all()
    classes = [c[0] for c in classes] # flatten result
    
    for class_name in classes:
        # Header for the Class
        elements.append(Paragraph(f"<b>Class: {class_name}</b>", styles['Heading2']))
        elements.append(Spacer(1, 5))
        
        # Get students for this class
        students = Student.query.filter_by(student_class=class_name).order_by(Student.name).all()
        
        if not students: continue
        
        # Table Data
        data = [['No.', 'Student Name']]
        for i, s in enumerate(students, 1):
            data.append([str(i), s.name])
            
        # Table Style
        table = Table(data, colWidths=[50, 400])
        table.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#4e73df')),
            ('TEXTCOLOR', (0,0), (-1,0), colors.whitesmoke),
            ('ALIGN', (0,0), (-1,-1), 'LEFT'),
            ('GRID', (0,0), (-1,-1), 1, colors.black),
            ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
            ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.whitesmoke, colors.white]),
        ]))
        
        elements.append(table)
        elements.append(Spacer(1, 20)) # Space between tables
        
    doc.build(elements)
    buffer.seek(0)
    return send_file(buffer, download_name="students_list.pdf", as_attachment=True)

# --- NEW: STUDENT LIVE SEARCH API ---
@main.route('/api/search_students')
@login_required
def search_students_api():
    query = request.args.get('q', '').strip()
    class_filter = request.args.get('class', '').strip() # Get class parameter
    
    if not query:
        return jsonify([])
    
    db_query = school_query(Student)
    
    # If a class is selected, strict filter by that class
    if class_filter:
        db_query = db_query.filter(Student.student_class == class_filter)
    
    results = db_query.filter(Student.name.ilike(f"%{query}%")).limit(8).all()
    
    suggestions = [{'name': s.name, 'class': s.student_class} for s in results]
    return jsonify(suggestions)

@main.route('/download_student_template')
@login_required
def download_student_template():
    data = { "S1 A": ["MUGISHA"], "S5 MPC": ["ISHIMWE"] }
    df = pd.DataFrame(data)
    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False)
    output.seek(0)
    return send_file(output, as_attachment=True, download_name="student_import_template.xlsx")

# --- BORROW TRANSACTION ---
@main.route('/borrow', methods=['GET', 'POST'])
@login_required
def borrow():
    # Helper to calculate missing subset for display
    def get_missing_parts(base_id, id_set):
        missing_set = set()
        for i in id_set:
            if not Book.query.get(f"{base_id}/{i}"):
                missing_set.add(i)
        return set_to_range_string(missing_set)

    if request.method == 'POST':
        action = request.form.get('action')
        config = load_config()

        # --- 0. SPECIAL: QUICK ADD & BORROW HANDLER ---
        if action == 'quick_add_and_borrow':
            # A. Add ONLY the New (Missing) Books
            common_id = request.form.get('qa_common_id')
            unique_ids_to_create = request.form.get('qa_unique_ids') # This is the partial list (e.g. "3-5")
            title = request.form.get('qa_title')
            author = request.form.get('qa_author') or "Unknown"
            
            try:
                # Create only the missing ones
                id_set = parse_range_to_set(unique_ids_to_create)
                added_count = 0
                created_books = []
                for uid in id_set:
                    full_id = f"{common_id}/{uid}"
                    if not school_get(Book, full_id, pk_name='book_id'):
                        book = Book(
                            book_id=full_id,
                            title=title,
                            author=author,
                            added_at=datetime.now().strftime("%Y-%m-%d"),
                        )
                        stamp_sync_fields(book)
                        db.session.add(book)
                        created_books.append(book)
                        added_count += 1
                db.session.flush()
                for book in created_books:
                    queue_record_change('books', book, operation='upsert')
                db.session.commit()
                flash(f"Quick Added {added_count} new books.", "success")
            except Exception as e:
                flash(f"Error creating book: {str(e)}", "danger")
                return redirect(url_for('main.borrow'))

            # B. Resume Original Borrow Action (Using the FULL list)
            original_action = request.form.get('original_action')
            
            if original_action == 'student_borrow':
                s_name = request.form.get('qa_borrower')
                raw_ids = request.form.get('qa_ids_raw') # This has ALL IDs (existing + newly created)
                condition = request.form.get('qa_notes')
                
                student = Student.query.filter(Student.name.ilike(f"{s_name}")).first()
                student = school_query(Student).filter(Student.name.ilike(f"{s_name}")).first()
                if not student:
                    flash("Student not found during resume.", "danger"); return redirect(url_for('main.borrow'))
                
                id_list = [x.strip() for x in raw_ids.split(',') if x.strip()]
                
                success_count = 0
                days = config.get('default_borrow_days', 14)
                due = (datetime.now() + timedelta(days=days)).strftime("%Y-%m-%d")
                
                for b_id in id_list:
                    if not is_book_active(b_id): # Check availability
                        book = school_get(Book, b_id, pk_name='book_id') # Should exist now
                        if book:
                            loan = BorrowedBook(
                                book_id=book.book_id,
                                book_title=book.title,
                                student_name=student.name,
                                student_class=student.student_class,
                                condition=condition,
                                timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                                due_date=due,
                            )
                            stamp_sync_fields(loan)
                            db.session.add(loan)
                            db.session.flush()
                            queue_record_change('checkouts', loan, operation='upsert')
                            success_count += 1
                db.session.commit()
                log_action("/borrow", "STUDENT_BORROW", f"{current_user.username} issued {success_count} book(s) to {s_name}")
                safe_push_sync()
                flash(f"Complete! Issued {success_count} books to {s_name}.", "success")
                return redirect(url_for('main.borrow'))

            elif original_action == 'staff_borrow':
                t_name = request.form.get('qa_borrower')
                raw_ids = request.form.get('qa_ids_raw')
                notes = request.form.get('qa_notes')
                
                id_list = [x.strip() for x in raw_ids.split(',') if x.strip()]
                c = 0
                for b_id in id_list:
                    if not is_book_active(b_id):
                        book = school_get(Book, b_id, pk_name='book_id')
                        if book:
                            loan = TeacherBorrowedBook(
                                book_id=book.book_id,
                                book_title=book.title,
                                teacher_name=t_name,
                                notes=notes,
                                timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                            )
                            stamp_sync_fields(loan)
                            db.session.add(loan)
                            db.session.flush()
                            queue_record_change('staff_checkouts', loan, operation='upsert')
                            c += 1
                db.session.commit()
                log_action("/borrow", "STAFF_BORROW", f"{current_user.username} issued {c} book(s) to {t_name}")
                safe_push_sync()
                flash(f"Complete! Issued {c} books to {t_name}.", "success")
                return redirect(url_for('main.borrow'))

            elif original_action == 'class_borrow':
                c_name = request.form.get('qa_borrower')
                responsibles = request.form.get('qa_responsibles')
                notes = request.form.get('qa_notes')
                full_range_str = request.form.get('qa_ids_raw') # e.g. "100-20/1-10"
                
                base_id, unique_ids = full_range_str.split('/', 1)
                id_set = parse_range_to_set(unique_ids)
                
                # Fetch title from one of the books (now they all exist)
                ref_book = school_query(Book).filter(Book.book_id.like(f"{base_id}/%")).first()
                title = ref_book.title if ref_book else "Unknown"
                
                class_loan = ClassBorrowing(
                    class_name=c_name,
                    responsibles=responsibles,
                    book_title=title,
                    book_ids=full_range_str,
                    quantity=len(id_set),
                    condition=notes,
                    borrow_time=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                )
                stamp_sync_fields(class_loan)
                db.session.add(class_loan)
                db.session.flush()
                queue_record_change('class_checkouts', class_loan, operation='upsert')
                db.session.commit()
                log_action("/borrow", "CLASS_BORROW", f"{current_user.username} issued {len(id_set)} class book(s) to {c_name}")
                safe_push_sync()
                flash(f"Complete! Issued to class {c_name}.", "success")
                return redirect(url_for('main.borrow'))


        # --- 1. STUDENT BORROW ---
        if action == 'student_borrow':
            s_name = request.form.get('student_name')
            raw_ids = request.form.get('book_ids_hidden', '')
            condition = request.form.get('condition') or "Good"
            
            student = school_query(Student).filter(Student.name.ilike(f"{s_name}")).first()
            if not student:
                flash(f"Error: Student '{s_name}' not found.", "danger")
                return redirect(url_for('main.borrow'))

            id_list = [x.strip() for x in raw_ids.split(',') if x.strip()]
            if not id_list:
                flash("No books selected.", "warning"); return redirect(url_for('main.borrow'))

            # CHECK FOR MISSING BOOKS
            missing_ids = [bid for bid in id_list if not school_get(Book, bid, pk_name='book_id')]
            
            if missing_ids:
                first_missing = missing_ids[0]
                base_id = first_missing.split('/')[0] if '/' in first_missing else first_missing
                
                # Calculate ONLY the unique parts that are missing
                missing_uniques_set = set()
                for m in missing_ids:
                    if '/' in m: missing_uniques_set.add(int(m.split('/')[1]))
                    else: missing_uniques_set.add(int(m)) # Fallback
                
                missing_range_str = set_to_range_string(missing_uniques_set)
                
                qa_data = {
                    'original_action': 'student_borrow',
                    'borrower': s_name,
                    'ids_raw': raw_ids, # Keep FULL list for resume
                    'notes': condition,
                    'base_id': base_id,
                    'unique_ids': missing_range_str, # Show ONLY missing range
                    'responsibles': ''
                }
                return render_template('borrow.html', quick_add_data=qa_data)

            # Normal Processing
            current_loans = school_query(BorrowedBook).filter_by(student_name=student.name, returned=False).count()
            limit = config.get('max_books_per_student', 3)
            if current_loans + len(id_list) > limit:
                flash(f"Limit Reached: Student has {current_loans}/{limit} books.", "danger")
                return redirect(url_for('main.borrow'))

            count = 0
            due = (datetime.now() + timedelta(days=config.get('default_borrow_days', 14))).strftime("%Y-%m-%d")
            for b_id in id_list:
                if not is_book_active(b_id):
                    book = school_get(Book, b_id, pk_name='book_id')
                    loan = BorrowedBook(
                        book_id=b_id,
                        book_title=book.title,
                        student_name=student.name,
                        student_class=student.student_class,
                        condition=condition,
                        timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        due_date=due,
                    )
                    stamp_sync_fields(loan)
                    db.session.add(loan)
                    db.session.flush()
                    queue_record_change('checkouts', loan, operation='upsert')
                    count += 1
                else:
                    flash(f"Book {b_id} is already borrowed.", "warning")
            
            db.session.commit()
            if count:
                log_action("/borrow", "STUDENT_BORROW", f"{current_user.username} issued {count} book(s) to {student.name}")
                safe_push_sync()
            if count: flash(f"Issued {count} books.", "success")
        
        # --- 2. STAFF BORROW ---
        elif action == 'staff_borrow':
            t_name = request.form.get('staff_name')
            raw_ids = request.form.get('book_ids_hidden_staff') or request.form.get('book_ids_hidden', '')
            notes = request.form.get('notes', '')
            
            id_list = [x.strip() for x in raw_ids.split(',') if x.strip()]
            
            # CHECK MISSING
            missing_ids = [bid for bid in id_list if not school_get(Book, bid, pk_name='book_id')]
            if missing_ids:
                first_missing = missing_ids[0]
                base_id = first_missing.split('/')[0] if '/' in first_missing else first_missing
                
                missing_uniques_set = set()
                for m in missing_ids:
                    if '/' in m: missing_uniques_set.add(int(m.split('/')[1]))
                missing_range_str = set_to_range_string(missing_uniques_set)
                
                qa_data = {
                    'original_action': 'staff_borrow',
                    'borrower': t_name,
                    'ids_raw': raw_ids,
                    'notes': notes,
                    'base_id': base_id,
                    'unique_ids': missing_range_str,
                    'responsibles': ''
                }
                return render_template('borrow.html', quick_add_data=qa_data)

            count = 0
            for b_id in id_list:
                book = school_get(Book, b_id, pk_name='book_id')
                if book and not is_book_active(b_id):
                    loan = TeacherBorrowedBook(
                        book_id=book.book_id,
                        book_title=book.title,
                        teacher_name=t_name,
                        notes=notes,
                        timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    )
                    stamp_sync_fields(loan)
                    db.session.add(loan)
                    db.session.flush()
                    queue_record_change('staff_checkouts', loan, operation='upsert')
                    count += 1
            db.session.commit()
            if count:
                log_action("/borrow", "STAFF_BORROW", f"{current_user.username} issued {count} book(s) to {t_name}")
                safe_push_sync()
            if count: flash(f"Issued {count} books.", "success")

        # --- 3. CLASS BORROW ---
        elif action == 'class_borrow':
            c_name = request.form.get('class_name', '').strip()
            responsibles = request.form.get('responsibles', '')
            base_id = request.form.get('base_id', '').strip()
            unique_ids = request.form.get('unique_ids', '').strip()
            notes = request.form.get('condition')
            
            if not school_query(Student).filter(Student.student_class.ilike(c_name)).first():
                flash(f"Class '{c_name}' not found.", "danger"); return redirect(url_for('main.borrow'))
            
            id_set = parse_range_to_set(unique_ids)
            if not id_set:
                flash("Invalid ID range.", "danger"); return redirect(url_for('main.borrow'))

            # CHECK MISSING (PARTIAL LOGIC)
            missing_set = set()
            for i in id_set:
                if not school_get(Book, f"{base_id}/{i}", pk_name='book_id'):
                    missing_set.add(i)
            
            if missing_set:
                # We found some missing books!
                missing_range = set_to_range_string(missing_set) # e.g. "3-5"
                
                qa_data = {
                    'original_action': 'class_borrow',
                    'borrower': c_name,
                    'ids_raw': f"{base_id}/{unique_ids}", # FULL range for resume
                    'notes': notes,
                    'base_id': base_id,
                    'unique_ids': missing_range, # ONLY missing ones for creation
                    'responsibles': responsibles
                }
                # Also pass 'preserved_input' to repopulate the form
                qa_data['input_unique_ids'] = unique_ids 
                return render_template('borrow.html', quick_add_data=qa_data)

            # Normal Processing (All books exist)
            full_ids_requested = {f"{base_id}/{i}" for i in id_set}
            conflict = False
            for fid in full_ids_requested:
                if is_book_active(fid):
                    conflict = True; break
            
            if conflict:
                flash("Some books in this range are already borrowed.", "danger")
            else:
                ref_book = school_query(Book).filter(Book.book_id.like(f"{base_id}/%")).first()
                title = ref_book.title if ref_book else "Unknown"
                class_loan = ClassBorrowing(
                    class_name=c_name,
                    responsibles=responsibles,
                    book_title=title,
                    book_ids=f"{base_id}/{unique_ids}",
                    quantity=len(id_set),
                    condition=notes,
                    borrow_time=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                )
                stamp_sync_fields(class_loan)
                db.session.add(class_loan)
                db.session.flush()
                queue_record_change('class_checkouts', class_loan, operation='upsert')
                db.session.commit()
                log_action("/borrow", "CLASS_BORROW", f"{current_user.username} issued {len(id_set)} class book(s) to {c_name}")
                safe_push_sync()
                flash(f"Issued {len(id_set)} books to {c_name}.", "success")

        return redirect(url_for('main.borrow'))
    
    return render_template('borrow.html')

# --- TEMPLATE DOWNLOADS FOR LOANS ---
@main.route('/borrow/template/<type>')
@login_required
def download_loan_template(type):
    output = BytesIO()
    if type == 'student':
        data = {"Student Name": ["MUGISHA"], "Book ID": ["100-20/1"], "Condition": ["Good"]}
        name = "student_loan_template.xlsx"
    elif type == 'staff':
        data = {"Staff Name": ["Teacher John"], "Book ID": ["100-20/5"], "Condition": ["Good"]}
        name = "staff_loan_template.xlsx"
    elif type == 'class':
        data = {"Class": ["S3MPC"], "Responsibles": ["Alice"], "Base ID": ["100-20"], "Unique IDs": ["1-50"], "Condition": ["Good"]}
        name = "class_loan_template.xlsx"
    else:
        return redirect(url_for('main.borrow'))
        
    df = pd.DataFrame(data)
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False)
    output.seek(0)
    return send_file(output, as_attachment=True, download_name=name)

# --- AUTOCOMPLETE APIs ---
@main.route('/api/search_books')
@login_required
def search_books_api():
    query = request.args.get('q', '').strip()
    if not query: return jsonify([])
    results = school_query(Book).filter((Book.title.ilike(f"%{query}%")) | (Book.book_id.ilike(f"%{query}%"))).limit(8).all()
    return jsonify([{'id': b.book_id, 'title': b.title, 'author': b.author} for b in results])

@main.route('/api/search_staff')
@login_required
def search_staff_api():
    query = request.args.get('q', '').strip()
    if not query: return jsonify([])
    # Search unique names from previous teacher loans
    results = school_query(TeacherBorrowedBook).with_entities(TeacherBorrowedBook.teacher_name).filter(TeacherBorrowedBook.teacher_name.ilike(f"%{query}%")).distinct().limit(8).all()
    return jsonify([{'name': r[0]} for r in results])

@main.route('/api/search_classes')
@login_required
def search_classes_api():
    query = request.args.get('q', '').strip()
    if not query: return jsonify([])
    # Search distinct classes from Student table
    results = school_query(Student).with_entities(Student.student_class).filter(Student.student_class.ilike(f"%{query}%")).distinct().limit(8).all()
    return jsonify([{'name': r[0]} for r in results])

@main.route('/api/sync/upload', methods=['POST'])
@login_required
def sync_upload():
    sync_service = get_sync_service()
    if not sync_service:
        return jsonify({"success": False, "message": "Sync service unavailable."}), 503

    payload = request.get_json(silent=True) or {}
    items = payload.get('items', [])
    limit = int(payload.get('limit', current_app.config.get('SYNC_BATCH_SIZE', 100)))
    imported = 0

    try:
        if isinstance(items, list) and items:
            for item in items:
                entity_type = item.get('entity_type')
                operation = item.get('operation')
                operation_id = item.get('operation_id')
                item_payload = item.get('payload') or {}
                school_id = (
                    item_payload.get('school')
                    or item_payload.get('school_id')
                    or get_current_school_id()
                )
                entity_id = (
                    item_payload.get('book_id')
                    or item_payload.get('id')
                    or item.get('entity_id')
                    or operation_id
                )

                if not entity_type or not operation or not item_payload:
                    continue

                if operation_id and SyncQueue.query.filter_by(operation_id=operation_id).first():
                    continue

                item_payload.setdefault('school_id', school_id)
                sync_service.queue_change(
                    entity_type=entity_type,
                    entity_id=entity_id,
                    operation=operation,
                    payload=item_payload,
                    school_id=school_id,
                    record_updated_at=item_payload.get('updated_at'),
                    operation_id=operation_id,
                )
                imported += 1
            db.session.commit()

        summary = sync_service.upload_pending_changes(
            school_id=get_current_school_id(),
            limit=limit,
        )
        return jsonify({
            "success": True,
            "imported": imported,
            "summary": summary,
            "status": sync_service.get_status(get_current_school_id()),
        })
    except Exception as exc:
        db.session.rollback()
        return jsonify({"success": False, "message": str(exc)}), 500


@main.route('/api/sync/download', methods=['POST'])
@login_required
def sync_download():
    sync_service = get_sync_service()
    if not sync_service:
        return jsonify({"success": False, "message": "Sync service unavailable."}), 503

    payload = request.get_json(silent=True) or {}
    limit = int(payload.get('limit', 250))

    try:
        summary = sync_service.download_remote_changes(
            school_id=get_current_school_id(),
            limit=limit,
        )
        return jsonify({
            "success": True,
            "summary": summary,
            "status": sync_service.get_status(get_current_school_id()),
        })
    except Exception as exc:
        return jsonify({"success": False, "message": str(exc)}), 500


@main.route('/api/sync/status')
@login_required
def sync_status():
    sync_service = get_sync_service()
    if not sync_service:
        return jsonify({"success": False, "message": "Sync service unavailable."}), 503

    school_id = get_current_school_id()
    status = sync_service.get_status(school_id)
    recent_queue = (
        SyncQueue.query.filter_by(school_id=school_id)
        .order_by(SyncQueue.created_at.desc())
        .limit(20)
        .all()
    )
    status["recent_queue"] = [
        {
            "entity_type": item.entity_type,
            "entity_id": item.entity_id,
            "operation": item.operation,
            "status": item.status,
            "attempt_count": item.attempt_count,
            "last_error": item.last_error,
            "created_at": item.created_at.isoformat() if item.created_at else None,
        }
        for item in recent_queue
    ]
    status["success"] = True
    return jsonify(status)


@main.route('/api/sync/conflicts/<int:conflict_id>/resolve', methods=['POST'])
@login_required
def resolve_sync_conflict(conflict_id):
    sync_service = get_sync_service()
    if not sync_service:
        return jsonify({"success": False, "message": "Sync service unavailable."}), 503

    payload = request.get_json(silent=True) or {}
    resolution = payload.get('resolution')
    merged_payload = payload.get('merged_payload')

    try:
        resolved = sync_service.resolve_conflict(conflict_id, resolution, merged_payload)
        return jsonify({"success": True, "resolved": resolved})
    except Exception as exc:
        return jsonify({"success": False, "message": str(exc)}), 400


@main.route('/api/cloud-sync/status', methods=['GET'])
@login_required
def cloud_sync_status():
    return sync_status()


@main.route('/api/cloud-sync/upload', methods=['POST'])
@login_required
def cloud_sync_upload():
    return sync_upload()


@main.route('/api/cloud-sync/download', methods=['POST'])
@login_required
def cloud_sync_download():
    return sync_download()


@main.route('/api/cloud-sync/conflicts/<int:conflict_id>/resolve', methods=['POST'])
@login_required
def resolve_cloud_conflict(conflict_id):
    return resolve_sync_conflict(conflict_id)

# --- ACTIVE LOANS (4 SECTIONS) ---
@main.route('/borrowed')
@login_required
def borrowed():
    # 1. Students
    students = school_query(BorrowedBook).filter_by(returned=False).order_by(BorrowedBook.id.desc()).all()
    # 2. Graduates (Individual)
    graduates = school_query(GraduateBorrowing).all()
    # 3. Staff
    staff = school_query(TeacherBorrowedBook).filter_by(returned=False).all()
    # 4. Classes (Active)
    classes = school_query(ClassBorrowing).filter_by(returned=False).all()
    # 5. NEW: Archived Class Loans
    grad_classes = school_query(GraduateClassBorrowing).all()
    # 6. Issues (if any)
    try:
        issues = school_query(BookIssue).order_by(BookIssue.created_at.desc()).all()
    except Exception:
        issues = []

    # Build issue_map and issue_details similar to the newer implementation
    from collections import defaultdict
    issue_map = defaultdict(list)
    issue_details = []
    if issues:
        for issue in issues:
            key = f"{issue.loan_type}_{issue.loan_id}"
            issue_map[key].append(issue)

            borrower = 'Unknown'
            extra = ''
            if issue.loan_type == 'student':
                loan = school_get(BorrowedBook, issue.loan_id)
                if loan:
                    borrower = loan.student_name
                    extra = loan.student_class
            elif issue.loan_type == 'staff':
                loan = school_get(TeacherBorrowedBook, issue.loan_id)
                if loan:
                    borrower = loan.teacher_name
            elif issue.loan_type == 'class':
                loan = school_get(ClassBorrowing, issue.loan_id)
                if loan:
                    borrower = loan.class_name
            elif issue.loan_type == 'graduate':
                loan = school_get(GraduateBorrowing, issue.loan_id)
                if loan:
                    borrower = loan.student_name

            issue_details.append({'issue': issue, 'borrower': borrower, 'extra': extra})
    
    return render_template('borrowed_list.html', 
                         students=students, 
                         graduates=graduates,
                         staff=staff,
                         classes=classes,
                         grad_classes=grad_classes,
                         issues=issues,
                         issue_map=issue_map,
                         issue_details=issue_details)

# --- RETURN ROUTES ---


@main.route('/return/<int:id>', methods=['POST'])
@login_required
def return_book(id):
    # 1. FETCH LOAN
    loan = school_get_or_404(BorrowedBook, id)
    
    # 2. CHECK FOR ISSUE FLAG (The "Split" Logic)
    has_issue = request.form.get('has_issue')
    
    if has_issue == 'yes':
        # --- BRANCH A: RETURN WITH ISSUES ---
        try:
            description = request.form.get('issue_description')
            cost_input = request.form.get('repair_cost', '0').strip()
            cost = float(cost_input) if cost_input else 0.0
            
            new_issue = BookIssue(
                loan_id=loan.id,
                loan_type='student',
                issue_description=description,
                repair_cost=cost,
                created_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            )
            db.session.add(new_issue)
            flash("Book returned with  issue(s) recorded.", "success")
            
            
        except ValueError:
            flash("Error: Invalid repair cost format.", "danger")
            return redirect(url_for('main.borrowed'))
            
    else:
        # --- BRANCH B: NORMAL RETURN ---
        flash("Book returned successfully (Good Condition).", "success")

    # 3. CLOSE THE LOAN (Common Action)
    loan.returned = True
    loan.return_date = datetime.now().strftime("%Y-%m-%d")
    stamp_sync_fields(loan)
    queue_record_change('checkouts', loan, operation='upsert')
    
    db.session.commit()
    log_action("/return", "RETURN_BOOK", f"{current_user.username} returned {loan.book_title} for {loan.student_name}")
    safe_push_sync()
    return redirect(url_for('main.borrowed'))

@main.route('/return_grad_class/<int:id>', methods=['POST'])
@login_required
def return_grad_class(id):
    loan = school_get_or_404(GraduateClassBorrowing, id)
    return_type = request.form.get('return_type')
    returned_names = request.form.getlist('returned_members')
    
    # 1. PARTIAL RETURN
    if return_type == 'partial':
        ids_to_return_str = request.form.get('return_ids', '')
        
        if '/' not in loan.book_ids:
            flash("Database Error: Invalid ID format.", "danger")
            return redirect(url_for('main.borrowed'))
            
        base_id, current_range_str = loan.book_ids.split('/', 1)
        current_set = parse_range_to_set(current_range_str)
        returning_set = parse_range_to_set(ids_to_return_str)
        new_set = current_set - returning_set
        
        # --- A. UPDATE MEMBER LIST ---
        if returned_names:
            # 1. Extract Monitor and List
            raw_data = loan.responsibles or ""
            if '||' in raw_data:
                monitor_part, list_part = raw_data.split('||', 1)
            else:
                monitor_part = raw_data # Fallback for old data
                list_part = raw_data

            # 2. Process List
            current_list = [s.strip() for s in list_part.split(',') if s.strip()]
            updated_list = []
            
            for member in current_list:
                clean_name = member.replace('(Returned)', '').strip()
                if clean_name in returned_names or f"{clean_name} (Returned)" in list_part:
                    updated_list.append(f"{clean_name} (Returned)")
                else:
                    updated_list.append(clean_name)
            
            # 3. Save Back (Monitor || Updated List)
            # If we had a split, preserve it. If not, just save the list.
            if '||' in raw_data:
                loan.responsibles = f"{monitor_part}||{', '.join(updated_list)}"
            else:
                loan.responsibles = ", ".join(updated_list)

        # --- B. UPDATE BOOKS ---
        if len(new_set) == 0:
            db.session.delete(loan)
            flash("All books returned. Class debt cleared.", "success")
        else:
            if returning_set:
                from .routes import set_to_range_string
                new_range_str = set_to_range_string(new_set)
                loan.book_ids = f"{base_id}/{new_range_str}"
                loan.quantity = len(new_set)
                flash(f"Returned {len(returning_set)} books. Records updated.", "success")
            else:
                flash("Student list updated.", "info")
            
    # 2. FULL RETURN
    elif return_type == 'full':
        db.session.delete(loan)
        flash("All books returned.", "success")
        
    else:
        flash("Please select an action.", "warning")

    db.session.commit()
    log_action("/return_grad_class", "RETURN_GRAD_CLASS", f"{current_user.username} updated graduate class return for {loan.class_name}")
    safe_push_sync()
    return redirect(url_for('main.borrowed'))

@main.route('/return_graduate/<int:id>', methods=['POST'])
@login_required
def return_graduate(id):
    grad_loan = school_get_or_404(GraduateBorrowing, id)
    has_issue = request.form.get('has_issue')
    if has_issue == 'yes':
        try:
            issue = BookIssue(
                loan_id=grad_loan.id,
                loan_type='graduate',
                issue_description=request.form.get('issue_description'),
                repair_cost=float(request.form.get('repair_cost') or 0)
            )
            db.session.add(issue)
        except Exception:
            pass
    db.session.delete(grad_loan)
    db.session.commit()
    log_action("/return_graduate", "RETURN_GRADUATE", f"{current_user.username} cleared graduate debt for {grad_loan.student_name}")
    safe_push_sync()
    flash("Graduate debt cleared.", "success")
    return redirect(url_for('main.borrowed'))

@main.route('/return_staff/<int:id>', methods=['POST'])
@login_required
def return_staff(id):
    loan = school_get_or_404(TeacherBorrowedBook, id)
    loan.returned = True
    stamp_sync_fields(loan)
    has_issue = request.form.get('has_issue')
    if has_issue == 'yes':
        try:
            issue = BookIssue(
                loan_id=loan.id,
                loan_type='staff',
                issue_description=request.form.get('issue_description'),
                repair_cost=float(request.form.get('repair_cost') or 0)
            )
            db.session.add(issue)
        except Exception:
            pass
    queue_record_change('staff_checkouts', loan, operation='upsert')
    db.session.commit()
    log_action("/return_staff", "RETURN_STAFF", f"{current_user.username} returned {loan.book_title} for {loan.teacher_name}")
    safe_push_sync()
    flash("Staff book returned.", "success")
    return redirect(url_for('main.borrowed'))

@main.route('/return_class/<int:id>', methods=['POST'])
@login_required
def return_class(id):
    loan = school_get_or_404(ClassBorrowing, id)
    return_type = request.form.get('return_type')
    
    # NEW: Capture checked students from the "View Class List" modal
    returned_names = request.form.getlist('returned_members')
    
    if return_type == 'partial':
        ids_to_return_str = request.form.get('return_ids', '')
        
        if '/' not in loan.book_ids:
            flash("Database Error: Invalid ID format.", "danger")
            return redirect(url_for('main.borrowed'))
            
        base_id, current_range_str = loan.book_ids.split('/', 1)
        
        current_set = parse_range_to_set(current_range_str)
        returning_set = parse_range_to_set(ids_to_return_str)
        
        # Calculate Remaining
        new_set = current_set - returning_set
        
        # --- NEW LOGIC: Update Responsibles with Checkmarks ---
        if returned_names:
            current_text = loan.responsibles or ""
            # Fetch ALL students in this class to build the full tracking list
            all_students = school_query(Student).filter_by(student_class=loan.class_name).order_by(Student.name).all()
            all_names = [s.name for s in all_students]
            
            # Fallback if class roster is empty (e.g., deleted class)
            if not all_names: 
                all_names = [x.strip() for x in current_text.split(',') if x.strip()]

            new_resp_list = []
            for name in all_names:
                clean = name.strip()
                # Mark as (Returned) if checked now OR already marked previously
                if clean in returned_names or (f"{clean} (Returned)" in current_text):
                     new_resp_list.append(f"{clean} (Returned)")
                else:
                     new_resp_list.append(clean)
            
            loan.responsibles = ", ".join(new_resp_list)
        # ------------------------------------------------------
        
        if len(new_set) == len(current_set):
            flash("No matching IDs found to return.", "warning")
            return redirect(url_for('main.borrowed'))

        if len(new_set) == 0:
            loan.returned = True
            loan.return_date = datetime.now().strftime("%Y-%m-%d")
            loan.quantity = 0
            loan.book_ids = f"{base_id}/(Returned)"
            flash("All books returned.", "success")
        else:
            # FIX: Call the global helper function directly
            new_range_str = set_to_range_string(new_set)
            loan.book_ids = f"{base_id}/{new_range_str}"
            loan.quantity = len(new_set)
            flash(f"Returned {len(returning_set)} books. {loan.quantity} remaining.", "success")
            
    else:
        # Full Return (Keeps your existing Issue logic)
        loan.returned = True
        loan.return_date = datetime.now().strftime("%Y-%m-%d")
        
        # For class returns, allow form to indicate issue
        has_issue = request.form.get('has_issue')
        if has_issue == 'yes':
            try:
                # Ensure BookIssue is imported or available
                from .database import BookIssue 
                issue = BookIssue(
                    loan_id=loan.id,
                    loan_type='class',
                    issue_description=request.form.get('issue_description'),
                    repair_cost=float(request.form.get('repair_cost') or 0)
                )
                db.session.add(issue)
            except Exception:
                pass
        flash("All class books returned.", "success")

    stamp_sync_fields(loan)
    queue_record_change('class_checkouts', loan, operation='upsert')
    db.session.commit()
    log_action("/return_class", "RETURN_CLASS", f"{current_user.username} updated class return for {loan.class_name}")
    safe_push_sync()
    return redirect(url_for('main.borrowed'))

# --- CLASS BORROWING ---
@main.route('/class_borrowing')
@login_required
def class_borrowing():
    records = school_query(ClassBorrowing).order_by(ClassBorrowing.borrow_time.desc()).all()
    return render_template('class_borrowing.html', borrowings=records)

@main.route('/class_borrowing/add', methods=['POST'])
@login_required
def class_borrowing_add():
    class_name = (request.form.get('class_name') or '').strip()
    book_title = (request.form.get('book_title') or '').strip()
    if not class_name or not book_title:
        flash("Class name and book title are required.", "warning")
        return redirect(url_for('main.class_borrowing'))

    try:
        quantity = max(1, int(request.form.get('quantity', 1) or 1))
    except ValueError:
        flash("Quantity must be a whole number.", "warning")
        return redirect(url_for('main.class_borrowing'))

    cb = ClassBorrowing(
        class_name=class_name,
        responsibles=(request.form.get('responsibles') or '').strip(),
        book_title=book_title,
        book_ids=(request.form.get('book_ids') or '').strip(),
        quantity=quantity,
        condition=(request.form.get('condition') or 'Good').strip(),
        borrow_time=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    )
    stamp_sync_fields(cb)
    db.session.add(cb)
    db.session.flush()
    queue_record_change('class_checkouts', cb, operation='upsert')
    db.session.commit()
    safe_push_sync()
    flash("Class borrowing added.", "success")
    return redirect(url_for('main.class_borrowing'))

# --- LOGS ---
@main.route('/logs')
@login_required
def logs():
    records = school_query(Log).order_by(Log.id.desc()).limit(100).all()
    return render_template('logs.html', records=records, can_clear_logs=can_clear_logs())


@main.route('/resolve_issue', methods=['POST'])
@login_required
def resolve_issue():
    issue_id = request.form.get('issue_id')
    if not issue_id:
        flash('No issue specified.', 'warning')
        return redirect(url_for('main.borrowed'))
    try:
        issue = BookIssue.query.get(int(issue_id))
        if issue:
            db.session.delete(issue)
            db.session.commit()
            flash('Issue marked as resolved and removed.', 'success')
        else:
            flash('Issue not found.', 'warning')
    except Exception as e:
        flash('Error resolving issue.', 'danger')
    return redirect(url_for('main.borrowed'))

# --- IMPORT BORROWERS ---
@main.route('/import_borrowers')
@login_required
def import_borrowers():
    return render_template('import_borrowers.html')

# --- NOTES ---
@main.route('/notes')
@login_required
def notes():
    all_notes = school_query(Note).order_by(Note.id.desc()).all()
    return render_template('notes.html', notes=all_notes)

@main.route('/add_note', methods=['POST'])
@login_required
def add_note():
    title = (request.form.get('note_title') or '').strip()
    content = (request.form.get('note_content') or '').strip()
    if content or title:
        note = Note(
            title=title or None,
            content=content or '',
            timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        )
        stamp_sync_fields(note)
        db.session.add(note)
        db.session.commit()
        flash("Note saved.", "success")
    else:
        flash("Add a title or note content before saving.", "warning")
    return redirect(url_for('main.notes'))


@main.route('/api/notes/add', methods=['POST'])
@login_required
def api_add_note():
    try:
        data = request.get_json() or {}
        title = (data.get('title') or '').strip()
        content = (data.get('content') or '').strip()
        if not content and not title:
            return jsonify({'success': False, 'error': 'No content'}), 400
        # Store title and content in separate columns
        note = Note(title=title if title else None, content=content, timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        stamp_sync_fields(note)
        db.session.add(note)
        db.session.commit()
        return jsonify({'success': True, 'id': note.id})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@main.route('/api/notes/recent')
@login_required
def api_get_notes():
    # return most recent 8 notes as JSON
    notes = school_query(Note).order_by(Note.id.desc()).limit(8).all()
    out = [{'id': n.id, 'title': n.title or '', 'content': n.content or '', 'timestamp': n.timestamp} for n in notes]
    return jsonify(out)


@main.route('/api/notes/update', methods=['POST'])
@login_required
def api_update_note():
    try:
        data = request.get_json() or {}
        nid = data.get('id')
        if not nid:
            return jsonify({'success': False, 'error': 'Missing id'}), 400
        note = school_get(Note, int(nid))
        if not note:
            return jsonify({'success': False, 'error': 'Not found'}), 404
        title = (data.get('title') or '').strip()
        content = (data.get('content') or '').strip()
        note.title = title if title else None
        note.content = content
        stamp_sync_fields(note)
        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@main.route('/api/notes/delete', methods=['POST'])
@login_required
def api_delete_notes():
    try:
        data = request.get_json() or {}
        ids = data.get('ids') or []
        if not isinstance(ids, list):
            return jsonify({'success': False, 'error': 'ids must be a list'}), 400
        for nid in ids:
            n = school_get(Note, int(nid))
            if n:
                db.session.delete(n)
        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@main.route('/api/notes/clear', methods=['POST'])
@login_required
def api_clear_notes():
    try:
        school_query(Note).delete(synchronize_session=False)
        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

# --- TEACHER BORROW ---
@main.route('/teacher_borrow', methods=['GET', 'POST'])
@login_required
def teacher_borrow():
    if request.method == 'POST':
        book_id = (request.form.get('book_id') or '').strip()
        teacher_name = (request.form.get('teacher_name') or '').strip()
        notes = (request.form.get('notes') or '').strip()
        condition = (request.form.get('condition') or 'Good').strip()

        if not teacher_name or not book_id:
            flash("Teacher name and book ID are required.", "warning")
            return redirect(url_for('main.teacher_borrow'))

        book = school_get(Book, book_id, pk_name='book_id')
        if not book:
            flash("That book ID was not found in this school catalog.", "danger")
            return redirect(url_for('main.teacher_borrow'))

        if is_book_active(book_id):
            flash("That book is already issued.", "warning")
            return redirect(url_for('main.teacher_borrow'))

        tb = TeacherBorrowedBook(
            book_id=book.book_id,
            book_title=book.title,
            teacher_name=teacher_name,
            notes=notes,
            condition=condition,
            timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        )
        stamp_sync_fields(tb)
        db.session.add(tb)
        db.session.flush()
        queue_record_change('staff_checkouts', tb, operation='upsert')
        db.session.commit()
        log_action("/teacher_borrow", "STAFF_BORROW", f"{current_user.username} issued {book.book_id} to {teacher_name}")
        safe_push_sync()
        flash("Teacher borrow recorded.", "success")
        return redirect(url_for('main.teacher_borrow'))

    recent_loans = (
        school_query(TeacherBorrowedBook)
        .order_by(TeacherBorrowedBook.id.desc())
        .limit(12)
        .all()
    )
    return render_template('teacher_borrow.html', recent_loans=recent_loans)

# --- BACKUPS ---
@main.route('/backups')
@login_required
def backups():
    files = []
    if os.path.exists(BACKUP_DIR):
        for f in sorted(os.listdir(BACKUP_DIR), reverse=True):
            if f.endswith(".json"):
                files.append(f)
    return render_template('backups.html', files=files)

@main.route('/export/borrowed/<type>/<format>')
@login_required
def export_borrowed(type, format):
    # 1. FETCH DATA & SET TITLES
    pdf_data = [] 
    excel_data = [] 
    title = ""
    
    if type == 'students':
        title = "ACTIVE STUDENT BOOK LOANS"
        # Sort by Class (A-Z), then Name (A-Z)
        data_query = BorrowedBook.query.filter_by(returned=False).order_by(
            BorrowedBook.student_class.asc(), 
            BorrowedBook.student_name.asc()
        ).all()
        # Excel remains standard flat list
        excel_data = [{'Class': d.student_class, 'Name': d.student_name, 'Book': d.book_title, 'Book ID': d.book_id, 'Date': d.timestamp, 'Notes': d.condition} for d in data_query]
        
    elif type == 'staff':
        title = "ACTIVE STAFF BOOK LOANS"
        data_query = TeacherBorrowedBook.query.filter_by(returned=False).order_by(TeacherBorrowedBook.teacher_name.asc()).all()
        
        # Staff PDF Data (Standard Single Table)
        # New Columns: No, Staff Name, Book Title, Book ID, Notes
        pdf_data = [['No', 'Staff Name', 'Book Title', 'Book ID', 'Notes']]
        for i, d in enumerate(data_query, 1):
            pdf_data.append([str(i), d.teacher_name, d.book_title, d.book_id, d.notes])
            
        excel_data = [{'Name': d.teacher_name, 'Book': d.book_title, 'Book ID': d.book_id, 'Date': d.timestamp, 'Notes': d.notes} for d in data_query]
        
    elif type == 'graduates':
        title = "ACTIVE GRADUATE BOOK LOANS"
        # Sort by Promotion, then Original Class, then Name
        data_query = GraduateBorrowing.query.order_by(
            GraduateBorrowing.promotion_name.asc(),
            GraduateBorrowing.original_class.asc(),
            GraduateBorrowing.student_name.asc()
        ).all()
        
        # Excel Data
        excel_data = [{'Promotion': d.promotion_name, 'Class': d.original_class, 'Name': d.student_name, 'Book': d.book_title, 'Book ID': d.book_id, 'Notes': d.notes} for d in data_query]
        
    elif type == 'classes':
        title = "ACTIVE CLASS BOOK LOANS"
        data_query = ClassBorrowing.query.filter_by(returned=False).order_by(ClassBorrowing.class_name.asc()).all()
        
        # Classes PDF Data (Standard Single Table)
        pdf_data = [['Class', 'Book Title', 'Range', 'Qty', 'Responsibles']]
        for d in data_query:
            pdf_data.append([d.class_name, d.book_title, d.book_ids, str(d.quantity), d.responsibles])
            
        excel_data = [{'Class': d.class_name, 'Responsibles': d.responsibles, 'Book Title': d.book_title, 'IDs Range': d.book_ids, 'Qty': d.quantity, 'Notes': d.condition} for d in data_query]

    elif type == 'archived_classes':
        title = "ARCHIVED CLASS LOANS"
        data_query = GraduateClassBorrowing.query.order_by(GraduateClassBorrowing.promotion_name.asc()).all()

        pdf_data = [['Promotion', 'Class', 'Book Title', 'Range', 'Qty', 'Responsibles']]
        for d in data_query:
            pdf_data.append([d.promotion_name, d.class_name, d.book_title, d.book_ids, str(d.quantity), d.responsibles])

        excel_data = [{'Promotion': d.promotion_name, 'Class': d.class_name, 'Book Title': d.book_title, 'IDs Range': d.book_ids, 'Qty': d.quantity, 'Responsibles': d.responsibles} for d in data_query]

    elif type == 'issues':
        title = "REPORTED BOOK ISSUES"
        data_query = BookIssue.query.order_by(BookIssue.created_at.desc()).all()

        pdf_data = [['Date', 'Type', 'Borrower', 'Extra', 'Description', 'Cost']]
        excel_data = []
        for issue in data_query:
            borrower = 'N/A'
            extra = ''
            try:
                if issue.loan_type == 'student':
                    lb = BorrowedBook.query.get(issue.loan_id)
                    if lb:
                        borrower = lb.student_name
                        extra = lb.student_class
                elif issue.loan_type == 'graduate':
                    gb = GraduateBorrowing.query.get(issue.loan_id)
                    if gb:
                        borrower = gb.student_name
                        extra = gb.original_class
                    else:
                        gcl = GraduateClassBorrowing.query.get(issue.loan_id)
                        if gcl:
                            borrower = gcl.promotion_name
                            extra = gcl.class_name
                elif issue.loan_type == 'staff':
                    tb = TeacherBorrowedBook.query.get(issue.loan_id)
                    if tb:
                        borrower = tb.teacher_name
                elif issue.loan_type == 'class':
                    cb = ClassBorrowing.query.get(issue.loan_id)
                    if cb:
                        borrower = cb.class_name
                        extra = cb.book_ids
            except Exception:
                pass

            pdf_data.append([issue.created_at, issue.loan_type.capitalize(), borrower, extra or '—', issue.issue_description or '', issue.repair_cost or '—'])
            excel_data.append({'Date': issue.created_at, 'Type': issue.loan_type, 'Borrower': borrower, 'Extra': extra, 'Description': issue.issue_description, 'Cost': issue.repair_cost})

    # 2. GENERATE OUTPUT
    output = BytesIO()
    
    if format == 'pdf':
        doc = SimpleDocTemplate(output, pagesize=letter)
        elements = []
        styles = getSampleStyleSheet()
        
        # Main Document Title
        elements.append(Paragraph(f"<b>{title}</b>", styles['Title']))
        elements.append(Spacer(1, 12))
        
        # --- MULTI-TABLE LOGIC (Students & Graduates) ---
        if type == 'students' or type == 'graduates':
            
            # 1. Group Data
            grouped_data = {}
            for item in data_query:
                # Group by Class (Students) or Promotion (Graduates)
                key = item.student_class if type == 'students' else item.promotion_name
                if key not in grouped_data:
                    grouped_data[key] = []
                grouped_data[key].append(item)
            
            # 2. Loop through Groups (Sorted A-Z)
            for group_name in sorted(grouped_data.keys()):
                # Section Header
                header_text = f"Class: {group_name}" if type == 'students' else f"Promotion: {group_name}"
                elements.append(Paragraph(f"<b>{header_text}</b>", styles['Heading2']))
                elements.append(Spacer(1, 6))
                
                # Table Headers
                table_data = [['No', 'Student Name', 'Book Title', 'Book ID']]
                
                # Table Rows
                for idx, row in enumerate(grouped_data[group_name], 1):
                    # For graduates, append old class to name for clarity
                    name_display = row.student_name
                    if type == 'graduates':
                        name_display += f" ({row.original_class})"
                        
                    table_data.append([str(idx), name_display, row.book_title, row.book_id])
                
                # Create Table
                # Col Widths: No(35), Name(160), Title(240), ID(105)
                t = Table(table_data, colWidths=[35, 160, 240, 105])
                t.setStyle(TableStyle([
                    ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#4e73df')),
                    ('TEXTCOLOR', (0,0), (-1,0), colors.whitesmoke),
                    ('ALIGN', (0,0), (-1,-1), 'LEFT'),
                    ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
                    ('GRID', (0,0), (-1,-1), 1, colors.black),
                    ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.whitesmoke, colors.white]),
                    ('FONTSIZE', (0,0), (-1,-1), 9),
                    ('BOTTOMPADDING', (0,0), (-1,-1), 6),
                    ('TOPPADDING', (0,0), (-1,-1), 6),
                ]))
                elements.append(t)
                elements.append(Spacer(1, 20))
                
        # --- STANDARD SINGLE TABLE LOGIC (Staff & Classes) ---
        else:
            table = Table(pdf_data)
            # Adjust column widths slightly if Staff (5 cols) vs Classes (5 cols)
            # Default autosizing works okay, but fixed widths are safer for PDF
            if type == 'staff':
                col_widths = [30, 120, 180, 80, 130] # Optimized for No, Name, Title, ID, Notes
            else:
                col_widths = None # Let reportlab decide for Classes
                
            table = Table(pdf_data, colWidths=col_widths)
            table.setStyle(TableStyle([
                ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#4e73df')),
                ('TEXTCOLOR', (0,0), (-1,0), colors.whitesmoke),
                ('ALIGN', (0,0), (-1,-1), 'LEFT'),
                ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
                ('GRID', (0,0), (-1,-1), 1, colors.black),
                ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.whitesmoke, colors.white]),
                ('FONTSIZE', (0,0), (-1,-1), 9),
            ]))
            elements.append(table)
        
        doc.build(elements)
        fname = f"{title.replace(' ', '_')}.pdf"
        mimetype = 'application/pdf'
        
    else: # Excel Export logic (unchanged structure)
        df = pd.DataFrame(excel_data)
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            df.to_excel(writer, index=False)
        fname = f"{title.replace(' ', '_')}.xlsx"
        mimetype = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'

    output.seek(0)
    return send_file(output, as_attachment=True, download_name=fname, mimetype=mimetype)


@main.route('/settings', methods=['GET', 'POST'])
@login_required
def settings():
    config = load_config()
    
    if request.method == 'POST':
        action = request.form.get('action')
        old_auto = config.get('auto_backup', False)
        
        if action == 'save_defaults':
            try:
                config['max_books_per_student'] = int(request.form.get('max_books', 3))
                config['default_borrow_days'] = int(request.form.get('borrow_days', 14))
                config['auto_lock_minutes'] = int(request.form.get('auto_lock', 5))
                config['lockout_wait_time'] = int(request.form.get('lockout_time', 30))
                config['theme'] = request.form.get('theme', 'light')
                config['language'] = request.form.get('language', 'English')
                config['auto_backup'] = 'auto_backup' in request.form
                if request.form.get('backup_freq'):
                    config['backup_frequency'] = int(request.form.get('backup_freq'))

                save_config(config)
                flash("System configuration updated successfully.", "success")
                log_action("/settings", "UPDATE_CONFIG", "Modified system defaults")
            except ValueError:
                flash("Error: Please enter valid numbers for timers and limits.", "danger")
            else:
                if config.get('auto_backup') and not old_auto:
                    try:
                        from .utils import create_backup_file
                        filename = create_backup_file(manual=False)
                        path = os.path.join(BACKUP_DIR, filename)
                        return send_file(path, as_attachment=True, download_name=filename, mimetype='application/json')
                    except Exception as e:
                        flash(f"Backup created but download failed: {e}", "warning")
            return redirect(url_for('main.settings'))

        if action == 'save_connectivity':
            config['supabase_url'] = (request.form.get('supabase_url') or '').strip()
            config['supabase_key'] = (request.form.get('supabase_key') or '').strip()
            config['supabase_service_role_key'] = (request.form.get('supabase_service_role_key') or '').strip()
            try:
                config['sync_batch_size'] = int(
                    request.form.get('sync_batch_size', config.get('sync_batch_size', 100)) or 100
                )
            except ValueError:
                config['sync_batch_size'] = config.get('sync_batch_size', 100)
            save_config(config)

            current_app.config['SUPABASE_URL'] = config.get('supabase_url', '')
            current_app.config['SUPABASE_KEY'] = config.get('supabase_service_role_key') or config.get('supabase_key', '')
            current_app.config['SUPABASE_ANON_KEY'] = config.get('supabase_key', '')
            current_app.config['SYNC_BATCH_SIZE'] = config.get('sync_batch_size', 100)

            sync_service = get_sync_service()
            if sync_service:
                sync_service.init_app(current_app)

            flash("Connectivity settings saved.", "success")
            log_action("/settings", "UPDATE_CONNECTIVITY", "Updated Supabase and cloud sync settings")
            return redirect(url_for('main.settings'))

    backups = []
    if os.path.exists(BACKUP_DIR):
        try:
            files = sorted(os.listdir(BACKUP_DIR), reverse=True)
            for f in files:
                if f.endswith('.json'):
                    path = os.path.join(BACKUP_DIR, f)
                    size_kb = os.path.getsize(path) / 1024
                    mod_time = os.path.getmtime(path)
                    timestamp = datetime.fromtimestamp(mod_time).strftime('%Y-%m-%d %H:%M')
                    
                    backups.append({
                        'name': f, 
                        'size': f"{size_kb:.1f} KB", 
                        'date': timestamp,
                        'raw_date': mod_time,
                    })
        except Exception as e:
            print(f"Error listing backups: {e}")

    return render_template('settings.html', config=config, backups=backups)

@main.route('/system/update/check', methods=['POST'])
@login_required
def check_update():
    # SECURE: Use the backend constant instead of accepting input from frontend
    clean_url = f"{UPDATE_URL}?t={int(time.time())}"
    
    try:
        response = requests.get(clean_url, timeout=30)
        response.raise_for_status()
        data = response.json()
        
        remote_v = data.get('version')
        is_critical = data.get('is_critical', False)
        
        # MATH COMPARISON: Handles 1.10.0 > 1.2.0 correctly
        if version.parse(remote_v) > version.parse(VERSION):
            return jsonify({
                "update_available": True,
                "new_version": remote_v,
                "is_critical": is_critical,
                "changelog": data.get('changelog', []),
                "download_url": data.get('download_url'),
                "message": "🚨 CRITICAL SECURITY PATCH AVAILABLE" if is_critical else f"🚀 New Version v{remote_v} is ready for install!"
            })
        
        return jsonify({
            "update_available": False, 
            "message": "✅ You are running the latest stable version of Edraze."
        })
        
    except Exception as e:
        return jsonify({"error": f"Unable to reach update server: {str(e)}"}), 400

@main.route('/system/update/run', methods=['POST'])
@login_required
def run_update():
    data = request.get_json()
    download_url = data.get('download_url')
    new_v = data.get('new_version')
    changelog = data.get('changelog', [])
    
    # 1. PERMANENT LOGGING: Save history before the app shuts down
    history = UpdateHistory(
        version=new_v,
        changelog="\n".join(changelog) if isinstance(changelog, list) else changelog,
        status="Success", # Assumed success; sidecar handles actual rollback
        timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    )
    db.session.add(history)
    db.session.commit()
    
    # 2. TRIGGER EXTERNAL UPDATER
    app_root = os.path.abspath(os.getcwd())
    # This script kills the Flask process, swaps files, and restarts the server
    subprocess.Popen([sys.executable, "updater.py", download_url, app_root, BACKUP_DIR])
    
    log_action("/system/update/run", "EXECUTE_UPDATE", f"Migrating to v{new_v}")
    return jsonify({"message": "Update process started. The application will restart in 30 seconds."})

@main.route('/system/update/history')
@login_required
def get_history():
    # Fetch all logs, newest first, to populate the "Pretty Div"
    history = UpdateHistory.query.order_by(UpdateHistory.id.desc()).all()
    return jsonify([{
        'version': h.version,
        'changelog': h.changelog,
        'status': h.status,
        'timestamp': h.timestamp
    } for h in history])

# 2. Add this specific function to make it GLOBAL
@main.app_context_processor
def inject_version():
    """Makes {{ current_version }} available to all templates (sidebar, footer, etc.)"""
    return dict(current_version=VERSION)

# --- PROFILE MANAGEMENT ROUTES ---
def sorted_librarians(records):
    return sorted(records, key=lambda item: (0 if current_role(item) == 'admin' else 1, item.username.lower()))


def librarian_listing_response():
    school = db.session.get(School, current_user.school_id) if current_user.school_id else None
    librarians = sorted_librarians(school_query(Admin).order_by(Admin.username.asc()).all())
    if wants_json_response():
        return jsonify(
            {
                "success": True,
                "school": {
                    "id": school.id if school else None,
                    "name": school.name if school else None,
                },
                "librarians": [serialize_librarian(librarian) for librarian in librarians],
            }
        )
    return render_template(
        'admin_librarians.html',
        librarians=librarians,
        school=school,
        can_manage_librarians=can_manage_librarians(),
    )


def create_librarian_account(username, password, confirm_password=None, email=None):
    username = (username or '').strip()
    password = password or ''
    confirm_password = confirm_password or password
    email = (email or '').strip() or None

    if not can_manage_librarians():
        return False, "Only an admin can add another librarian.", None, 403

    if not current_user.school_id:
        return False, "Your admin account is not linked to a school yet.", None, 400

    if not username or not password:
        return False, "Username and password are required.", None, 400

    if password != confirm_password:
        return False, "Librarian passwords do not match.", None, 400

    existing = Admin.query.filter_by(username=username).first()
    if existing:
        return False, f"Username '{username}' already exists. Choose a different librarian username.", None, 409

    try:
        librarian = Admin(
            username=username,
            password=hash_pw(password),
            role='librarian',
            email1=email,
            school_id=current_user.school_id,
        )
        stamp_sync_fields(librarian)
        db.session.add(librarian)
        db.session.flush()
        queue_record_change('librarians', librarian, operation='upsert')
        db.session.commit()

        log_action(
            "/admin/add-librarian",
            "POST",
            f"{current_user.username} added librarian {username} for school {current_user.school_id}",
            status_code=201,
        )
        safe_push_sync(limit=10, force=True)
        return True, f"Librarian '{username}' created successfully.", librarian, 201
    except Exception as exc:
        db.session.rollback()
        current_app.logger.exception("Failed to create librarian account.")
        return False, f"Could not create librarian: {exc}", None, 500


def remove_librarian_account(librarian_id):
    if not can_manage_librarians():
        return False, "Only an admin can remove librarians.", None, 403

    librarian = school_get(Admin, librarian_id, include_deleted=True)
    if not librarian or librarian.deleted:
        return False, "Librarian not found.", None, 404

    if librarian.id == current_user.id:
        return False, "You cannot delete your own account.", librarian, 400

    if current_role(librarian) == 'admin':
        return False, "You cannot delete another admin account.", librarian, 403

    try:
        stamp_sync_fields(librarian, deleted=True)
        queue_record_change('librarians', librarian, operation='upsert')
        db.session.commit()

        log_action(
            f"/admin/delete-librarian/{librarian_id}",
            "POST",
            f"{current_user.username} removed librarian {librarian.username} from school {current_user.school_id}",
        )
        safe_push_sync(limit=10, force=True)
        return True, f"Librarian '{librarian.username}' removed successfully.", librarian, 200
    except Exception as exc:
        db.session.rollback()
        current_app.logger.exception("Failed to delete librarian account.")
        return False, f"Could not remove librarian: {exc}", librarian, 500


@main.route('/profile')
@login_required
def profile():
    school = db.session.get(School, current_user.school_id) if current_user.school_id else None
    librarians = sorted_librarians(school_query(Admin).order_by(Admin.username.asc()).all())
    return render_template(
        'profile.html',
        user=current_user,
        school=school,
        librarians=librarians,
        can_manage_librarians=can_manage_librarians(),
        timestamp=int(datetime.now().timestamp()),
    )

@main.route('/profile/security', methods=['POST'])
@login_required
def update_security():
    action = request.form.get('action')
    current_pw = request.form.get('current_password')
    should_sync_admin = False
    
    # 1. Verify Current Password
    if hash_pw(current_pw) != current_user.password:
        flash("Incorrect current password.", "danger")
        return redirect(url_for('main.profile'))
    
    if action == 'update_info':
        new_username = request.form.get('username').strip()
        
        # 2. DUPLICATE USERNAME CHECK
        # If username is changing, check if the new one already exists
        if new_username != current_user.username:
            existing_user = Admin.query.filter_by(username=new_username).first()
            if existing_user:
                flash(f"Error: The username '{new_username}' is already taken.", "warning")
                return redirect(url_for('main.profile'))
        
        # If safe, update details
        current_user.username = new_username
        current_user.email1 = request.form.get('email1')
        current_user.email2 = request.form.get('email2')
        current_user.email3 = request.form.get('email3')
        stamp_sync_fields(current_user)
        queue_record_change('librarians', current_user, operation='upsert')
        should_sync_admin = True
        db.session.commit()
        flash("Profile info updated successfully.", "success")
        log_action("/profile/security", "UPDATE_INFO", f"{current_user.username} updated account details")
        
    elif action == 'change_password':
        new = request.form.get('new_password')
        confirm = request.form.get('confirm_password')
        
        if new != confirm:
            flash("New passwords do not match.", "danger")
        else:
            current_user.password = hash_pw(new)
            stamp_sync_fields(current_user)
            queue_record_change('librarians', current_user, operation='upsert')
            should_sync_admin = True
            db.session.commit()
            flash("Password changed successfully.", "success")
            log_action("/profile/security", "CHANGE_PASSWORD", f"{current_user.username} changed account password")

    if should_sync_admin:
        safe_push_sync()
            
    return redirect(url_for('main.profile'))


@main.route('/admin/librarians')
@login_required
def admin_librarians():
    if not can_manage_librarians():
        return admin_access_denied()
    return librarian_listing_response()


@main.route('/admin/add-librarian', methods=['POST'])
@login_required
def admin_add_librarian():
    if not can_manage_librarians():
        return admin_access_denied("Only an admin can add another librarian.")

    payload = request.get_json(silent=True) or {}
    success, message, librarian, status_code = create_librarian_account(
        username=payload.get('username') or request.form.get('username'),
        password=payload.get('password') or request.form.get('password'),
        confirm_password=payload.get('confirm_password') or request.form.get('confirm_password'),
        email=payload.get('email') or request.form.get('email'),
    )
    if wants_json_response():
        return jsonify(
            {
                "success": success,
                "message": message,
                "librarian": serialize_librarian(librarian) if librarian else None,
            }
        ), status_code

    flash(message, "success" if success else "danger")
    return redirect(url_for('main.admin_librarians' if success else 'main.profile'))


@main.route('/admin/delete-librarian/<int:librarian_id>', methods=['POST'])
@login_required
def admin_delete_librarian(librarian_id):
    if not can_manage_librarians():
        return admin_access_denied("Only an admin can remove librarians.")

    success, message, librarian, status_code = remove_librarian_account(librarian_id)
    if wants_json_response():
        return jsonify(
            {
                "success": success,
                "message": message,
                "librarian": serialize_librarian(librarian) if librarian else None,
            }
        ), status_code

    flash(message, "success" if success else "danger")
    return redirect(url_for('main.admin_librarians'))


@main.route('/profile/librarians/add', methods=['POST'])
@login_required
def add_librarian():
    if not can_manage_librarians():
        flash("Only an admin can add another librarian.", "danger")
        return redirect(url_for('main.profile'))

    current_pw = request.form.get('current_password')
    if hash_pw(current_pw or '') != current_user.password:
        flash("Incorrect password. Librarian account not created.", "danger")
        return redirect(url_for('main.profile'))

    success, message, _librarian, _status_code = create_librarian_account(
        username=request.form.get('username'),
        password=request.form.get('password'),
        confirm_password=request.form.get('confirm_password'),
        email=request.form.get('email'),
    )
    flash(message, "success" if success else "danger")
    return redirect(url_for('main.profile'))

@main.route('/profile/generate_codes', methods=['POST'])
@login_required
def generate_codes():
    password = request.form.get('password_for_codes')
    
    # PASSWORD GATE
    if hash_pw(password) != current_user.password:
        flash("Incorrect password. Cannot generate codes.", "danger")
        return redirect(url_for('main.profile'))
    
    # Generate 10 codes (8 chars each)
    import secrets
    codes = [secrets.token_hex(4).upper() for _ in range(10)]
    current_user.recovery_codes = ",".join(codes)
    db.session.commit()
    
    flash("New recovery codes generated. Please save them immediately.", "success")
    return redirect(url_for('main.profile'))      

# --- FIX PROFILE PICTURE VISIBILITY ---
@main.route('/uploads/<filename>')
def uploaded_file(filename):
    """Serves uploaded profile images and falls back to a bundled default avatar."""
    safe_name = secure_filename(filename or "")
    upload_folder = current_app.config['UPLOAD_FOLDER']
    file_path = os.path.join(upload_folder, safe_name)
    default_avatar = os.path.join(current_app.static_folder, 'img', 'default_profile.svg')

    if safe_name and os.path.exists(file_path):
        return send_from_directory(upload_folder, safe_name)
    return send_file(default_avatar, mimetype='image/svg+xml')

# --- PROFILE: SETUP QUESTIONS ---
@main.route('/profile/setup_questions', methods=['POST'])
@login_required
def setup_questions():
    current_pw = request.form.get('current_password')
    if hash_pw(current_pw) != current_user.password:
        flash("Incorrect password.", "danger")
        return redirect(url_for('main.profile'))
        
    current_user.question1 = request.form.get('q1')
    current_user.answer1 = hash_pw(request.form.get('a1').strip().lower())
    
    current_user.question2 = request.form.get('q2')
    current_user.answer2 = hash_pw(request.form.get('a2').strip().lower())
    
    current_user.question3 = request.form.get('q3')
    current_user.answer3 = hash_pw(request.form.get('a3').strip().lower())
    
    db.session.commit()
    flash("Questions updated.", "success")
    return redirect(url_for('main.profile'))

# --- PROFILE: UPDATE PICTURE (Already there? Ensure it looks like this) ---
@main.route('/profile/update_picture', methods=['POST'])
@login_required
def update_picture():
    if 'profile_image' not in request.files:
        return jsonify({'status': 'error', 'message': 'No image uploaded.'}), 400

    file = request.files['profile_image']
    if not file.filename:
        return jsonify({'status': 'error', 'message': 'Empty filename.'}), 400

    try:
        filename = secure_filename(f"{current_user.id}_{int(datetime.now().timestamp())}.png")
        file.save(os.path.join(current_app.config['UPLOAD_FOLDER'], filename))
        current_user.profile_image = filename
        db.session.commit()
        return jsonify({'status': 'success'})
    except Exception as exc:
        db.session.rollback()
        current_app.logger.exception("Profile image upload failed.")
        return jsonify({'status': 'error', 'message': str(exc)}), 500

# --- PROFILE: DELETE PICTURE ---
@main.route('/profile/delete_picture', methods=['POST'])
@login_required
def delete_picture():
    try:
        if current_user.profile_image and 'default' not in current_user.profile_image:
            file_path = os.path.join(current_app.config['UPLOAD_FOLDER'], current_user.profile_image)
            if os.path.exists(file_path):
                os.remove(file_path)

        current_user.profile_image = 'default_profile.png'
        db.session.commit()
        flash("Profile picture removed.", "info")
    except Exception as exc:
        db.session.rollback()
        current_app.logger.exception("Profile image delete failed.")
        flash(f"Could not remove profile picture: {exc}", "danger")
    return redirect(url_for('main.profile'))

    # --- BACKUP MANAGEMENT ROUTES ---

@main.route('/settings/backup/create', methods=['POST'])
@login_required
def create_backup():
    try:
        from .utils import create_backup_file
        filename = create_backup_file(manual=True)
        flash(f"Backup created successfully: {filename}", "success")
        log_action("/settings/backup", "CREATE_BACKUP", f"Created {filename}")
    except Exception as e:
        flash(f"Error creating backup: {str(e)}", "danger")
    return redirect(url_for('main.settings'))

@main.route('/settings/backup/delete/<filename>', methods=['POST'])
@login_required
def delete_backup(filename):
    try:
        path = os.path.join(BACKUP_DIR, secure_filename(filename))
        if os.path.exists(path):
            os.remove(path)
            flash("Backup file deleted.", "success")
    except Exception as e:
        flash(f"Error deleting file: {str(e)}", "danger")
    return redirect(url_for('main.settings'))

@main.route('/settings/backup/verify/<filename>', methods=['GET'])
@login_required
def verify_backup(filename):
    from .utils import verify_backup_file
    path = os.path.join(BACKUP_DIR, secure_filename(filename))
    is_valid, msg = verify_backup_file(path)
    if is_valid:
        flash(f"Integrity Check Passed: {msg}", "success")
    else:
        flash(f"Integrity Check FAILED: {msg}", "danger")
    return redirect(url_for('main.settings'))

@main.route('/settings/backup/download/<filename>')
@login_required
def download_backup(filename):
    return send_from_directory(BACKUP_DIR, secure_filename(filename), as_attachment=True)

@main.route('/settings/backup/upload', methods=['POST'])
@login_required
def upload_backup():
    if 'backup_file' not in request.files:
        flash("No file selected.", "warning")
        return redirect(url_for('main.settings'))
        
    file = request.files['backup_file']
    if file.filename:
        filename = secure_filename(file.filename)
        path = os.path.join(BACKUP_DIR, filename)
        file.save(path)
        
        # Auto-Verify on upload
        from .utils import verify_backup_file
        is_valid, msg = verify_backup_file(path)
        
        if is_valid:
            flash(f"Backup uploaded and verified successfully.", "success")
        else:
            os.remove(path) # Delete bad file immediately
            flash(f"Upload rejected: File corrupted or invalid signature.", "danger")
            
    return redirect(url_for('main.settings'))

@main.route('/settings/backup/restore/<filename>', methods=['POST'])
@login_required
def restore_backup(filename):
    # Security: Ensure Admin Password confirmation was passed if you want extra security, 
    # but for now we trust the login session.
    from .utils import restore_backup_file
    success, msg = restore_backup_file(secure_filename(filename))
    if success:
        flash(msg, "success")
        log_action("/settings/restore", "RESTORE_DB", f"Restored from {filename}")
    else:
        flash(f"Restore Failed: {msg}", "danger")
    return redirect(url_for('main.settings'))

@main.route('/settings/backup/bulk_action', methods=['POST'])
@login_required
def bulk_backup_action():
    action = request.form.get('bulk_action')
    selected_files = request.form.getlist('selected_backups')
    
    if not selected_files:
        flash("No files selected.", "warning")
        return redirect(url_for('main.settings'))
        
    # 1. BULK DELETE
    if action == 'delete':
        count = 0
        for fname in selected_files:
            path = os.path.join(BACKUP_DIR, secure_filename(fname))
            if os.path.exists(path):
                os.remove(path)
                count += 1
        flash(f"Deleted {count} backup files.", "success")
        
    # 2. BULK VERIFY
    elif action == 'verify':
        from .utils import verify_backup_file
        passed = 0
        failed = 0
        for fname in selected_files:
            path = os.path.join(BACKUP_DIR, secure_filename(fname))
            is_valid, _ = verify_backup_file(path)
            if is_valid: passed += 1
            else: failed += 1
        
        if failed > 0:
            flash(f"Verification Results: {passed} Valid, {failed} Corrupted.", "warning")
        else:
            flash(f"All {passed} files verified successfully.", "success")
            
    # 3. BULK DOWNLOAD (ZIP)
    elif action == 'download':
        from .utils import create_zip_of_backups
        zip_buffer = create_zip_of_backups(selected_files)
        timestamp = datetime.now().strftime("%Y%m%d")
        return send_file(
            zip_buffer,
            mimetype='application/zip',
            as_attachment=True,
            download_name=f"backups_archive_{timestamp}.zip"
        )
        
    return redirect(url_for('main.settings'))

# --- NEW API: FETCH CLASS MEMBERS ---
@main.route('/api/class_members/<class_name>')
@login_required
def get_class_members(class_name):
    # Fetch all students in this class
    students = school_query(Student).filter_by(student_class=class_name).order_by(Student.name).all()
    names = [s.name for s in students]
    return jsonify(names)
    
@main.route('/system/logs/reset', methods=['POST'])
@login_required
def reset_logs():
    """
    Securely clears the Log table after verifying the admin password.
    Uses the app's internal hash_pw utility for consistency.
    """
    data = request.get_json(silent=True) or {}
    password = data.get('password', '')

    if not can_clear_logs():
        return jsonify({
            "success": False,
            "message": "Only an admin can clear logs."
        }), 403
    
    # 1. SECURITY CHECK
    # We use hash_pw() to match the logic in update_security (line 533)
    if hash_pw(password) != current_user.password:
        return jsonify({
            "success": False, 
            "message": "Security Alert: Incorrect administrative password."
        }), 403

    try:
        # 2. DATABASE OPERATION
        # Deletes all rows in the Log table
        school_query(Log, include_deleted=True).delete()
        db.session.commit()
        
        # 3. AUDIT TRAIL
        # We immediately log the reset so the 'empty' table has its first entry
        log_action("/system/logs/reset", "RESET_LOGS", f"Complete audit log wipe performed by {current_user.username}")
        
        return jsonify({
            "success": True, 
            "message": "System logs cleared. Audit trail restarted."
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            "success": False, 
            "message": f"Database Error: {str(e)}"
        }), 500


@main.route("/sync")
@login_required
def sync_page():
    return render_template("sync.html")


@main.route("/sync/start", methods=["POST"])
@login_required
def start_sync():
    status = get_lan_sync_status()
    if status.get("state") in ("waiting", "authenticating", "syncing"):
        return jsonify({"status": "error", "message": "Server already running."})
    start_tcp_server(current_app._get_current_object())
    return jsonify({"status": "success", "message": "Sync server started."})


@main.route("/sync/stop", methods=["POST"])
@login_required
def stop_sync():
    stop_tcp_server()
    return jsonify({"status": "success"})


@main.route("/sync/status", methods=["GET"])
@login_required
def sync_status_api():
    status = get_lan_sync_status()
    return jsonify(
        {
            "state": status.get("state", "idle"),
            "otp": status.get("otp"),
            "server_ip": status.get("server_ip"),
            "clients": status.get("clients", []),
            "last_result": status.get("last_result"),
        }
    )


@main.route("/sync/reset", methods=["POST"])
@login_required
def reset_sync():
    status = get_lan_sync_status()
    if status.get("state") in ("waiting", "authenticating", "syncing"):
        return jsonify({"status": "error", "message": "Cannot reset while sync is in progress."})
    reset_lan_sync_status()
    return jsonify({"status": "success"})


@main.route("/sync/conflicts", methods=["GET"])
@login_required
def get_sync_conflicts():
    conflicts = (
        PeerSyncLog.query.filter_by(status="conflict")
        .order_by(PeerSyncLog.id.desc())
        .limit(20)
        .all()
    )
    return jsonify(
        [
            {
                "id": record.id,
                "change_id": record.change_id,
                "device_label": record.device_label or "",
                "performed_by": record.performed_by or "",
                "action": record.action,
                "error": record.error,
                "timestamp": record.timestamp,
            }
            for record in conflicts
        ]
    )


@main.route("/bluetooth")
@login_required
def bluetooth_page():
    return redirect(url_for("main.sync_page"))


@main.route("/setup/role", methods=["GET"])
def role_wizard():
    return render_template("role_wizard.html", config=load_config())


@main.route("/setup/role", methods=["POST"])
def role_wizard_save():
    import socket as _socket
    import peer_sync

    role = request.form.get("role", "").strip()
    device_label = request.form.get("device_label", _socket.gethostname()).strip()

    if role not in ("major", "minor"):
        flash("Please choose a role.", "warning")
        return redirect(url_for("main.role_wizard"))

    config = load_config()
    config["role"] = role
    config["device_label"] = device_label
    if not config.get("device_id"):
        config["device_id"] = f"{role}_{secrets.token_hex(4)}"
    save_config(config)

    peer_sync.start(
        role,
        current_app._get_current_object(),
        sync_interval=int(config.get("sync_interval", 5) or 5),
    )
    flash(f"Role set to {role.upper()}. Sync engine started.", "success")
    return redirect(url_for("auth.login"))


@main.route("/peers")
@login_required
def peers_page():
    import peer_sync

    status = peer_sync.get_status()
    sessions = PeerSession.query.filter(PeerSession.device_id != "self").all()
    return render_template("peers.html", status=status, sessions=sessions, cfg=load_config())


@main.route("/peers/status", methods=["GET"])
@login_required
def peers_status_api():
    import peer_sync

    return jsonify(peer_sync.get_status())


@main.route("/peers/otp/create", methods=["POST"])
@login_required
def create_peer_otp():
    import peer_sync

    config = load_config()
    if config.get("role") != "major":
        return jsonify({"status": "error", "message": "Only the Major PC can create OTPs."})
    return jsonify({"status": "ok", "otp": peer_sync.create_otp()})


@main.route("/peers/connect", methods=["POST"])
@login_required
def connect_minor_peer():
    import peer_sync

    config = load_config()
    if config.get("role") != "minor":
        return jsonify({"status": "error", "message": "Only a Minor PC can use this action."})
    data = request.get_json(silent=True) or {}
    otp = str(data.get("otp", "")).strip()
    major_ip = (data.get("major_ip") or "").strip() or None
    if len(otp) != 6 or not otp.isdigit():
        return jsonify({"status": "error", "message": "OTP must be exactly 6 digits."})
    return jsonify(peer_sync.submit_otp_and_connect(otp, major_ip))


@main.route("/peers/disconnect/<device_id>", methods=["POST"])
@login_required
def disconnect_peer(device_id):
    import peer_sync

    config = load_config()
    if config.get("role") != "major":
        return jsonify({"status": "error", "message": "Only the Major PC can disconnect peers."})
    peer_sync.disconnect_peer(device_id)
    return jsonify({"status": "ok"})


@main.route("/peers/trust/<device_id>", methods=["POST"])
@login_required
def toggle_peer_trust(device_id):
    config = load_config()
    if config.get("role") != "major":
        return jsonify({"status": "error", "message": "Only the Major PC can change trust settings."})
    peer_session = PeerSession.query.filter_by(device_id=device_id).first()
    if not peer_session:
        return jsonify({"status": "error", "message": "Device not found."}), 404
    payload = request.get_json(silent=True) or {}
    peer_session.trusted = bool(payload.get("trusted", True))
    db.session.commit()
    return jsonify({"status": "ok", "trusted": peer_session.trusted})


@main.route("/peers/conflicts/dismiss/<int:index>", methods=["POST"])
@login_required
def dismiss_peer_conflict(index):
    import peer_sync

    peer_sync.dismiss_conflict(index)
    return jsonify({"status": "ok"})


@main.route("/peers/sync-interval", methods=["POST"])
@login_required
def set_peer_sync_interval():
    import peer_sync

    payload = request.get_json(silent=True) or {}
    seconds = max(1, min(int(payload.get("seconds", 5)), 300))
    peer_sync.set_sync_interval(seconds)
    config = load_config()
    config["sync_interval"] = seconds
    save_config(config)
    return jsonify({"status": "ok", "sync_interval": seconds})
