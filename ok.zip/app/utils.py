import hashlib
from io import BytesIO
import os
import sys
import json
import socket
import sqlite3
import uuid
import zipfile
from datetime import datetime
from .database import db, Book, Student, BorrowedBook, TeacherBorrowedBook, ClassBorrowing, GraduateBorrowing, GraduateClassBorrowing, Note

try:
    from dotenv import load_dotenv
except ImportError:  # pragma: no cover - optional in packaged builds
    load_dotenv = None

if load_dotenv:
    load_dotenv()

# Navigate up from 'app/' to root
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, "library.db")
CONFIG_PATH = os.path.join(BASE_DIR, "config.json")
BACKUP_DIR = os.path.join(BASE_DIR, "backups")
UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")
ADMIN_ROLES = {"admin", "owner"}

def hash_pw(pw):
    return hashlib.sha256(pw.encode()).hexdigest()


def normalize_role(role):
    normalized = (role or "librarian").strip().lower()
    return "admin" if normalized in ADMIN_ROLES else "librarian"


def is_admin_role(role):
    return normalize_role(role) == "admin"


def role_label(role):
    return "Admin" if is_admin_role(role) else "Librarian"


def default_device_id():
    host = socket.gethostname().replace(" ", "-").lower()
    return f"{host}-{uuid.getnode():x}"

def load_config():
    # --- NEW DEFAULTS ADDED HERE ---
    default_config = {
        "admin_username": "admin",
        "admin_password": hash_pw("admin123"),
        
        # 1. Borrowing Rules
        "max_books_per_student": 3,
        "default_borrow_days": 14,
        
        # 2. Security Timers
        "auto_lock_minutes": 5,      # 0 = Disabled
        "lockout_wait_time": 30,     # Seconds to wait after failed logins
        
        # 3. Appearance & Locale
        "theme": "light",            # light / dark
        "language": "English",
        
        # 4. Backup Automation (For Phase 2)
        "auto_backup": False,
        "backup_frequency": 24,      # Hours
        
        # 5. Email Settings
        "smtp_server": os.getenv("SMTP_SERVER", "smtp.gmail.com"),
        "smtp_port": int(os.getenv("SMTP_PORT", "587")),
        "sender_email": os.getenv("SENDER_EMAIL", ""),
        "sender_password": os.getenv("SENDER_PASSWORD", ""),

        # 6. Offline/Cloud Sync
        "app_host": os.getenv("APP_HOST", "0.0.0.0"),
        "app_port": int(os.getenv("APP_PORT", "5000")),
        "database_url": os.getenv("DATABASE_URL", ""),
        "secret_key": os.getenv("FLASK_SECRET_KEY", "strong_random_secret_key"),
        "master_key": os.getenv("MASTER_KEY", ""),
        "device_id": default_device_id(),
        "device_label": socket.gethostname(),
        "role": None,
        "session_token": "",
        "major_ip": "",
        "sync_interval": 5,
        "sync_batch_size": 100,
        "sync_min_interval_seconds": 20,
        "sync_poll_interval_seconds": 60,
        "sync_retry_max_seconds": 300,
        "supabase_url": os.getenv("SUPABASE_URL", ""),
        "supabase_key": os.getenv("SUPABASE_ANON_KEY", os.getenv("SUPABASE_KEY", "")),
        "supabase_service_role_key": os.getenv("SUPABASE_SERVICE_ROLE_KEY", os.getenv("SUPABASE_SERVICE_KEY", "")),
    }
    
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, 'r') as f:
            try:
                config = json.load(f)
                # Merge defaults to ensure new keys exist in old config files
                config_updated = False
                for key, value in default_config.items():
                    if key not in config:
                        config[key] = value
                        config_updated = True
                    elif key in {"supabase_url", "supabase_key", "supabase_service_role_key"} and not config.get(key):
                        config[key] = value
                        config_updated = True
                
                if config_updated:
                    save_config(config)
                    
                return config
            except:
                return default_config
    else:
        with open(CONFIG_PATH, 'w') as f:
            json.dump(default_config, f, indent=4)
        return default_config

def save_config(config):
    with open(CONFIG_PATH, 'w') as f:
        json.dump(config, f, indent=4)


# --- BACKUP LOGIC ---
def calculate_checksum(data):
    """
    Generates a SHA256 hash of the data.
    USES STRICT SERIALIZATION: sort_keys=True, separators=(',', ':')
    This removes all whitespace to ensure '{"a": 1}' hashes the same as '{"a":1}'
    """
    # separators=(',', ':') removes the default spaces after commas/colons
    json_str = json.dumps(data, sort_keys=True, separators=(',', ':'), ensure_ascii=True)
    return hashlib.sha256(json_str.encode('utf-8')).hexdigest()

def create_backup_file(manual=True):
    """Exports all database tables to a signed JSON file."""
    if not os.path.exists(BACKUP_DIR):
        os.makedirs(BACKUP_DIR)
    
    # 1. Gather Data (Manual Mapping for Safety)
    content = {
        "books": [{
            "book_id": b.book_id,
            "title": b.title,
            "author": b.author,
            "category": b.category or "Uncategorized",
            "added_at": b.added_at,
        } for b in Book.query.all()],
        
        "students": [{
            "name": s.name, "class": s.student_class
        } for s in Student.query.all()],
        
        "loans_student": [{
            "book_id": l.book_id, "book_title": l.book_title, "student": l.student_name, "class": l.student_class,
            "condition": l.condition, "date": l.timestamp, "due": l.due_date
        } for l in BorrowedBook.query.filter_by(returned=False).all()],
        
        "loans_staff": [{
            "book_id": l.book_id, "book_title": l.book_title, "teacher": l.teacher_name,
            "condition": l.condition, "date": l.timestamp, "notes": l.notes
        } for l in TeacherBorrowedBook.query.filter_by(returned=False).all()],

        "loans_class": [{
            "class": l.class_name, "resp": l.responsibles, "title": l.book_title, "ids": l.book_ids,
            "qty": l.quantity, "cond": l.condition, "date": l.borrow_time
        } for l in ClassBorrowing.query.filter_by(returned=False).all()]
    }
    
    # 2. Calculate Strict Checksum
    checksum = calculate_checksum(content)
    
    # 3. Construct Final Object
    final_data = {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "type": "Manual" if manual else "Auto",
        "checksum": checksum,
        "content": content
    }
    
    # 4. Save to Disk
    filename = f"backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    with open(os.path.join(BACKUP_DIR, filename), 'w') as f:
        json.dump(final_data, f, indent=4) # Indent for readability, doesn't affect checksum logic
    
    return filename

def verify_backup_file(filepath):
    """Checks if a backup file is valid and untampered."""
    try:
        with open(filepath, 'r') as f:
            data = json.load(f)
        
        if 'content' not in data or 'checksum' not in data:
            return False, "Invalid file format: Missing content or checksum."
            
        # Recalculate hash of the content found in the file
        calculated = calculate_checksum(data['content'])
        
        # Compare with the signature stamped in the file
        if calculated != data['checksum']:
            return False, "CRITICAL: File content has been modified externally!"
            
        return True, "Valid Signature"
    except json.JSONDecodeError:
        return False, "File is not valid JSON."
    except Exception as e:
        return False, f"Read Error: {str(e)}"

def restore_backup_file(filename):
    """Wipes current active data and restores from backup."""
    filepath = os.path.join(BACKUP_DIR, filename)
    is_valid, msg = verify_backup_file(filepath)
    if not is_valid:
        return False, msg
        
    try:
        with open(filepath, 'r') as f:
            backup = json.load(f)
        content = backup['content']
        
        # 1. WIPE TABLES
        BorrowedBook.query.delete()
        TeacherBorrowedBook.query.delete()
        ClassBorrowing.query.delete()
        Student.query.delete()
        Book.query.delete()
        
        # 2. RESTORE DATA
        for b in content.get('books', []):
            db.session.add(
                Book(
                    book_id=b['book_id'],
                    title=b['title'],
                    author=b['author'],
                    category=b.get('category', 'Uncategorized'),
                    added_at=b['added_at'],
                )
            )
            
        for s in content.get('students', []):
            db.session.add(Student(name=s['name'], student_class=s['class']))
            
        for l in content.get('loans_student', []):
            db.session.add(BorrowedBook(
                book_id=l['book_id'], book_title=l['book_title'], student_name=l['student'], student_class=l['class'],
                condition=l.get('condition', 'Good'), timestamp=l['date'], due_date=l['due']
            ))
            
        for l in content.get('loans_staff', []):
            db.session.add(TeacherBorrowedBook(
                book_id=l['book_id'], book_title=l['book_title'], teacher_name=l['teacher'],
                condition=l.get('condition', 'Good'), notes=l.get('notes', ''), timestamp=l['date']
            ))
            
        for l in content.get('loans_class', []):
            db.session.add(ClassBorrowing(
                class_name=l['class'], responsibles=l['resp'], book_title=l['title'], book_ids=l['ids'],
                quantity=l['qty'], condition=l.get('cond', 'Good'), borrow_time=l['date']
            ))
            
        db.session.commit()
        return True, f"Restored snapshot from {backup['timestamp']}"
        
    except Exception as e:
        db.session.rollback()
        return False, str(e)

def create_zip_of_backups(filenames):
    memory_file = BytesIO()
    with zipfile.ZipFile(memory_file, 'w') as zf:
        for fname in filenames:
            path = os.path.join(BACKUP_DIR, fname)
            if os.path.exists(path):
                zf.write(path, fname)
    memory_file.seek(0)
    return memory_file


# --- MIGRATION HELPERS ---
def migrate_add_book_category():
    """Add `category` to `bookstable` if it is missing."""
    conn = None
    try:
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        _ensure_column(
            cur,
            'bookstable',
            'category',
            'category TEXT DEFAULT "Uncategorized"',
        )
        cur.execute(
            "UPDATE bookstable SET category = COALESCE(NULLIF(category, ''), 'Uncategorized')"
        )
        conn.commit()
    except Exception:
        if conn:
            conn.rollback()
    finally:
        if conn:
            conn.close()


def migrate_add_note_title():
    """Add `title` column to `notes` table if missing and migrate existing '|||'-delimited rows.
    This function is safe to call multiple times.
    """
    import sqlite3
    conn = None
    try:
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()

        # Check if column exists
        cur.execute("PRAGMA table_info(notes)")
        cols = [r[1] for r in cur.fetchall()]
        if 'title' not in cols:
            try:
                cur.execute('ALTER TABLE notes ADD COLUMN title TEXT')
                conn.commit()
            except Exception:
                pass

        # Migrate existing rows that used the delimiter
        cur.execute('SELECT id, content FROM notes')
        rows = cur.fetchall()
        for rid, content in rows:
            raw = '' if content is None else str(content)
            if '|||' in raw:
                parts = raw.split('|||', 1)
                title = parts[0].strip() or None
                body = parts[1].strip() if len(parts) > 1 else ''
                cur.execute('UPDATE notes SET title = ?, content = ? WHERE id = ?', (title, body, rid))
            else:
                # ensure title is NULL for old-format rows
                cur.execute('UPDATE notes SET title = NULL, content = ? WHERE id = ?', (raw, rid))

        conn.commit()
    except Exception:
        if conn:
            conn.rollback()
    finally:
        if conn:
            conn.close()


SYNC_TRACKED_TABLES = [
    'admin',
    'students',
    'bookstable',
    'borrowed_books',
    'teacher_borrowed_books',
    'class_borrowing',
    'graduates_borrowed_books',
    'graduates_class_borrowing',
    'notes',
    'logs',
    'book_issues',
    'update_history',
]


def _table_exists(cursor, table_name):
    cursor.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name = ?",
        (table_name,),
    )
    return cursor.fetchone() is not None


def _column_names(cursor, table_name):
    cursor.execute(f"PRAGMA table_info({table_name})")
    return {row[1] for row in cursor.fetchall()}


def _ensure_column(cursor, table_name, column_name, sql_definition, fallback_definition=None):
    if column_name in _column_names(cursor, table_name):
        return

    try:
        cursor.execute(f"ALTER TABLE {table_name} ADD COLUMN {sql_definition}")
    except sqlite3.OperationalError as exc:
        message = str(exc).lower()
        if fallback_definition and "non-constant default" in message:
            cursor.execute(f"ALTER TABLE {table_name} ADD COLUMN {fallback_definition}")
            return
        if "duplicate column name" in message:
            return
        raise


def _shared_columns(cursor, source_table, target_table, preferred_columns):
    source_columns = _column_names(cursor, source_table)
    target_columns = _column_names(cursor, target_table)
    return [column for column in preferred_columns if column in source_columns and column in target_columns]


def _copy_shared_columns(cursor, source_table, target_table, preferred_columns):
    columns = _shared_columns(cursor, source_table, target_table, preferred_columns)
    if not columns:
        return
    column_list = ", ".join(columns)
    cursor.execute(
        f"INSERT OR IGNORE INTO {target_table} ({column_list}) "
        f"SELECT {column_list} FROM {source_table}"
    )


def _available_table_name(cursor, base_name):
    candidate = base_name
    suffix = 1
    while _table_exists(cursor, candidate):
        candidate = f"{base_name}_{suffix}"
        suffix += 1
    return candidate


def migrate_sync_schema():
    conn = None
    try:
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()

        legacy_peer_queue_columns = {
            'id',
            'change_id',
            'action',
            'table_name',
            'record_id',
            'payload',
            'performed_by',
            'timestamp',
            'delivered',
        }
        modern_sync_queue_columns = {
            'id',
            'operation_id',
            'school_id',
            'device_id',
            'entity_type',
            'entity_id',
            'operation',
            'status',
            'payload',
            'record_updated_at',
            'attempt_count',
            'next_retry_at',
            'last_error',
            'created_at',
            'processed_at',
            'updated_at',
        }

        if _table_exists(cur, 'sync_queue'):
            existing_sync_queue_columns = _column_names(cur, 'sync_queue')
            if legacy_peer_queue_columns.issubset(existing_sync_queue_columns) and not modern_sync_queue_columns.issubset(existing_sync_queue_columns):
                if _table_exists(cur, 'peer_sync_queue'):
                    _copy_shared_columns(
                        cur,
                        'sync_queue',
                        'peer_sync_queue',
                        [
                            'id',
                            'change_id',
                            'action',
                            'table_name',
                            'record_id',
                            'payload',
                            'performed_by',
                            'timestamp',
                            'delivered',
                        ],
                    )
                    cur.execute(
                        f"ALTER TABLE sync_queue RENAME TO {_available_table_name(cur, 'sync_queue_legacy_backup')}"
                    )
                else:
                    cur.execute("ALTER TABLE sync_queue RENAME TO peer_sync_queue")
            elif not modern_sync_queue_columns.issubset(existing_sync_queue_columns):
                cur.execute(
                    f"ALTER TABLE sync_queue RENAME TO {_available_table_name(cur, 'sync_queue_legacy_backup')}"
                )

        if _table_exists(cur, 'cloud_sync_queue') and not _table_exists(cur, 'sync_queue'):
            cur.execute("ALTER TABLE cloud_sync_queue RENAME TO sync_queue")

        for table_name in SYNC_TRACKED_TABLES:
            if not _table_exists(cur, table_name):
                continue

            _ensure_column(cur, table_name, 'updated_at', 'updated_at TEXT')
            _ensure_column(cur, table_name, 'deleted', 'deleted INTEGER DEFAULT 0')
            _ensure_column(cur, table_name, 'sync_status', "sync_status TEXT DEFAULT 'synced'")
            _ensure_column(cur, table_name, 'school_id', 'school_id INTEGER')

            cur.execute(f"UPDATE {table_name} SET updated_at = COALESCE(updated_at, CURRENT_TIMESTAMP)")
            cur.execute(f"UPDATE {table_name} SET deleted = COALESCE(deleted, 0)")
            cur.execute(f"UPDATE {table_name} SET sync_status = COALESCE(sync_status, 'synced')")
            cur.execute(f"CREATE INDEX IF NOT EXISTS idx_{table_name}_school_id ON {table_name}(school_id)")

        if _table_exists(cur, 'admin'):
            _ensure_column(cur, 'admin', 'role', "role TEXT DEFAULT 'admin'")
            cur.execute("UPDATE admin SET role = COALESCE(role, 'admin')")
            _ensure_column(cur, 'admin', 'profile_image', "profile_image TEXT DEFAULT 'default_profile.png'")

        if _table_exists(cur, 'bookstable'):
            _ensure_column(cur, 'bookstable', 'category', 'category TEXT DEFAULT "Uncategorized"')
            cur.execute(
                "UPDATE bookstable SET category = COALESCE(NULLIF(category, ''), 'Uncategorized')"
            )

        if _table_exists(cur, 'borrowed_books'):
            _ensure_column(cur, 'borrowed_books', 'performed_by', 'performed_by TEXT')

        if _table_exists(cur, 'logs'):
            _ensure_column(cur, 'logs', 'username', 'username TEXT')
            _ensure_column(cur, 'logs', 'route', 'route TEXT')
            _ensure_column(cur, 'logs', 'method', 'method TEXT')
            _ensure_column(cur, 'logs', 'status_code', 'status_code INTEGER DEFAULT 200')
            _ensure_column(cur, 'logs', 'details', 'details TEXT')
            _ensure_column(cur, 'logs', 'timestamp', 'timestamp TEXT')
            _ensure_column(
                cur,
                'logs',
                'created_at',
                'created_at TEXT DEFAULT CURRENT_TIMESTAMP',
                fallback_definition='created_at TEXT',
            )
            cur.execute("UPDATE logs SET status_code = COALESCE(status_code, 200)")
            cur.execute("UPDATE logs SET timestamp = COALESCE(timestamp, CURRENT_TIMESTAMP)")
            cur.execute("UPDATE logs SET created_at = COALESCE(created_at, CURRENT_TIMESTAMP)")
            if 'user_name' in _column_names(cur, 'logs'):
                cur.execute(
                    "UPDATE logs SET username = COALESCE(NULLIF(username, ''), user_name)"
                )
            if 'action' in _column_names(cur, 'logs'):
                cur.execute(
                    "UPDATE logs SET route = COALESCE(NULLIF(route, ''), action)"
                )

        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS schools (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                slug TEXT NOT NULL UNIQUE,
                contact_email TEXT,
                contact_phone TEXT,
                status TEXT NOT NULL DEFAULT 'active',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                deleted INTEGER NOT NULL DEFAULT 0
            )
            """
        )

        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS sync_metadata (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                device_id TEXT NOT NULL UNIQUE,
                school_id INTEGER NOT NULL,
                last_upload_at TEXT,
                last_download_at TEXT,
                last_synced_at TEXT,
                last_error TEXT,
                pending_operations INTEGER NOT NULL DEFAULT 0,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (school_id) REFERENCES schools(id)
            )
            """
        )

        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS sync_queue (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                operation_id TEXT NOT NULL UNIQUE,
                school_id INTEGER NOT NULL,
                device_id TEXT NOT NULL,
                entity_type TEXT NOT NULL,
                entity_id TEXT NOT NULL,
                operation TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending',
                payload TEXT NOT NULL DEFAULT '{}',
                record_updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                attempt_count INTEGER NOT NULL DEFAULT 0,
                next_retry_at TEXT,
                last_error TEXT,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                processed_at TEXT,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (school_id) REFERENCES schools(id)
            )
            """
        )

        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS sync_conflicts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                school_id INTEGER NOT NULL,
                entity_type TEXT NOT NULL,
                entity_id TEXT NOT NULL,
                local_payload TEXT NOT NULL,
                remote_payload TEXT NOT NULL,
                resolved_payload TEXT,
                local_updated_at TEXT,
                remote_updated_at TEXT,
                resolution TEXT NOT NULL DEFAULT 'pending',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                resolved_at TEXT,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (school_id) REFERENCES schools(id)
            )
            """
        )

        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS sync_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                change_id TEXT UNIQUE,
                device_id TEXT,
                device_label TEXT,
                performed_by TEXT,
                action TEXT,
                status TEXT,
                error TEXT,
                timestamp TEXT
            )
            """
        )

        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS peer_sync_queue (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                change_id TEXT NOT NULL UNIQUE,
                action TEXT NOT NULL,
                table_name TEXT NOT NULL,
                record_id TEXT,
                payload TEXT,
                performed_by TEXT,
                timestamp TEXT,
                delivered INTEGER NOT NULL DEFAULT 0
            )
            """
        )

        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS peer_sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                device_id TEXT NOT NULL UNIQUE,
                token TEXT,
                label TEXT,
                trusted INTEGER NOT NULL DEFAULT 1,
                last_seen TEXT
            )
            """
        )

        cur.execute("CREATE INDEX IF NOT EXISTS idx_sync_queue_status ON sync_queue(status)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_sync_queue_school_entity ON sync_queue(school_id, entity_type, entity_id)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_sync_conflicts_school_entity ON sync_conflicts(school_id, entity_type, entity_id)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_peer_sync_queue_delivered ON peer_sync_queue(delivered)")

        if _table_exists(cur, 'cloud_sync_metadata'):
            _copy_shared_columns(
                cur,
                'cloud_sync_metadata',
                'sync_metadata',
                [
                    'device_id',
                    'school_id',
                    'last_upload_at',
                    'last_download_at',
                    'last_synced_at',
                    'last_error',
                    'pending_operations',
                    'updated_at',
                ],
            )

        if _table_exists(cur, 'cloud_sync_queue'):
            _copy_shared_columns(
                cur,
                'cloud_sync_queue',
                'sync_queue',
                [
                    'operation_id',
                    'school_id',
                    'device_id',
                    'entity_type',
                    'entity_id',
                    'operation',
                    'status',
                    'payload',
                    'record_updated_at',
                    'attempt_count',
                    'next_retry_at',
                    'last_error',
                    'created_at',
                    'processed_at',
                    'updated_at',
                ],
            )

        if _table_exists(cur, 'cloud_sync_conflicts'):
            cloud_conflict_columns = _column_names(cur, 'cloud_sync_conflicts')
            required_conflict_columns = {
                'school_id',
                'entity_type',
                'entity_id',
                'local_payload',
                'remote_payload',
                'merged_payload',
                'local_updated_at',
                'remote_updated_at',
                'resolution',
                'created_at',
                'resolved_at',
            }
            if required_conflict_columns.issubset(cloud_conflict_columns):
                cur.execute(
                    """
                    INSERT INTO sync_conflicts (
                        school_id,
                        entity_type,
                        entity_id,
                        local_payload,
                        remote_payload,
                        resolved_payload,
                        local_updated_at,
                        remote_updated_at,
                        resolution,
                        created_at,
                        resolved_at,
                        updated_at
                    )
                    SELECT
                        school_id,
                        entity_type,
                        entity_id,
                        local_payload,
                        remote_payload,
                        merged_payload,
                        local_updated_at,
                        remote_updated_at,
                        resolution,
                        created_at,
                        resolved_at,
                        COALESCE(resolved_at, created_at, CURRENT_TIMESTAMP)
                    FROM cloud_sync_conflicts
                    WHERE NOT EXISTS (
                        SELECT 1
                        FROM sync_conflicts
                        WHERE sync_conflicts.school_id = cloud_sync_conflicts.school_id
                          AND sync_conflicts.entity_type = cloud_sync_conflicts.entity_type
                          AND sync_conflicts.entity_id = cloud_sync_conflicts.entity_id
                          AND COALESCE(sync_conflicts.created_at, '') = COALESCE(cloud_sync_conflicts.created_at, '')
                    )
                    """
                )

        cur.execute("SELECT id FROM schools WHERE deleted = 0 ORDER BY id LIMIT 1")
        school_row = cur.fetchone()
        if school_row:
            default_school_id = school_row[0]
        else:
            cur.execute(
                """
                INSERT INTO schools (name, slug, contact_email, contact_phone, status)
                VALUES (?, ?, ?, ?, ?)
                """,
                ("Default School", "default-school", None, None, "active"),
            )
            default_school_id = cur.lastrowid

        for table_name in SYNC_TRACKED_TABLES:
            if _table_exists(cur, table_name):
                cur.execute(
                    f"UPDATE {table_name} SET school_id = COALESCE(school_id, ?)",
                    (default_school_id,),
                )

        cur.execute(
            """
            INSERT OR IGNORE INTO sync_metadata (device_id, school_id, pending_operations)
            VALUES (?, ?, 0)
            """,
            (load_config().get('device_id', default_device_id()), default_school_id),
        )

        conn.commit()
    except Exception as exc:
        if conn:
            conn.rollback()
        print(f"[migrate_sync_schema] {exc}", file=sys.stderr)
    finally:
        if conn:
            conn.close()
