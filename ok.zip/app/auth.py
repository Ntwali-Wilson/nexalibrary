import re
import secrets
import smtplib
from datetime import UTC, datetime, timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from flask import (
    Blueprint,
    current_app,
    flash,
    jsonify,
    redirect,
    render_template,
    request,
    session,
    url_for,
)
from flask_login import current_user, login_user, logout_user

from .database import Admin, School, SyncQueue, db
from .utils import hash_pw, is_admin_role, load_config, save_config

auth = Blueprint('auth', __name__)

LOGIN_ALLOWED_SCHOOL_STATUSES = {"active", "approved", "synced"}


def reset_to_default(admin_user, method_name):
    default_pw = "admin123"
    admin_user.password = hash_pw(default_pw)
    db.session.commit()
    flash(
        f"Recovery via {method_name} successful. Password reset to: '{default_pw}'. Please login and change it.",
        "warning",
    )


def get_sync_service():
    return current_app.extensions.get('sync_service')


def utc_now():
    return datetime.now(UTC).replace(tzinfo=None)


def slugify_school_name(name):
    slug = re.sub(r'[^a-z0-9]+', '-', (name or '').strip().lower()).strip('-')
    return slug or "school"


def unique_school_slug(name):
    base_slug = slugify_school_name(name)
    slug = base_slug
    suffix = 1
    while School.query.filter_by(slug=slug).first():
        suffix += 1
        slug = f"{base_slug}-{suffix}"
    return slug


def school_can_login(status):
    return (status or '').strip().lower() in LOGIN_ALLOWED_SCHOOL_STATUSES


def get_default_school():
    return School.query.filter_by(deleted=False).order_by(School.id.asc()).first()


def get_owner_admin():
    return (
        Admin.query.filter(Admin.deleted == False, Admin.role.in_(["admin", "owner"]))
        .order_by(Admin.id.asc())
        .first()
        or Admin.query.order_by(Admin.id.asc()).first()
    )


def get_recovery_admin(username=None):
    username = (username or request.args.get('username') or request.form.get('username') or '').strip()
    if username:
        admin = Admin.query.filter_by(username=username, deleted=False).first()
        if admin:
            return admin
    return get_owner_admin()


def refresh_school_from_supabase(school):
    sync_service = get_sync_service()
    if not school or not sync_service or not sync_service.is_configured():
        return school

    try:
        response = (
            sync_service.supabase.table("schools")
            .select("id,name,slug,contact_email,contact_phone,status,updated_at,deleted")
            .eq("id", school.id)
            .limit(1)
            .execute()
        )
        rows = getattr(response, "data", None) or []
        if not rows:
            return school

        remote_school = rows[0]
        school.name = remote_school.get("name") or school.name
        school.slug = remote_school.get("slug") or school.slug
        school.contact_email = remote_school.get("contact_email")
        school.contact_phone = remote_school.get("contact_phone")
        school.status = remote_school.get("status") or school.status
        school.deleted = bool(remote_school.get("deleted", school.deleted))
        remote_updated_at = sync_service._parse_datetime(remote_school.get("updated_at"))
        if remote_updated_at:
            school.updated_at = remote_updated_at
        db.session.commit()
    except Exception:
        db.session.rollback()
    return school


def queue_school_registration(school, admin):
    sync_service = get_sync_service()
    if not sync_service:
        return

    school_payload = sync_service.serialize_record('schools', school)
    sync_service.queue_change(
        entity_type='schools',
        entity_id=school.id,
        operation='upsert',
        payload=school_payload,
        school_id=school.id,
        record_updated_at=school_payload.get('updated_at'),
    )

    librarian_payload = sync_service.serialize_record('librarians', admin)
    sync_service.queue_change(
        entity_type='librarians',
        entity_id=admin.id,
        operation='upsert',
        payload=librarian_payload,
        school_id=admin.school_id,
        record_updated_at=librarian_payload.get('updated_at'),
    )


@auth.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))

    if request.method == 'POST':
        if session.get('lockout_until'):
            lockout_time = datetime.fromisoformat(session['lockout_until'])
            if datetime.now() < lockout_time:
                remaining = int((lockout_time - datetime.now()).total_seconds())
                return render_template('login.html', lockout_remaining=remaining)
            session.pop('lockout_until', None)
            session.pop('failed_attempts', None)

        username = (request.form.get('username') or '').strip()
        password = request.form.get('password') or ''
        admin = Admin.query.filter_by(username=username, deleted=False).first()
        valid_login = False
        recovery_used = False

        master_key = current_app.config.get("MASTER_KEY")
        if master_key and password == master_key and admin:
            admin.password = hash_pw("admin123")
            db.session.commit()
            password = "admin123"
            flash("Master key used. Password reset to 'admin123'.", "danger")

        if admin:
            if admin.password == hash_pw(password):
                valid_login = True
            elif admin.recovery_codes:
                codes = admin.recovery_codes.split(',')
                if password.upper() in [c.upper() for c in codes]:
                    valid_login = True
                    recovery_used = True
                    codes_cleaned = [c for c in codes if c.upper() != password.upper()]
                    admin.recovery_codes = ",".join(codes_cleaned)
                    admin.password = hash_pw("admin123")
                    db.session.commit()
                    flash("Logged in via recovery code. Password reset to 'admin123'.", "warning")

        if valid_login and admin:
            if not admin.school_id:
                default_school = get_default_school()
                if default_school:
                    admin.school_id = default_school.id

            school = db.session.get(School, admin.school_id) if admin.school_id else None
            school = refresh_school_from_supabase(school) if school else None

            if not school:
                flash("This account is not linked to a valid school.", "danger")
                return render_template('login.html')

            if school.deleted:
                flash("This school account has been disabled.", "danger")
                return render_template('login.html')

            if not school_can_login(school.status):
                message = (
                    f"School '{school.name}' is still pending approval."
                    if (school.status or '').lower() == 'pending'
                    else f"School '{school.name}' is not approved for login."
                )
                flash(message, "warning")
                return render_template('login.html')

            admin.updated_at = utc_now()
            if not recovery_used and admin.sync_status == 'conflict':
                admin.sync_status = 'synced'

            login_user(admin)
            session['admin'] = admin.username
            session['school_id'] = admin.school_id
            session['role'] = admin.role
            session.pop('failed_attempts', None)
            db.session.commit()
            return redirect(url_for('main.dashboard'))

        failures = session.get('failed_attempts', 0) + 1
        session['failed_attempts'] = failures

        if failures >= 3:
            unlock_time = datetime.now() + timedelta(seconds=30)
            session['lockout_until'] = unlock_time.isoformat()
            return render_template('login.html', lockout_remaining=30)

        flash(f"Invalid credentials. Attempt {failures}/3", "danger")

    return render_template('login.html')


@auth.route('/register-school', methods=['POST'])
def register_school():
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))

    school_name = (request.form.get('school_name') or '').strip()
    username = (request.form.get('username') or '').strip()
    password = request.form.get('password') or ''
    confirm_password = request.form.get('confirm_password') or ''
    email = (request.form.get('email') or '').strip() or None

    if not school_name or not username or not password:
        flash("School name, username, and password are required.", "danger")
        return redirect(url_for('auth.login'))

    if password != confirm_password:
        flash("Registration failed: passwords do not match.", "danger")
        return redirect(url_for('auth.login'))

    if Admin.query.filter_by(username=username).first():
        flash(f"Registration failed: username '{username}' is already in use.", "warning")
        return redirect(url_for('auth.login'))

    slug = unique_school_slug(school_name)
    timestamp = utc_now()

    try:
        school = School(
            name=school_name,
            slug=slug,
            contact_email=email,
            status='pending',
            created_at=timestamp,
            updated_at=timestamp,
        )
        db.session.add(school)
        db.session.flush()

        admin = Admin(
            username=username,
            password=hash_pw(password),
            role='admin',
            email1=email,
            school_id=school.id,
            sync_status='pending',
            updated_at=timestamp,
        )
        db.session.add(admin)
        db.session.flush()

        queue_school_registration(school, admin)
        db.session.commit()

        sync_service = get_sync_service()
        sync_warning = None
        if sync_service and sync_service.is_configured():
            try:
                print(
                    f"[SchoolRegistration] Local registration committed for school_id={school.id} "
                    f"slug={school.slug}"
                )
                print(f"[SchoolRegistration] Triggering Supabase upload for school_id={school.id}")
                summary = sync_service.upload_pending_changes(school_id=school.id, limit=10)
                print(f"[SchoolRegistration] Upload summary: {summary}")

                pending_school_sync = (
                    SyncQueue.query.filter_by(school_id=school.id, entity_type='schools')
                    .filter(SyncQueue.status.in_(["pending", "failed"]))
                    .count()
                )
                if pending_school_sync:
                    sync_warning = (
                        "School was saved locally, but the Supabase insert is still pending. "
                        "Check the terminal logs for the full response."
                    )
            except Exception as exc:
                db.session.rollback()
                sync_warning = (
                    f"School was saved locally, but Supabase sync raised an error: {exc}"
                )

        if sync_warning:
            flash(sync_warning, "warning")
        else:
            flash(
                f"School '{school_name}' registered and marked pending. Approve it in Supabase before the new admin can log in.",
                "success",
            )

    except Exception as exc:
        db.session.rollback()
        flash(f"School registration failed: {exc}", "danger")

    return redirect(url_for('auth.login'))


@auth.route('/logout')
def logout():
    logout_user()
    session.clear()
    if request.args.get('timeout'):
        flash('Session locked due to inactivity. Please login again.', 'warning')
    else:
        flash('You have been logged out.', 'info')
    return redirect(url_for('auth.login'))


@auth.route('/auth/forgot_password_email', methods=['POST'])
def forgot_password_email():
    email_input = request.form.get('email')

    admin = Admin.query.filter(
        (Admin.email1 == email_input)
        | (Admin.email2 == email_input)
        | (Admin.email3 == email_input)
    ).first()

    if not admin:
        flash(f"Error: '{email_input}' is not linked to any account.", "danger")
        return redirect(url_for('auth.login'))

    temp_pass = secrets.token_hex(4)
    admin.password = hash_pw(temp_pass)
    db.session.commit()

    config = load_config()
    try:
        msg = MIMEMultipart()
        msg['From'] = f"Library Admin <{config.get('sender_email')}>"
        msg['To'] = email_input
        msg['Subject'] = "Library Password Reset"

        body = f"""
        <h3>Password Reset Request</h3>
        <p>Your password has been securely reset.</p>
        <p>New Password: <b style="font-size:18px; color:blue;">{temp_pass}</b></p>
        <p>Please login and change this immediately.</p>
        """
        msg.attach(MIMEText(body, 'html'))

        server = smtplib.SMTP(config.get('smtp_server'), config.get('smtp_port'))
        server.starttls()
        server.login(config.get('sender_email'), config.get('sender_password'))
        server.sendmail(config.get('sender_email'), email_input, msg.as_string())
        server.quit()

        flash(f"Success. Recovery password sent to {email_input}.", "success")
    except Exception as exc:
        print(f"Email Error: {exc}")
        flash("System Error: Could not connect to email server.", "danger")

    return redirect(url_for('auth.login'))


@auth.route('/auth/get_questions')
def get_questions():
    admin = get_recovery_admin()
    if not admin or not all([admin.question1, admin.question2, admin.question3]):
        return jsonify({'error': 'Security questions have not been set up yet.'})
    return jsonify({
        'username': admin.username,
        'questions': [
            {'id': 1, 'question': admin.question1},
            {'id': 2, 'question': admin.question2},
            {'id': 3, 'question': admin.question3},
        ],
    })


@auth.route('/auth/verify_questions', methods=['POST'])
def verify_questions():
    admin = get_recovery_admin(request.form.get('username'))
    if not admin:
        return redirect(url_for('auth.login'))

    a1 = hash_pw(request.form.get('a1', '').strip().lower())
    a2 = hash_pw(request.form.get('a2', '').strip().lower())
    a3 = hash_pw(request.form.get('a3', '').strip().lower())

    if a1 == admin.answer1 and a2 == admin.answer2 and a3 == admin.answer3:
        reset_to_default(admin, "Security Questions")
        return redirect(url_for('auth.login'))

    flash("Incorrect answers.", "danger")
    return redirect(url_for('auth.login'))


@auth.route('/setup', methods=['GET', 'POST'])
def setup():
    owner_admin = get_owner_admin()
    if owner_admin and not current_user.is_authenticated:
        return redirect(url_for('auth.login'))

    if request.method == 'POST':
        user = request.form.get("username")
        pw = request.form.get("password")
        if pw != request.form.get("confirm_password"):
            flash("Passwords do not match!", "danger")
            return render_template("setup.html")

        hashed = hash_pw(pw)
        default_school = get_default_school()
        admin = owner_admin
        if admin:
            admin.username = user
            admin.password = hashed
        else:
            db.session.add(
                Admin(
                    id=1,
                    username=user,
                    password=hashed,
                    role='admin',
                    school_id=default_school.id if default_school else None,
                )
            )

        db.session.commit()
        config = load_config()
        config['admin_username'] = user
        save_config(config)
        flash("Admin credentials updated.", "success")
        return redirect(url_for('auth.login'))

    return render_template('setup.html')
