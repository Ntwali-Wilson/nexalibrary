const DATABASE_NAME = "LibraryOfflineDB";
const DATABASE_VERSION = 1;
const SYNC_QUEUE_SCHEMA =
  "++id, operation_id, school_id, entity_type, entity_id, operation, status, created_at, attempt_count";

let db = window.db;
const isDbInitialized = window.__LibraryOfflineDBInitialized;
let _isOnline = navigator.onLine;
let _syncInProgress = false;
let _lastStatus = null;
const BASE_SYNC_INTERVAL_MS = Math.max(
  15000,
  (window.librarySyncConfig?.syncPollIntervalSeconds || 60) * 1000
);
const MAX_SYNC_RETRY_MS = Math.max(
  BASE_SYNC_INTERVAL_MS,
  (window.librarySyncConfig?.syncRetryMaxSeconds || 300) * 1000
);
let _syncRetryDelayMs = BASE_SYNC_INTERVAL_MS;
let _syncLoopTimer = null;

if (!db) {
  db = new Dexie(DATABASE_NAME);
  window.db = db;
}

if (!isDbInitialized) {
  db.version(DATABASE_VERSION).stores({
    syncQueue: SYNC_QUEUE_SCHEMA,
  });
  window.__LibraryOfflineDBInitialized = true;
  db.open()
    .then(() => console.log("[Sync] IndexedDB ready:", db.name))
    .catch((err) => console.error("[Sync] IndexedDB failed:", err));
}

function generateUUID() {
  if (crypto?.randomUUID) return crypto.randomUUID();
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    return (c === "x" ? r : (r & 0x3) | 0x8).toString(16);
  });
}

function getSchoolId() {
  return localStorage.getItem("school_id") || window.SCHOOL_ID || null;
}

function isOnline() {
  return _isOnline;
}

function createAbortSignal(timeoutMs) {
  if (typeof AbortController === "undefined") {
    return { signal: undefined, cleanup: () => {} };
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  return {
    signal: controller.signal,
    cleanup: () => clearTimeout(timer),
  };
}

async function fetchWithTimeout(url, options = {}, timeoutMs = 10000) {
  const { signal, cleanup } = createAbortSignal(timeoutMs);
  try {
    return await fetch(url, { ...options, signal });
  } finally {
    cleanup();
  }
}

function safeParsePayload(payload, operationId) {
  if (!payload) return {};
  try {
    return JSON.parse(payload);
  } catch (err) {
    console.warn(`[Sync] Invalid payload JSON for ${operationId}:`, err);
    return {};
  }
}

async function safeParseResponse(response) {
  try {
    return await response.json();
  } catch (err) {
    console.warn("[Sync] Unable to parse server response as JSON:", err);
    return {};
  }
}

function getSyncBadge() {
  return document.getElementById("syncStatusBadge");
}

function getConflictSummary() {
  return document.getElementById("syncConflictSummary");
}

function setSyncState(state, label) {
  const badge = getSyncBadge();
  if (!badge) return;
  badge.dataset.state = state;
  badge.textContent = label;
}

function updateConflictSummary(statusData) {
  const summary = getConflictSummary();
  if (!summary) return;

  const conflictCount = Array.isArray(statusData?.conflicts)
    ? statusData.conflicts.length
    : 0;

  if (conflictCount > 0) {
    summary.textContent = `${conflictCount} sync conflict(s) need review.`;
    summary.classList.add("is-visible");
  } else {
    summary.textContent = "";
    summary.classList.remove("is-visible");
  }
}

function updateLegacyPendingBadge(totalCount) {
  const legacyBadge = document.getElementById("sync-pending-badge");
  if (!legacyBadge) return;
  legacyBadge.textContent = totalCount > 0 ? `${totalCount} unsynced` : "Synced";
  legacyBadge.style.display = totalCount > 0 ? "inline-block" : "none";
}

function resetSyncBackoff() {
  _syncRetryDelayMs = BASE_SYNC_INTERVAL_MS;
}

function increaseSyncBackoff() {
  _syncRetryDelayMs = Math.min(
    MAX_SYNC_RETRY_MS,
    Math.max(BASE_SYNC_INTERVAL_MS, _syncRetryDelayMs * 2)
  );
  return _syncRetryDelayMs;
}

function scheduleSyncLoop(delayMs = BASE_SYNC_INTERVAL_MS) {
  if (_syncLoopTimer) {
    clearTimeout(_syncLoopTimer);
  }
  _syncLoopTimer = window.setTimeout(runSyncLoop, delayMs);
}

function isTransientSyncMessage(message) {
  const text = String(message || "").toLowerCase();
  return [
    "winerror 10054",
    "connection reset",
    "connectionreseterror",
    "network",
    "timeout",
    "timed out",
    "transient sync error",
  ].some((marker) => text.includes(marker));
}

function renderSyncState({ localCount = 0, backendCount = 0, statusData = null } = {}) {
  const totalCount = localCount + backendCount;
  const configured = Boolean(statusData?.configured);
  const cloudReachable = Boolean(statusData?.cloud_reachable);

  updateLegacyPendingBadge(totalCount);
  updateConflictSummary(statusData);

  if (!navigator.onLine || !configured || !cloudReachable) {
    setSyncState("offline", "Offline");
    return "offline";
  }

  if (_syncInProgress || totalCount > 0) {
    setSyncState("syncing", "Syncing");
    return "syncing";
  }

  setSyncState("synced", "Synced");
  return "synced";
}

async function probeConnectivity() {
  try {
    const response = await fetchWithTimeout(
      window.librarySyncConfig?.syncStatusEndpoint || "/api/sync/status",
      { method: "GET", cache: "no-store" },
      5000
    );
    const data = await safeParseResponse(response);
    _lastStatus = data;
    _isOnline = Boolean(
      response.ok && data?.configured && data?.cloud_reachable
    );
    return _isOnline;
  } catch (err) {
    console.warn("[Sync] Connectivity probe failed:", err.message || err);
    _isOnline = false;
    _lastStatus = null;
    return false;
  }
}

async function queueOperation(entityType, operation, data) {
  const school_id = getSchoolId();
  if (!school_id) {
    console.warn("[Sync] school_id not found - cannot queue operation.");
    return null;
  }

  const operation_id = generateUUID();
  const entity_id = data.id || data.book_id || operation_id;
  const record = {
    operation_id,
    school_id,
    entity_type: entityType,
    entity_id: String(entity_id),
    operation,
    payload: JSON.stringify(data),
    status: "pending",
    created_at: new Date().toISOString(),
    attempt_count: 0,
  };

  const id = await db.syncQueue.add(record);
  await updateSyncBadge();
  console.log(`[Sync] Queued operation: ${operation} on ${entityType}`, record);
  return id;
}

async function apiRequest(url, options = {}, entityType = null, operation = null, data = null) {
  const online = await probeConnectivity();

  if (!online) {
    if (entityType && operation && data) {
      await queueOperation(entityType, operation, data);
      return { queued: true, offline: true };
    }
    throw new Error("Offline and no queue config provided.");
  }

  try {
    const response = await fetchWithTimeout(
      url,
      {
        headers: { "Content-Type": "application/json" },
        ...options,
      },
      15000
    );

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`HTTP ${response.status}: ${errorText}`);
    }

    const result = await safeParseResponse(response);
    await updateSyncBadge();
    return result;
  } catch (err) {
    _isOnline = false;
    console.warn("[Sync] Request failed, switching to offline queue:", err.message || err);
    if (entityType && operation && data) {
      await queueOperation(entityType, operation, data);
      return { queued: true, offline: true };
    }
    throw err;
  }
}

async function addBook(bookData) {
  return apiRequest(
    "/api/books",
    { method: "POST", body: JSON.stringify(bookData) },
    "books",
    "create",
    bookData
  );
}

async function updateBook(bookId, bookData) {
  return apiRequest(
    `/api/books/${bookId}`,
    { method: "PUT", body: JSON.stringify(bookData) },
    "books",
    "update",
    { ...bookData, book_id: bookId }
  );
}

async function deleteBook(bookId) {
  return apiRequest(
    `/api/books/${bookId}`,
    { method: "DELETE" },
    "books",
    "delete",
    { book_id: bookId, deleted: true }
  );
}

async function addMember(memberData) {
  return apiRequest(
    "/api/members",
    { method: "POST", body: JSON.stringify(memberData) },
    "members",
    "create",
    memberData
  );
}

async function updateMember(memberId, memberData) {
  return apiRequest(
    `/api/members/${memberId}`,
    { method: "PUT", body: JSON.stringify(memberData) },
    "members",
    "update",
    { ...memberData, id: memberId }
  );
}

async function deleteMember(memberId) {
  return apiRequest(
    `/api/members/${memberId}`,
    { method: "DELETE" },
    "members",
    "delete",
    { id: memberId, deleted: true }
  );
}

async function addCheckout(checkoutData) {
  return apiRequest(
    "/api/checkouts",
    { method: "POST", body: JSON.stringify(checkoutData) },
    "checkouts",
    "create",
    checkoutData
  );
}

async function returnBook(checkoutId, data = {}) {
  return apiRequest(
    `/api/checkouts/${checkoutId}/return`,
    { method: "PUT", body: JSON.stringify(data) },
    "checkouts",
    "update",
    { ...data, id: checkoutId }
  );
}

async function incrementAttempts(items) {
  for (const item of items) {
    await db.syncQueue.update(item.id, {
      status: "failed",
      attempt_count: (item.attempt_count || 0) + 1,
    });
  }
}

async function processQueue() {
  if (_syncInProgress) {
    return false;
  }

  _syncInProgress = true;
  renderSyncState({ localCount: 1, backendCount: 0, statusData: _lastStatus });

  try {
    const pendingItems = await db.syncQueue
      .where("status")
      .anyOf(["pending", "failed"])
      .sortBy("created_at");

    const batch = pendingItems.map((item) => ({
      operation_id: item.operation_id,
      school_id: item.school_id,
      entity_type: item.entity_type,
      entity_id: item.entity_id,
      operation: item.operation,
      payload: safeParsePayload(item.payload, item.operation_id),
      created_at: item.created_at,
    }));

    let uploadResponse;
    try {
      uploadResponse = await fetchWithTimeout(
        window.librarySyncConfig?.syncUploadEndpoint || "/api/sync/upload",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ items: batch }),
        },
        30000
      );
    } catch (networkErr) {
      console.warn("[Sync] Upload failed:", networkErr.message || networkErr);
      _isOnline = false;
      increaseSyncBackoff();
      return false;
    }

    if (!uploadResponse.ok) {
      const failurePayload = await safeParseResponse(uploadResponse);
      const message = failurePayload?.message || uploadResponse.statusText;
      if (isTransientSyncMessage(message)) {
        _isOnline = false;
      }
      await incrementAttempts(pendingItems);
      increaseSyncBackoff();
      return false;
    }

    const uploadData = await safeParseResponse(uploadResponse);
    if (uploadData?.success === false) {
      increaseSyncBackoff();
      return false;
    }
    const syncedIds = new Set(uploadData?.summary?.synced || uploadData?.synced || []);
    const conflictIds = new Set(uploadData?.summary?.conflicts || uploadData?.conflicts || []);
    const failedIds = new Set(uploadData?.summary?.failed || uploadData?.failed || []);

    for (const item of pendingItems) {
      if (syncedIds.has(item.operation_id)) {
        await db.syncQueue.delete(item.id);
      } else if (conflictIds.has(item.operation_id)) {
        await db.syncQueue.update(item.id, { status: "conflict" });
      } else if (failedIds.has(item.operation_id)) {
        await db.syncQueue.update(item.id, {
          status: "failed",
          attempt_count: (item.attempt_count || 0) + 1,
        });
      } else if (uploadData?.success !== false) {
        await db.syncQueue.delete(item.id);
      }
    }

    try {
      await fetchWithTimeout(
        window.librarySyncConfig?.syncDownloadEndpoint || "/api/sync/download",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ limit: 250 }),
        },
        30000
      );
    } catch (downloadErr) {
      console.warn("[Sync] Download refresh failed:", downloadErr.message || downloadErr);
    }
    resetSyncBackoff();
    return true;
  } finally {
    _syncInProgress = false;
    await updateSyncBadge();
  }
}

async function updateSyncBadge() {
  const localCount = await db.syncQueue.where("status").anyOf(["pending", "failed"]).count();
  let backendCount = 0;
  let statusData = _lastStatus;

  try {
    const response = await fetchWithTimeout(
      window.librarySyncConfig?.syncStatusEndpoint || "/api/sync/status",
      { method: "GET", cache: "no-store" },
      5000
    );
    statusData = await safeParseResponse(response);
    _lastStatus = statusData;
    backendCount = statusData?.pending_count || 0;
    _isOnline = Boolean(response.ok && statusData?.configured && statusData?.cloud_reachable);
  } catch (err) {
    _isOnline = false;
  }

  return renderSyncState({ localCount, backendCount, statusData });
}

window.addEventListener("online", async () => {
  setSyncState("syncing", "Syncing");
  const online = await probeConnectivity();
  if (online) {
    resetSyncBackoff();
    await processQueue();
    scheduleSyncLoop(BASE_SYNC_INTERVAL_MS);
  } else {
    await updateSyncBadge();
    scheduleSyncLoop(increaseSyncBackoff());
  }
});

window.addEventListener("offline", async () => {
  _isOnline = false;
  renderSyncState({ localCount: 0, backendCount: 0, statusData: _lastStatus });
  scheduleSyncLoop(increaseSyncBackoff());
});

async function runSyncLoop() {
  const online = await probeConnectivity();
  if (online) {
    const synced = await processQueue();
    scheduleSyncLoop(synced ? BASE_SYNC_INTERVAL_MS : _syncRetryDelayMs);
  } else {
    increaseSyncBackoff();
    await updateSyncBadge();
    scheduleSyncLoop(_syncRetryDelayMs);
  }
}

probeConnectivity().then(async () => {
  await updateSyncBadge();
  scheduleSyncLoop(BASE_SYNC_INTERVAL_MS);
});

window.LibrarySync = {
  isOnline,
  queueOperation,
  processQueue,
  updateSyncBadge,
  addBook,
  updateBook,
  deleteBook,
  addMember,
  updateMember,
  deleteMember,
  addCheckout,
  returnBook,
  db,
};
