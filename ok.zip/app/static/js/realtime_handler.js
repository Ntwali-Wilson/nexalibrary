(function () {
    const config = window.librarySyncConfig || {};

    class LibraryRealtime {
        constructor(options) {
            this.config = options;
            this.client = null;
            this.channel = null;
            this.connected = false;
            this.tableMap = {
                bookstable: "books",
                students: "members",
                borrowed_books: "checkouts",
                logs: "logs",
            };
        }

        async init() {
            if (!navigator.onLine) {
                return;
            }

            if (!window.supabase || !window.supabase.createClient) {
                console.warn("Supabase browser client is not loaded.");
                return;
            }

            if (!this.config.supabaseUrl || !this.config.supabaseKey || !this.config.schoolId) {
                return;
            }

            this.client = window.supabase.createClient(
                this.config.supabaseUrl,
                this.config.supabaseKey,
                {
                    auth: {
                        persistSession: false,
                        autoRefreshToken: false,
                    },
                }
            );

            this.channel = this.client.channel(`school:${this.config.schoolId}:library`, {
                config: {
                    broadcast: { self: false },
                    presence: { key: this.config.deviceId || crypto.randomUUID() },
                },
            });

            this.registerDatabaseSubscriptions();
            this.registerBroadcastHandlers();
            this.registerPresenceHandlers();

            this.channel.subscribe(async (status) => {
                if (status !== "SUBSCRIBED") {
                    return;
                }

                this.connected = true;
                await this.channel.track({
                    librarian: this.config.librarianName || "Library Staff",
                    device_id: this.config.deviceId || crypto.randomUUID(),
                    online_at: new Date().toISOString(),
                });
            });

            window.addEventListener("online", async () => {
                if (!this.connected) {
                    await this.init();
                }
            });
        }

        registerDatabaseSubscriptions() {
            ["bookstable", "borrowed_books", "students", "logs"].forEach((tableName) => {
                this.channel.on(
                    "postgres_changes",
                    {
                        event: "*",
                        schema: "public",
                        table: tableName,
                        filter: `school_id=eq.${this.config.schoolId}`,
                    },
                    async (payload) => {
                        await this.handleTableChange(tableName, payload);
                    }
                );
            });
        }

        registerBroadcastHandlers() {
            this.channel.on("broadcast", { event: "activity" }, ({ payload }) => {
                if (!payload || payload.school_id !== this.config.schoolId) {
                    return;
                }
                this.showToast(payload.message || "Realtime activity received.");
            });
        }

        registerPresenceHandlers() {
            const render = () => this.renderPresence();
            this.channel.on("presence", { event: "sync" }, render);
            this.channel.on("presence", { event: "join" }, render);
            this.channel.on("presence", { event: "leave" }, render);
        }

        async handleTableChange(tableName, payload) {
            const entityType = this.tableMap[tableName];
            const row = payload.new || payload.old;
            const normalizedRow = row
                ? {
                    ...row,
                    deleted: payload.eventType === "DELETE" ? true : Boolean(row.deleted),
                }
                : null;

            if (entityType && normalizedRow && window.librarySyncClient) {
                await window.librarySyncClient.cacheRows(entityType, [normalizedRow]);
            }

            if (payload.eventType !== "DELETE") {
                const fallbackMessage = this.buildFallbackMessage(tableName, payload);
                if (fallbackMessage) {
                    this.showToast(fallbackMessage);
                }
            }

            window.dispatchEvent(
                new CustomEvent("library:realtime-update", {
                    detail: { tableName, payload },
                })
            );
        }

        buildFallbackMessage(tableName, payload) {
            if (tableName === "borrowed_books" && payload.eventType === "INSERT") {
                const bookTitle = payload.new.book_title || payload.new.book_id || "a book";
                return `${bookTitle} was checked out.`;
            }

            if (tableName === "logs" && payload.new && payload.new.details) {
                return payload.new.details;
            }

            if (tableName === "bookstable" && payload.eventType === "UPDATE") {
                return `Book ${payload.new.title || payload.new.book_id} was updated.`;
            }

            if (tableName === "students" && payload.eventType === "UPDATE") {
                return `Member ${payload.new.name || payload.new.id} was updated.`;
            }

            return "";
        }

        async broadcastActivity(activity) {
            if (!this.channel || !navigator.onLine) {
                return;
            }

            const payload = {
                ...activity,
                school_id: this.config.schoolId,
                actor: this.config.librarianName || "Library Staff",
                device_id: this.config.deviceId || "desktop-device",
                created_at: new Date().toISOString(),
            };

            try {
                await this.channel.send({
                    type: "broadcast",
                    event: "activity",
                    payload,
                });
            } catch (error) {
                console.warn("Broadcast failed:", error);
            }
        }

        renderPresence() {
            const list = document.getElementById("onlineLibrariansList");
            if (!list || !this.channel) {
                return;
            }

            const state = this.channel.presenceState();
            const librarians = Object.values(state)
                .flat()
                .map((entry) => entry.librarian)
                .filter(Boolean);
            const uniqueLibrarians = [...new Set(librarians)];

            if (!uniqueLibrarians.length) {
                list.innerHTML = "<li>No librarians online</li>";
                return;
            }

            list.innerHTML = uniqueLibrarians
                .map((name) => `<li>${name}</li>`)
                .join("");
        }

        showToast(message) {
            const container = document.getElementById("realtimeToastContainer");
            if (!container || !message) {
                return;
            }

            const element = document.createElement("div");
            element.className = "toast align-items-center border-0 show";
            element.setAttribute("role", "alert");
            element.innerHTML = `
                <div class="d-flex">
                    <div class="toast-body">${message}</div>
                    <button type="button" class="btn-close me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
                </div>
            `;

            container.appendChild(element);
            const toast = new bootstrap.Toast(element, { delay: 4500 });
            toast.show();
            element.addEventListener("hidden.bs.toast", () => element.remove());
        }
    }

    document.addEventListener("DOMContentLoaded", async () => {
        const realtime = new LibraryRealtime(config);
        window.libraryRealtime = realtime;
        await realtime.init();

        const liveRefreshEndpoints = new Set([
            "main.dashboard",
            "main.analytics",
            "main.books",
            "main.students",
            "main.borrowed",
        ]);
        let refreshTimer = null;
        window.addEventListener("library:realtime-update", (event) => {
            const detail = event.detail || {};
            if (!liveRefreshEndpoints.has(config.endpoint)) {
                return;
            }
            if (!["bookstable", "borrowed_books", "students", "logs"].includes(detail.tableName)) {
                return;
            }
            clearTimeout(refreshTimer);
            refreshTimer = window.setTimeout(() => {
                window.location.reload();
            }, 1200);
        });
    });
})();
