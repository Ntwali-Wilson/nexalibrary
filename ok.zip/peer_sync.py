"""
peer_sync.py  —  Unified LAN Sync Engine  (v2 — fixed)
========================================================
Fixes from v1:
  - Minor now uses saved major_ip as fallback when UDP broadcast fails
  - Eliminated recv/send deadlock: Major PUSHES first every cycle
  - Full-state bundled inside auth_ok (one round trip on connect)
  - TCP probe confirms Major is reachable before spending time on auth
"""

import socket
import threading
import json
import time
import uuid
import random
import logging
from datetime import datetime

logger = logging.getLogger("peer_sync")

TCP_PORT        = 9000
BROADCAST_PORT  = 9001
SERVICE_TAG     = "LibraryPeerSync_v2"
BUFFER_SIZE     = 131072
MAX_PEERS       = 8

_state = {
    "role": None, "running": False, "peers": {},
    "pending_count": 0, "conflicts": [], "last_sync": None,
    "major_ip": None, "my_ip": None, "sync_interval": 5, "error": None,
    "session_token": "", "connected": False,
}
_lock        = threading.Lock()
_server_sock = None
_flask_app   = None
_stop_event  = threading.Event()
_retry_event = threading.Event()

# ── Public API ────────────────────────────────────────────────────────────────

def start(role, flask_app, sync_interval=5):
    global _flask_app
    _flask_app = flask_app
    with _lock:
        _state["role"]          = role
        _state["sync_interval"] = sync_interval
        _state["my_ip"]         = _local_ip()
        _state["running"]       = True
        _state["connected"]     = False
    _stop_event.clear()
    _retry_event.clear()
    if role == "major":
        threading.Thread(target=_major_server_loop, daemon=True).start()
        threading.Thread(target=_broadcast_loop,    daemon=True).start()
    else:
        try:
            with flask_app.app_context():
                from app.utils import load_config
                cfg = load_config()
                saved = cfg.get("major_ip", "")
                if saved:
                    with _lock:
                        _state["major_ip"] = saved
                _state["session_token"] = cfg.get("session_token", "")
        except Exception:
            pass
        threading.Thread(target=_minor_client_loop, daemon=True).start()
    logger.info(f"[PEER] Started as {role.upper()} — {_state['my_ip']}")

def stop():
    _stop_event.set()
    _retry_event.set()
    with _lock:
        _state["running"] = False
        _state["connected"] = False
    if _server_sock:
        try: _server_sock.close()
        except Exception: pass

def get_status():
    with _lock:
        status = {k: (dict(v) if isinstance(v, dict) else list(v) if isinstance(v, list) else v)
                  for k, v in _state.items()}
    status["pending_count"] = _pending_count()
    role = status.get("role")
    if role == "major":
        status["connected"] = bool(status.get("running")) and not status.get("error") and (
            len(status.get("peers", {})) > 0
        )
    elif role == "minor":
        status["connected"] = bool(status.get("major_ip")) and not status.get("error")
    else:
        status["connected"] = False
    return status

def set_sync_interval(seconds):
    with _lock:
        _state["sync_interval"] = max(1, int(seconds))

def dismiss_conflict(index):
    with _lock:
        if 0 <= index < len(_state["conflicts"]):
            _state["conflicts"].pop(index)

def disconnect_peer(device_id):
    with _flask_app.app_context():
        from app.database import db, PeerSession
        PeerSession.query.filter_by(device_id=device_id).delete()
        db.session.commit()
    with _lock:
        _state["peers"].pop(device_id, None)

def generate_otp():
    return str(random.randint(100000, 999999))

def _wait_or_retry(seconds):
    deadline = time.time() + max(0, seconds)
    while not _stop_event.is_set():
        remaining = deadline - time.time()
        if remaining <= 0:
            return
        if _retry_event.wait(timeout=min(remaining, 0.5)):
            _retry_event.clear()
            return

# ── Network ───────────────────────────────────────────────────────────────────

def _local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]; s.close(); return ip
    except Exception:
        try:
            return socket.gethostbyname(socket.gethostname())
        except Exception:
            return "0.0.0.0"

def _send(sock, payload):
    data = json.dumps(payload, default=str).encode("utf-8") + b"<END>"
    total = 0
    while total < len(data):
        sent = sock.send(data[total:])
        if sent == 0: raise RuntimeError("Socket broken")
        total += sent

def _recv(sock, timeout=20):
    sock.settimeout(timeout)
    buf = b""
    try:
        while True:
            chunk = sock.recv(BUFFER_SIZE)
            if not chunk: break
            buf += chunk
            if b"<END>" in buf: break
    except Exception:
        pass
    if not buf: return None
    try:
        return json.loads(buf.split(b"<END>")[0].decode("utf-8"))
    except Exception:
        return None

def _tcp_probe(ip, timeout=2):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout); s.connect((ip, TCP_PORT)); s.close(); return True
    except Exception:
        return False

# ── OTP ───────────────────────────────────────────────────────────────────────

_active_otps = {}
_otp_lock    = threading.Lock()

def create_otp(device_id=None):
    code = generate_otp()
    with _otp_lock:
        _active_otps[code] = {"device_id": device_id, "expires": time.time() + 300}
    return code

def _consume_otp(code):
    with _otp_lock:
        e = _active_otps.get(code)
        if not e or time.time() > e["expires"]:
            _active_otps.pop(code, None); return None
        del _active_otps[code]; return e.get("device_id") or "auto"

def get_active_otps():
    now = time.time()
    with _otp_lock:
        return {k: v for k, v in _active_otps.items() if v["expires"] > now}

# ── Sessions ──────────────────────────────────────────────────────────────────

def _load_session(device_id):
    try:
        with _flask_app.app_context():
            from app.database import PeerSession
            s = PeerSession.query.filter_by(device_id=device_id).first()
            if s and s.trusted: return s.token
    except Exception: pass
    return None

def _save_session(device_id, label, token, trusted=True):
    try:
        with _flask_app.app_context():
            from app.database import db, PeerSession
            s = PeerSession.query.filter_by(device_id=device_id).first()
            if s:
                s.token = token; s.label = label; s.trusted = trusted; s.last_seen = _now()
            else:
                db.session.add(PeerSession(device_id=device_id, token=token,
                    label=label, trusted=trusted, last_seen=_now()))
            db.session.commit()
    except Exception as e:
        logger.error(f"[PEER] Session save: {e}")

def _my_device_identity():
    try:
        with _flask_app.app_context():
            from app.utils import load_config, save_config
            cfg = load_config()
            did, tok = cfg.get("device_id",""), cfg.get("session_token","")
            if not did:
                did = "minor_" + uuid.uuid4().hex[:8]
                cfg["device_id"] = did; save_config(cfg)
            return did, tok
    except Exception:
        return "minor_" + uuid.uuid4().hex[:8], ""

def _load_saved_identity():
    try:
        with _flask_app.app_context():
            from app.utils import load_config
            cfg = load_config()
            return cfg.get("device_id", ""), cfg.get("session_token", ""), cfg.get("major_ip", "")
    except Exception:
        return "", "", ""

def _minor_label():
    try:
        with _flask_app.app_context():
            from app.utils import load_config
            return load_config().get("device_label", socket.gethostname())
    except Exception:
        return socket.gethostname()

# ── Delta helpers ─────────────────────────────────────────────────────────────

def _get_pending_deltas():
    try:
        with _flask_app.app_context():
            from app.database import PeerSyncQueue
            rows = PeerSyncQueue.query.filter_by(delivered=False)\
                       .order_by(PeerSyncQueue.timestamp).limit(200).all()
            return [{"change_id":r.change_id,"action":r.action,"table_name":r.table_name,
                     "record_id":r.record_id,"payload":r.payload,
                     "performed_by":r.performed_by,"timestamp":r.timestamp} for r in rows]
    except Exception as e:
        logger.error(f"[PEER] get_pending: {e}"); return []

def _mark_delivered(ids):
    if not ids: return
    try:
        with _flask_app.app_context():
            from app.database import db, PeerSyncQueue
            PeerSyncQueue.query.filter(PeerSyncQueue.change_id.in_(ids))\
                .update({"delivered": True}, synchronize_session=False)
            db.session.commit()
    except Exception as e:
        logger.error(f"[PEER] mark_delivered: {e}")

def _pending_count():
    try:
        with _flask_app.app_context():
            from app.database import PeerSyncQueue
            return PeerSyncQueue.query.filter_by(delivered=False).count()
    except Exception:
        return 0

def _apply_delta(delta, source):
    try:
        with _flask_app.app_context():
            from app.database import db, PeerSyncQueue
            if PeerSyncQueue.query.filter_by(change_id=delta["change_id"]).first():
                return {"status": "duplicate"}
            action  = delta.get("action")
            table   = delta.get("table_name")
            payload = json.loads(delta.get("payload", "{}"))
            result  = _apply_action(action, table, payload)
            if result.get("status") == "conflict":
                with _lock:
                    _state["conflicts"].append({"from": source, "action": action,
                        "table": table, "message": result["message"], "timestamp": _now()})
                    _state["conflicts"] = _state["conflicts"][-50:]
            db.session.add(PeerSyncQueue(
                change_id=delta["change_id"], action=action, table_name=table,
                record_id=delta.get("record_id",""), payload=delta.get("payload","{}"),
                performed_by=delta.get("performed_by", source),
                timestamp=delta.get("timestamp", _now()), delivered=True))
            db.session.commit()
            return result
    except Exception as e:
        logger.error(f"[PEER] apply_delta: {e}")
        return {"status": "error", "message": str(e)}

def _apply_action(action, table, payload):
    from app.database import (db, BorrowedBook, Book, Student,
                               ClassBorrowing, TeacherBorrowedBook)
    model_map = {"borrowed_books": BorrowedBook, "bookstable": Book,
                 "students": Student, "class_borrowing": ClassBorrowing,
                 "teacher_borrowed_books": TeacherBorrowedBook}
    model = model_map.get(table)
    if not model: return {"status": "error", "message": f"Unknown table: {table}"}
    try:
        is_book = (table == "bookstable")
        pk_col  = "book_id" if is_book else "id"
        pk_val  = payload.get(pk_col)
        if action == "insert":
            if table == "borrowed_books":
                ex = BorrowedBook.query.filter_by(book_id=payload.get("book_id"), returned=False).first()
                if ex:
                    return {"status":"conflict",
                            "message":f"'{payload.get('book_title')}' already borrowed by {ex.student_name}"}
            if pk_val and model.query.get(pk_val):
                return {"status": "duplicate"}
            db.session.add(model(**_safe_fields(model, payload)))
            db.session.commit()
        elif action == "update":
            row = model.query.get(pk_val) if pk_val else None
            if row:
                for k, v in payload.items():
                    if hasattr(row, k): setattr(row, k, v)
                db.session.commit()
        elif action == "delete":
            row = model.query.get(pk_val) if pk_val else None
            if row:
                db.session.delete(row); db.session.commit()
        return {"status": "ok"}
    except Exception as e:
        db.session.rollback()
        return {"status": "error", "message": str(e)}

def _safe_fields(model, payload):
    cols = {c.name for c in model.__table__.columns}
    return {k: v for k, v in payload.items() if k in cols}

def _build_full_state():
    try:
        with _flask_app.app_context():
            from app.database import (BorrowedBook, Book, Student,
                                       ClassBorrowing, TeacherBorrowedBook)
            def rows(q):
                return [{c.name: getattr(r,c.name) for c in r.__table__.columns} for r in q.all()]
            return {"borrowed_books": rows(BorrowedBook.query), "books": rows(Book.query),
                    "students": rows(Student.query), "class_borrowing": rows(ClassBorrowing.query),
                    "teacher_borrowed_books": rows(TeacherBorrowedBook.query)}
    except Exception as e:
        logger.error(f"[MAJOR] build_full_state: {e}"); return {}

# ── MAJOR server ──────────────────────────────────────────────────────────────

def _major_server_loop():
    global _server_sock
    _server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    _server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        _server_sock.bind(("0.0.0.0", TCP_PORT))
        _server_sock.listen(MAX_PEERS)
        _server_sock.settimeout(1.0)
        with _lock:
            _state["error"] = None
        logger.info(f"[MAJOR] Listening on :{TCP_PORT}")
        while not _stop_event.is_set():
            try: conn, addr = _server_sock.accept()
            except socket.timeout: continue
            threading.Thread(target=_major_handle_peer, args=(conn, addr), daemon=True).start()
    except Exception as e:
        with _lock: _state["error"] = f"Server error: {e}"
    finally:
        try: _server_sock.close()
        except Exception: pass

def _major_handle_peer(conn, addr):
    peer_ip = addr[0]; device_id = None; peer_label = peer_ip
    try:
        # 1. Recv hello
        hello = _recv(conn, timeout=15)
        if not hello: return
        device_id  = hello.get("device_id", peer_ip)
        peer_label = hello.get("label",      peer_ip)
        token      = hello.get("token",      "")
        otp        = hello.get("otp",        "")

        # 2. Auth
        trusted = _load_session(device_id)
        otp_claim = _consume_otp(otp) if otp else None
        if trusted and token == trusted:
            pass  # token OK
        elif otp_claim is not None:
            token = uuid.uuid4().hex
            _save_session(device_id, peer_label, token, trusted=True)
        else:
            _send(conn, {"type": "auth_fail" if otp else "auth_required",
                         "message": "Invalid OTP" if otp else "OTP required"})
            return

        # 3. Send auth_ok + full state in one message
        _send(conn, {"type": "auth_ok", "token": token, "full_state": _build_full_state()})

        with _lock:
            _state["peers"][device_id] = {"label": peer_label, "ip": peer_ip, "last_seen": _now()}
            _state["connected"] = True
        logger.info(f"[MAJOR] {peer_label} connected")

        # 4. Push-first sync loop
        peer_seen_ids = set()
        while not _stop_event.is_set():
            interval = _state["sync_interval"]
            # PUSH our deltas to Minor
            our = [d for d in _get_pending_deltas() if d["change_id"] not in peer_seen_ids]
            _send(conn, {"type": "push", "deltas": our})
            if our: _mark_delivered([d["change_id"] for d in our])

            # RECV Minor's response
            msg = _recv(conn, timeout=interval * 3 + 30)
            if msg is None: break

            if msg.get("type") == "push_ack":
                minor_deltas = msg.get("deltas", [])
                results = []
                for d in minor_deltas:
                    r = _apply_delta(d, peer_label)
                    results.append({"change_id": d["change_id"], **r})
                    peer_seen_ids.add(d["change_id"])
                    # Re-mark as undelivered so other peers receive it
                    if r.get("status") == "ok":
                        try:
                            with _flask_app.app_context():
                                from app.database import db, PeerSyncQueue
                                PeerSyncQueue.query.filter_by(change_id=d["change_id"])\
                                    .update({"delivered": False}, synchronize_session=False)
                                db.session.commit()
                        except Exception: pass
                _send(conn, {"type": "ack", "results": results})

            with _lock:
                if device_id in _state["peers"]:
                    _state["peers"][device_id]["last_seen"] = _now()
                _state["last_sync"] = _now()
            time.sleep(interval)

    except Exception as e:
        logger.warning(f"[MAJOR] {peer_label} disconnected: {e}")
    finally:
        conn.close()
        with _lock:
            _state["peers"].pop(device_id, None)
            _state["connected"] = bool(_state["peers"])

def _broadcast_loop():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    beacon = json.dumps({"service": SERVICE_TAG, "ip": _state["my_ip"], "port": TCP_PORT}).encode()
    while not _stop_event.is_set():
        try: sock.sendto(beacon, ("<broadcast>", BROADCAST_PORT))
        except Exception: pass
        time.sleep(3)
    sock.close()

# ── MINOR client ──────────────────────────────────────────────────────────────

def _resolve_major_ip():
    """saved state → saved config → UDP broadcast"""
    with _lock:
        known = _state.get("major_ip", "")
    if known and _tcp_probe(known):
        return known
    # Clear stale IP
    if known:
        with _lock: _state["major_ip"] = None
    try:
        with _flask_app.app_context():
            from app.utils import load_config
            saved = load_config().get("major_ip", "")
            if saved and _tcp_probe(saved):
                with _lock: _state["major_ip"] = saved
                return saved
    except Exception: pass
    found = _discover_major(timeout=5)
    if found:
        with _lock: _state["major_ip"] = found
    return found

def _discover_major(timeout=5):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.settimeout(timeout)
    try:
        sock.bind(("", BROADCAST_PORT))
        data, addr = sock.recvfrom(1024)
        b = json.loads(data.decode())
        if b.get("service") == SERVICE_TAG:
            return b.get("ip", addr[0])
    except Exception: pass
    finally: sock.close()
    return None

def _minor_client_loop():
    device_id, my_token = _my_device_identity()
    backoff = 2
    while not _stop_event.is_set():
        saved_device_id, saved_token, saved_major_ip = _load_saved_identity()
        if saved_device_id:
            device_id = saved_device_id
        if saved_token is not None:
            my_token = saved_token
            with _lock:
                _state["session_token"] = saved_token
        if saved_major_ip:
            with _lock:
                _state["major_ip"] = saved_major_ip

        major_ip = _resolve_major_ip()
        if not major_ip:
            with _lock:
                _state["error"] = "Major PC not found. Check network or enter IP on Peers page."
                _state["pending_count"] = _pending_count()
                _state["connected"] = False
            _wait_or_retry(backoff)
            backoff = min(backoff * 2, 30)
            continue

        with _lock:
            _state["major_ip"] = major_ip
            _state["error"]    = None
            _state["connected"] = False
        backoff = 2

        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            sock.settimeout(10)
            sock.connect((major_ip, TCP_PORT))

            # Send hello
            _send(sock, {"device_id": device_id, "label": _minor_label(), "token": my_token})

            # Recv auth
            resp = _recv(sock, timeout=20)
            if not resp: raise ConnectionError("No response from Major")

            t = resp.get("type")
            if t == "auth_fail":
                with _lock:
                    _state["error"] = resp.get("message","Auth failed — enter OTP on Peers page.")
                    _state["connected"] = False
                _wait_or_retry(10); continue
            if t == "auth_required":
                with _lock:
                    _state["error"] = "OTP required — go to Peers & Sync."
                    _state["connected"] = False
                _wait_or_retry(10); continue
            if t != "auth_ok":
                raise ConnectionError(f"Unexpected: {t}")

            # Save new token
            new_tok = resp.get("token", my_token)
            if new_tok and new_tok != my_token:
                my_token = new_tok
                try:
                    with _flask_app.app_context():
                        from app.utils import load_config, save_config
                        cfg = load_config()
                        cfg["session_token"]=my_token
                        cfg["major_ip"]=major_ip
                        cfg["device_id"] = device_id
                        save_config(cfg)
                except Exception: pass
                with _lock:
                    _state["session_token"] = my_token

            # Apply full state
            fs = resp.get("full_state")
            if fs: _apply_full_state(fs)

            with _lock:
                _state["error"] = None
                _state["last_sync"] = _now()
                _state["connected"] = True
            logger.info(f"[MINOR] Auth OK — sync loop starting")

            # Sync loop: Major pushes, we respond
            while not _stop_event.is_set():
                interval = _state["sync_interval"]
                msg = _recv(sock, timeout=interval * 3 + 30)
                if msg is None:
                    logger.warning("[MINOR] Major stopped responding — reconnecting")
                    break
                if msg.get("type") != "push": continue

                # Apply Major's deltas
                for d in msg.get("deltas", []):
                    _apply_delta(d, "major")

                # Send our pending deltas + ack
                our = _get_pending_deltas()
                _send(sock, {"type": "push_ack", "deltas": our})

                # Recv ack for our deltas
                if our:
                    ack = _recv(sock, timeout=15)
                    if ack and ack.get("type") == "ack":
                        confirmed = {r["change_id"] for r in ack.get("results",[])
                                     if r.get("status") in ("ok","duplicate")}
                        _mark_delivered(list(confirmed))

                with _lock:
                    _state["last_sync"]     = _now()
                    _state["pending_count"] = _pending_count()
                    _state["error"]         = None
                    _state["connected"]     = True

        except ConnectionRefusedError:
            with _lock:
                _state["error"] = f"Major at {major_ip} refused — is it running?"
                _state["connected"] = False
        except Exception as e:
            logger.warning(f"[MINOR] {e}")
            with _lock:
                _state["error"] = f"Sync interrupted: {e}"
                _state["connected"] = False
        finally:
            try: sock.close()
            except Exception: pass
        _wait_or_retry(backoff)

def _apply_full_state(snap):
    try:
        with _flask_app.app_context():
            from app.database import (db, BorrowedBook, Book, Student,
                                       ClassBorrowing, TeacherBorrowedBook)
            BorrowedBook.query.delete(); Book.query.delete(); Student.query.delete()
            ClassBorrowing.query.delete(); TeacherBorrowedBook.query.delete()
            for r in snap.get("borrowed_books",[]): db.session.add(BorrowedBook(**_safe_fields(BorrowedBook,r)))
            for r in snap.get("books",[]): db.session.add(Book(**_safe_fields(Book,r)))
            for r in snap.get("students",[]): db.session.add(Student(**_safe_fields(Student,r)))
            for r in snap.get("class_borrowing",[]): db.session.add(ClassBorrowing(**_safe_fields(ClassBorrowing,r)))
            for r in snap.get("teacher_borrowed_books",[]): db.session.add(TeacherBorrowedBook(**_safe_fields(TeacherBorrowedBook,r)))
            db.session.commit()
            logger.info("[MINOR] Full state applied")
    except Exception as e:
        logger.error(f"[MINOR] apply_full_state: {e}")

def submit_otp_and_connect(otp, major_ip=None):
    target = major_ip
    if not target:
        with _lock: target = _state.get("major_ip")
    if not target: target = _discover_major(timeout=6)
    if not target: return {"status":"error","message":"Major PC not found. Enter its IP manually."}
    device_id, _ = _my_device_identity()
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(15)
    try:
        sock.connect((target, TCP_PORT))
        _send(sock, {"device_id": device_id, "label": _minor_label(), "token": "", "otp": str(otp)})
        resp = _recv(sock, timeout=15)
        if resp and resp.get("type") == "auth_ok":
            tok = resp.get("token","")
            try:
                with _flask_app.app_context():
                    from app.utils import load_config, save_config
                    cfg = load_config()
                    cfg["device_id"]=device_id; cfg["session_token"]=tok; cfg["major_ip"]=target
                    save_config(cfg)
            except Exception: pass
            fs = resp.get("full_state")
            if fs:
                _apply_full_state(fs)
            with _lock:
                _state["major_ip"] = target
                _state["session_token"] = tok
                _state["error"] = None
                _state["last_sync"] = _now()
                _state["connected"] = True
            _retry_event.set()
            return {"status":"ok","message":f"Connected to Major at {target}. Live sync is now active."}
        return {"status":"error","message":(resp or {}).get("message","Wrong PIN?")}
    except Exception as e:
        return {"status":"error","message":str(e)}
    finally:
        sock.close()

def _now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def queue(action, table, record_id, data, performed_by="system"):
    try:
        with _flask_app.app_context():
            from app.database import db, PeerSyncQueue
            db.session.add(PeerSyncQueue(
                change_id=str(uuid.uuid4()), action=action, table_name=table,
                record_id=str(record_id), payload=json.dumps(data, default=str),
                performed_by=performed_by, timestamp=_now(), delivered=False))
            db.session.commit()
            with _lock: _state["pending_count"] = _pending_count()
    except Exception as e:
        logger.error(f"[PEER] queue: {e}")
