import os
import sys
import socket
import uuid
import hashlib
import subprocess
import threading
import time
import requests
from datetime import datetime, timedelta
from pathlib import Path
from flask import send_from_directory, Response, redirect, request
import json
from packaging import version

# --- 0. PREVENT WINDOWLESS CRASHES ---
import sys
import os
if sys.stdout is None:
    sys.stdout = open(os.devnull, 'w')
if sys.stderr is None:
    sys.stderr = open(os.devnull, 'w')

# Simple in-memory rate limiter for welcome signup: allow 5 requests per IP per 60s
_rate_buckets = {}
_RATE_WINDOW = 60
_RATE_LIMIT = 5

# --- 1. PORTABLE & DEPENDENCY SETUP ---
if getattr(sys, 'frozen', False):
    base_dir = os.path.dirname(sys.executable)
else:
    base_dir = os.path.dirname(os.path.abspath(__file__))

# CRITICAL: Put base_dir at index 0 BEFORE sys._MEIPASS so live updates in
# the installation folder override the old code compiled into the .exe!
if base_dir not in sys.path:
    sys.path.insert(0, base_dir)

lib_path = os.path.join(base_dir, 'lib')
if lib_path not in sys.path:
    sys.path.insert(0, lib_path)
# --- 2. OPTIONAL DEPENDENCIES (Safe Loading) ---
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    load_dotenv = None

try:
    from supabase import create_client
except ImportError:
    create_client = None

try:
    from app import create_app
    from app.utils import load_config, STORAGE_ROOT
except ImportError as exc:
    sys.stderr.write(f"CRITICAL_IMPORT_ERROR: {exc}\n")
    sys.exit(1)

# --- 3. HARDWARE SECURITY (The Anchor) ---
SECRET_SALT = "Library_System_Top_Secret_777"
HIDDEN_DIR_NAME = ".metadata" 
HIDDEN_FILE_NAME = "system_link.bin"

def get_disk_id():
    if sys.platform == "win32":
        try:
            output = subprocess.check_output('wmic diskdrive get serialnumber', shell=True).decode()
            lines = [line.strip() for line in output.split('\n') if line.strip()]
            if len(lines) > 1: return lines[1]
        except: pass
    return str(uuid.getnode())

def check_anchor():
    try:
        device_id = get_disk_id()
        correct_hash = hashlib.sha256((device_id + SECRET_SALT).encode()).hexdigest()
        anchor_dir = os.path.join(STORAGE_ROOT, HIDDEN_DIR_NAME)
        os.makedirs(anchor_dir, exist_ok=True)
        path = os.path.join(anchor_dir, HIDDEN_FILE_NAME)

        if  os.path.exists(path):
            with open(path, "w") as f: f.write(correct_hash)
            return True

        with open(path, "r") as f:
            return f.read().strip() == correct_hash
    except:
        return False

# --- 4. SUPABASE & NETWORK LOGIC ---
def build_supabase_client(url, key):
    if not create_client or not url or not key:
        return None
    try:
        return create_client(url, key)
    except Exception:
        return None

def find_free_port():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(('', 0))
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        return s.getsockname()[1]


# --- 5. UPDATE POLLER FUNCTION ---
# MOVED HERE: Must be defined before the __main__ block
def run_update_poller(app):
    import zipfile as _zipfile
    REPO_API_URL = "https://raw.githubusercontent.com/Ntwali-Wilson/nexalibrary/refs/heads/main/version.json"

    staging_dir = os.path.join(base_dir, 'staging')
    os.makedirs(staging_dir, exist_ok=True)
    staging_path = os.path.join(staging_dir, 'update.zip')
    staging_part = os.path.join(staging_dir, 'update.zip.part')

    while True:
        try:
            with app.app_context():
                from app.utils import load_config, save_config
                from app.routes import VERSION

                config = load_config()
                if config.get('sa_directive') == 'lockdown':
                    time.sleep(300)
                    continue

                github_pat = config.get('PAT') or os.environ.get("GITHUB_PAT", "")
                headers = {"Accept": "application/vnd.github.v3.raw"}
                if github_pat:
                    headers["Authorization"] = f"Bearer {github_pat}"

                last_etag = config.get('last_update_etag')
                if last_etag:
                    headers['If-None-Match'] = last_etag

                # 1. Fetch version.json
                res = requests.get(REPO_API_URL, headers=headers, timeout=15)

                if res.status_code == 200:
                    config['last_update_etag'] = res.headers.get('ETag', '')
                    save_config(config)

                    data = res.json()
                    remote_v = data.get('version')
                    download_api_url = data.get('download_url')

                    if remote_v and download_api_url and version.parse(remote_v) > version.parse(VERSION):
                        # 2. Download atomically to .part and verify zip integrity before exposing update_ready
                        dl_headers = {"Accept": "application/vnd.github.v3.raw"}
                        if github_pat:
                            dl_headers["Authorization"] = f"Bearer {github_pat}"
                        dl_res = requests.get(download_api_url, headers=dl_headers, stream=True, timeout=90)

                        if dl_res.status_code == 200:
                            with open(staging_part, 'wb') as f:
                                for chunk in dl_res.iter_content(chunk_size=16384):
                                    if chunk:
                                        f.write(chunk)

                            if _zipfile.is_zipfile(staging_part):
                                os.replace(staging_part, staging_path)
                                config['update_ready'] = True
                                config['update_version'] = remote_v
                                config['update_changelog'] = data.get('changelog', [])
                                config['pending_manual_download_url'] = download_api_url
                                save_config(config)
                            else:
                                try:
                                    os.remove(staging_part)
                                except OSError:
                                    pass

        except Exception as e:
            sys.stderr.write(f"Background update poller error (Offline?): {e}\n" if "getaddrinfo" not in str(e) else "Offline Mode: Background updater paused.\n")
        
        # Sleep for 5 minutes
        time.sleep(300)


# --- 6. MAIN EXECUTION ---
if __name__ == "__main__":
    try:
        # 1. IMMEDIATE PORT RECOVERY VIA COMMAND LINE ARGUMENT
        safe_port = None
        
        # Check if updater.py passed the port as the first argument
        if len(sys.argv) > 1 and sys.argv[1].isdigit():
            safe_port = int(sys.argv[1])
            print(f"Successfully recovered port from command line: {safe_port}")
        else:
            safe_port = find_free_port()
            print(f"Allocated new free port: {safe_port}")

        # 2. NOW INITIALIZE THE REST OF THE APP
        from app.utils import load_config, save_config
        app = create_app()
        config = load_config()

        supabase_url = os.getenv("SUPABASE_URL") or app.config.get("SUPABASE_URL", "")
        supabase_key = (
            os.getenv("SUPABASE_SERVICE_ROLE_KEY") or 
            os.getenv("SUPABASE_SERVICE_KEY") or 
            app.config.get("SUPABASE_KEY", "")
        )
        
        supabase_client = build_supabase_client(supabase_url, supabase_key)
        if supabase_client:
            with app.app_context():
                sync_service = app.extensions.get("sync_service")
                if sync_service:
                    sync_service.supabase = supabase_client

                    def run_background_sync():
                        while True:
                            sleep_time = 60  # Hibernate by default (sleep 1 min)
                            try:
                                with app.app_context():
                                    if sync_service.is_configured():
                                        from app.database import School, Admin, db
                                        from app.utils import load_config, save_config
                                        from datetime import datetime, timezone
                                        
                                        config = load_config()
                                        
                                        # --- 1. GLOBAL FETCHING (Runs regardless of login state) ---
                                        # A. Fetch Announcements
                                        now_iso = datetime.now(timezone.utc).isoformat()
                                        ann_res = sync_service.supabase.table('announcements').select('*').or_(f"expires_at.gt.{now_iso},expires_at.is.null").order('created_at', desc=True).limit(1).execute()
                                        if ann_res.data:
                                            ann = ann_res.data[0]
                                            config['sa_announcement_id'] = ann.get('id')
                                            config['sa_announcement_title'] = ann.get('title')
                                            config['sa_announcement_content'] = ann.get('content')
                                            config['sa_announcement_time'] = ann.get('created_at')
                                            config['sa_announcement_targets'] = ann.get('target_users', [])
                                        else:
                                            config.pop('sa_announcement_id', None)
                                            config.pop('sa_announcement_title', None)
                                            config.pop('sa_announcement_content', None)
                                            config.pop('sa_announcement_time', None)
                                            config.pop('sa_announcement_targets', None)

                                        # --- 2. SCHOOL-SPECIFIC FETCHING (Runs only after setup) ---
                                        school = School.query.filter_by(allow_online_sync=True, deleted=False).first()
                                        
                                        if school:
                                            # Execute normal payload sync
                                            sync_service._background_cloud_sync()
                                            sb_school_id = school.id
                                            
                                            # B. Fetch Librarian Suspensions
                                            lib_res = sync_service.supabase.table('librarians').select('username, deleted').eq('school_id', sb_school_id).execute()
                                            if lib_res.data:
                                                for lib in lib_res.data:
                                                    local_admin = Admin.query.filter_by(username=lib['username']).first()
                                                    if local_admin and local_admin.deleted != lib['deleted']:
                                                        local_admin.deleted = lib['deleted']
                                                        db.session.commit()

                                            # C. Fetch Security Directives
                                            sec_res = sync_service.supabase.table('security_directives').select('*').eq('school_id', sb_school_id).execute()
                                            if sec_res.data:
                                                state = sec_res.data[0]
                                                current_directive = state.get('directive')
                                                config['sa_directive'] = current_directive
                                                config['sa_impact_time'] = state.get('impact_time')
                                                
                                                # D. Execute Remote Wipe if time is up!
                                                if current_directive == 'wipe' and state.get('status') == 'pending':
                                                    impact = state.get('impact_time')
                                                    if impact:
                                                        impact_dt = datetime.fromisoformat(impact.replace('Z', '+00:00'))
                                                        if datetime.now(timezone.utc) >= impact_dt:
                                                            import subprocess

                                                            

                                                            # Execute wipe sidecar detached
                                                            env = os.environ.copy()
                                                            env["WIPE_SCHOOL_ID"] = sb_school_id

                                                            sidecar_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'wipe_sidecar.py')
                                                            subprocess.Popen([sys.executable, sidecar_path], env=env)
                                                            
                                                            # The sidecar will kill this process, so sleep indefinitely
                                                            time.sleep(3600)
                                            else:
                                                config['sa_directive'] = 'none'
                                                
                                        save_config(config)
                                        sleep_time = 10  # Switch to active polling
                            except Exception as e:
                                sys.stderr.write(f"Background sync/platform error (Offline?): {e}\n" if "getaddrinfo" not in str(e) else "Offline Mode: Background sync paused.\n")
                            
                            time.sleep(sleep_time)

                    sync_thread = threading.Thread(target=run_background_sync, daemon=True)
                    sync_thread.start()

        role = config.get("role")
        if role in ("major", "minor"):
            import peer_sync
            peer_sync.start(role, app, sync_interval=int(config.get("sync_interval", 5) or 5))

        update_thread = threading.Thread(target=run_update_poller, args=(app,), daemon=True)
        update_thread.start()

        # Start the app using the exact port we pulled safely!
        app.run(host="127.0.0.1", port=safe_port, debug=False, use_reloader=False, threaded=True)

    except Exception as exc:
        sys.stderr.write(f"FATAL_ERROR: {exc}\n")
        sys.exit(1)
