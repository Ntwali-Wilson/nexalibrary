import sys

if sys.platform == 'win32':
    import winreg
    import subprocess
    import os

    MINIMUM_VERSION = (115, 0, 0, 0) 

    def get_installed_version():
        keys = [
            (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}"),
            (winreg.HKEY_CURRENT_USER, r"Software\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}"),
            (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}")
        ]
        
        for root, path in keys:
            try:
                with winreg.OpenKey(root, path) as key:
                    pv, _ = winreg.QueryValueEx(key, "pv")
                    if pv and pv != "0.0.0.0":
                        return pv
            except FileNotFoundError:
                continue
        return None

    def is_version_sufficient(installed_version_str):
        if not installed_version_str:
            return False
        try:
            installed_tuple = tuple(map(int, installed_version_str.split('.')))
            return installed_tuple >= MINIMUM_VERSION
        except ValueError:
            return False

    def install_or_update_webview2():
        installed_version = get_installed_version()
        
        if is_version_sufficient(installed_version):
            return
            
        # Determine where PyInstaller has extracted the bundled files
        if hasattr(sys, '_MEIPASS'):
            base_path = sys._MEIPASS
        else:
            base_path = os.path.abspath(".")
            
        installer_path = os.path.join(base_path, "WebView2Standalone.exe")
        
        if os.path.exists(installer_path):
            try:
                # Run the bundled standalone installer silently
                subprocess.run([installer_path, "/silent", "/install"], check=True)
            except Exception as e:
                print(f"Failed to install WebView2 offline: {e}")
        else:
            print("WebView2Standalone.exe not found in the application bundle.")

    install_or_update_webview2()