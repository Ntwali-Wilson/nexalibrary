"""Windows desktop entry point for the Flask library system."""

from __future__ import annotations

import json
import os
import runpy
import socket
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request

import webview

APP_TITLE = "Edraze Library System"


def resource_path(relative_path: str) -> str:
    """Resolve bundled asset paths inside PyInstaller (--onedir / --onefile) or local dev."""
    if getattr(sys, "frozen", False):
        exe_dir = os.path.dirname(sys.executable)
        candidate = os.path.join(exe_dir, relative_path)
        if os.path.exists(candidate):
            return candidate
        base_path = getattr(sys, "_MEIPASS", exe_dir)
        return os.path.join(base_path, relative_path)
    base_path = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base_path, relative_path)


def get_persistent_webview_storage() -> str:
    """Return a permanent WebView2 cache folder so reloads never rebuild temp browser storage."""
    if sys.platform == "win32":
        base = os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA") or tempfile.gettempdir()
        storage_dir = os.path.join(base, "LibraryManager", "webview_cache")
    else:
        storage_dir = os.path.join(os.path.expanduser("~"), ".edraze_library", "webview_cache")
    os.makedirs(storage_dir, exist_ok=True)
    return storage_dir


def find_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


def backend_command(port: int) -> list[str]:
    if getattr(sys, "frozen", False):
        return [sys.executable, "--backend", str(port)]
    return [sys.executable, os.path.abspath(__file__), "--backend", str(port)]


def backend_ready(health_url: str, backend_proc: subprocess.Popen, timeout: float = 120) -> bool:
    """Check if backend is ready via fast polling, aborting early if the subprocess crashes."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if backend_proc.poll() is not None:
            return False
        try:
            with urllib.request.urlopen(health_url, timeout=1.5) as response:
                return 200 <= response.status < 500
        except OSError:
            time.sleep(0.2)
    return False


def show_startup_error(message: str) -> None:
    """Display error dialog based on platform."""
    if sys.platform == "win32":
        import ctypes
        ctypes.windll.user32.MessageBoxW(None, message, APP_TITLE, 0x10)
    else:
        raise RuntimeError(message)


def run_backend(port: str) -> None:
    """Run Flask backend with the specified port."""
    sys.argv = ["run.py", port]
    os.environ["ELECTRON_APP"] = "1"
    runpy.run_module("run", run_name="__main__")


def run_desktop() -> None:
    """Main desktop application entry point."""
    os.environ["ELECTRON_APP"] = "1"
    port = find_free_port()
    health_url = f"http://127.0.0.1:{port}/system/health"
    url = f"http://127.0.0.1:{port}/auth/login"
    creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)

    storage_dir = get_persistent_webview_storage()
    log_path = os.path.join(os.path.dirname(storage_dir), "edraze_backend.log")
    log_file = open(log_path, "w", encoding="utf-8", buffering=1)

    backend = subprocess.Popen(
        backend_command(port),
        creationflags=creationflags,
        stdout=log_file,
        stderr=subprocess.STDOUT,
    )

    loading_html = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Loading</title>
        <style>
            body {{
                display: flex; justify-content: center; align-items: center;
                height: 100vh; margin: 0;
                font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
                background-color: #f3f4f6; color: #1f2937;
            }}
            .loading-card {{
                background: white; padding: 40px 60px; border-radius: 12px;
                box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
                text-align: center; max-width: 600px;
            }}
            .spinner {{
                border: 4px solid #e5e7eb; border-top: 4px solid #3b82f6;
                border-radius: 50%; width: 40px; height: 40px;
                animation: spin 1s linear infinite; margin: 0 auto 20px auto;
            }}
            @keyframes spin {{
                0% {{ transform: rotate(0deg); }}
                100% {{ transform: rotate(360deg); }}
            }}
            h2 {{ margin: 0 0 10px 0; font-size: 22px; font-weight: 600; }}
            p {{ margin: 0; color: #6b7280; font-size: 15px; }}
            pre {{
                text-align: left; background: #fee2e2; color: #991b1b;
                padding: 12px; border-radius: 6px; overflow-x: auto;
                font-size: 12px; max-height: 250px; white-space: pre-wrap;
            }}
        </style>
    </head>
    <body>
        <div class="loading-card" id="card">
            <div class="spinner"></div>
            <h2>Starting {APP_TITLE}</h2>
            <p>Initializing local server, please wait...</p>
        </div>
        <script>
            function showBackendError(errText) {{
                const card = document.getElementById('card');
                card.innerHTML = '<h2 style="color:#dc2626;">Server failed to start</h2><pre id="err-box"></pre>';
                document.getElementById('err-box').textContent = errText;
            }}
        </script>
    </body>
    </html>
    """

    try:
        webview.settings["ALLOW_DOWNLOADS"] = True

        window = webview.create_window(
            APP_TITLE,
            html=loading_html,
            width=1280,
            height=800,
            min_size=(900, 600),
            confirm_close=True,
        )

        def check_backend_and_redirect():
            if backend_ready(health_url, backend, timeout=120):
                window.load_url(url)
            else:
                if backend.poll() is None:
                    backend.terminate()
                try:
                    log_file.flush()
                    with open(log_path, "r", encoding="utf-8", errors="ignore") as f:
                        error_msg = f.read().strip() or "Backend process exited without output."
                except Exception as exc:
                    error_msg = f"Backend process timeout: {exc}"
                window.evaluate_js(f"showBackendError({json.dumps(error_msg)});")

        threading.Thread(target=check_backend_and_redirect, daemon=True).start()

        icon_file = resource_path("logo.ico")
        webview.start(
            gui="edgechromium",
            icon=icon_file if os.path.exists(icon_file) else None,
            debug=False,
            private_mode=False,
            storage_path=storage_dir,
        )

    except Exception as exc:
        show_startup_error(str(exc))
    finally:
        if backend.poll() is None:
            backend.terminate()
            try:
                backend.wait(timeout=5)
            except subprocess.TimeoutExpired:
                backend.kill()
        # Terminate any restarted backend listening on our port after an in-place update
        try:
            import psutil
            for conn in psutil.net_connections(kind="inet"):
                if conn.laddr.port == port and conn.pid and conn.pid != os.getpid():
                    psutil.Process(conn.pid).terminate()
        except Exception:
            pass
        try:
            log_file.close()
        except Exception:
            pass


if __name__ == "__main__":
    # 1. Normal Flask Backend Subprocess
    if len(sys.argv) == 3 and sys.argv[1] == "--backend":
        run_backend(sys.argv[2])
    # 2. Updater Subprocess (--updater flag or updater.py path)
    elif len(sys.argv) >= 2 and (sys.argv[1] == "--updater" or sys.argv[1].endswith("updater.py")):
        import updater
        raise SystemExit(updater.main(sys.argv[2:]))
    # 3. Remote Wipe Sidecar Subprocess (spawned by run.py)
    elif len(sys.argv) >= 2 and sys.argv[1].endswith("wipe_sidecar.py"):
        runpy.run_module("wipe_sidecar", run_name="__main__")
    # 4. Main GUI Launch
    else:
        run_desktop()
