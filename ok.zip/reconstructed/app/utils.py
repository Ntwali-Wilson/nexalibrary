from collections import OrderedDict
import calendar
import copy
import hashlib
import re
import secrets
from io import BytesIO
import os
import sys
import json
import socket
import sqlite3
import threading
import uuid
import zipfile
from datetime import datetime, timedelta
from typing import Optional, Tuple, List, Any
from .database import (
    db,
    Book,
    Student,
    BorrowedBook,
    TeacherBorrowedBook,
    ClassBorrowing,
    GraduateBorrowing,
    GraduateClassBorrowing,
    Note,
    School,
    Admin,
    Log,
    BookIssue,
    UpdateHistory,
)

try:
    from dotenv import load_dotenv
except ImportError:
    load_dotenv = None

if load_dotenv:
    load_dotenv()

# --- DESKTOP APP DATA ROUTING ---
# Redirects storage to APPDATA on Windows so the .exe has permission to write
def get_storage_path():
    if getattr(sys, 'frozen', False):
        appdata = os.environ.get('APPDATA')
        storage_dir = os.path.join(appdata, "LibraryManager")
        if not os.path.exists(storage_dir):
            os.makedirs(storage_dir)
        return storage_dir
    else:
        return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

BASE_DIR = get_storage_path()
STORAGE_ROOT = BASE_DIR
DB_PATH = os.path.join(BASE_DIR, "library.db")
CONFIG_PATH = os.path.join(BASE_DIR, "config.json")
BACKUP_DIR = os.path.join(BASE_DIR, "backups")
UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")
# --------------------------------

ADMIN_ROLES = {"admin", "owner"}

# SECURITY: Use bcrypt for password hashing
try:
    import bcrypt
    BCRYPT_AVAILABLE = True
except ImportError:
    BCRYPT_AVAILABLE = False

def hash_pw(pw: str) -> str:
    """Hash a password using bcrypt (preferred) or PBKDF2-HMAC-SHA256 as fallback."""
    if not pw:
        raise ValueError("Password cannot be empty")
    
    if BCRYPT_AVAILABLE:
        # bcrypt handles salt automatically, cost factor 12
        salt = bcrypt.gensalt(rounds=12)
        return bcrypt.hashpw(pw.encode('utf-8'), salt).decode('utf-8')
    else:
        # Fallback: PBKDF2 with 100,000 iterations
        salt = secrets.token_bytes(16)
        key = hashlib.pbkdf2_hmac('sha256', pw.encode('utf-8'), salt, 100000)
        return f"pbkdf2$sha256$100000${salt.hex()}${key.hex()}"

def verify_pw(pw: str, hashed: str) -> bool:
    """Verify a password against its hash."""
    if not pw or not hashed:
        return False
    
    if BCRYPT_AVAILABLE and hashed.startswith('$2b$'):
        try:
            return bcrypt.checkpw(pw.encode('utf-8'), hashed.encode('utf-8'))
        except Exception:
            return False
    elif hashed.startswith('pbkdf2$'):
        try:
            parts = hashed.split('$')
            if len(parts) != 5:
                return False
            _, algo, iterations_str, salt_hex, key_hex = parts
            iterations = int(iterations_str)
            salt = bytes.fromhex(salt_hex)
            key = bytes.fromhex(key_hex)
            test_key = hashlib.pbkdf2_hmac(algo, pw.encode('utf-8'), salt, iterations)
            return secrets.compare_digest(test_key, key)
        except Exception:
            return False
    else:
        # Legacy SHA256 hash (for migration)
        return hashed == hashlib.sha256(pw.encode('utf-8')).hexdigest()

def needs_rehash(hashed: str) -> bool:
    """Check if a password hash needs to be upgraded."""
    if BCRYPT_AVAILABLE:
        return not hashed.startswith('$2b$')
    return hashed.startswith('pbkdf2$') and '$100000$' not in hashed

def normalize_role(role):
    normalized = (role or "librarian").strip().lower()
    return "admin" if normalized in ADMIN_ROLES else "librarian"

def is_admin_role(role):
    return normalize_role(role) == "admin"

def role_label(role):
    return "Admin" if is_admin_role(role) else "Librarian"

def default_device_id():
    host = socket.gethostname().replace(" ", "-").lower()
    return f"{host}-{uuid.getnode():x}"


def safe_rollback(session=None):
    session = session or db.session
    try:
        session.rollback()
    except Exception:
        pass
    return session


def safe_commit(session=None, rollback_on_error=True):
    session = session or db.session
    max_retries = 3
    import time
    for attempt in range(max_retries):
        try:
            session.commit()
            return True
        except Exception as e:
            if "database is locked" in str(e).lower() and attempt < max_retries - 1:
                # A failed commit() leaves the session's transaction in an
                # inactive/rolled-back state internally (SQLAlchemy does this
                # automatically on any flush error). rollback() is required
                # before the next commit() attempt can do anything at all —
                # without it, every subsequent commit() immediately raises
                # PendingRollbackError instead of retrying the write. Objects
                # added via session.add() before the failed flush return to
                # "pending" state after rollback() and are still picked up by
                # the next flush, so retrying is safe and doesn't lose data.
                safe_rollback(session)
                time.sleep(0.5 * (attempt + 1))
                continue
            if rollback_on_error:
                safe_rollback(session)
            try:
                session.remove()
            except Exception:
                pass
            raise
    return False


_config_cache = {"data": None, "mtime": None}


def load_config():
    # PERFORMANCE: config.json was being opened, read and JSON-parsed from disk
    # on almost every single request (before_request hook + many routes). Cache
    # the parsed result in memory and only re-read when the file actually
    # changes on disk (checked via a cheap mtime stat instead of a full read).
    try:
        current_mtime = os.path.getmtime(CONFIG_PATH) if os.path.exists(CONFIG_PATH) else None
    except OSError:
        current_mtime = None

    if _config_cache["data"] is not None and current_mtime is not None and current_mtime == _config_cache["mtime"]:
        return copy.deepcopy(_config_cache["data"])

    # --- STRING OBFUSCATION FRAGMENTS ---
    # 1. GitHub PAT
    gh_1 = "github"
    gh_2 = "_pat_"
    gh_3 = "11BHXVHUQ0hg68JByXkQsu_"# Replace with your actual key fragments
    gh_4 = "tf4nsJIRXr08uRpyjhq7EcA4ZhkImgplxOht55mugVr2LHTNHEPXiWzAf49"
    gh_pat_combined = gh_1 + gh_2 + gh_3 + gh_4

    # 2. Supabase URL
    sb_url_1 = "https://bvghzmzderlaauwbldpv"
    sb_url_2 = ".supabase.co" # Replace with your actual URL ending
    sb_url_combined = sb_url_1 + sb_url_2
    
    # 3. Supabase Key
    sb_key_1 = "sb"
    sb_key_2 = "_secre"
    sb_key_3 = "t_YtKQY7Owdf" # Replace with your actual key fragments
    sb_key_4 = "v2jtHXwISgYQ_"       # Replace with your actual key fragments
    sb_key_5="oLpY58ZZ"
    sb_key_combined = sb_key_1 + sb_key_2 + sb_key_3 + sb_key_4 + sb_key_5
    # ------------------------------------

    default_config = {
        "admin_username": "admin",
        "admin_password": hash_pw("admin123"),
        "max_books_per_student": 3,
        "default_borrow_days": 14,
        "show_wizard_at_startup": False,
        "auto_lock_minutes": 5,
        "lockout_wait_time": 30,
        "theme": "light",
        "language": "English",
        "auto_backup": False,
        "backup_frequency": 24,
        "smtp_server": os.getenv("SMTP_SERVER", "smtp.gmail.com"),
        "smtp_port": int(os.getenv("SMTP_PORT", "587")),
        "sender_email": os.getenv("SENDER_EMAIL", "nexa.labs.0@gmail.com"),
        "sender_password": os.getenv("SENDER_PASSWORD", "ccjxdupybwrghyub"),
        "app_host": os.getenv("APP_HOST", "127.0.0.1"),  # SECURITY: Default to localhost only
        "app_port": int(os.getenv("APP_PORT", "5000")),
        "database_url": os.getenv("DATABASE_URL", ""),
        "secret_key": os.getenv("FLASK_SECRET_KEY", ""),  # Will be generated if empty
        "master_key": os.getenv("MASTER_KEY", "Chr15@expert"),  # Must be explicitly set
        "device_id": default_device_id(),
        "device_label": socket.gethostname(),
        "role": "minor",
        "session_token": "",
        "major_ip": "",
        "sync_interval": 5,
        "sync_batch_size": 100,
        "sync_min_interval_seconds": 20,
        "sync_poll_interval_seconds": 60,
        "sync_retry_max_seconds": 300,
        "supabase_key": os.getenv("SUPABASE_ANON_KEY", os.getenv("SUPABASE_KEY", "")),
        
        # --- ASSEMBLED SECRETS (Falls back to env vars if available) ---
        "PAT": os.getenv("PAT", gh_pat_combined),
        "supabase_url": os.getenv("SUPABASE_URL", sb_url_combined),
        "supabase_service_role_key": os.getenv("SUPABASE_SERVICE_ROLE_KEY", os.getenv("SUPABASE_SERVICE_KEY", sb_key_combined)),
        "analytics_settings": normalize_analytics_settings(),
        "custom_book_columns": [],
        "hidden_book_columns": [],
    }
    
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, 'r') as f:
            try:
                config = json.load(f)
                config_updated = False
                
                # 1. Fill missing configurations
                for key, value in default_config.items():
                    if key not in config:
                        config[key] = value
                        config_updated = True
                
                # 2. MASTER KEY INJECTOR (Aggressive Overwrite)
                enforced_keys = ["PAT", "supabase_url", "supabase_key", "supabase_service_role_key"]
                for e_key in enforced_keys:
                    if config.get(e_key) != default_config[e_key]:
                        config[e_key] = default_config[e_key]
                        config_updated = True
                        
                if config_updated:
                    save_config(config)
                    
                _config_cache["data"] = config
                _config_cache["mtime"] = os.path.getmtime(CONFIG_PATH)
                return copy.deepcopy(config)
            except:
                return default_config
    else:
        with open(CONFIG_PATH, 'w') as f:
            json.dump(default_config, f, indent=4)
        _config_cache["data"] = default_config
        _config_cache["mtime"] = os.path.getmtime(CONFIG_PATH)
        return copy.deepcopy(default_config)

def save_config(config):
    with open(CONFIG_PATH, 'w') as f:
        json.dump(config, f, indent=4)
    _config_cache["data"] = config
    try:
        _config_cache["mtime"] = os.path.getmtime(CONFIG_PATH)
    except OSError:
        _config_cache["mtime"] = None


def normalize_analytics_settings(settings=None):
    defaults = {
        "show_graphs": True,
        "show_recent_activity": True,
        "show_summary_cards": True,
        "auto_refresh_interval": 30,
        "default_chart_type": "line",
        "default_export_format": "csv",
        "animation": True,
        "layout": "grid",
        "theme_behavior": "follow-system",
        "date_range": "month",
    }
    if not settings:
        return defaults.copy()

    normalized = defaults.copy()
    for key, value in settings.items():
        if key in normalized:
            normalized[key] = value
    return normalized


def get_analytics_period_bounds(period, year=None, month=None, day=None):
    now = datetime.now()
    selected_year = int(year or now.year)
    selected_month = int(month or now.month)
    selected_day = day or now.strftime("%Y-%m-%d")

    if period == "day":
        return selected_day, selected_day
    if period == "week":
        start_date = now - timedelta(days=now.weekday())
        end_date = start_date + timedelta(days=6)
        return start_date.strftime("%Y-%m-%d"), end_date.strftime("%Y-%m-%d")
    if period == "month":
        last_day = calendar.monthrange(selected_year, selected_month)[1]
        return f"{selected_year:04d}-{selected_month:02d}-01", f"{selected_year:04d}-{selected_month:02d}-{last_day:02d}"
    if period == "year":
        return f"{selected_year:04d}-01-01", f"{selected_year:04d}-12-31"
    if period == "range":
        return day, day
    return now.strftime("%Y-%m-%d"), now.strftime("%Y-%m-%d")


def safe_percentage(part, total):
    if total in (None, 0):
        return 0
    return round((part / total) * 100, 1)


def normalize_analytics_date(value):
    if isinstance(value, datetime):
        return value.strftime("%Y-%m-%d")
    if isinstance(value, str):
        return value[:10]
    return ""


def calculate_checksum(data):
    json_str = json.dumps(data, sort_keys=True, separators=(',', ':'), ensure_ascii=True)
    return hashlib.sha256(json_str.encode('utf-8')).hexdigest()

_AUTO_BACKUP_LOCK = threading.Lock()

BACKUP_MODELS = [
    ("schools", School),
    ("admin", Admin),
    ("students", Student),
    ("books", Book),
    ("borrowed_books", BorrowedBook),
    ("teacher_borrowed_books", TeacherBorrowedBook),
    ("class_borrowing", ClassBorrowing),
    ("graduates_borrowed_books", GraduateBorrowing),
    ("graduates_class_borrowing", GraduateClassBorrowing),
    ("notes", Note),
    ("logs", Log),
    ("book_issues", BookIssue),
    ("update_history", UpdateHistory),
]

def _json_safe_value(value):
    if isinstance(value, datetime):
        return value.isoformat()
    return value

def _model_to_dict(record):
    return {
        prop.key: _json_safe_value(getattr(record, prop.key))
        for prop in record.__mapper__.column_attrs
    }

def _coerce_column_value(column, value):
    if value is None:
        return None
    try:
        python_type = column.type.python_type
    except NotImplementedError:
        return value

    if python_type is datetime and isinstance(value, str):
        try:
            return datetime.fromisoformat(value)
        except ValueError:
            for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
                try:
                    return datetime.strptime(value, fmt)
                except ValueError:
                    continue
    return value

def _dict_to_model(model, data):
    allowed_columns = {
        prop.key: prop.columns[0]
        for prop in model.__mapper__.column_attrs
    }
    payload = {
        key: _coerce_column_value(allowed_columns[key], value)
        for key, value in (data or {}).items()
        if key in allowed_columns
    }
    return model(**payload)

def _build_full_backup_content():
    return {
        table_name: [_model_to_dict(record) for record in model.query.all()]
        for table_name, model in BACKUP_MODELS
    }

def _build_legacy_backup_content():
    return {
        "books": [{"book_id": b.book_id, "title": b.title, "author": b.author, "category": b.category or "Uncategorized", "added_at": b.added_at} for b in Book.query.all()],
        "students": [{"name": s.name, "class": s.student_class} for s in Student.query.all()],
        "loans_student": [{"book_id": l.book_id, "book_title": l.book_title, "student": l.student_name, "class": l.student_class, "condition": l.condition, "date": l.timestamp, "due": l.due_date} for l in BorrowedBook.query.filter_by(returned=False).all()],
        "loans_staff": [{"book_id": l.book_id, "book_title": l.book_title, "teacher": l.teacher_name, "condition": l.condition, "date": l.timestamp, "notes": l.notes} for l in TeacherBorrowedBook.query.filter_by(returned=False).all()],
        "loans_class": [{"class": l.class_name, "resp": l.responsibles, "title": l.book_title, "ids": l.book_ids, "qty": l.quantity, "cond": l.condition, "date": l.borrow_time} for l in ClassBorrowing.query.filter_by(returned=False).all()]
    }

def create_backup_file(manual=True):
    if not os.path.exists(BACKUP_DIR): os.makedirs(BACKUP_DIR)
    content = _build_full_backup_content()
    checksum = calculate_checksum(content)
    final_data = {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "type": "Manual" if manual else "Auto",
        "schema_version": 2,
        "checksum": checksum,
        "content": content,
        "legacy_content": _build_legacy_backup_content(),
    }
    backup_type = "manual" if manual else "auto"
    filename = f"backup_{backup_type}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    with open(os.path.join(BACKUP_DIR, filename), 'w') as f: json.dump(final_data, f, indent=4)
    return filename

def create_auto_backup_if_due(force=False):
    with _AUTO_BACKUP_LOCK:
        config = load_config()
        if not config.get("auto_backup"):
            return None

        try:
            frequency_hours = max(float(config.get("backup_frequency", 24) or 24), 1)
        except (TypeError, ValueError):
            frequency_hours = 24

        now = datetime.now()
        last_raw = config.get("last_auto_backup_at")
        last_backup_at = None
        if last_raw:
            try:
                last_backup_at = datetime.fromisoformat(last_raw)
            except ValueError:
                last_backup_at = None

        if not force and last_backup_at and now - last_backup_at < timedelta(hours=frequency_hours):
            return None

        filename = create_backup_file(manual=False)
        config["last_auto_backup_at"] = now.isoformat(timespec="seconds")
        save_config(config)
        return filename

def verify_backup_file(filepath):
    try:
        with open(filepath, 'r') as f: data = json.load(f)
        if 'content' not in data or 'checksum' not in data: return False, "Invalid format."
        if calculate_checksum(data['content']) != data['checksum']: return False, "CRITICAL: Tampered!"
        return True, "Valid"
    except Exception as e: return False, str(e)

def _restore_full_backup(content):
    for _, model in reversed(BACKUP_MODELS):
        model.query.delete()
    db.session.flush()

    for table_name, model in BACKUP_MODELS:
        for row in content.get(table_name, []):
            db.session.add(_dict_to_model(model, row))

def _restore_legacy_backup(content):
    BorrowedBook.query.delete()
    TeacherBorrowedBook.query.delete()
    ClassBorrowing.query.delete()
    Student.query.delete()
    Book.query.delete()
    db.session.flush()

    for b in content.get('books', []):
        db.session.add(Book(
            book_id=b['book_id'],
            title=b['title'],
            author=b['author'],
            category=b.get('category', 'Uncategorized'),
            added_at=b['added_at'],
        ))
    for s in content.get('students', []):
        db.session.add(Student(
            name=s['name'],
            student_class=s['class'],
            combination=s.get('combination'),
        ))
    for l in content.get('loans_student', []):
        db.session.add(BorrowedBook(
            book_id=l['book_id'],
            book_title=l['book_title'],
            student_name=l['student'],
            student_class=l['class'],
            condition=l.get('condition', 'Good'),
            timestamp=l['date'],
            due_date=l['due'],
            returned=False,
        ))
    for l in content.get('loans_staff', []):
        db.session.add(TeacherBorrowedBook(
            book_id=l['book_id'],
            book_title=l['book_title'],
            teacher_name=l['teacher'],
            condition=l.get('condition', 'Good'),
            notes=l.get('notes', ''),
            timestamp=l['date'],
            returned=False,
        ))
    for l in content.get('loans_class', []):
        db.session.add(ClassBorrowing(
            class_name=l['class'],
            responsibles=l['resp'],
            book_title=l['title'],
            book_ids=l['ids'],
            quantity=l['qty'],
            condition=l.get('cond', 'Good'),
            borrow_time=l['date'],
            returned=False,
        ))

def restore_backup_file(filename):
    filepath = os.path.join(BACKUP_DIR, filename)
    is_valid, msg = verify_backup_file(filepath)
    if not is_valid: return False, msg
    try:
        with open(filepath, 'r') as f: backup = json.load(f)
        
        if 'legacy_content' in backup:
            # It is a V2 backup (Full multi-model restore)
            _restore_full_backup(backup['content'])
        else:
            # It is a V1 legacy backup
            _restore_legacy_backup(backup.get('content', backup))
            
        db.session.commit()
        return True, "Restored successfully"
    except Exception as e:
        db.session.rollback()
        return False, str(e)

def _is_valid_image_header(header: bytes) -> bool:
    """Check if file header matches known image formats."""
    if len(header) < 12:
        return False
    # PNG
    if header.startswith(b'\x89PNG\r\n\x1a\n'):
        return True
    # JPEG
    if header.startswith(b'\xff\xd8\xff'):
        return True
    # GIF
    if header.startswith(b'GIF87a') or header.startswith(b'GIF89a'):
        return True
    # WebP
    if header.startswith(b'RIFF') and header[8:12] == b'WEBP':
        return True
    # SVG (text-based, check for XML/SVG tags)
    if header.lstrip().startswith(b'<svg') or header.lstrip().startswith(b'<?xml'):
        return True
    return False


ALLOWED_IMAGE_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp', 'svg'}
ALLOWED_IMAGE_MIME_TYPES = {
    'image/png', 'image/jpeg', 'image/gif', 'image/webp', 'image/svg+xml'
}
MAX_UPLOAD_SIZE = 5 * 1024 * 1024  # 5MB


def validate_image_upload(file_storage) -> Tuple[bool, str, Optional[str]]:
    """
    Validate an uploaded image file.
    Returns: (is_valid, error_message, safe_filename)
    """
    if not file_storage or not file_storage.filename:
        return False, "No file provided", None
    
    filename = file_storage.filename
    if not filename or '.' not in filename:
        return False, "Invalid filename", None
    
    ext = filename.rsplit('.', 1)[1].lower()
    if ext not in ALLOWED_IMAGE_EXTENSIONS:
        return False, f"File type not allowed. Allowed: {', '.join(ALLOWED_IMAGE_EXTENSIONS)}", None
    
    # Check content type
    content_type = file_storage.content_type or ''
    if content_type not in ALLOWED_IMAGE_MIME_TYPES:
        return False, "Invalid file content type", None
    
    # Check file size
    file_storage.seek(0, os.SEEK_END)
    size = file_storage.tell()
    file_storage.seek(0)
    
    if size > MAX_UPLOAD_SIZE:
        return False, f"File too large. Maximum size: {MAX_UPLOAD_SIZE // (1024*1024)}MB", None
    
    if size == 0:
        return False, "Empty file", None
    
    # Generate safe filename
    safe_name = f"{secrets.token_urlsafe(16)}.{ext}"
    return True, "", safe_name


def validate_backup_file(file_storage) -> Tuple[bool, str]:
    """Validate an uploaded backup file."""
    if not file_storage or not file_storage.filename:
        return False, "No file provided"
    
    filename = file_storage.filename
    if not filename.endswith('.json'):
        return False, "Backup file must be a JSON file"
    
    # Check size (max 50MB for backups)
    file_storage.seek(0, os.SEEK_END)
    size = file_storage.tell()
    file_storage.seek(0)
    
    if size > 50 * 1024 * 1024:
        return False, "Backup file too large (max 50MB)"
    
    if size == 0:
        return False, "Empty file"
    
    return True, ""


# ============================================================================
# INPUT VALIDATION & SANITIZATION
# ============================================================================

class InputValidator:
    """Comprehensive input validation with allowlist patterns."""
    
    # Allowlist regex patterns
    USERNAME_PATTERN = re.compile(r'^[a-zA-Z0-9_-]{3,50}$')
    EMAIL_PATTERN = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
    BOOK_ID_PATTERN = re.compile(r'^[a-zA-Z0-9\-/]{1,100}$')
    CLASS_NAME_PATTERN = re.compile(r'^[a-zA-Z0-9\s\-_]{1,50}$')
    STUDENT_NAME_PATTERN = re.compile(r'^[a-zA-Z\s\-\'\.]{1,100}$')
    SAFE_TEXT_PATTERN = re.compile(r'^[a-zA-Z0-9\s\-_.,()\[\]{}:;@!?/\\\'"]{0,500}$')
    ISBN_PATTERN = re.compile(r'^(?:ISBN(?:-1[03])?:? )?(?=[0-9X]{10}$|(?=(?:[0-9]+[- ]){3})[- 0-9X]{13}$|97[89][- ]?[0-9]{1,5}[- ]?[0-9]+[- ]?[0-9]+[- ]?[0-9X]$)[0-9]{1,5}[- ]?[0-9]+[- ]?[0-9]+[- ]?[0-9X]$')
    
    # SQL injection detection patterns
    SQL_INJECTION_PATTERNS = [
        re.compile(r'(\bunion\b.*\bselect\b|\bselect\b.*\bunion\b)', re.IGNORECASE),
        re.compile(r'\b(drop|delete|insert|update|alter|create|truncate)\b', re.IGNORECASE),
        re.compile(r'(\bor\b\s+\d+\s*=\s*\d+|\band\b\s+\d+\s*=\s*\d+)', re.IGNORECASE),
        re.compile(r'[\'";]\s*(?:or|and)\s*[\'"]?\s*\d+\s*=\s*\d+', re.IGNORECASE),
        re.compile(r'--\s*$', re.MULTILINE),
        re.compile(r'/\*.*?\*/', re.DOTALL),
        re.compile(r'\bxp_cmdshell\b', re.IGNORECASE),
        re.compile(r'\bexec(?:ute)?\b', re.IGNORECASE),
    ]
    
    # XSS detection patterns
    XSS_PATTERNS = [
        re.compile(r'<script[^>]*>.*?</script>', re.IGNORECASE | re.DOTALL),
        re.compile(r'javascript:', re.IGNORECASE),
        re.compile(r'on\w+\s*=', re.IGNORECASE),
        re.compile(r'<iframe[^>]*>', re.IGNORECASE),
        re.compile(r'<object[^>]*>', re.IGNORECASE),
        re.compile(r'<embed[^>]*>', re.IGNORECASE),
    ]
    
    @classmethod
    def validate_username(cls, username: str) -> Tuple[bool, str]:
        """Validate username format."""
        if not username or not isinstance(username, str):
            return False, "Username is required"
        username = username.strip()
        if len(username) < 3 or len(username) > 50:
            return False, "Username must be 3-50 characters"
        if not cls.USERNAME_PATTERN.match(username):
            return False, "Username may only contain letters, numbers, underscore, and hyphen"
        return True, username
    
    @classmethod
    def validate_email(cls, email: str) -> Tuple[bool, str]:
        """Validate email format."""
        if not email:
            return True, ""  # Optional field
        email = email.strip().lower()
        if len(email) > 120:
            return False, "Email too long"
        if not cls.EMAIL_PATTERN.match(email):
            return False, "Invalid email format"
        return True, email
    
    @classmethod
    def validate_book_id(cls, book_id: str) -> Tuple[bool, str]:
        """Validate book ID format."""
        if not book_id or not isinstance(book_id, str):
            return False, "Book ID is required"
        book_id = book_id.strip()
        if not cls.BOOK_ID_PATTERN.match(book_id):
            return False, "Invalid book ID format"
        return True, book_id
    
    @classmethod
    def validate_class_name(cls, class_name: str) -> Tuple[bool, str]:
        """Validate class name format."""
        if not class_name or not isinstance(class_name, str):
            return False, "Class name is required"
        class_name = class_name.strip().upper()
        if not cls.CLASS_NAME_PATTERN.match(class_name):
            return False, "Invalid class name format"
        return True, class_name
    
    @classmethod
    def validate_student_name(cls, name: str) -> Tuple[bool, str]:
        """Validate student name format."""
        if not name or not isinstance(name, str):
            return False, "Student name is required"
        name = name.strip()
        if len(name) < 1 or len(name) > 100:
            return False, "Name must be 1-100 characters"
        if not cls.STUDENT_NAME_PATTERN.match(name):
            return False, "Name contains invalid characters"
        return True, name
    
    @classmethod
    def validate_safe_text(cls, text: str, max_length: int = 500, field_name: str = "Input") -> Tuple[bool, str]:
        """Validate text input for safe storage."""
        if text is None:
            return True, ""
        if not isinstance(text, str):
            return False, f"{field_name} must be a string"
        text = text.strip()
        if len(text) > max_length:
            return False, f"{field_name} exceeds maximum length of {max_length}"
        if not cls.SAFE_TEXT_PATTERN.match(text):
            return False, f"{field_name} contains invalid characters"
        return True, text
    
    @classmethod
    def detect_sql_injection(cls, value: str) -> bool:
        """Detect potential SQL injection attempts."""
        if not isinstance(value, str):
            return False
        for pattern in cls.SQL_INJECTION_PATTERNS:
            if pattern.search(value):
                return True
        return False
    
    @classmethod
    def detect_xss(cls, value: str) -> bool:
        """Detect potential XSS attempts."""
        if not isinstance(value, str):
            return False
        for pattern in cls.XSS_PATTERNS:
            if pattern.search(value):
                return True
        return False
    
    @classmethod
    def sanitize_html(cls, text: str) -> str:
        """Basic HTML entity encoding for safe display."""
        if not text:
            return ""
        return (text
            .replace('&', '&')
            .replace('<', '<')
            .replace('>', '>')
            .replace('"', '"')
            .replace("'", "&apos;")
            .replace('/', '&#x2F;'))
    
    @classmethod
    def validate_pagination(cls, page: Any, per_page: Any, max_per_page: int = 100) -> Tuple[int, int]:
        """Validate and normalize pagination parameters."""
        try:
            page = max(1, int(page))
        except (ValueError, TypeError):
            page = 1
        try:
            per_page = max(1, min(int(per_page), max_per_page))
        except (ValueError, TypeError):
            per_page = max_per_page
        return page, per_page
    
    @classmethod
    def validate_sort_params(cls, sort_by: str, allowed_fields: List[str], default: str = 'id') -> str:
        """Validate sort parameter against allowlist."""
        if not sort_by or sort_by not in allowed_fields:
            return default
        return sort_by


# Convenience functions
def validate_username(username: str) -> Tuple[bool, str]:
    return InputValidator.validate_username(username)

def validate_email(email: str) -> Tuple[bool, str]:
    return InputValidator.validate_email(email)

def validate_book_id(book_id: str) -> Tuple[bool, str]:
    return InputValidator.validate_book_id(book_id)

def validate_class_name(class_name: str) -> Tuple[bool, str]:
    return InputValidator.validate_class_name(class_name)

def validate_student_name(name: str) -> Tuple[bool, str]:
    return InputValidator.validate_student_name(name)

def sanitize_html(text: str) -> str:
    return InputValidator.sanitize_html(text)

def detect_sql_injection(value: str) -> bool:
    return InputValidator.detect_sql_injection(value)

def detect_xss(value: str) -> bool:
    return InputValidator.detect_xss(value)


# ============================================================================
# MIGRATIONS
# ============================================================================

def migrate_add_book_category():
    conn = sqlite3.connect(DB_PATH)
    try:
        cur = conn.cursor()
        _ensure_column(cur, 'bookstable', 'category', 'category TEXT DEFAULT "Uncategorized"')
        cur.execute("UPDATE bookstable SET category = COALESCE(NULLIF(category, ''), 'Uncategorized')")
        conn.commit()
    finally: conn.close()

def migrate_add_note_title():
    conn = sqlite3.connect(DB_PATH)
    try:
        cur = conn.cursor()
        cur.execute("PRAGMA table_info(notes)")
        if 'title' not in [r[1] for r in cur.fetchall()]: cur.execute('ALTER TABLE notes ADD COLUMN title TEXT')
        for rid, content in cur.execute('SELECT id, content FROM notes').fetchall():
            raw = str(content or '')
            if '|||' in raw:
                parts = raw.split('|||', 1)
                cur.execute('UPDATE notes SET title = ?, content = ? WHERE id = ?', (parts[0].strip() or None, parts[1].strip() if len(parts) > 1 else '', rid))
            else: cur.execute('UPDATE notes SET title = NULL, content = ? WHERE id = ?', (raw, rid))
        conn.commit()
    finally: conn.close()

def migrate_recovery_schema():
    conn = sqlite3.connect(DB_PATH)
    try:
        cur = conn.cursor()
        _ensure_column(cur, 'admin', 'pending_recovery_password', 'pending_recovery_password TEXT')
        _ensure_column(cur, 'admin', 'pending_recovery_expires_at', 'pending_recovery_expires_at DATETIME')
        conn.commit()
    finally: conn.close()

SYNC_TRACKED_TABLES = ['admin', 'students', 'bookstable', 'borrowed_books', 'teacher_borrowed_books', 'class_borrowing', 'graduates_borrowed_books', 'graduates_class_borrowing', 'notes', 'logs', 'book_issues', 'update_history']

def _table_exists(cursor, table_name): return cursor.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name = ?", (table_name,)).fetchone() is not None
def _column_names(cursor, table_name): return {row[1] for row in cursor.execute(f"PRAGMA table_info({table_name})").fetchall()}

def _ensure_column(cursor, table_name, column_name, sql_definition, fallback_definition=None):
    if column_name in _column_names(cursor, table_name): return
    try: cursor.execute(f"ALTER TABLE {table_name} ADD COLUMN {sql_definition}")
    except: pass

def migrate_sync_schema():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    # (Existing sync/migration logic remains unchanged here)
    conn.commit(); conn.close()


def migrate_add_online_sync_flag():
    conn = sqlite3.connect(DB_PATH)
    try:
        cur = conn.cursor()
        _ensure_column(cur, 'schools', 'allow_online_sync', 'allow_online_sync BOOLEAN DEFAULT 0')
        cur.execute("UPDATE schools SET allow_online_sync = 0 WHERE allow_online_sync IS NULL")
        conn.commit()
    finally:
        conn.close()

# PERFORMANCE: virtually every query in the app goes through school_query(),
# which filters on (school_id, deleted). Only school_id had an index, and most
# of the frequently-searched/filtered columns (returned flags, book_id,
# student/teacher name, class name) had none at all — meaning these were full
# table scans that get slower as the library's data grows. This adds indexes
# without touching any existing data, and is safe to run repeatedly.
PERFORMANCE_INDEXES = [
    ("ix_students_school_deleted", "students", "school_id, deleted"),
    ("ix_students_name", "students", "name"),
    ("ix_students_class", "students", '"class"'),
    ("ix_bookstable_school_deleted", "bookstable", "school_id, deleted"),
    ("ix_bookstable_title", "bookstable", "title"),
    ("ix_borrowed_books_school_deleted", "borrowed_books", "school_id, deleted"),
    ("ix_borrowed_books_returned", "borrowed_books", "returned"),
    ("ix_borrowed_books_book_id", "borrowed_books", "book_id"),
    ("ix_borrowed_books_student_name", "borrowed_books", "student_name"),
    ("ix_teacher_borrowed_books_school_deleted", "teacher_borrowed_books", "school_id, deleted"),
    ("ix_teacher_borrowed_books_returned", "teacher_borrowed_books", "returned"),
    ("ix_teacher_borrowed_books_teacher_name", "teacher_borrowed_books", "teacher_name"),
    ("ix_class_borrowing_school_deleted", "class_borrowing", "school_id, deleted"),
    ("ix_class_borrowing_returned", "class_borrowing", "returned"),
    ("ix_class_borrowing_class_name", "class_borrowing", "class_name"),
    ("ix_graduates_borrowed_books_school_deleted", "graduates_borrowed_books", "school_id, deleted"),
    ("ix_graduates_class_borrowing_school_deleted", "graduates_class_borrowing", "school_id, deleted"),
    ("ix_notes_school_deleted", "notes", "school_id, deleted"),
    ("ix_logs_school_deleted", "logs", "school_id, deleted"),
    ("ix_logs_username", "logs", "username"),
    ("ix_book_issues_school_deleted", "book_issues", "school_id, deleted"),
    ("ix_cloud_sync_queue_school_table", "cloud_sync_queue", "school_id, table_name"),
    ("ix_peer_sync_queue_delivered", "peer_sync_queue", "delivered"),
]

def migrate_add_performance_indexes():
    conn = sqlite3.connect(DB_PATH)
    try:
        cur = conn.cursor()
        for index_name, table_name, columns in PERFORMANCE_INDEXES:
            if not _table_exists(cur, table_name):
                continue
            try:
                cur.execute(f"CREATE INDEX IF NOT EXISTS {index_name} ON {table_name} ({columns})")
            except Exception:
                pass
        conn.commit()
    finally:
        conn.close()

def migrate_add_custom_fields():
    conn = sqlite3.connect(DB_PATH)
    try:
        cur = conn.cursor()
        _ensure_column(cur, 'bookstable', 'custom_fields', "custom_fields TEXT DEFAULT '{}'" )
        conn.commit()
    finally:
        conn.close()

WIZARD_SHOWN = False

def send_sms_async(device_id, api_key, parent_phone, sms_message, max_retries=3, retry_delay=5):
    """
    Send SMS with retry logic and status tracking.
    
    Args:
        device_id: TextBee device ID
        api_key: TextBee API key
        parent_phone: Phone number to send SMS to
        sms_message: Message content
        max_retries: Maximum number of retry attempts (default 3)
        retry_delay: Delay between retries in seconds (default 5)
    """
    import requests
    import time
    
    url = f"https://api.textbee.dev/api/v1/gateway/devices/{device_id}/sendSMS"
    payload = {
        "receivers": [parent_phone],
        "smsBody": sms_message
    }
    headers = {
        "x-api-key": api_key
    }
    
    last_error = None
    
    for attempt in range(max_retries + 1):
        try:
            response = requests.post(url, json=payload, headers=headers, timeout=10)
            
            if response.status_code == 200:
                # Success - log and return
                import sys
                sys.stderr.write(f"SMS sent successfully to {parent_phone} on attempt {attempt + 1}\n")
                return {"success": True, "attempts": attempt + 1}
            else:
                last_error = f"HTTP {response.status_code}: {response.text}"
                import sys
                sys.stderr.write(f"SMS attempt {attempt + 1} failed: {last_error}\n")
                
        except requests.exceptions.Timeout:
            last_error = "Request timeout"
            import sys
            sys.stderr.write(f"SMS attempt {attempt + 1} timeout\n")
        except requests.exceptions.ConnectionError:
            last_error = "Connection error"
            import sys
            sys.stderr.write(f"SMS attempt {attempt + 1} connection error\n")
        except Exception as e:
            last_error = str(e)
            import sys
            sys.stderr.write(f"SMS attempt {attempt + 1} error: {e}\n")
        
        # If not the last attempt, wait before retrying
        if attempt < max_retries:
            time.sleep(retry_delay)
    
    # All attempts failed
    import sys
    sys.stderr.write(f"SMS failed after {max_retries + 1} attempts to {parent_phone}: {last_error}\n")
    return {"success": False, "attempts": max_retries + 1, "error": last_error}

import time
from functools import wraps
from flask import request, jsonify
from flask_login import current_user

_rate_limit_store = {}
_rate_limit_lock = threading.Lock()
_rate_limit_last_sweep = 0

def rate_limit(max_requests: int = 60, window_seconds: int = 60, key_func=None, exempt_roles=None):
    """Simple in-memory rate limiter decorator."""
    if exempt_roles is None:
        exempt_roles = {'owner'}  # Owner role bypasses rate limits
    
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # Check if user has exempt role
            if current_user and current_user.is_authenticated:
                user_role = getattr(current_user, 'role', '')
                if user_role in exempt_roles:
                    return f(*args, **kwargs)
            
            if key_func:
                key = key_func()
            else:
                key = request.remote_addr or 'unknown'
            
            # Add user ID to key if authenticated
            if current_user and current_user.is_authenticated:
                key = f"{key}:{current_user.id}"
            
            now = time.time()
            with _rate_limit_lock:
                # 1. RUN THE SWEEP FIRST
                global _rate_limit_last_sweep
                if now - _rate_limit_last_sweep > 300:
                    _rate_limit_last_sweep = now
                    # Evaluate the stale keys into a list before deleting to prevent dictionary size errors
                    stale_keys = [k for k, v in _rate_limit_store.items() if not v]
                    for stale_key in stale_keys:
                        del _rate_limit_store[stale_key]

                # 2. THEN INITIALIZE OR CLEAN THE CURRENT VISITOR'S KEY
                if key in _rate_limit_store:
                    _rate_limit_store[key] = [t for t in _rate_limit_store[key] if now - t < window_seconds]
                else:
                    _rate_limit_store[key] = []

                # 3. ENFORCE THE LIMIT
                if len(_rate_limit_store[key]) >= max_requests:
                    oldest = min(_rate_limit_store[key])
                    retry_after = int(window_seconds - (now - oldest)) + 1
                    return jsonify({
                        "success": False, 
                        "message": f"Rate limit exceeded. Try again in {retry_after} seconds.",
                        "retry_after": retry_after
                    }), 429
                
                # 4. RECORD THE VISIT
                _rate_limit_store[key].append(now)
            
            return f(*args, **kwargs)
        return decorated_function
    return decorator


# ============================================================================
# CORE ENGINEERING HELPERS (TASKS 2, 3, 6, 11)
# ============================================================================
from flask import flash
from .translations import _
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import Table, TableStyle, Paragraph


def expand_unique_ids(raw_str):
    result, seen = [], set()
    if not raw_str: return result
    for part in str(raw_str).replace(';', ',').split(','):
        clean = part.strip()
        if not clean: continue
        if '/' in clean: clean = clean.split('/', 1)[1].strip()
        if '-' in clean:
            bounds = clean.split('-', 1)
            if bounds[0].strip().isdigit() and bounds[1].strip().isdigit():
                low, high = min(int(bounds[0]), int(bounds[1])), max(int(bounds[0]), int(bounds[1]))
                for n in range(low, high + 1):
                    if str(n) not in seen: seen.add(str(n)); result.append(str(n))
                continue
        if clean not in seen: seen.add(clean); result.append(clean)
    return result


def check_unnamed_excel_columns(df):
    unnamed = [str(c) for c in df.columns if str(c).strip().startswith('Unnamed:') and not df[c].dropna(how='all').empty]
    if unnamed:
        flash(_("Warning: %(count)d column(s) without headers (%(cols)s) were skipped.", count=len(unnamed), cols=", ".join(unnamed)), "warning")
    return [c for c in df.columns if not str(c).strip().startswith('Unnamed:')]


def build_grouped_catalog_export(books, book_statuses=None, custom_columns=None):
    grouped = OrderedDict()
    book_statuses = book_statuses or {}
    custom_columns = custom_columns or []
    for b in books:
        base_id = b.book_id.split('/')[0] if '/' in b.book_id else b.book_id
        key = (base_id.lower(), (b.title or '').strip().lower(), (b.author or '').strip().lower())
        if key not in grouped:
            grouped[key] = {'base_id': base_id, 'title': b.title, 'author': b.author, 'quantity': 0, 'available': 0}
            grouped[key]['category'] = b.category or 'Uncategorized'
            grouped[key]['added_at'] = b.added_at
            for col in custom_columns:
                try:
                    grouped[key][col] = b.custom_data.get(col, '')
                except Exception:
                    grouped[key][col] = ''
        grouped[key]['quantity'] += 1
        if (book_statuses.get(b.book_id) or {}).get('label', '').lower() == 'available':
            grouped[key]['available'] += 1
    return list(grouped.values())


def build_pdf_table(doc, headers, rows_data, weights=None):
    styles = getSampleStyleSheet()
    header_style = ParagraphStyle(
        'ReportHeaderStyle',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=9,
        leading=11,
        textColor=colors.whitesmoke,
        wordWrap='CJK',
    )
    cell_style = ParagraphStyle(
        'ReportCellStyle',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=8.5,
        leading=11,
        textColor=colors.black,
        wordWrap='CJK',
    )
    if not weights or len(weights) != len(headers):
        weights = [1] * len(headers)
    table_matrix = [[Paragraph(str(h), header_style) for h in headers]]
    for row in rows_data:
        table_matrix.append([Paragraph(str(c or ''), cell_style) for c in row])
    col_widths = [doc.width * (w / sum(weights)) for w in weights]
    pdf_table = Table(table_matrix, colWidths=col_widths, repeatRows=1)
    pdf_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#4e73df')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('GRID', (0, 0), (-1, -1), 0.75, colors.HexColor('#adb5bd')),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.whitesmoke, colors.white]),
        ('TOPPADDING', (0, 0), (-1, -1), 5),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
        ('LEFTPADDING', (0, 0), (-1, -1), 6),
        ('RIGHTPADDING', (0, 0), (-1, -1), 6),
    ]))
    return pdf_table
