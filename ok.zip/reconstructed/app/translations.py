TRANSLATIONS = {
    'Help': {
        "French": 'Aide',
        "Kinyarwanda": 'Ubufasha'
    },
    'Help & Guide': {
        "French": 'Aide et Guide',
        "Kinyarwanda": "Ubufasha n'Amabwiriza"
    },
    'General Help': {
        "French": 'Aide Générale',
        "Kinyarwanda": 'Ubufasha Rusange'
    },
    'Welcome to your dashboard! This is your main overview. Here you can see quick summaries like the total number of books, students, and active loans. You can also view recent activity to know what happened last.': {
        "French": "Bienvenue sur votre tableau de bord ! Voici votre aperçu principal. Vous pouvez y voir des résumés rapides comme le nombre total de livres, d'étudiants et de prêts actifs. Vous pouvez également consulter l'activité récente pour savoir ce qui s'est passé en dernier.",
        "Kinyarwanda": "Ikaze ku rubuga rwawe! Iyi ni incamake yawe nyamukuru. Hano ushobora kubona incamake yihuse n'umubare wose w'ibitabo, abanyeshuri, n'inguzanyo zikora. Ushobora kandi kureba ibikorwa biheruka kugirango umenye ibyabaye vuba aha."
    },
    "This page lets you manage all the books in the library. You can add new books, search for existing ones, edit their details, or remove them. It helps you keep track of your library's inventory.": {
        "French": "Cette page vous permet de gérer tous les livres de la bibliothèque. Vous pouvez ajouter de nouveaux livres, rechercher des livres existants, modifier leurs détails ou les supprimer. Elle vous aide à garder une trace de l'inventaire de votre bibliothèque.",
        "Kinyarwanda": "Uru rupapuro rugufasha gucunga ibitabo byose mu isomero. Ushobora kongeramo ibitabo bishya, gushaka ibisanzweho, guhindura amakuru yabyo, cyangwa kubisiba. Bigufasha gukurikirana ibikoresho by'isomero ryawe."
    },
    'Here you can manage the students and their classes. You can add new students, group them by class, and promote them to the next grade when the school year ends.': {
        "French": "Ici, vous pouvez gérer les étudiants et leurs classes. Vous pouvez ajouter de nouveaux étudiants, les regrouper par classe et les faire passer au niveau supérieur à la fin de l'année scolaire.",
        "Kinyarwanda": "Hano ushobora gucunga abanyeshuri n'amashuri yabo. Ushobora kongeramo abanyeshuri bashya, kubashyira mu mashuri yabo, no kubimura mu mwaka ukurikira iyo umwaka w'amashuri urangiye."
    },
    'Use this page when someone wants to borrow a book. You can issue books to individual students, teachers, or even entire classes at once.': {
        "French": "Utilisez cette page lorsque quelqu'un souhaite emprunter un livre. Vous pouvez prêter des livres à des étudiants individuels, des enseignants, ou même à des classes entières en une seule fois.",
        "Kinyarwanda": 'Koresha uru rupapuro igihe umuntu ashaka gutira igitabo. Ushobora guha ibitabo abanyeshuri ku giti cyabo, abarimu, cyangwa amashuri yose icyarimwe.'
    },
    'This page shows all the books that are currently borrowed out. When a student or teacher brings a book back, you use this page to mark it as returned.': {
        "French": "Cette page affiche tous les livres actuellement empruntés. Lorsqu'un étudiant ou un enseignant ramène un livre, vous utilisez cette page pour le marquer comme retourné.",
        "Kinyarwanda": 'Uru rupapuro rwerekana ibitabo byose byatiwe muri iki gihe. Igihe umunyeshuri cyangwa mwarimu agaruye igitabo, ukoresha uru rupapuro kugirango wemeze ko cyagarutse.'
    },
    'This section provides charts and statistics. It helps you understand which books are most popular and which classes borrow the most books.': {
        "French": 'Cette section propose des graphiques et des statistiques. Elle vous aide à comprendre quels livres sont les plus populaires et quelles classes empruntent le plus de livres.',
        "Kinyarwanda": "Iki gice gitanga ibishushanyo n'imibare. Bigufasha kumva ibitabo bikunzwe cyane n'amashuri atira ibitabo byinshi."
    },
    'The audit logs keep a detailed history of important actions taken in the system, like who added a book or who deleted a record, for security and tracking.': {
        "French": "Les journaux d'audit conservent un historique détaillé des actions importantes effectuées dans le système, comme qui a ajouté un livre ou qui a supprimé un enregistrement, pour la sécurité et le suivi.",
        "Kinyarwanda": "Amateka y'ibikorwa abika amateka arambuye y'ibikorwa byingenzi byakozwe muri sisitemu, nko kongeramo igitabo cyangwa gusiba inyandiko, kubera umutekano no gukurikirana."
    },
    'Only admins see this. You can add new librarians, change their passwords, or remove their access to the system.': {
        "French": 'Seuls les administrateurs voient cela. Vous pouvez ajouter de nouveaux bibliothécaires, changer leurs mots de passe ou supprimer leur accès au système.',
        "Kinyarwanda": "Abayobozi gusa nibo babona ibi. Ushobora kongeramo abakozi b'isomero bashya, guhindura amagambo y'ibanga yabo, cyangwa kubambura uburenganzira bwo gukoresha sisitemu."
    },
    'Here you can customize the system. You can change your password, update your profile picture, set loan rules, and configure backups.': {
        "French": 'Ici, vous pouvez personnaliser le système. Vous pouvez changer votre mot de passe, mettre à jour votre photo de profil, définir les règles de prêt et configurer les sauvegardes.',
        "Kinyarwanda": "Hano ushobora guhindura sisitemu. Ushobora guhindura ijambo ry'ibanga ryawe, kuvugurura ifoto yawe, gushyiraho amategeko yo gutira, no gutegura ububiko."
    },
    'This is your personal space. You can update your contact information and change your profile picture.': {
        "French": "C'est votre espace personnel. Vous pouvez mettre à jour vos coordonnées et changer votre photo de profil.",
        "Kinyarwanda": "Uyu ni umwanya wawe bwite. Ushobora kuvugurura amakuru yawe y'itumanaho no guhindura ifoto yawe."
    },
    'This page lets you connect multiple computers in the library together so they share the same data, even without internet.': {
        "French": "Cette page vous permet de connecter plusieurs ordinateurs de la bibliothèque ensemble afin qu'ils partagent les mêmes données, même sans internet.",
        "Kinyarwanda": "Uru rupapuro rugufasha guhuza mudasobwa nyinshi mu isomero kugirango zisangire amakuru amwe, ndetse n'igihe nta internet ihari."
    },
    "Navigate through the left menu to access different features. Click on the '?' icon on any specific page to learn more about how to use it.": {
        "French": "Naviguez dans le menu de gauche pour accéder à différentes fonctionnalités. Cliquez sur l'icône '?' sur n'importe quelle page spécifique pour en savoir plus sur son utilisation.",
        "Kinyarwanda": "Koresha menu y'ibumoso kugirango ugero ku bikorwa bitandukanye. Kanda ku kamenyetso '?' kuri paji iyo ari yo yose kugirango umenye byinshi kuburyo bwo kuyikoresha."
    },
    '.              It will': {
        "French": '.              Ce sera',
        "Kinyarwanda": '.              Bizashoboka'
    },
    '. It will': {
        "French": '. Ça va',
        "Kinyarwanda": '. Bizaba'
    },
    '. Live sync is active.': {
        "French": '. La synchronisation en direct est active.',
        "Kinyarwanda": '. Guhuza bizima birakora.'
    },
    '/row': {
        "French": '/rangée',
        "Kinyarwanda": '/ umurongo'
    },
    '1. Download Template': {
        "French": '1. Télécharger le modèle',
        "Kinyarwanda": '1. Kuramo icyitegererezo'
    },
    '1. Enter Returned Book IDs (Optional)': {
        "French": '1. Saisissez les identifiants des livres retournés (facultatif)',
        "Kinyarwanda": '1. Injira nimero zatiruwe (Si ngombwa)'
    },
    '1. Returned IDs (Optional)': {
        "French": '1. ID retournés (facultatif)',
        "Kinyarwanda": '1. Nimero yasubijwe (Si ngombwa)'
    },
    '1. Search Bar': {
        "French": '1. Barre de recherche',
        "Kinyarwanda": '1. Ishakiro'
    },
    '15s': {
        "French": '15s',
        "Kinyarwanda": '15s'
    },
    '2. Base ID + Combo Box Dropdown': {
        "French": '2. ID de base + liste déroulante de la liste déroulante',
        "Kinyarwanda": '2. Shingiro ID + Agasanduku kamanuka'
    },
    '2. Mark Students': {
        "French": '2. Marquer les étudiants',
        "Kinyarwanda": '2. Shira akamenyetso ku banyeshuri'
    },
    '2. Mark Students (Who returned?)': {
        "French": '2. Marquer les étudiants (qui sont revenus\xa0?)',
        "Kinyarwanda": '2. Shira akamenyetso ku banyeshuri (Ninde watiruye?)'
    },
    '2. Review Students': {
        "French": '2. Examiner les étudiants',
        "Kinyarwanda": '2. Iga ku banyeshuri'
    },
    '3. Issue Books': {
        "French": '3. Publier des livres',
        "Kinyarwanda": '3. Tiza ibitabo'
    },
    '30s': {
        "French": 'années 30',
        "Kinyarwanda": '30s'
    },
    '60s': {
        "French": 'années 60',
        "Kinyarwanda": '60s'
    },
    '? The application will restart.': {
        "French": "? L'application va redémarrer.",
        "Kinyarwanda": '? Porogaramu igiye kongera gutangira.'
    },
    'A production-ready view of borrowing behavior, member activity, and operational health for this school.': {
        "French": "Une vue prête pour la production du comportement d'emprunt, de l'activité des membres et de la santé opérationnelle de cette école.",
        "Kinyarwanda": 'Kureberahamwe imyitwarire yo kuguza, ibikorwa byabanyeshuri, nubuzima rusange bw iri shuri.'
    },
    'AUTO': {
        "French": 'AUTO',
        "Kinyarwanda": 'BYIKORA'
    },
    'Accepted formats: PNG, JPG, JPEG. Max size: 2MB.': {
        "French": 'Formats acceptés : PNG, JPG, JPEG. Taille maximale : 2 Mo.',
        "Kinyarwanda": 'Imiterere yemewe: PNG, JPG, JPEG. Ingano ntarengwa: 2MB.'
    },
    'Access Portal': {
        "French": "Portail d'accès",
        "Kinyarwanda": 'Kwinjira'
    },
    'Account Details': {
        "French": 'Détails du compte',
        "Kinyarwanda": 'Ibyerekeye Konti'
    },
    'Actions': {
        "French": 'Actions',
        "Kinyarwanda": 'Ibikorwa'
    },
    'Active': {
        "French": 'Actif',
        "Kinyarwanda": 'Iriho'
    },
    'Active Borrowers': {
        "French": 'Emprunteurs actifs',
        "Kinyarwanda": 'Abagifite Ibitabo'
    },
    'Active Loans': {
        "French": 'Prêts actifs',
        "Kinyarwanda": 'Inguzanyo zigihari'
    },
    'Active.': {
        "French": 'Actif.',
        "Kinyarwanda": 'Bikora.'
    },
    'Activity Log': {
        "French": "Journal d'activité",
        "Kinyarwanda": "Logi y'ibyakozwe"
    },
    'Add': {
        "French": 'Ajouter',
        "Kinyarwanda": 'Ongera'
    },
    'Add Book': {
        "French": 'Ajouter un livre',
        "Kinyarwanda": 'Ongeramo Igitabo'
    },
    'Add Class Loan': {
        "French": 'Ajouter un prêt de classe',
        "Kinyarwanda": 'Ongeramo Inguzanyo'
    },
    'Add Librarian': {
        "French": 'Ajouter un bibliothécaire',
        "Kinyarwanda": "Ongeraho Umukozi w'Isomero"
    },
    'Add New Books': {
        "French": 'Ajouter de nouveaux livres',
        "Kinyarwanda": 'Ongeramo Ibitabo bishya'
    },
    'Add New Student': {
        "French": 'Ajouter un nouvel étudiant',
        "Kinyarwanda": 'Ongeramo Umunyeshuri mushya'
    },
    'Add Note': {
        "French": 'Ajouter une note',
        "Kinyarwanda": 'Ongeramo Icyitonderwa'
    },
    'Add Student': {
        "French": 'Ajouter un étudiant',
        "Kinyarwanda": 'Ongeramo Umunyeshuri'
    },
    'Added': {
        "French": 'Ajouté',
        "Kinyarwanda": 'Yongeweho'
    },
    'Admin Password': {
        "French": 'Mot de passe administrateur',
        "Kinyarwanda": 'Ijambobanga rya Admin'
    },
    'Admin Password Required': {
        "French": 'Mot de passe administrateur requis',
        "Kinyarwanda": "Ijambo ry'ibanga ry'umuyobozi rirakenewe"
    },
    'Admin Username': {
        "French": "Nom d'utilisateur administrateur",
        "Kinyarwanda": "Izina ry'Umuyobozi"
    },
    'Admin only': {
        "French": 'Administrateur uniquement',
        "Kinyarwanda": 'Umuyobozi gusa'
    },
    'All Categories': {
        "French": 'Toutes les catégories',
        "Kinyarwanda": 'Ibyiciro byose'
    },
    'All Time': {
        "French": 'Tout le temps',
        "Kinyarwanda": 'Igihe cyose'
    },
    'All Types': {
        "French": 'Tous les types',
        "Kinyarwanda": 'Amoko Yosse'
    },
    'All clear.': {
        "French": 'Tout est clair.',
        "Kinyarwanda": 'Byose birasobanutse.'
    },
    'All students in the old class will be moved to this new class name.': {
        "French": 'Tous les élèves de l’ancienne classe seront déplacés vers ce nouveau nom de classe.',
        "Kinyarwanda": 'Abanyeshuri bose muri iki kiciro bazimurirwa kuri iri zina rishya ryishuri.'
    },
    'Analytics Settings': {
        "French": "Paramètres d'analyse",
        "Kinyarwanda": 'Igenamiterere'
    },
    'Animation': {
        "French": 'Animation',
        "Kinyarwanda": 'Animation'
    },
    'Answer security questions to open the credential reset screen.': {
        "French": 'Répondez aux questions de sécurité pour ouvrir l’écran de réinitialisation des informations d’identification.',
        "Kinyarwanda": 'Subiza ibibazo byumutekano kugirango uhindure ijambo banga.'
    },
    'Answer security questions to reset password to': {
        "French": 'Répondez aux questions de sécurité pour réinitialiser le mot de passe à',
        "Kinyarwanda": "Subiza ibibazo by'umutekano kugira ngo usubize ijambo ry'ibanga kuri"
    },
    'Answers are case-insensitive but spelling matters.': {
        "French": "Les réponses ne sont pas sensibles à la casse, mais l'orthographe est importante.",
        "Kinyarwanda": 'Ibisubizo ni ibintu bitumva ariko ibibazo byimyandikire.'
    },
    'App Host:': {
        "French": "Hôte de l'application :",
        "Kinyarwanda": 'Umurongo ya Porogaramu:'
    },
    'App Port:': {
        "French": "Port de l'application :",
        "Kinyarwanda": 'Icyambu cya Porogaramu:'
    },
    'Apply Filters': {
        "French": 'Appliquer des filtres',
        "Kinyarwanda": 'Koresha Akayunguruzo'
    },
    'Approval': {
        "French": 'Approbation',
        "Kinyarwanda": 'Kwemeza'
    },
    'Archived': {
        "French": 'Archivé',
        "Kinyarwanda": 'Yabitswe'
    },
    'Archived Class Debts': {
        "French": 'Dettes de classe archivées',
        "Kinyarwanda": "Ububiko bw'amadeni yo mu byiciro"
    },
    'Archives': {
        "French": 'Archives',
        "Kinyarwanda": 'Ububiko'
    },
    'Archives (': {
        "French": 'Archives (',
        "Kinyarwanda": 'Ububiko ('
    },
    'Are you ABSOLUTELY sure? This will delete all library records.': {
        "French": 'Êtes-vous ABSOLUMENT sûr ? Cela supprimera tous les enregistrements de la bibliothèque.',
        "Kinyarwanda": "Wizeye neza? Ibi bizasiba inyandiko zose z'isomero."
    },
    'Are you sure this issue has been fixed/resolved?': {
        "French": 'Êtes-vous sûr que ce problème a été résolu/résolu\xa0?',
        "Kinyarwanda": 'Urahamya neza ko iki kibazo cyakemutse?'
    },
    'Are you sure you want to install v': {
        "French": 'Êtes-vous sûr de vouloir installer la v',
        "Kinyarwanda": 'Wizeye neza ko ushaka kuvugurura ujya kuri v'
    },
    'Are you sure?': {
        "French": 'Es-tu sûr?',
        "Kinyarwanda": 'Urabyizeye?'
    },
    'Audit Logs': {
        "French": "Journaux d'audit",
        "Kinyarwanda": "Amateka y'Ibikorwa"
    },
    'Author': {
        "French": 'Auteur',
        "Kinyarwanda": 'Umwanditsi'
    },
    'Author (Optional)': {
        "French": 'Auteur (facultatif)',
        "Kinyarwanda": 'Umwanditsi (Si ngombwa)'
    },
    'Authorize Reset': {
        "French": 'Autoriser la réinitialisation',
        "Kinyarwanda": 'Emera guttangira bundi bushya'
    },
    'Auto': {
        "French": 'Auto',
        "Kinyarwanda": 'Bikora'
    },
    'Auto Refresh': {
        "French": 'Actualisation automatique',
        "Kinyarwanda": 'Kuvugurura byikoze'
    },
    'Auto-Lock Timer (Minutes)': {
        "French": 'Minuterie de verrouillage automatique (Minutes)',
        "Kinyarwanda": 'Gufunga mu Gihe Cyagenwe (Iminota)'
    },
    'Auto-generated numeric code.': {
        "French": 'Code numérique généré automatiquement.',
        "Kinyarwanda": 'Kode yimibare yakozwe.'
    },
    'Auto-verification enabled.': {
        "French": 'Vérification automatique activée.',
        "Kinyarwanda": 'Kugenzura byikora byafunguwe.'
    },
    'Automated notes for the librarian.': {
        "French": 'Notes automatisées pour le bibliothécaire.',
        "Kinyarwanda": "Inyandiko zigenewe Umukozi w'Isomero."
    },
    'Automation': {
        "French": 'Automatisation',
        "Kinyarwanda": 'Kwikora'
    },
    'Available Books': {
        "French": 'Livres disponibles',
        "Kinyarwanda": 'Ibitabo bihari'
    },
    'Back to Borrow Desk': {
        "French": "Retour au bureau d'emprunt",
        "Kinyarwanda": "Subira ku kiciro k'inguzanyo"
    },
    'Back to Profile': {
        "French": 'Retour au profil',
        "Kinyarwanda": 'Subira aha kuranga'
    },
    'Backup & Restore': {
        "French": 'Sauvegarde et restauration',
        "Kinyarwanda": 'Kubika no Kugarura'
    },
    'Backup Archive': {
        "French": 'Archives de sauvegarde',
        "Kinyarwanda": 'Ubike Ububiko'
    },
    'Backup Tools': {
        "French": 'Outils de sauvegarde',
        "Kinyarwanda": 'Ibikoresho byo Kubika'
    },
    'Bar': {
        "French": 'Bar',
        "Kinyarwanda": 'Bar'
    },
    'Base ID': {
        "French": 'Identifiant de la base',
        "Kinyarwanda": 'Base Id'
    },
    'Book': {
        "French": 'Livre',
        "Kinyarwanda": 'Igitabo'
    },
    'Book / Range': {
        "French": 'Livre / Gamme',
        "Kinyarwanda": 'Igitabo / Urwego'
    },
    'Book Catalog': {
        "French": 'Catalogue de livres',
        "Kinyarwanda": "Urutonde rw'Ibitabo"
    },
    'Book ID': {
        "French": 'Identifiant du livre',
        "Kinyarwanda": "Nimero y'igitabo"
    },
    'Book IDs / Range': {
        "French": 'ID de livre/plage',
        "Kinyarwanda": "Indangamuntu y'Igitabo / Urwego"
    },
    'Book Range': {
        "French": 'Gamme de livres',
        "Kinyarwanda": 'Urutonde rwibitabo'
    },
    'Book Title': {
        "French": 'Titre du livre',
        "Kinyarwanda": "Umutwe w'igitabo"
    },
    'Book:': {
        "French": 'Livre:',
        "Kinyarwanda": 'Igitabo:'
    },
    'Books, Students, Loans, Archives, Notes, and Issues': {
        "French": 'Livres, étudiants, prêts, archives, notes et problèmes',
        "Kinyarwanda": "Ibitabo, Abanyeshuri, Ibyatiwe, Ububiko, Inyandiko, n'Ibibazo"
    },
    'Borrow': {
        "French": 'Emprunter',
        "Kinyarwanda": 'Gutira'
    },
    'Borrow Date: Newest': {
        "French": "Date d'emprunt\xa0: Le plus récent",
        "Kinyarwanda": 'Itariki yo kuguza: Agashya'
    },
    'Borrow Date: Oldest': {
        "French": "Date d'emprunt\xa0: la plus ancienne",
        "Kinyarwanda": 'Itariki yo kuguza: Kera'
    },
    'Borrowed': {
        "French": 'Emprunté',
        "Kinyarwanda": 'Icyatiwe'
    },
    'Borrowed Books': {
        "French": 'Livres empruntés',
        "Kinyarwanda": 'Ibitabo Byatiwe'
    },
    'Borrowed Books List': {
        "French": 'Liste des livres empruntés',
        "Kinyarwanda": " Urutonde rw' Inguzanyo y'ibitabo"
    },
    'Borrowed vs Available': {
        "French": 'Emprunté vs disponible',
        "Kinyarwanda": 'Ibyatiwe vs Ibihari'
    },
    'Borrower': {
        "French": 'Emprunteur',
        "Kinyarwanda": 'Uwagurijwe'
    },
    'Borrower Import Workspace': {
        "French": "Espace de travail d'importation de l'emprunteur",
        "Kinyarwanda": 'Kwinjiza Abagurijwe ibitabo'
    },
    'Borrower records remain school-scoped, so the same school team can safely share them across librarians and analytics.': {
        "French": "Les dossiers des emprunteurs restent limités à l'école, de sorte que la même équipe scolaire peut les partager en toute sécurité entre les bibliothécaires et les analystes.",
        "Kinyarwanda": "Inyandiko z'abatira ziba muri ishuri, bityo ishuri rishobora kuzisangiza abakozi b'isomero bose n'isesengura."
    },
    'Borrowing Trend': {
        "French": "Tendance d'emprunt",
        "Kinyarwanda": 'Inguzanyo'
    },
    'Borrowing by Class': {
        "French": 'Emprunter par classe',
        "Kinyarwanda": 'Inguzanyo ku ishuri'
    },
    'Borrowings This Month': {
        "French": 'Emprunts ce mois-ci',
        "Kinyarwanda": 'Ibyatiwe uku kwezi'
    },
    'Borrowings Today': {
        "French": "Emprunts aujourd'hui",
        "Kinyarwanda": 'Ibyatiwe uyu munsi'
    },
    'Bulk Edit Books': {
        "French": 'Modification groupée de livres',
        "Kinyarwanda": 'Guhindura Ibitabo byinshi'
    },
    'Bulk Import': {
        "French": 'Importation en masse',
        "Kinyarwanda": 'Ibicuruzwa byinshi'
    },
    'Buttons': {
        "French": 'Boutons',
        "Kinyarwanda": 'Utubuto'
    },
    'CSV': {
        "French": 'CSV',
        "Kinyarwanda": 'CSV'
    },
    'Cancel': {
        "French": 'Annuler',
        "Kinyarwanda": 'Hagarika'
    },
    'Capture handoff details, reminders, and operational notes for this school workspace.': {
        "French": 'Capturez les détails du transfert, les rappels et les notes opérationnelles pour cet espace de travail scolaire.',
        "Kinyarwanda": 'Gufata amaboko arambuye, kwibutsa, hamwe nibikorwa byakazi kuriyi shuri.'
    },
    'Catalog size': {
        "French": 'Taille du catalogue',
        "Kinyarwanda": "Ubunini bw'urutonde"
    },
    'Category': {
        "French": 'Catégorie',
        "Kinyarwanda": 'Icyiciro'
    },
    'Change Password': {
        "French": 'Changer le mot de passe',
        "Kinyarwanda": 'Hindura ijambo ryibanga'
    },
    'Changelog:': {
        "French": 'Journal des modifications :',
        "Kinyarwanda": 'Ibyahinduwe:'
    },
    'Chart Type': {
        "French": 'Type de graphique',
        "Kinyarwanda": "Ubwoko bw'imbonerahamwe"
    },
    'Check for Updates': {
        "French": 'Vérifier les mises à jour',
        "Kinyarwanda": 'Reba Ibyasohotse bishya'
    },
    'Check for official improvements and security patches.': {
        "French": 'Vérifiez les améliorations officielles et les correctifs de sécurité.',
        "Kinyarwanda": "Reba inyongera nshya n'umutekano."
    },
    'Choose the username and password you will use from now on.': {
        "French": "Choisissez le nom d'utilisateur et le mot de passe que vous utiliserez désormais.",
        "Kinyarwanda": 'Hitamo izina ukoresha nijambobanga uzakoresha guhera ubu.'
    },
    'Class': {
        "French": 'Classe',
        "Kinyarwanda": 'Icyiciro'
    },
    'Class (S1 → S6)': {
        "French": 'Classe (S1 → S6)',
        "Kinyarwanda": 'Icyiciro (S1 → S6)'
    },
    'Class (S6 → S1)': {
        "French": 'Classe (S6 → S1)',
        "Kinyarwanda": 'Icyiciro (S6 → S1)'
    },
    'Class Archives': {
        "French": 'Archives de classe',
        "Kinyarwanda": "Ububiko bw'ishuri"
    },
    'Class Archives:': {
        "French": 'Archives de classe\xa0:',
        "Kinyarwanda": "Ububiko bw'ishuri:"
    },
    'Class Borrowing Desk': {
        "French": "Bureau d'emprunt de classe",
        "Kinyarwanda": "Ibiro by'inguzanyo"
    },
    'Class Group': {
        "French": 'Groupe de classe',
        "Kinyarwanda": 'Itsinda Ryiciro'
    },
    'Class List': {
        "French": 'Liste des classes',
        "Kinyarwanda": 'Urutonde rwibyiciro'
    },
    'Class Name': {
        "French": 'Nom de la classe',
        "Kinyarwanda": 'Izina ryishuri'
    },
    'Class: S1 → S6': {
        "French": 'Classe : S1 → S6',
        "Kinyarwanda": 'Icyiciro: S1 → S6'
    },
    'Class: S6 → S1': {
        "French": 'Classe : S6 → S1',
        "Kinyarwanda": 'Icyiciro: S6 → S1'
    },
    'Classes': {
        "French": 'Cours',
        "Kinyarwanda": 'Amasomo'
    },
    'Clear': {
        "French": 'Clair',
        "Kinyarwanda": 'Biragaragara'
    },
    'Clear All (Full Return)': {
        "French": 'Tout effacer (retour complet)',
        "Kinyarwanda": 'Kuraho Byose (Garuka Byuzuye)'
    },
    'Clear Debt': {
        "French": 'Effacer la dette',
        "Kinyarwanda": 'Kuraho umwenda'
    },
    'Clear Logs': {
        "French": 'Effacer les journaux',
        "Kinyarwanda": 'Kuraho Ibiti'
    },
    "Clear This School's Notes": {
        "French": 'Effacer les notes de cette école',
        "Kinyarwanda": "Kuraho Inyandiko z'iri shuri"
    },
    'Client Device (Minor)': {
        "French": 'Périphérique client (mineur)',
        "Kinyarwanda": 'Igikoresho cyabakiriya (Ntoya)'
    },
    'Close': {
        "French": 'Fermer',
        "Kinyarwanda": 'Funga'
    },
    'Common Base ID': {
        "French": 'ID de base commun',
        "Kinyarwanda": 'Indangamuntu rusange'
    },
    'Common ID Base': {
        "French": "Base d'identification commune",
        "Kinyarwanda": 'Urufatiro rusanzwe'
    },
    'Common ID Part': {
        "French": "Partie d'identification commune",
        "Kinyarwanda": "Igice rusange cy'indangamuntu"
    },
    'Compact': {
        "French": 'Compact',
        "Kinyarwanda": 'Kwiyunga'
    },
    'Completed': {
        "French": 'Complété',
        "Kinyarwanda": 'Byarangiye'
    },
    'Condition': {
        "French": 'Condition',
        "Kinyarwanda": 'Imiterere'
    },
    'Configure how this device connects to your library system.': {
        "French": 'Configurez la façon dont cet appareil se connecte à votre système de bibliothèque.',
        "Kinyarwanda": 'Hindura uburyo iki gikoresho gihuza sisitemu yububiko bwibitabo.'
    },
    'Confirm': {
        "French": 'Confirmer',
        "Kinyarwanda": 'Emeza'
    },
    'Confirm Factory Reset': {
        "French": "Confirmer la réinitialisation d'usine",
        "Kinyarwanda": 'Emeza Gusubiza uko byari bimeze'
    },
    'Confirm Issue': {
        "French": 'Confirmer le problème',
        "Kinyarwanda": 'Emeza Ikibazo'
    },
    'Confirm New Password': {
        "French": 'Confirmer le nouveau mot de passe',
        "Kinyarwanda": 'Emeza ijambo ryibanga rishya'
    },
    'Confirm Password': {
        "French": 'Confirmer le mot de passe',
        "Kinyarwanda": "Emeza Ijambo ry'ibanga"
    },
    'Confirm Promotion': {
        "French": 'Confirmer la promotion',
        "Kinyarwanda": 'Emeza kuzamurwa mu ntera'
    },
    'Confirm Update': {
        "French": 'Confirmer la mise à jour',
        "Kinyarwanda": 'Emeza ivugurura'
    },
    'Connect Now': {
        "French": 'Connectez-vous maintenant',
        "Kinyarwanda": 'Ihuze Noneho'
    },
    'Connect a New Minor PC': {
        "French": 'Connecter un nouveau PC mineur',
        "Kinyarwanda": 'Huza PC nshya'
    },
    'Connect to Major PC': {
        "French": 'Connectez-vous au PC principal',
        "Kinyarwanda": 'Kwihuza na PC nkuru'
    },
    'Connected Minor PCs           (': {
        "French": 'PC mineurs connectés (',
        "Kinyarwanda": 'Ihuza PC Ntoya ('
    },
    'Connected clients': {
        "French": 'Clients connectés',
        "Kinyarwanda": 'Abakiriya bahujwe'
    },
    'Connected peers list': {
        "French": 'Liste des pairs connectés',
        "Kinyarwanda": 'Urutonde rwurungano'
    },
    'Connected to': {
        "French": 'Connecté à',
        "Kinyarwanda": 'Kwihuza na'
    },
    'Connection error. Could not reach the server.': {
        "French": 'Erreur de connexion. Impossible de joindre le serveur.',
        "Kinyarwanda": "Ikosa ry'umuyoboro. Ntibyashobotse kugera kuri seriveri."
    },
    'Connectivity': {
        "French": 'Connectivité',
        "Kinyarwanda": 'Imiyoboro'
    },
    'Connects to the Main Server. Automatically syncs all changes.': {
        "French": 'Se connecte au serveur principal. Synchronise automatiquement toutes les modifications.',
        "Kinyarwanda": 'Ihuza Kuri Seriveri Nkuru. Mu buryo bwikora ihuza impinduka zose.'
    },
    'Contact Email': {
        "French": 'E-mail de contact',
        "Kinyarwanda": "Imeri y'Itumanaho"
    },
    'Contact support:': {
        "French": "Contacter l'assistance :",
        "Kinyarwanda": 'Baza ababishinzwe:'
    },
    'Content': {
        "French": 'Contenu',
        "Kinyarwanda": 'Ibirimo'
    },
    'Continue to Reset': {
        "French": 'Continuer à réinitialiser',
        "Kinyarwanda": 'Komeza gusubiramo'
    },
    'Cookie settings are configured for cross-device browser sessions on the same network.': {
        "French": 'Les paramètres des cookies sont configurés pour des sessions de navigateur multi-appareils sur le même réseau.',
        "Kinyarwanda": 'Igenamiterere rya kuki rigenewe kwinjira ku bindi bikoresho mu rusobe rumwe.'
    },
    'Cost': {
        "French": 'Coût',
        "Kinyarwanda": 'Igiciro'
    },
    'Create Admin Account': {
        "French": 'Créer un compte administrateur',
        "Kinyarwanda": 'Kora Konti ya Admin'
    },
    'Create Backup': {
        "French": 'Créer une sauvegarde',
        "Kinyarwanda": 'Kora Ububiko'
    },
    'Create Librarian': {
        "French": 'Créer un bibliothécaire',
        "Kinyarwanda": 'Kurema Isomero'
    },
    'Create, review, and remove librarian accounts from the dedicated admin panel.': {
        "French": "Créez, examinez et supprimez des comptes de bibliothécaire à partir du panneau d'administration dédié.",
        "Kinyarwanda": 'Kurema, gusubiramo, no kuvanaho konti yububiko bwibitabo byabigenewe byabayobozi.'
    },
    'Create, verify, download, restore, and remove signed backup files.': {
        "French": 'Créez, vérifiez, téléchargez, restaurez et supprimez des fichiers de sauvegarde signés.',
        "Kinyarwanda": 'Kurema, kugenzura, gukuramo, kugarura, no gukuraho dosiye zasinywe zasinywe.'
    },
    'Crop & Save': {
        "French": 'Recadrer et enregistrer',
        "Kinyarwanda": 'Ibihingwa & Kubika'
    },
    'Current Password': {
        "French": 'Mot de passe actuel',
        "Kinyarwanda": 'Ijambobanga ryubu'
    },
    'Current Password (Required)': {
        "French": 'Mot de passe actuel (obligatoire)',
        "Kinyarwanda": 'Ijambobanga ryubu (Bisabwa)'
    },
    'Current Version:': {
        "French": 'Version actuelle :',
        "Kinyarwanda": "Verisiyo y'Ubu:"
    },
    'Current account': {
        "French": 'Compte courant',
        "Kinyarwanda": "Konti y'ubu"
    },
    'Current circulation': {
        "French": 'Circulation actuelle',
        "Kinyarwanda": 'Ikwirakwizwa ryubu'
    },
    'Current circulation balance.': {
        "French": 'Bilan actuel de la circulation.',
        "Kinyarwanda": 'Impuzandengo yikwirakwizwa ryubu.'
    },
    'Currently holding books': {
        "French": 'Détient actuellement des livres',
        "Kinyarwanda": 'Bafite ibitabo ubu'
    },
    'DANGER ZONE: Factory Reset': {
        "French": "ZONE DE DANGER\xa0: réinitialisation d'usine",
        "Kinyarwanda": 'AKARERE KA DANGER: Gusubiramo uruganda'
    },
    'Daily (24 Hours)': {
        "French": 'Quotidiennement (24 heures)',
        "Kinyarwanda": 'Buri Munsi (Masaha 24)'
    },
    'Danger Zone: Factory Reset': {
        "French": "Zone de danger : Réinitialisation d'usine",
        "Kinyarwanda": 'Ahatari heza: Gusubiza uko byari bimeze'
    },
    'Dark': {
        "French": 'Sombre',
        "Kinyarwanda": 'Kwijihiye'
    },
    'Dashboard': {
        "French": 'Tableau de bord',
        "Kinyarwanda": 'Ahabanza'
    },
    'Date': {
        "French": 'Date',
        "Kinyarwanda": 'Itariki'
    },
    'Day': {
        "French": 'Jour',
        "Kinyarwanda": 'Umunsi'
    },
    'Debt:': {
        "French": 'Dette:',
        "Kinyarwanda": 'Umwenda:'
    },
    'Debtors:': {
        "French": 'Débiteurs\xa0:',
        "Kinyarwanda": 'Ababerewemo imyenda:'
    },
    'Default Loan Duration (Days)': {
        "French": 'Durée de prêt par défaut (Jours)',
        "Kinyarwanda": 'Iminsi yo Gutira (Iminsi)'
    },
    'Defaults & Security': {
        "French": 'Valeurs par défaut et sécurité',
        "Kinyarwanda": "Iby'ibanze n'Umutekano"
    },
    'Delete': {
        "French": 'Supprimer',
        "Kinyarwanda": 'Siba'
    },
    'Description': {
        "French": 'Description',
        "Kinyarwanda": 'Ibisobanuro'
    },
    'Details': {
        "French": 'Détails',
        "Kinyarwanda": 'Ibisobanuro'
    },
    'Device Identifier': {
        "French": "Identifiant de l'appareil",
        "Kinyarwanda": 'Ikiranga ibikoresho'
    },
    'Disconnect': {
        "French": 'Déconnecter',
        "Kinyarwanda": 'Guhagarika'
    },
    'Dismiss': {
        "French": 'Rejeter',
        "Kinyarwanda": 'Kwirukana'
    },
    'Done': {
        "French": 'Fait',
        "Kinyarwanda": 'Byakozwe'
    },
    'Download': {
        "French": 'Télécharger',
        "Kinyarwanda": 'Kuramo'
    },
    'Due Date: Newest': {
        "French": "Date d'échéance\xa0:\xa0la plus récente",
        "Kinyarwanda": 'Itariki Yateganijwe: Agashya'
    },
    'Due Date: Oldest': {
        "French": "Date d'échéance\xa0: la plus ancienne",
        "Kinyarwanda": 'Itariki Yateganijwe: Kera'
    },
    'Duplicate Books Skipped': {
        "French": 'Livres en double ignorés',
        "Kinyarwanda": 'Kwigana Ibitabo Byasimbuwe'
    },
    'Duplicate Students Skipped': {
        "French": 'Étudiants en double ignorés',
        "Kinyarwanda": 'Kwigana Abanyeshuri Basimbutse'
    },
    'EDRAZE': {
        "French": 'ÉDRAZÉ',
        "Kinyarwanda": 'EDRAZE'
    },
    'Edit': {
        "French": 'Modifier',
        "Kinyarwanda": 'Hindura'
    },
    'Edit Class Name': {
        "French": 'Modifier le nom de la classe',
        "Kinyarwanda": 'Hindura Izina ryishuri'
    },
    'Edit Student': {
        "French": "Modifier l'élève",
        "Kinyarwanda": 'Hindura Umunyeshuri'
    },
    'Email': {
        "French": 'E-mail',
        "Kinyarwanda": 'Imeri'
    },
    'Empty Database': {
        "French": 'Base de données vide',
        "Kinyarwanda": "Ububiko bw'Amakuru Busa"
    },
    'Enable Auto-Backup': {
        "French": 'Activer la sauvegarde automatique',
        "Kinyarwanda": 'Fungura Kubika Byikora'
    },
    'English': {
        "French": 'Anglais',
        "Kinyarwanda": 'Icyongereza'
    },
    'Enter Current Password to Save Changes': {
        "French": 'Entrez le mot de passe actuel pour enregistrer les modifications',
        "Kinyarwanda": 'Injira ijambo ryibanga kugirango ubike impinduka'
    },
    'Enter linked email...': {
        "French": "Entrez l'e-mail lié...",
        "Kinyarwanda": 'Shyiramo imeri ihuje...'
    },
    'Error details:': {
        "French": "Détails de l'erreur\xa0:",
        "Kinyarwanda": 'Ibisobanuro birambuye:'
    },
    'Error: ': {
        "French": 'Erreur : ',
        "Kinyarwanda": 'Ikosa: '
    },
    'Every 12 Hours': {
        "French": 'Toutes les 12 heures',
        "Kinyarwanda": 'Buri Masaha 12'
    },
    'Every 6 Hours': {
        "French": 'Toutes les 6 heures',
        "Kinyarwanda": 'Buri Masaha 6'
    },
    'Example: Green Hills School': {
        "French": 'Exemple : École Green Hills',
        "Kinyarwanda": 'Urugero: Green Hills School'
    },
    'Excel': {
        "French": 'Exceller',
        "Kinyarwanda": 'Excel'
    },
    'Excel (By Class)': {
        "French": 'Excel (par classe)',
        "Kinyarwanda": 'Excel (Ukurikije Ishuri)'
    },
    'Export': {
        "French": 'Exporter',
        "Kinyarwanda": 'Kohereza hanze'
    },
    'Export CSV': {
        "French": 'Exporter au format CSV',
        "Kinyarwanda": 'Kohereza CSV'
    },
    'Export Excel': {
        "French": 'Exporter Excel',
        "Kinyarwanda": 'Kohereza Excel'
    },
    'Export Format': {
        "French": "Format d'exportation",
        "Kinyarwanda": 'Imiterere yohereza hanze'
    },
    'Export List': {
        "French": 'Exporter la liste',
        "Kinyarwanda": 'Urutonde rwohereza hanze'
    },
    'Export PDF': {
        "French": 'Exporter un PDF',
        "Kinyarwanda": 'Kohereza PDF'
    },
    'Factory Reset Modal': {
        "French": "Modal de réinitialisation d'usine",
        "Kinyarwanda": 'Gusubiramo Uruganda'
    },
    'Failed to load history.': {
        "French": "Échec du chargement de l'historique.",
        "Kinyarwanda": 'Gufungura amateka byananiranye.'
    },
    'Fast view of the strongest classes by active loans.': {
        "French": 'Vue rapide des classes les plus fortes par prêts actifs.',
        "Kinyarwanda": 'Kureba byihuse ibyiciro bikomeye byinguzanyo zikora.'
    },
    'Filename': {
        "French": 'Nom de fichier',
        "Kinyarwanda": "Izina ry'Idosiye"
    },
    'Finish the first-time setup so the system can be used from any device.': {
        "French": "Terminez la première configuration afin que le système puisse être utilisé à partir de n'importe quel appareil.",
        "Kinyarwanda": 'Kurangiza ubwambere gushiraho kugirango sisitemu ikoreshwe mubikoresho byose.'
    },
    'Fixed / Resolved': {
        "French": 'Corrigé / Résolu',
        "Kinyarwanda": 'Byakemuwe / Byakemutse'
    },
    'Forgot Password?': {
        "French": 'Mot de passe oublié ?',
        "Kinyarwanda": "Wibagiwe ijambo ry'ibanga?"
    },
    'Format:': {
        "French": 'Format:',
        "Kinyarwanda": 'Imiterere:'
    },
    'French': {
        "French": 'Français',
        "Kinyarwanda": 'Igifaransa'
    },
    'Frequency': {
        "French": 'Fréquence',
        "Kinyarwanda": 'Inshuro'
    },
    'Full Name': {
        "French": 'Nom et prénom',
        "Kinyarwanda": 'Izina ryuzuye'
    },
    'Generate': {
        "French": 'Générer',
        "Kinyarwanda": 'Kubyara'
    },
    'Generate / View': {
        "French": 'Générer/Afficher',
        "Kinyarwanda": 'Kubyara / Reba'
    },
    'Generate New Codes': {
        "French": 'Générer de nouveaux codes',
        "Kinyarwanda": 'Kora Kode Nshya'
    },
    'Generate New PIN': {
        "French": 'Générer un nouveau code PIN',
        "Kinyarwanda": 'Kora PIN Nshya'
    },
    'Generate a one-time PIN. Give it to the librarian on the other PC —             they enter it in their': {
        "French": "Générez un code PIN à usage unique. Donnez-le au bibliothécaire sur l'autre PC : il le saisira dans son",
        "Kinyarwanda": 'Gukora PIN inshuro imwe. Uhe isomero kurindi PC - barayinjiramo'
    },
    'Get Template': {
        "French": 'Obtenir un modèle',
        "Kinyarwanda": 'Kubona Inyandikorugero'
    },
    'Go Back': {
        "French": 'Retourner',
        "Kinyarwanda": 'Subira inyuma'
    },
    'Graduate Archive': {
        "French": 'Archives des diplômés',
        "Kinyarwanda": 'Abahawe impamyabumenyi'
    },
    'Graduate:': {
        "French": 'Diplômé:',
        "Kinyarwanda": 'Abahawe impamyabumenyi:'
    },
    'Graduates': {
        "French": 'Diplômés',
        "Kinyarwanda": 'Abahawe impamyabumenyi'
    },
    'Graduates with unreturned books will be moved to the': {
        "French": "Les diplômés dont les livres n'ont pas été rendus seront transférés au",
        "Kinyarwanda": 'Abahawe impamyabumenyi bafite ibitabo bidasubijwe bazimurirwa kuri'
    },
    'Grid': {
        "French": 'Grille',
        "Kinyarwanda": 'Grid'
    },
    'Hello Again!': {
        "French": 'Bonjour de nouveau !',
        "Kinyarwanda": 'Muraho nanone!'
    },
    'Hidden span to safely pass Python data to JavaScript without upsetting VS Code': {
        "French": 'Durée cachée pour transmettre en toute sécurité les données Python à JavaScript sans perturber VS Code',
        "Kinyarwanda": 'Umwanya uhishe kugirango utambike neza amakuru ya Python kuri JavaScript utabangamiye VS Code'
    },
    'Hide': {
        "French": 'Cacher',
        "Kinyarwanda": 'Hisha'
    },
    'Highest demand': {
        "French": 'Demande la plus élevée',
        "Kinyarwanda": 'Bisabwa cyane'
    },
    'Home': {
        "French": 'Accueil',
        "Kinyarwanda": 'Ahabanza'
    },
    'Hourly': {
        "French": 'Toutes les heures',
        "Kinyarwanda": 'Buri Saha'
    },
    'How to use': {
        "French": 'Comment utiliser',
        "Kinyarwanda": 'Uburyo bwo gukoresha'
    },
    'ID': {
        "French": 'IDENTIFIANT',
        "Kinyarwanda": 'Indangamuntu'
    },
    'Import': {
        "French": 'Importer',
        "Kinyarwanda": 'Kuzana ibicuruzwa'
    },
    'Import Books': {
        "French": 'Importer des livres',
        "Kinyarwanda": 'Kuzana ibitabo'
    },
    'Import Students': {
        "French": 'Importer des étudiants',
        "Kinyarwanda": 'Kuzana Abanyeshuri'
    },
    'Import from File': {
        "French": 'Importer depuis un fichier',
        "Kinyarwanda": 'Kuzana Bivuye mu Idosiye'
    },
    'Import students to automatically generate the class list.': {
        "French": 'Importez des étudiants pour générer automatiquement la liste des classes.',
        "Kinyarwanda": 'Kuzana abanyeshuri guhita batanga urutonde rwibyiciro.'
    },
    'Initializing Systems...': {
        "French": 'Initialisation des systèmes...',
        "Kinyarwanda": 'Gutangiza Sisitemu ...'
    },
    'Insights': {
        "French": 'Connaissances',
        "Kinyarwanda": 'Ubushishozi'
    },
    'Install Update Now': {
        "French": 'Installer la mise à jour maintenant',
        "Kinyarwanda": 'Kwinjiza Ivugurura Ubu'
    },
    'Installing... Do not close.': {
        "French": 'Installation en cours... Ne fermez pas.',
        "Kinyarwanda": 'Kwinjiza... Ntugafunge.'
    },
    'Issue Books': {
        "French": 'Livres de publication',
        "Kinyarwanda": 'Tanga Ibitabo'
    },
    'Issue Description': {
        "French": 'Description du problème',
        "Kinyarwanda": 'Ibisobanuro'
    },
    'Issue books to staff members and keep recent staff loans visible.': {
        "French": 'Distribuez des livres aux membres du personnel et gardez visibles les prêts récents du personnel.',
        "Kinyarwanda": 'Tanga ibitabo kubakozi kandi ukomeze inguzanyo zabakozi ziherutse kugaragara.'
    },
    'Issue to Class': {
        "French": 'Problème adressé à la classe',
        "Kinyarwanda": 'Ikibazo Cyiciro'
    },
    'Issue to Staff': {
        "French": 'Problème pour le personnel',
        "Kinyarwanda": 'Ikibazo ku bakozi'
    },
    'Issue to Student': {
        "French": "Problème à l'étudiant",
        "Kinyarwanda": 'Ikibazo Kubanyeshuri'
    },
    'Issue to Teacher': {
        "French": "Problème à l'enseignant",
        "Kinyarwanda": 'Ikibazo kuri Mwarimu'
    },
    'Issued': {
        "French": 'Émis',
        "Kinyarwanda": 'Yatanzwe'
    },
    'Issues': {
        "French": 'Problèmes',
        "Kinyarwanda": 'Ibibazo'
    },
    'Kinyarwanda': {
        "French": 'Kinyarwanda',
        "Kinyarwanda": 'Ikinyarwanda'
    },
    'LEFT COLUMN': {
        "French": 'COLONNE DE GAUCHE',
        "Kinyarwanda": 'INKINGI YASIGAYE'
    },
    'LEFT: Server control': {
        "French": 'GAUCHE\xa0: Contrôle du serveur',
        "Kinyarwanda": 'Ibumoso: kugenzura seriveri'
    },
    'Language': {
        "French": 'Langue',
        "Kinyarwanda": 'Ururimi'
    },
    'Last 7 days': {
        "French": '7 derniers jours',
        "Kinyarwanda": 'Iminsi 7 ishize'
    },
    'Last Hour': {
        "French": 'Dernière heure',
        "Kinyarwanda": 'Isaha yanyuma'
    },
    'Last sync': {
        "French": 'Dernière synchronisation',
        "Kinyarwanda": 'Isano rya nyuma'
    },
    'Last sync result': {
        "French": 'Résultat de la dernière synchronisation',
        "Kinyarwanda": 'Igisubizo cyanyuma'
    },
    'Layout': {
        "French": 'Mise en page',
        "Kinyarwanda": 'Imiterere'
    },
    'Leave as 0 if no fine is charged.': {
        "French": 'Laissez 0 si aucune amende n’est facturée.',
        "Kinyarwanda": 'Kureka nka 0 niba ntamande yishyurwa.'
    },
    'Lending Rules (Students)': {
        "French": 'Règles de prêt (Étudiants)',
        "Kinyarwanda": 'Amategeko yo Gutira (Abanyeshuri)'
    },
    'Librarian': {
        "French": 'Bibliothécaire',
        "Kinyarwanda": "Umukozi w'Isomero"
    },
    'Librarian Management': {
        "French": 'Gestion des bibliothécaires',
        "Kinyarwanda": 'Gucunga amasomero'
    },
    'Library': {
        "French": 'Bibliothèque',
        "Kinyarwanda": 'Isomero'
    },
    'Library Overview': {
        "French": 'Présentation de la bibliothèque',
        "Kinyarwanda": "Incamake y'ibitabo"
    },
    'Light': {
        "French": 'Clair',
        "Kinyarwanda": 'Kwerurutse'
    },
    'Line': {
        "French": 'Doubler',
        "Kinyarwanda": 'Umurongo'
    },
    'Live': {
        "French": 'En direct',
        "Kinyarwanda": 'Baho'
    },
    'Load Class List': {
        "French": 'Charger la liste des classes',
        "Kinyarwanda": 'Umutwaro Urutonde'
    },
    'Loading history...': {
        "French": "Chargement de l'historique...",
        "Kinyarwanda": 'Gufungura amateka...'
    },
    'Loading questions...': {
        "French": 'Chargement des questions...',
        "Kinyarwanda": 'Gufungura ibibazo...'
    },
    'Loading...': {
        "French": 'Chargement...',
        "Kinyarwanda": 'Kuremera ...'
    },
    'Log Details': {
        "French": 'Détails du journal',
        "Kinyarwanda": 'Injira Ibisobanuro'
    },
    'Login Lockout (Seconds)': {
        "French": 'Verrouillage de connexion (Secondes)',
        "Kinyarwanda": 'Gufunga Kwinjira (Amasegonda)'
    },
    'Logout': {
        "French": 'Se déconnecter',
        "Kinyarwanda": 'Gusohoka'
    },
    'Logs out after inactivity. Set 0 to disable.': {
        "French": 'Déconnexion après inactivité. Mettez 0 pour désactiver.',
        "Kinyarwanda": "Gusohoka nyuma y'igihe nta gikorwa. Shyira 0 kugira ngo ubuhagarike."
    },
    'MANUAL': {
        "French": 'MANUEL',
        "Kinyarwanda": "N'INTOKI"
    },
    'Main Server (Major)': {
        "French": 'Serveur principal (majeur)',
        "Kinyarwanda": 'Seriveri Nkuru (Major)'
    },
    'Major PC': {
        "French": 'PC majeur',
        "Kinyarwanda": 'PC nkuru'
    },
    'Major PC IP (leave blank for auto-detect)': {
        "French": 'IP principale du PC (laisser vide pour la détection automatique)',
        "Kinyarwanda": 'IP nkuru ya PC (usige ubusa kuri auto-detect)'
    },
    'Major/minor device pairing and LAN queue sync are available from the peers screen.': {
        "French": "Le couplage des appareils majeurs/mineurs et la synchronisation de la file d'attente LAN sont disponibles depuis l'écran des pairs.",
        "Kinyarwanda": "Guhuza ibikoresho by'ingenzi/bito no guhuza LAN byaboneka kuri paji y'abagenzi."
    },
    'Manage Class Debt': {
        "French": 'Gérer la dette de classe',
        "Kinyarwanda": 'Gucunga umwenda wo mu ishuri'
    },
    'Manage Class Loan': {
        "French": 'Gérer le prêt de classe',
        "Kinyarwanda": 'Gucunga Inguzanyo'
    },
    'Manage Classes': {
        "French": 'Gérer les cours',
        "Kinyarwanda": 'Gucunga amasomo'
    },
    'Manage Librarians': {
        "French": 'Gérer les bibliothécaires',
        "Kinyarwanda": "Gucunga Abakozi b'Isomero"
    },
    'Manage Security Questions': {
        "French": 'Gérer les questions de sécurité',
        "Kinyarwanda": 'Gucunga ibibazo byumutekano'
    },
    'Manual': {
        "French": 'Manuel',
        "Kinyarwanda": "N'intoki"
    },
    'Mark Issue as Resolved': {
        "French": 'Marquer le problème comme résolu',
        "Kinyarwanda": 'Shyira ikibazo nkuko byakemuwe'
    },
    'Master Key': {
        "French": 'Clé principale',
        "Kinyarwanda": 'Urufunguzo Rukuru'
    },
    'Master Key Help:': {
        "French": 'Aide pour la clé principale :',
        "Kinyarwanda": "Ubufasha bw'Urufunguzo Rukuru:"
    },
    'Max Books per Student': {
        "French": 'Maximum de livres par étudiant',
        "Kinyarwanda": 'Ibitabo Ntangarugero ku Munyeshuri'
    },
    'Members with the biggest active footprint.': {
        "French": 'Membres ayant la plus grande empreinte active.',
        "Kinyarwanda": 'Abanyamuryango bafite ikirenge kinini gikora.'
    },
    'Minor: OTP connect form': {
        "French": 'Mineur\xa0: formulaire de connexion OTP',
        "Kinyarwanda": 'Ntoya: Ifishi yo guhuza OTP'
    },
    'Missing Unique ID(s) Only': {
        "French": 'ID unique(s) manquant(s) uniquement',
        "Kinyarwanda": 'Kubura Indangamuntu Yihariye'
    },
    'Month': {
        "French": 'Mois',
        "Kinyarwanda": 'Ukwezi'
    },
    'Most Borrowed Book': {
        "French": 'Livre le plus emprunté',
        "Kinyarwanda": 'Igitabo gitizwa cyane'
    },
    'Most Borrowed Books': {
        "French": 'Livres les plus empruntés',
        "Kinyarwanda": 'Ibitabo byinshi byatijwe'
    },
    'Most requested titles during the filtered period.': {
        "French": 'Titres les plus demandés pendant la période filtrée.',
        "Kinyarwanda": 'Byinshi byasabwe imitwe mugihe cyayunguruwe.'
    },
    'My Profile': {
        "French": 'Mon Profil',
        "Kinyarwanda": 'Umwirondoro wanjye'
    },
    'Name': {
        "French": 'Nom',
        "Kinyarwanda": 'Izina'
    },
    'Name (A-Z)': {
        "French": 'Nom (A-Z)',
        "Kinyarwanda": 'Izina (A-Z)'
    },
    'Name (Z-A)': {
        "French": 'Nom (Z-A)',
        "Kinyarwanda": 'Izina (Z-A)'
    },
    'Need a new school workspace?': {
        "French": "Besoin d'un nouvel espace de travail scolaire ?",
        "Kinyarwanda": "Ukeneye umwanya mushya w'ishuri?"
    },
    'Needs follow-up': {
        "French": 'Nécessite un suivi',
        "Kinyarwanda": 'Bikeneye gukurikiranwa'
    },
    'Network Setup': {
        "French": 'Configuration du réseau',
        "Kinyarwanda": 'Gushiraho Urusobe'
    },
    'New Class Name': {
        "French": 'Nouveau nom de classe',
        "Kinyarwanda": 'Izina Rishya'
    },
    'New Password': {
        "French": 'Nouveau mot de passe',
        "Kinyarwanda": 'Ijambobanga Rishya'
    },
    'New System Backup': {
        "French": 'Nouvelle sauvegarde du système',
        "Kinyarwanda": 'Kubika Sisitemu Nshya'
    },
    'New Username': {
        "French": "Nouveau nom d'utilisateur",
        "Kinyarwanda": 'Izina Rishya'
    },
    'New Version Available:': {
        "French": 'Nouvelle version disponible :',
        "Kinyarwanda": 'Verisiyo Nshya Yabonetse:'
    },
    'New librarians are linked to your school automatically and receive the `librarian` role.': {
        "French": 'Les nouveaux bibliothécaires sont automatiquement liés à votre école et reçoivent le rôle de « bibliothécaire ».',
        "Kinyarwanda": 'Abanyamasomero bashya bahujwe nishuri ryanyu mu buryo bwikora kandi bakira uruhare rwumubitsi.'
    },
    'Newest First': {
        "French": 'Le plus récent en premier',
        "Kinyarwanda": 'Ibishya Mbere'
    },
    'No Classes Yet': {
        "French": 'Pas encore de cours',
        "Kinyarwanda": 'Nta masomo'
    },
    'No Graduate Debtors': {
        "French": 'Aucun débiteur diplômé',
        "Kinyarwanda": 'Nta barangije imyenda'
    },
    'No Logs Found': {
        "French": 'Aucun journal trouvé',
        "Kinyarwanda": 'Nta biti byabonetse'
    },
    'No Minor PCs connected yet. Generate a PIN above to add one.': {
        "French": "Aucun PC mineur connecté pour l'instant. Générez un code PIN ci-dessus pour en ajouter un.",
        "Kinyarwanda": 'Nta PC ntoya ihujwe kugeza ubu. Kora PIN hejuru kugirango wongere imwe.'
    },
    'No active class loans.': {
        "French": 'Aucun prêt de classe active.',
        "Kinyarwanda": 'Nta nguzanyo ikora.'
    },
    'No active staff loans.': {
        "French": 'Pas de prêt de personnel actif.',
        "Kinyarwanda": "Nta nguzanyo ikora y'abakozi."
    },
    'No active student loans.': {
        "French": 'Aucun prêt étudiant actif.',
        "Kinyarwanda": 'Nta nguzanyo ikora yabanyeshuri.'
    },
    'No archived class debts found.': {
        "French": 'Aucune dettes de classe archivées trouvée.',
        "Kinyarwanda": 'Nta mwenda wo mu cyiciro wabitswe.'
    },
    'No backup files are stored yet.': {
        "French": "Aucun fichier de sauvegarde n'est encore stocké.",
        "Kinyarwanda": 'Nta dosiye zo kubika zabitswe kugeza ubu.'
    },
    'No backups found.': {
        "French": 'Aucune sauvegarde trouvée.',
        "Kinyarwanda": 'Nta nyandiko zibitswe zabonetse.'
    },
    'No books found matching your criteria.': {
        "French": 'Aucun livre trouvé correspondant à vos critères.',
        "Kinyarwanda": "Nta gitabo cyabonetse gihuye n'ibipimo byawe."
    },
    'No borrower activity yet.': {
        "French": "Aucune activité de l'emprunteur pour l'instant.",
        "Kinyarwanda": 'Nta gikorwa cyo kuguriza.'
    },
    'No borrowing data yet.': {
        "French": "Aucune donnée d'emprunt pour l'instant.",
        "Kinyarwanda": 'Nta makuru yo kuguza kugeza ubu.'
    },
    'No class activity yet.': {
        "French": "Aucune activité de classe pour l'instant.",
        "Kinyarwanda": 'Nta gikorwa cyo mu ishuri.'
    },
    'No class borrowing records yet.': {
        "French": "Aucun dossier d'emprunt de cours pour l'instant.",
        "Kinyarwanda": 'Nta cyiciro cyo kuguza inyandiko.'
    },
    'No issues reported': {
        "French": 'Aucun problème signalé',
        "Kinyarwanda": 'Nta kibazo cyatanzwe'
    },
    'No librarians found for this school.': {
        "French": 'Aucun bibliothécaire trouvé pour cette école.',
        "Kinyarwanda": 'Nta masomero wabonetse kuri iri shuri.'
    },
    'No notes saved yet for this school.': {
        "French": 'Aucune note enregistrée pour cette école.',
        "Kinyarwanda": 'Nta nyandiko zabitswe kugeza kuri iri shuri.'
    },
    'No recent activity.': {
        "French": 'Aucune activité récente.',
        "Kinyarwanda": 'Nta gikorwa giherutse.'
    },
    'No spaces allowed (e.g. use S1A, not S1 A).': {
        "French": "Aucun espace n'est autorisé (par exemple, utilisez S1A, pas S1 A).",
        "Kinyarwanda": 'Nta mwanya wemewe (urugero koresha S1A, ntabwo S1 A).'
    },
    'No student names found.': {
        "French": "Aucun nom d'élève trouvé.",
        "Kinyarwanda": "Nta mazina y'abanyeshuri yabonetse."
    },
    'No students found matching your criteria.': {
        "French": 'Aucun étudiant trouvé correspondant à vos critères.',
        "Kinyarwanda": "Nta munyeshuri wasanze uhuye n'ibipimo byawe."
    },
    'No teacher loans have been recorded yet.': {
        "French": 'Aucun prêt d’enseignant n’a encore été enregistré.',
        "Kinyarwanda": 'Nta nguzanyo ya mwarimu yigeze yandikwa.'
    },
    'No update history found.': {
        "French": 'Aucun historique de mise à jour trouvé.',
        "Kinyarwanda": "Nta mateka y'ivugurura yabonetse."
    },
    'No.': {
        "French": 'Non.',
        "Kinyarwanda": 'Oya.'
    },
    'Not Generated.': {
        "French": 'Non généré.',
        "Kinyarwanda": 'Ntabwo Byakozwe.'
    },
    'Not Set': {
        "French": 'Non défini',
        "Kinyarwanda": 'Ntabwo washyizweho'
    },
    'Not connected': {
        "French": 'Non connecté',
        "Kinyarwanda": 'Ntabwo bihujwe'
    },
    'Notes': {
        "French": 'Remarques',
        "Kinyarwanda": 'Inyandiko'
    },
    'Novels': {
        "French": 'Romans',
        "Kinyarwanda": 'Ibitabo'
    },
    'OTP': {
        "French": 'Bureau du Procureur',
        "Kinyarwanda": 'OTP'
    },
    'OTP generator for Majors': {
        "French": "Générateur d'OTP pour les majors",
        "Kinyarwanda": 'Imashini itanga amashanyarazi ya Majoro'
    },
    'Off': {
        "French": 'Désactivé',
        "Kinyarwanda": 'Hanze'
    },
    'Oldest First': {
        "French": 'Le plus ancien en premier',
        "Kinyarwanda": 'Ibishaje Mbere'
    },
    'On': {
        "French": 'Sur',
        "Kinyarwanda": 'Kuri'
    },
    'Once borrowers are ready, move straight into the regular borrow workflow.': {
        "French": 'Une fois que les emprunteurs sont prêts, passez directement au flux de travail d’emprunt habituel.',
        "Kinyarwanda": 'Abahawe inguzanyo nibamara kwitegura, jya mu buryo busanzwe bwo kuguza akazi.'
    },
    'Once connected,': {
        "French": 'Une fois connecté,',
        "Kinyarwanda": 'Bimaze guhuzwa,'
    },
    'One-time PIN from the Major PC': {
        "French": 'Code PIN unique du PC principal',
        "Kinyarwanda": 'PIN inshuro imwe kuva PC nkuru'
    },
    'One-time passwords for emergency login.': {
        "French": "Mots de passe à usage unique pour la connexion d'urgence.",
        "Kinyarwanda": 'Ijambobanga rimwe gusa ryo kwinjira byihutirwa.'
    },
    'Open Admin Panel': {
        "French": "Ouvrir le panneau d'administration",
        "Kinyarwanda": 'Fungura akanama gashinzwe kuyobora'
    },
    'Open Borrow Desk': {
        "French": "Bureau d'emprunt ouvert",
        "Kinyarwanda": "Fungura Ibiro by'inguzanyo"
    },
    'Open Librarian Management': {
        "French": 'Gestion des bibliothèques ouvertes',
        "Kinyarwanda": 'Gufungura imicungire yibitabo'
    },
    'Open Peers & Sync': {
        "French": 'Ouvrir les pairs et synchroniser',
        "Kinyarwanda": 'Fungura Abagenzi & Guhuza'
    },
    'Open Role Wizard': {
        "French": "Ouvrir l'assistant de rôle",
        "Kinyarwanda": "Fungura Umufasha w'Inshingano"
    },
    'Open Settings': {
        "French": 'Ouvrir les paramètres',
        "Kinyarwanda": 'Fungura Igenamiterere'
    },
    'Open Students': {
        "French": 'Étudiants ouverts',
        "Kinyarwanda": 'Fungura Abanyeshuri'
    },
    'Open the students page to confirm names, classes, and school-scoped records.': {
        "French": "Ouvrez la page des étudiants pour confirmer les noms, les classes et les enregistrements relatifs à l'école.",
        "Kinyarwanda": 'Fungura urupapuro rwabanyeshuri kugirango wemeze amazina, amasomo, hamwe nishuri ryanditse.'
    },
    'Optional email': {
        "French": 'E-mail facultatif',
        "Kinyarwanda": 'Imeri itegetswe'
    },
    'Optional, but useful for later partial returns.': {
        "French": 'Facultatif, mais utile pour les retours partiels ultérieurs.',
        "Kinyarwanda": 'Bihitamo, ariko bifite akamaro nyuma yo kugaruka igice.'
    },
    'Original Class': {
        "French": 'Classe originale',
        "Kinyarwanda": "Icyiciro cy'umwimerere"
    },
    'Other': {
        "French": 'Autre',
        "Kinyarwanda": 'Ibindi'
    },
    'Overdue': {
        "French": 'En retard',
        "Kinyarwanda": 'Igihe kirenze'
    },
    'Overdue Books': {
        "French": 'Livres en retard',
        "Kinyarwanda": 'Ibitabo byarengeje igihe'
    },
    'Overview Cards': {
        "French": 'Cartes de présentation',
        "Kinyarwanda": 'Ikarita rusange'
    },
    'Owes:': {
        "French": 'Doit\xa0:',
        "Kinyarwanda": 'Intama:'
    },
    'PDF': {
        "French": 'PDF',
        "Kinyarwanda": 'PDF'
    },
    'PDF (Class Tables)': {
        "French": 'PDF (Tableaux de classe)',
        "Kinyarwanda": "PDF (Imbonerahamwe y'Icyiciro)"
    },
    'PIN expires after 5 minutes or one use.': {
        "French": 'Le code PIN expire après 5 minutes ou une seule utilisation.',
        "Kinyarwanda": 'PIN irangira nyuma yiminota 5 cyangwa ikoreshwa rimwe.'
    },
    'Partial Return (Specific Books/Students)': {
        "French": 'Retour partiel (livres spécifiques/étudiants)',
        "Kinyarwanda": 'Garuka Igice (Ibitabo byihariye / Abanyeshuri)'
    },
    'Password': {
        "French": 'Mot de passe',
        "Kinyarwanda": "Ijambo ry'ibanga"
    },
    'Peers': {
        "French": 'Pairs',
        "Kinyarwanda": 'Urungano'
    },
    'Peers & Sync': {
        "French": 'Pairs et synchronisation',
        "Kinyarwanda": 'Urungano & Sync'
    },
    'Pending (not yet synced)': {
        "French": 'En attente (pas encore synchronisé)',
        "Kinyarwanda": 'Bitegereje (bitarahuzwa)'
    },
    'Period': {
        "French": 'Période',
        "Kinyarwanda": 'Ikiringo'
    },
    'Persisted for this school and restored automatically on your next visit.': {
        "French": 'Persisté pour cette école et restauré automatiquement lors de votre prochaine visite.',
        "Kinyarwanda": 'Komeza kuri iri shuri kandi usubizwe mu buryo bwikora muruzinduko rutaha.'
    },
    'Please enter your admin password to proceed.': {
        "French": "Veuillez entrer votre mot de passe d'administration pour continuer.",
        "Kinyarwanda": "Shyiramo ijambo ry'ibanga ry'umuyobozi kugira ngo ukomeze."
    },
    'Preview': {
        "French": 'Aperçu',
        "Kinyarwanda": 'Imbere'
    },
    'Print': {
        "French": 'Imprimer',
        "Kinyarwanda": 'Icapa'
    },
    'Profile': {
        "French": 'Profil',
        "Kinyarwanda": 'Umwirondoro'
    },
    'Promote & Graduate': {
        "French": 'Promouvoir et obtenir un diplôme',
        "Kinyarwanda": 'Teza imbere & Abahawe impamyabumenyi'
    },
    'Promote All Classes': {
        "French": 'Promouvoir toutes les classes',
        "Kinyarwanda": 'Teza imbere ibyiciro byose'
    },
    'Promote:': {
        "French": 'Promouvoir:',
        "Kinyarwanda": 'Teza imbere:'
    },
    'Promotion Name': {
        "French": 'Nom de la promotion',
        "Kinyarwanda": 'Izina ryizamurwa'
    },
    'Promotion Name (For Graduates)': {
        "French": 'Nom de la promotion (pour les diplômés)',
        "Kinyarwanda": 'Izina ryizamurwa (Kubarangije)'
    },
    'Protected admin': {
        "French": 'Administrateur protégé',
        "Kinyarwanda": 'Kurinda admin'
    },
    'Qty': {
        "French": 'Quantité',
        "Kinyarwanda": 'Qty'
    },
    'Quantity': {
        "French": 'Quantité',
        "Kinyarwanda": 'Umubare'
    },
    'Questions': {
        "French": 'Questions',
        "Kinyarwanda": 'Ibibazo'
    },
    'RIGHT COLUMN': {
        "French": 'COLONNE DE DROITE',
        "Kinyarwanda": 'INKINGI NYAKURI'
    },
    'RIGHT: Log + Last result': {
        "French": 'DROITE\xa0: Journal + Dernier résultat',
        "Kinyarwanda": 'UBURENGANZIRA: Logika + Ibisubizo byanyuma'
    },
    'RWF': {
        "French": 'FRW',
        "Kinyarwanda": 'RWF'
    },
    'Range / Title': {
        "French": 'Plage / Titre',
        "Kinyarwanda": 'Urwego / Umutwe'
    },
    'Ready to lend': {
        "French": 'Prêt à être emprunté',
        "Kinyarwanda": 'Biteguye gutangwa'
    },
    'Reason': {
        "French": 'Raison',
        "Kinyarwanda": 'Impamvu'
    },
    'Recent Activity': {
        "French": 'Activité récente',
        "Kinyarwanda": 'Igikorwa cya vuba'
    },
    'Recent Activity (Live Feed)': {
        "French": 'Activité récente (flux en direct)',
        "Kinyarwanda": 'Igikorwa giheruka (Kugaburira Live)'
    },
    'Recent Class Loans': {
        "French": 'Prêts de classe récents',
        "Kinyarwanda": 'Inguzanyo zo mucyiciro cya vuba'
    },
    'Recent Notes': {
        "French": 'Notes récentes',
        "Kinyarwanda": 'Inyandiko ziherutse'
    },
    'Recent Staff Loans': {
        "French": 'Prêts de personnel récents',
        "Kinyarwanda": "Inguzanyo y'abakozi baherutse"
    },
    'Recent activity is hidden in the current dashboard view.': {
        "French": "L'activité récente est masquée dans la vue actuelle du tableau de bord.",
        "Kinyarwanda": 'Ibikorwa bya vuba byihishe muburyo bugezweho.'
    },
    'Record Class Borrowing': {
        "French": 'Emprunt de classe record',
        "Kinyarwanda": 'Andika Inguzanyo'
    },
    'Record Staff Borrow': {
        "French": 'Emprunt de personnel record',
        "Kinyarwanda": 'Andika abakozi'
    },
    'Recover Account': {
        "French": 'Récupérer le compte',
        "Kinyarwanda": 'Kugarura Konti'
    },
    'Recovery Codes': {
        "French": 'Codes de récupération',
        "Kinyarwanda": 'Kode yo Kugarura'
    },
    'Recovery Email': {
        "French": 'E-mail de récupération',
        "Kinyarwanda": 'Imeri yo kugarura'
    },
    'Recovery Emails (Add up to 3)': {
        "French": "E-mails de récupération (ajoutez jusqu'à 3)",
        "Kinyarwanda": 'Imeri yo Kugarura (Ongeraho kuri 3)'
    },
    'Reference': {
        "French": 'Référence',
        "Kinyarwanda": 'Reba'
    },
    'Register School': {
        "French": "Inscrire l'école",
        "Kinyarwanda": 'Kwiyandikisha Ishuri'
    },
    'Registration creates a pending school admin account. You must approve the school in Supabase before login is allowed.': {
        "French": "L'inscription crée un compte administrateur d'école en attente. Vous devez approuver l'école dans Supabase avant de pouvoir vous connecter.",
        "Kinyarwanda": "Kwiyandikisha bikora konti y'umuyobozi w'ishuri itegereje. Ugomba kwemeza ishuri muri Supabase mbere y'uko winjira."
    },
    'Remote Access & LAN Sync': {
        "French": 'Accès à distance et synchronisation LAN',
        "Kinyarwanda": 'Kwinjira Kure & Guhuza LAN'
    },
    'Rename': {
        "French": 'Rebaptiser',
        "Kinyarwanda": 'Hindura izina'
    },
    'Repair/Replacement Cost': {
        "French": 'Coût de réparation/remplacement',
        "Kinyarwanda": 'Igiciro cyo Gusana / Gusimbuza'
    },
    'Report Book Issue': {
        "French": 'Problème de livre de rapport',
        "Kinyarwanda": 'Raporo Ikibazo'
    },
    'Reset': {
        "French": 'Réinitialiser',
        "Kinyarwanda": 'Gusubiramo'
    },
    'Reset Account Credentials': {
        "French": "Réinitialiser les informations d'identification du compte",
        "Kinyarwanda": 'Ongera usubize ibyangombwa bya konti'
    },
    'Resolve Issue Modal': {
        "French": 'Résoudre le problème modal',
        "Kinyarwanda": 'Gukemura Ikibazo'
    },
    'Responsibles': {
        "French": 'Responsables',
        "Kinyarwanda": 'Inshingano'
    },
    'Responsibles (Students in Class)': {
        "French": 'Responsables (élèves en classe)',
        "Kinyarwanda": 'Inshingano (Abanyeshuri mu ishuri)'
    },
    'Restore': {
        "French": 'Restaurer',
        "Kinyarwanda": 'Kugarura'
    },
    'Return': {
        "French": 'Retour',
        "Kinyarwanda": 'Garuka'
    },
    'Return & Record Issue': {
        "French": "Problème de retour et d'enregistrement",
        "Kinyarwanda": 'Garuka & Kwandika Ikibazo'
    },
    'Return Action': {
        "French": 'Action de retour',
        "Kinyarwanda": 'Garuka Igikorwa'
    },
    'Return All': {
        "French": 'Retourner tout',
        "Kinyarwanda": 'Garuka Byose'
    },
    'Return All (Close Loan)': {
        "French": 'Tout retourner (fermer le prêt)',
        "Kinyarwanda": 'Subiza Byose (Gufunga Inguzanyo)'
    },
    'Return Rate': {
        "French": 'Taux de retour',
        "Kinyarwanda": 'Igipimo cyo gusubiza'
    },
    'Return to Dashboard': {
        "French": 'Retour au tableau de bord',
        "Kinyarwanda": 'Garuka kuri Dashboard'
    },
    'Return to Login': {
        "French": 'Revenir à la connexion',
        "Kinyarwanda": 'Garuka Kwinjira'
    },
    'Returned Books': {
        "French": 'Livres retournés',
        "Kinyarwanda": 'Ibitabo byasubijwe'
    },
    'Returns in sight': {
        "French": 'Retours en vue',
        "Kinyarwanda": 'Ibizasubizwa vuba'
    },
    'Role': {
        "French": 'Rôle',
        "Kinyarwanda": 'Uruhare'
    },
    'Role & connection status': {
        "French": 'Statut de rôle et de connexion',
        "Kinyarwanda": 'Uruhare & guhuza imiterere'
    },
    'Rolling activity for the selected period.': {
        "French": 'Activité glissante pour la période sélectionnée.',
        "Kinyarwanda": 'Igikorwa cyo kuzunguruka mugihe cyatoranijwe.'
    },
    'S1 → S2, S2 → S3, S4 → S5, S5 → S6.': {
        "French": 'S1 → S2, S2 → S3, S4 → S5, S5 → S6.',
        "Kinyarwanda": 'S1 → S2, S2 → S3, S4 → S5, S5 → S6.'
    },
    'S3': {
        "French": 'S3',
        "Kinyarwanda": 'S3'
    },
    'S6': {
        "French": 'S6',
        "Kinyarwanda": 'S6'
    },
    'SIGN IN': {
        "French": 'SE CONNECTER',
        "Kinyarwanda": 'INJIRA'
    },
    'Save': {
        "French": 'Sauvegarder',
        "Kinyarwanda": 'Bika'
    },
    'Save & Continue': {
        "French": 'Enregistrer et continuer',
        "Kinyarwanda": 'Bika & Komeza'
    },
    'Save Admin Credentials': {
        "French": "Enregistrer les informations d'identification de l'administrateur",
        "Kinyarwanda": 'Bika ibyangombwa bya Admin'
    },
    'Save Analytics Settings': {
        "French": "Enregistrer les paramètres d'analyse",
        "Kinyarwanda": 'Bika Analytics Igenamiterere'
    },
    'Save Books': {
        "French": 'Enregistrer des livres',
        "Kinyarwanda": 'Bika Ibitabo'
    },
    'Save Changes': {
        "French": 'Enregistrer les modifications',
        "Kinyarwanda": 'Bika Impinduka'
    },
    'Save Cloud Sync Settings': {
        "French": 'Enregistrer les paramètres de synchronisation cloud',
        "Kinyarwanda": 'Kubika Igenamiterere ryo Guhuza mu Bicu'
    },
    'Save Configuration': {
        "French": 'Enregistrer la configuration',
        "Kinyarwanda": 'Kubika Igenamiterere'
    },
    'Save New Credentials': {
        "French": 'Enregistrer les nouveaux identifiants',
        "Kinyarwanda": 'Bika ibyangombwa bishya'
    },
    'Save Note': {
        "French": 'Enregistrer la note',
        "Kinyarwanda": 'Bika Icyitonderwa'
    },
    'Save Questions': {
        "French": 'Enregistrer les questions',
        "Kinyarwanda": 'Bika Ibibazo'
    },
    'Save these codes safely.': {
        "French": 'Enregistrez ces codes en toute sécurité.',
        "Kinyarwanda": 'Bika aya ma code neza.'
    },
    'Saved Files': {
        "French": 'Fichiers enregistrés',
        "Kinyarwanda": 'Amadosiye yabitswe'
    },
    'School ID': {
        "French": "Carte d'identité de l'école",
        "Kinyarwanda": "Indangamuntu y'ishuri"
    },
    'School Librarians': {
        "French": 'Bibliothécaires scolaires',
        "Kinyarwanda": "Amasomero y'ishuri"
    },
    'School Name': {
        "French": "Nom de l'école",
        "Kinyarwanda": "Izina ry'Ishuri"
    },
    'School Staff': {
        "French": "Personnel de l'école",
        "Kinyarwanda": "Abakozi b'ishuri"
    },
    'School Workspace': {
        "French": 'Espace de travail scolaire',
        "Kinyarwanda": "Umwanya w'ishuri"
    },
    'School admin username': {
        "French": "Nom d'utilisateur de l'administrateur de l'école",
        "Kinyarwanda": "Izina ry'umuyobozi w'ishuri"
    },
    'Search & Add Books': {
        "French": 'Rechercher et ajouter des livres',
        "Kinyarwanda": 'Shakisha & Ongera Ibitabo'
    },
    'Security & System': {
        "French": 'Sécurité et système',
        "Kinyarwanda": 'Umutekano na Sisitemu'
    },
    'Security Questions': {
        "French": 'Questions de sécurité',
        "Kinyarwanda": 'Ibibazo byumutekano'
    },
    'Security Verification': {
        "French": 'Vérification de sécurité',
        "Kinyarwanda": 'Kugenzura Umutekano'
    },
    'Security Zone': {
        "French": 'Zone de sécurité',
        "Kinyarwanda": "Agace k'umutekano"
    },
    'Select Action...': {
        "French": 'Sélectionnez Action...',
        "Kinyarwanda": 'Hitamo Igikorwa ...'
    },
    'Select Excel file to upload.': {
        "French": 'Sélectionnez le fichier Excel à télécharger.',
        "Kinyarwanda": 'Hitamo dosiye ya Excel kugirango wohereze.'
    },
    'Selected': {
        "French": 'Sélectionné',
        "Kinyarwanda": 'Byatoranijwe'
    },
    'Send Recovery': {
        "French": 'Envoyer la récupération',
        "Kinyarwanda": 'Ohereza Icyo Kugarura'
    },
    'Server IP': {
        "French": 'IP du serveur',
        "Kinyarwanda": 'Seriveri IP'
    },
    'Settings': {
        "French": 'Paramètres',
        "Kinyarwanda": 'Igenamiterere'
    },
    'Setup Questions': {
        "French": 'Questions de configuration',
        "Kinyarwanda": 'Gushiraho Ibibazo'
    },
    'Shared Notes': {
        "French": 'Notes partagées',
        "Kinyarwanda": 'Inyandiko Zisangiwe'
    },
    'Shared School Analytics': {
        "French": 'Analyses scolaires partagées',
        "Kinyarwanda": 'Isesengura ryishuri risangiwe'
    },
    'Show': {
        "French": 'Montrer',
        "Kinyarwanda": 'Erekana'
    },
    'Show Graphs': {
        "French": 'Afficher les graphiques',
        "Kinyarwanda": 'Erekana Igishushanyo'
    },
    'Show this setup wizard next time the app starts': {
        "French": "Afficher cet assistant de configuration au prochain démarrage de l'application",
        "Kinyarwanda": 'Erekana iyi wizard wizard ubutaha porogaramu itangiye'
    },
    'Sign In': {
        "French": 'Se connecter',
        "Kinyarwanda": 'Injira'
    },
    'Size': {
        "French": 'Taille',
        "Kinyarwanda": 'Ingano'
    },
    'Smart': {
        "French": 'Intelligent',
        "Kinyarwanda": 'Ubwenge'
    },
    'Smart Library': {
        "French": 'Bibliothèque Intelligente',
        "Kinyarwanda": 'Isomero Nyabwenge'
    },
    'Software Update': {
        "French": 'Mise à jour du logiciel',
        "Kinyarwanda": 'Ivugurura rya Porogaramu'
    },
    'Some books are missing from the catalog.': {
        "French": 'Certains livres manquent au catalogue.',
        "Kinyarwanda": 'Ibitabo bimwe byabuze kurutonde.'
    },
    'Sort: A → Z (Borrower)': {
        "French": 'Trier\xa0: A → Z (Emprunteur)',
        "Kinyarwanda": 'Itondekanya: A → Z (Uwagurijwe)'
    },
    'Sort: A → Z (Class)': {
        "French": 'Trier\xa0: A → Z (Classe)',
        "Kinyarwanda": 'Itondekanya: A → Z (Urwego)'
    },
    'Sort: A → Z (Name)': {
        "French": 'Trier\xa0: A → Z (Nom)',
        "Kinyarwanda": 'Itondekanya: A → Z (Izina)'
    },
    'Sort: A → Z (Promotion)': {
        "French": 'Trier\xa0: A → Z (Promotion)',
        "Kinyarwanda": 'Sort: A → Z (Kuzamurwa)'
    },
    'Sort: Newest First': {
        "French": 'Trier\xa0: Les plus récents en premier',
        "Kinyarwanda": 'Sort: Ibishya Byambere'
    },
    'Sort: Oldest First': {
        "French": 'Trier\xa0: le plus ancien en premier',
        "Kinyarwanda": 'Sort: Kera Kera'
    },
    'Sort: Z → A (Borrower)': {
        "French": 'Trier\xa0: Z → A (Emprunteur)',
        "Kinyarwanda": 'Itondekanya: Z → A (Uwagurijwe)'
    },
    'Sort: Z → A (Class)': {
        "French": 'Trier\xa0: Z → A (Classe)',
        "Kinyarwanda": 'Itondekanya: Z → A (Urwego)'
    },
    'Sort: Z → A (Name)': {
        "French": 'Trier\xa0: Z → A (Nom)',
        "Kinyarwanda": 'Sort: Z → A (Izina)'
    },
    'Sort: Z → A (Promotion)': {
        "French": 'Trier\xa0: Z → A (Promotion)',
        "Kinyarwanda": 'Sort: Z → A (Kuzamurwa)'
    },
    'Staff': {
        "French": 'Personnel',
        "Kinyarwanda": 'Abakozi'
    },
    'Staff Name': {
        "French": 'Nom du personnel',
        "Kinyarwanda": "Izina ry'abakozi"
    },
    'Stats Cards': {
        "French": 'Cartes de statistiques',
        "Kinyarwanda": 'Ikarita'
    },
    'Status row': {
        "French": "Ligne d'état",
        "Kinyarwanda": 'Imirongo'
    },
    'Student': {
        "French": 'Étudiant',
        "Kinyarwanda": 'Umunyeshuri'
    },
    'Student Books': {
        "French": 'Livres étudiants',
        "Kinyarwanda": "Ibitabo by'abanyeshuri"
    },
    'Student Name': {
        "French": "Nom de l'étudiant",
        "Kinyarwanda": 'Izina ryabanyeshuri'
    },
    'Student Registry': {
        "French": 'Registre des étudiants',
        "Kinyarwanda": "Kwiyandikisha kw'abanyeshuri"
    },
    'Student:': {
        "French": 'Étudiant:',
        "Kinyarwanda": 'Umunyeshuri:'
    },
    'Students': {
        "French": 'Étudiants',
        "Kinyarwanda": 'Abanyeshuri'
    },
    'Students / Classes': {
        "French": 'Étudiants / Classes',
        "Kinyarwanda": 'Abanyeshuri / Amashuri'
    },
    'Students in': {
        "French": 'Les étudiants en',
        "Kinyarwanda": 'Abanyeshuri muri'
    },
    'Submit Registration': {
        "French": "Soumettre l'inscription",
        "Kinyarwanda": 'Ohereza Kwiyandikisha'
    },
    'Success rate': {
        "French": 'Taux de réussite',
        "Kinyarwanda": 'Igipimo cyo gutsinda'
    },
    'Success! ': {
        "French": 'Succès ! ',
        "Kinyarwanda": 'Byagenze neza! '
    },
    'Summary Cards': {
        "French": 'Cartes récapitulatives',
        "Kinyarwanda": 'Ikarita Incamake'
    },
    'Supabase Anon Key': {
        "French": 'Clé Anon Supabase',
        "Kinyarwanda": 'Urufunguzo rwa Anon rwa Supabase'
    },
    'Supabase Cloud Sync': {
        "French": 'Synchronisation cloud Supabase',
        "Kinyarwanda": 'Guhuza mu bicu bya Supabase'
    },
    'Supabase Service Role Key': {
        "French": 'Clé de rôle de service Supabase',
        "Kinyarwanda": "Urufunguzo rw'Inshingano za Supabase"
    },
    'Supabase URL': {
        "French": 'URL Supabase',
        "Kinyarwanda": 'URL ya Supabase'
    },
    'Swipe through the key metrics in a compact, easy-to-scan view.': {
        "French": 'Parcourez les indicateurs clés dans une vue compacte et facile à analyser.',
        "Kinyarwanda": 'Ihanagura unyuze mubipimo byingenzi muburyo bworoshye, byoroshye-gusikana.'
    },
    'Sync Batch Size': {
        "French": 'Taille du lot de synchronisation',
        "Kinyarwanda": "Ingano y'Icyiciro cyo Guhuza"
    },
    'Sync interval': {
        "French": 'Intervalle de synchronisation',
        "Kinyarwanda": 'Intera'
    },
    'Sync interval (seconds)': {
        "French": 'Intervalle de synchronisation (secondes)',
        "Kinyarwanda": 'Guhuza intera (amasegonda)'
    },
    'Sync interval control': {
        "French": "Contrôle de l'intervalle de synchronisation",
        "Kinyarwanda": 'Kugenzura intera intera'
    },
    'System Locked': {
        "French": 'Système verrouillé',
        "Kinyarwanda": 'Sisitemu Yafunzwe'
    },
    'System Logs': {
        "French": 'Journaux système',
        "Kinyarwanda": 'Ibirango bya sisitemu'
    },
    'System Settings': {
        "French": 'Paramètres du système',
        "Kinyarwanda": 'Igenamiterere rya Sisitemu'
    },
    'System Version': {
        "French": 'Version du système',
        "Kinyarwanda": 'Sisitemu Sisitemu'
    },
    'Teacher': {
        "French": 'Professeur',
        "Kinyarwanda": 'Mwarimu'
    },
    'Teacher Borrowing': {
        "French": 'Emprunt d’enseignant',
        "Kinyarwanda": 'Inguzanyo ya mwarimu'
    },
    'Teacher Name': {
        "French": "Nom de l'enseignant",
        "Kinyarwanda": "Izina ry'Umwarimu"
    },
    'Teachers Guides': {
        "French": 'Guides des enseignants',
        "Kinyarwanda": 'Abayobozi bayobora'
    },
    'Template': {
        "French": 'Modèle',
        "Kinyarwanda": 'Inyandikorugero'
    },
    'The following books were ignored because they already exist:': {
        "French": 'Les livres suivants ont été ignorés car ils existent déjà\xa0:',
        "Kinyarwanda": 'Ibitabo bikurikira birengagijwe kuko bimaze kubaho:'
    },
    'The following students were ignored because they already exist:': {
        "French": 'Les étudiants suivants ont été ignorés car ils existent déjà\xa0:',
        "Kinyarwanda": 'Abanyeshuri bakurikira birengagijwe kuko basanzweho:'
    },
    'The latest audit events in the selected school scope.': {
        "French": "Les derniers événements d'audit dans le périmètre de l'école sélectionnée.",
        "Kinyarwanda": 'Ibikorwa byubugenzuzi biheruka murwego rwishuri ryatoranijwe.'
    },
    'The server should run on': {
        "French": 'Le serveur doit fonctionner sur',
        "Kinyarwanda": 'Seriveri igomba gukora'
    },
    'The software for library management.': {
        "French": 'Le logiciel pour la gestion de bibliothèque.',
        "Kinyarwanda": "Porogaramu y'imicungire y'isomero."
    },
    'The system has auto-filled the missing range below. Save to create them and finish the loan.': {
        "French": 'Le système a automatiquement rempli la plage manquante ci-dessous. Économisez pour les créer et terminer le prêt.',
        "Kinyarwanda": 'Sisitemu yujuje auto-yuzuye intera yabuze hepfo. Uzigame kubirema no kurangiza inguzanyo.'
    },
    'Theme': {
        "French": 'Thème',
        "Kinyarwanda": 'Isura'
    },
    'These classes graduated while still holding books.': {
        "French": 'Ces classes obtenaient leur diplôme tout en détenant des livres.',
        "Kinyarwanda": 'Aya masomo yarangije mugihe agifite ibitabo.'
    },
    'This PC': {
        "French": 'Ce PC',
        "Kinyarwanda": 'Iyi PC'
    },
    'This action is irreversible. All catalog and borrowing history will be instantly destroyed.': {
        "French": "Cette action est irréversible. Tout le catalogue et l'historique des prêts seront instantanément détruits.",
        "Kinyarwanda": "Iki gikorwa ntigishobora kugarurwa. Igitabo cyose n'amateka y'inguzanyo bizangizwa ako kanya."
    },
    'This action will modify all student records.': {
        "French": 'Cette action modifiera tous les dossiers des étudiants.',
        "Kinyarwanda": 'Iki gikorwa kizahindura inyandiko zose zabanyeshuri.'
    },
    'This app is configured for multi-device access. Run the server on': {
        "French": 'Cette application est configurée pour un accès multi-appareils. Exécutez le serveur sur',
        "Kinyarwanda": 'Iyi porogaramu yagenewe gukoreshwa ku bikoresho byinshi. Fungura seriveri kuri'
    },
    "This is the Head Librarian's PC. The authoritative database lives here.": {
        "French": "C'est le PC du bibliothécaire en chef. La base de données faisant autorité réside ici.",
        "Kinyarwanda": "Iyi ni PC y'umuyobozi w'ibitabo. Ububikoshingiro bwemewe butuye hano."
    },
    'This month': {
        "French": 'Ce mois-ci',
        "Kinyarwanda": 'Uku kwezi'
    },
    'This name will tag archived graduates (e.g. Class of 2025).': {
        "French": 'Ce nom identifiera les diplômés archivés (par exemple, promotion 2025).',
        "Kinyarwanda": 'Iri zina rizashyira ahagaragara abarangije muri archive (urugero: Icyiciro cya 2025).'
    },
    'This screen keeps the borrower onboarding flow in one place while the main student/member tools remain the source of truth.': {
        "French": "Cet écran maintient le flux d'intégration de l'emprunteur au même endroit tandis que les principaux outils étudiants/membres restent la source de vérité.",
        "Kinyarwanda": 'Iyi ecran ituma uwagurijwe atembera ahantu hamwe mugihe ibikoresho nyamukuru byabanyeshuri / abanyamuryango bikomeza kuba isoko yukuri.'
    },
    'This will permanently delete all': {
        "French": 'Cela supprimera définitivement tous les',
        "Kinyarwanda": 'Ibi bizasiba burundu ibi byose'
    },
    'This will remove the issue from the list.': {
        "French": 'Cela supprimera le problème de la liste.',
        "Kinyarwanda": 'Ibi bizakuraho ikibazo kurutonde.'
    },
    'Timestamp': {
        "French": 'Horodatage',
        "Kinyarwanda": 'Igihe'
    },
    'Title': {
        "French": 'Titre',
        "Kinyarwanda": 'Umutwe'
    },
    'Title (A-Z)': {
        "French": 'Titre (A-Z)',
        "Kinyarwanda": 'Umutwe (A-Z)'
    },
    'Title (Z-A)': {
        "French": 'Titre (Z-A)',
        "Kinyarwanda": 'Umutwe (Z-A)'
    },
    'Today': {
        "French": "Aujourd'hui",
        "Kinyarwanda": 'Uyu munsi'
    },
    "Today's volume": {
        "French": 'Volume du jour',
        "Kinyarwanda": "Ibikorwa by'uyu munsi"
    },
    'Top Borrowers': {
        "French": 'Principaux emprunteurs',
        "Kinyarwanda": 'Abaguriza hejuru'
    },
    'Total Books': {
        "French": 'Total des livres',
        "Kinyarwanda": 'Ibitabo byose'
    },
    'Total Students': {
        "French": "Nombre total d'étudiants",
        "Kinyarwanda": 'Abanyeshuri bose'
    },
    'Total active loans allowed at once.': {
        "French": 'Total des prêts actifs autorisés à la fois.',
        "Kinyarwanda": "Umubare wose w'ibitabo byatiwe icya rimwe."
    },
    'Track bulk loans issued to entire classes and return them from one place.': {
        "French": 'Suivez les prêts groupés accordés à des classes entières et restituez-les à partir d’un seul endroit.',
        "Kinyarwanda": 'Kurikirana inguzanyo nyinshi zahawe ibyiciro byose hanyuma uzisubize ahantu hamwe.'
    },
    'Trusted': {
        "French": 'Confiance',
        "Kinyarwanda": 'Wizeye'
    },
    'Trusted toggle': {
        "French": 'Bascule de confiance',
        "Kinyarwanda": 'Kwizerwa'
    },
    'Try again in': {
        "French": 'Réessayez dans',
        "Kinyarwanda": 'Gerageza nanone'
    },
    'Type': {
        "French": 'Taper',
        "Kinyarwanda": 'Andika'
    },
    'Uncategorized': {
        "French": 'Non classé',
        "Kinyarwanda": 'Urutonde'
    },
    'Unique ID Part': {
        "French": "Pièce d'identification unique",
        "Kinyarwanda": "Igice cyihariye cy'irangamuntu"
    },
    'Unrecognized Book Detected': {
        "French": 'Livre non reconnu détecté',
        "Kinyarwanda": 'Igitabo kitamenyekanye'
    },
    'Unsure which credential is wrong?': {
        "French": 'Vous ne savez pas quel identifiant est erroné\xa0?',
        "Kinyarwanda": 'Ntabwo uzi neza ko ibyangombwa ari bibi?'
    },
    'Update History': {
        "French": 'Historique des mises à jour',
        "Kinyarwanda": "Amateka y'Ivugurura"
    },
    'Update Profile': {
        "French": 'Mettre à jour le profil',
        "Kinyarwanda": 'Kuvugurura umwirondoro'
    },
    'Update Profile Picture': {
        "French": 'Mettre à jour la photo de profil',
        "Kinyarwanda": 'Kuvugurura Ishusho'
    },
    'Update Schedule': {
        "French": 'Mettre à jour le calendrier',
        "Kinyarwanda": 'Kuvugurura Gahunda'
    },
    'Update failed. Check logs.': {
        "French": 'La mise à jour a échoué. Vérifiez les journaux.',
        "Kinyarwanda": 'Ivugurura ryananiwe. Reba amateka.'
    },
    'Updates': {
        "French": 'Mises à jour',
        "Kinyarwanda": 'Ibyasohotse bishya'
    },
    'Upload & Import': {
        "French": 'Télécharger et importer',
        "Kinyarwanda": 'Kuramo & Kuzana'
    },
    'Use Class Names as headers (e.g. S1A, S2B). List names under each header.': {
        "French": 'Utilisez les noms de classe comme en-têtes (par exemple S1A, S2B). Répertoriez les noms sous chaque en-tête.',
        "Kinyarwanda": "Koresha Amazina y'Icyiciro nk'imitwe (urugero: S1A, S2B). Andika amazina munsi ya buri mutwe."
    },
    'Use Original': {
        "French": "Utiliser l'original",
        "Kinyarwanda": 'Koresha Umwimerere'
    },
    'Use environment variables for public URLs instead of hardcoded localhost values.': {
        "French": "Utilisez des variables d'environnement pour les URL publiques au lieu de valeurs localhost codées en dur.",
        "Kinyarwanda": "Koresha ibintu by'ibidukikije kuri URL rusange aho gukoresha localhost."
    },
    'Use the sample spreadsheet layout before preparing a class list.': {
        "French": 'Utilisez l’exemple de mise en page d’une feuille de calcul avant de préparer une liste de classes.',
        "Kinyarwanda": "Koresha icyitegererezo cy'urupapuro mbere yo gutegura urutonde."
    },
    'Use the system master key to reset the owner account credentials, even if the username is forgotten.': {
        "French": "Utilisez la clé principale du système pour réinitialiser les informations d'identification du compte propriétaire, même si le nom d'utilisateur est oublié.",
        "Kinyarwanda": 'Koresha sisitemu nyamukuru urufunguzo rwo kugarura ibyangombwa bya konte nyirizina, nubwo izina ryukoresha ryibagiwe.'
    },
    'Used to calculate due dates automatically.': {
        "French": "Utilisé pour calculer les dates d'échéance automatiquement.",
        "Kinyarwanda": 'Byifashishwa mu kubara amatariki yo kugarura byikora.'
    },
    'User': {
        "French": 'Utilisateur',
        "Kinyarwanda": 'Umukoresha'
    },
    'User Analytics': {
        "French": 'Analyses des utilisateurs',
        "Kinyarwanda": "Isesengura ry'Abakoresha"
    },
    'Username': {
        "French": "Nom d'utilisateur",
        "Kinyarwanda": "Izina ry'ukoresha"
    },
    'Verify': {
        "French": 'Vérifier',
        "Kinyarwanda": 'Emeza'
    },
    'Verify Answers': {
        "French": 'Vérifier les réponses',
        "Kinyarwanda": 'Emeza Ibisubizo'
    },
    'View Class List': {
        "French": 'Afficher la liste des cours',
        "Kinyarwanda": 'Reba Urutonde'
    },
    'Wait time after 3 failed login attempts.': {
        "French": "Temps d'attente après 3 tentatives de connexion échouées.",
        "Kinyarwanda": "Tegereza nyuma y'inshuro 3 zikiramiranwa."
    },
    'Warning:': {
        "French": 'Avertissement :',
        "Kinyarwanda": 'Iburira:'
    },
    'We will email your username and a temporary recovery password. Your current password is not changed unless you finish the reset screen.': {
        "French": "Nous vous enverrons par e-mail votre nom d'utilisateur et un mot de passe de récupération temporaire. Votre mot de passe actuel n'est pas modifié tant que vous n'avez pas terminé l'écran de réinitialisation.",
        "Kinyarwanda": 'Tuzohereza imeri yawe ukoresha nijambo ryibanga ryigihe gito. Ijambobanga ryubu ntabwo ryahinduwe keretse urangije gusubiramo ecran.'
    },
    'We will send a unique recovery password to your registered email.': {
        "French": 'Nous enverrons un mot de passe de récupération unique à votre adresse e-mail.',
        "Kinyarwanda": "Tuzohereza ijambo ry'ibanga ryo kugarura kuri imeri yawe."
    },
    'Week': {
        "French": 'Semaine',
        "Kinyarwanda": 'Icyumweru'
    },
    'Weekly': {
        "French": 'Hebdomadaire',
        "Kinyarwanda": 'Buri Cyumweru'
    },
    'Welcome back to your dashboard.': {
        "French": 'Bienvenue sur votre tableau de bord.',
        "Kinyarwanda": "Ikaze ku rubuga rwawe rw'ibanze."
    },
    'Wipe Database': {
        "French": 'Effacer la base de données',
        "Kinyarwanda": "Siba Ububiko bw'Amakuru"
    },
    'Wiping...': {
        "French": 'Effacement...',
        "Kinyarwanda": 'Gusiba...'
    },
    'Year': {
        "French": 'Année',
        "Kinyarwanda": 'Umwaka'
    },
    'Yes, Resolved': {
        "French": 'Oui, résolu',
        "Kinyarwanda": 'Yego, Byakemutse'
    },
    'You are about to clear all system activity logs. This action is irreversible. Please verify your identity to continue.': {
        "French": "Vous êtes sur le point d'effacer tous les journaux d'activité du système. Cette action est irréversible. Veuillez vérifier votre identité pour continuer.",
        "Kinyarwanda": "Ugiye gukuraho ibikorwa byose bya sisitemu y'ibikorwa. Iki gikorwa ntigisubirwaho. Nyamuneka reba umwirondoro wawe kugirango ukomeze."
    },
    'ZIP': {
        "French": 'ZIP',
        "Kinyarwanda": 'ZIP'
    },
    'and': {
        "French": 'et',
        "Kinyarwanda": 'na'
    },
    "and connect from other devices using this computer's network IP address.": {
        "French": "et connectez-vous depuis d'autres appareils en utilisant l'adresse IP réseau de cet ordinateur.",
        "Kinyarwanda": "kandi winjire uvuye mu bindi bikoresho ukoresheje aderesi IP y'uru rusobe rwa mudasobwa."
    },
    'delete your Admin accounts or School Configuration. Use this to clear fake testing data before launching.': {
        "French": "supprimer vos comptes d'administration ou la configuration de l'école. Utilisez ceci pour effacer les fausses données de test avant le lancement.",
        "Kinyarwanda": "siba konti zawe z'umuyobozi cyangwa Igenamiterere ry'Ishuri. Koresha ibi kugira ngo usibe amakuru y'ibizamini mbere yo gutangira."
    },
    'html': {
        "French": 'HTML',
        "Kinyarwanda": 'html'
    },
    'nexa.labs.0@gmail.com': {
        "French": 'nexa.labs.0@gmail.com',
        "Kinyarwanda": 'nexa.ibisobanuro.0@gmail.com'
    },
    'not': {
        "French": 'pas',
        "Kinyarwanda": 'oya'
    },
    'page to connect.': {
        "French": 'page pour se connecter.',
        "Kinyarwanda": 'urupapuro rwo guhuza.'
    },
    'paired, reconnecting…': {
        "French": 'jumelé, reconnecté…',
        "Kinyarwanda": 'byombi, guhuza…'
    },
    'seconds': {
        "French": 'secondes',
        "Kinyarwanda": 'amasegonda'
    },
    'so phones, tablets, and other PCs on the same network can sign in.': {
        "French": 'afin que les téléphones, tablettes et autres PC connectés au même réseau puissent se connecter.',
        "Kinyarwanda": 'terefone rero, tableti, nizindi PC kumurongo umwe urashobora kwinjira.'
    },
    'the app stays connected automatically.             You only need to enter the PIN again if the Major PC disconnects you.': {
        "French": "l'application reste connectée automatiquement.             Vous n'aurez besoin de saisir à nouveau le code PIN que si le Major PC vous déconnecte.",
        "Kinyarwanda": 'porogaramu iguma ihujwe mu buryo bwikora.             Ukeneye gusa kwinjira muri PIN niba PC nkuru iguhagaritse.'
    },
    'will be removed.': {
        "French": 'sera supprimé.',
        "Kinyarwanda": 'Bizakurwaho.'
    },
    '© 2026 Smart Library': {
        "French": '© 2026 Bibliothèque intelligente',
        "Kinyarwanda": '© 2026 Isomero ryubwenge'
    },
    'TextBee SMS Integration': {
        "French": 'Intégration SMS TextBee',
        "Kinyarwanda": 'Guhuza Ubutumwa bwa TextBee'
    },
    'Connect your TextBee app to send SMS notifications to parents.': {
        "French": 'Connectez votre application TextBee pour envoyer des notifications SMS aux parents.',
        "Kinyarwanda": 'Huza porogaramu yawe ya TextBee kugirango wohereze ababyeyi ubutumwa.'
    },
    'Configure TextBee': {
        "French": 'Configurer TextBee',
        "Kinyarwanda": 'Gushiraho TextBee'
    },
    'TextBee SMS Setup': {
        "French": 'Configuration SMS TextBee',
        "Kinyarwanda": 'Kugena Ubutumwa bwa TextBee'
    },
    'To use this feature, you must have the TextBee app installed on your Android device.': {
        "French": "Pour utiliser cette fonctionnalité, vous devez avoir installé l'application TextBee sur votre appareil Android.",
        "Kinyarwanda": 'Kugirango ukoreshe iyi mikorere, ugomba kuba ufite porogaramu ya TextBee kuri telefone yawe ya Android.'
    },
    'Learn how to set it up here.': {
        "French": 'Apprenez comment la configurer ici.',
        "Kinyarwanda": 'Iga uko wayishyiraho hano.'
    },
    'Device ID': {
        "French": "ID de l'appareil",
        "Kinyarwanda": 'Ikiranga Igikoresho'
    },
    'e.g. 64b81c2f9d3a1...': {
        "French": 'ex: 64b81c2f9d3a1...',
        "Kinyarwanda": 'urugero: 64b81c2f9d3a1...'
    },
    'API Key': {
        "French": 'Clé API',
        "Kinyarwanda": 'Urufunguzo rwa API'
    },
    'Your TextBee API Key': {
        "French": 'Votre clé API TextBee',
        "Kinyarwanda": 'Urufunguzo rwa API rwa TextBee yawe'
    },
    'Save Settings': {
        "French": 'Sauvegarder les paramètres',
        "Kinyarwanda": 'Bika Igenamiterere'
    },
    'Hello, this is the library. An issue was reported regarding the book': {
        "French": "Bonjour, c'est la bibliothèque. Un problème a été signalé concernant le livre",
        "Kinyarwanda": "Muraho, hano ni mu isomero. Ikibazo cyagaragajwe kubijyanye n'igitabo"
    },
    'borrowed by': {
        "French": 'emprunté par',
        "Kinyarwanda": 'cyatijwe'
    },
    'Please contact us for more details.': {
        "French": 'Veuillez nous contacter pour plus de détails.',
        "Kinyarwanda": 'Nyamuneka twandikire kugirango umenye byinshi.'
    },
    'Send SMS Notification to Parent': {
        "French": 'Envoyer une notification SMS au parent',
        "Kinyarwanda": 'Ohereza umubyeyi ubutumwa bugufi'
    },
    'Configure TextBee SMS in your profile': {
        "French": 'Configurez les SMS TextBee dans votre profil',
        "Kinyarwanda": 'Shiraho ubutumwa bwa TextBee muri profayili yawe'
    },
    "Parent's Phone Number": {
        "French": 'Numéro de téléphone du parent',
        "Kinyarwanda": "Nomero ya telefone y'umubyeyi"
    },
    'e.g. +25078...': {
        "French": 'ex: +25078...',
        "Kinyarwanda": 'urugero: +25078...'
    },
    'Message Body': {
        "French": 'Corps du message',
        "Kinyarwanda": 'Ubutumwa nyirizina'
    },
    'Connecting…': {
        "French": 'Connexion...',
        "Kinyarwanda": 'Kwinjira...'
    },
    'Unknown': {
        "French": 'Inconnu',
        "Kinyarwanda": 'Ntabizwi'
    },
    'Failed to load librarians.': {
        "French": 'Échec du chargement des bibliothécaires.',
        "Kinyarwanda": "Byanze kuzana abakozi b'isomero."
    },
    'Main Admin': {
        "French": 'Administrateur Principal',
        "Kinyarwanda": 'Umuyobozi Mukuru'
    },
    'Joined:': {
        "French": 'Rejoint :',
        "Kinyarwanda": 'Yinjiye :'
    },
    'Revoke Access': {
        "French": "Révoquer l'accès",
        "Kinyarwanda": 'Kuvana Uburenganzira'
    },
    "Revoke this device's session? They will need to re-enter a PIN.": {
        "French": 'Révoquer la session de cet appareil ? Ils devront saisir à nouveau un code PIN.',
        "Kinyarwanda": "Kuvana session y'iyi mashini? Bazakenera kongera kwinjiza PIN."
    },
    'Are you sure you want to revoke online access for this librarian?': {
        "French": "Êtes-vous sûr de vouloir révoquer l'accès en ligne de ce bibliothécaire ?",
        "Kinyarwanda": "Uzi neza ko ushaka kuvanaho uburenganzira bwo gukoresha internet kuri uyu mukozi w'isomero?"
    },
    'Access revoked.': {
        "French": 'Accès révoqué.',
        "Kinyarwanda": 'Uburenganzira bwavanyweho.'
    },
    'Current Filter:': {
        "French": 'Filtre Actuel:',
        "Kinyarwanda": 'Ikinyuzeho Ubu:'
    },
    'Server started. Waiting for Child PC...': {
        "French": 'Serveur démarré. En attente du PC enfant...',
        "Kinyarwanda": 'Server yatangiye. Itgereje Mudasobwa Ntoya...'
    },
    'Server stopped.': {
        "French": 'Serveur arrêté.',
        "Kinyarwanda": 'Server yahagaze.'
    },
    'Status reset. Ready for next sync.': {
        "French": 'Statut réinitialisé. Prêt pour la prochaine synchronisation.',
        "Kinyarwanda": 'Statut yasubiwemo. Yiteguye guhuza ubutaha.'
    },
    'Child PC connected. Verifying PIN...': {
        "French": 'PC enfant connecté. Vérification du code PIN...',
        "Kinyarwanda": 'Mudasobwa Ntoya yinjiye. Kureba PIN...'
    },
    'Authenticated. Applying changes...': {
        "French": 'Authentifié. Application des modifications...',
        "Kinyarwanda": 'Yemejwe. Gushyira mu bikorwa impinduka...'
    },
    'Sync complete!': {
        "French": 'Synchronisation terminée !',
        "Kinyarwanda": 'Guhuza byarangiye !'
    },
    'Authenticating': {
        "French": 'Authentification',
        "Kinyarwanda": 'Kwinjira'
    },
    'Error:': {
        "French": 'Erreur:',
        "Kinyarwanda": 'Ikosa:'
    },
    'Checking Cloud...': {
        "French": 'Vérification du Cloud...',
        "Kinyarwanda": 'Kureba Cloud...'
    },
    'Checking LAN...': {
        "French": 'Vérification du LAN...',
        "Kinyarwanda": 'Kureba LAN...'
    },
    'Cloud Online': {
        "French": 'Cloud En Ligne',
        "Kinyarwanda": 'Cloud Ikoraho'
    },
    'Synced:': {
        "French": 'Synchronisé:',
        "Kinyarwanda": 'Byahujwe:'
    },
    'Never': {
        "French": 'Jamais',
        "Kinyarwanda": 'Nta na rimwe'
    },
    'Pending': {
        "French": 'En attente',
        "Kinyarwanda": 'Bitegereje'
    },
    'Cloud Offline / Unconfigured': {
        "French": 'Cloud Hors Ligne / Non Configuré',
        "Kinyarwanda": 'Cloud Ntihari / Ntabwo Yateguwe'
    },
    'LAN Active': {
        "French": 'LAN Actif',
        "Kinyarwanda": 'LAN Ikoraho'
    },
    'Minor': {
        "French": 'Mineur',
        "Kinyarwanda": 'Ntoya'
    },
    'Major': {
        "French": 'Majeur',
        "Kinyarwanda": 'Nkuru'
    },
    'peers': {
        "French": 'pairs',
        "Kinyarwanda": 'mudasobwa zindi'
    },
    'LAN Disconnected': {
        "French": 'LAN Déconnecté',
        "Kinyarwanda": 'LAN Yacitse'
    },
    'Manage Sync': {
        "French": 'Gérer la Synchronisation',
        "Kinyarwanda": 'Cunga Ibihuzwa'
    },
    'Connected Major Server': {
        "French": 'Serveur Majeur Connecté',
        "Kinyarwanda": 'Mudasobwa Nkuru Yihuijwe'
    },
    'Connected to Major PC at': {
        "French": 'Connecté au PC Majeur à',
        "Kinyarwanda": 'Yihujwe na Mudasobwa Nkuru kuri'
    },
    'Live synchronization is active.': {
        "French": 'La synchronisation en direct est active.',
        "Kinyarwanda": 'Guhuza imbonankubone birakora.'
    },
    'Paired with': {
        "French": 'Jumelé avec',
        "Kinyarwanda": 'Yabikanijwe na'
    },
    ', but the live sync link is reconnecting.': {
        "French": ', mais le lien de synchronisation se reconnecte.',
        "Kinyarwanda": ', ariko ihuza riri kongera gushaka inzira.'
    },
    'Not connected to a Major Server.': {
        "French": 'Non connecté à un Serveur Majeur.',
        "Kinyarwanda": 'Ntabwo yihujwe na Mudasobwa Nkuru.'
    },
    'The Major Sync server runs independently in the background on port 9000. It is currently active and listening for Minor PCs.': {
        "French": 'Le serveur de synchronisation Majeur fonctionne indépendamment en arrière-plan. Il est actif et écoute les PC mineurs.',
        "Kinyarwanda": 'Mudasobwa nkuru irikwikoresha inyuma. Ubu irakora kandi itegereje mudasobwa ntoya.'
    },
    'LAN Sync Diagnostics': {
        "French": 'Diagnostics de Synchro LAN',
        "Kinyarwanda": 'Isuzuma rya LAN Sync'
    },
    'Conflicts': {
        "French": 'Conflits',
        "Kinyarwanda": 'Ibigongana'
    },
    'Refresh Data': {
        "French": 'Actualiser',
        "Kinyarwanda": 'Vugurura Amakuru'
    },
    'Back to Peers': {
        "French": 'Retour aux Pairs',
        "Kinyarwanda": 'Sohoka usubire inyuma'
    },
    'Engine Status:': {
        "French": 'Statut du Moteur:',
        "Kinyarwanda": 'Uko Imashini Ihagaze:'
    },
    'Live Syncing': {
        "French": 'Synchronisation en Direct',
        "Kinyarwanda": 'Guhuza Imbonankubone'
    },
    'Idle / Disconnected': {
        "French": 'Inactif / Déconnecté',
        "Kinyarwanda": 'Ntikora / Yacitse'
    },
    'Last Update:': {
        "French": 'Dernière Mise à Jour:',
        "Kinyarwanda": 'Iheruka Kuvugururwa:'
    },
    'No recent sync': {
        "French": 'Aucune synchro récente',
        "Kinyarwanda": 'Nta guhuza gushya'
    },
    'Role:': {
        "French": 'Rôle:',
        "Kinyarwanda": 'Uruhare:'
    },
    'Unconfigured': {
        "French": 'Non Configuré',
        "Kinyarwanda": 'Ntabwo Yateguwe'
    },
    'Pending Batches': {
        "French": 'Lots en attente',
        "Kinyarwanda": 'Amakuru Ategereje'
    },
    'Waiting to be pushed to the Minor PC.': {
        "French": "En attente d'envoi vers le PC Mineur.",
        "Kinyarwanda": 'Itegereje koherezwa kuri Mudasobwa Ntoya.'
    },
    'Waiting to be pushed to the Major PC.': {
        "French": "En attente d'envoi vers le PC Majeur.",
        "Kinyarwanda": 'Itegereje koherezwa kuri Mudasobwa Nkuru.'
    },
    'Failed Transfers': {
        "French": 'Transferts Échoués',
        "Kinyarwanda": 'Ibyanze Koherezwa'
    },
    'Exceeded 15 retry attempts.': {
        "French": 'Dépasse 15 tentatives.',
        "Kinyarwanda": 'Yarengeje inshuro 15 zo kugerageza.'
    },
    'Retry Failed Items': {
        "French": 'Réessayer les Échecs',
        "Kinyarwanda": 'Ongera Ugerageze Ibyanze'
    },
    'Delivered Successfully': {
        "French": 'Livré avec Succès',
        "Kinyarwanda": 'Byoherejwe Neza'
    },
    'Records successfully verified by the Minor PC.': {
        "French": 'Enregistrements vérifiés par le PC Mineur.',
        "Kinyarwanda": 'Amakuru yemejwe na Mudasobwa Ntoya.'
    },
    'Records successfully verified by the Major PC.': {
        "French": 'Enregistrements vérifiés par le PC Majeur.',
        "Kinyarwanda": 'Amakuru yemejwe na Mudasobwa Nkuru.'
    },
    'Recent Queue Activity': {
        "French": 'Activité Récente de la File',
        "Kinyarwanda": 'Ibiherutse Gukorwa'
    },
    'Time': {
        "French": 'Heure',
        "Kinyarwanda": 'Igihe'
    },
    'Table': {
        "French": 'Tableau',
        "Kinyarwanda": 'Imbonerahamwe'
    },
    'Action': {
        "French": 'Action',
        "Kinyarwanda": 'Igikorwa'
    },
    'Status': {
        "French": 'Statut',
        "Kinyarwanda": 'Imiterere'
    },
    'Retries': {
        "French": 'Tentatives',
        "Kinyarwanda": 'Kugerageza'
    },
    'Delivered': {
        "French": 'Livré',
        "Kinyarwanda": 'Byoherejwe'
    },
    'Failed': {
        "French": 'Échoué',
        "Kinyarwanda": 'Byanze'
    },
    'No sync activity recorded yet.': {
        "French": 'Aucune activité de synchro.',
        "Kinyarwanda": 'Nta gikorwa cyo guhuza kirakorwa.'
    },
    'Select a Conflict to Resolve': {
        "French": 'Sélectionnez un Conflit',
        "Kinyarwanda": 'Hitamo Ikigongana ngo Ugikemure'
    },
    'Loading conflicts...': {
        "French": 'Chargement des conflits...',
        "Kinyarwanda": 'Gufungura ibigongana...'
    },
    'Detected:': {
        "French": 'Détecté:',
        "Kinyarwanda": 'Cyabonetse:'
    },
    'Review & Resolve': {
        "French": 'Examiner et Résoudre',
        "Kinyarwanda": 'Reba Kandi Ukemure'
    },
    'No pending conflicts! Everything is synchronized.': {
        "French": 'Aucun conflit! Tout est synchronisé.',
        "Kinyarwanda": 'Nta bigongana bihari! Byose byahujwe neza.'
    },
    'Resolve LAN Sync Conflict': {
        "French": 'Résoudre le Conflit LAN',
        "Kinyarwanda": 'Kemura Ikigongana cya LAN'
    },
    'A record was edited on both PCs at the same time. Choose which version to keep.': {
        "French": 'Modifié sur les deux PC. Choisissez la version à garder.',
        "Kinyarwanda": 'Byahinduwe kuri mudasobwa zombi. Hitamo ibyo ugumana.'
    },
    "This PC's Version (Local)": {
        "French": 'Version de ce PC (Local)',
        "Kinyarwanda": "Iby'iyi Mudasobwa"
    },
    "Other PC's Version (Remote)": {
        "French": "Version de l'autre PC (Distant)",
        "Kinyarwanda": "Iby'indi Mudasobwa"
    },
    'Custom Merge (Optional)': {
        "French": 'Fusion Personnalisée',
        "Kinyarwanda": 'Kuvanga Ku bushake'
    },
    'Edit JSON here if you want to merge values manually': {
        "French": 'Modifiez le JSON pour fusionner manuellement',
        "Kinyarwanda": 'Hindura JSON hano niba ushaka kubivanga'
    },
    "Keep This PC's Data": {
        "French": 'Garder les Données Locales',
        "Kinyarwanda": "Gumana iby'iyi Mudasobwa"
    },
    "Keep Other PC's Data": {
        "French": 'Garder les Données Distantes',
        "Kinyarwanda": "Gumana iby'indi Mudasobwa"
    },
    'Save Merged JSON': {
        "French": 'Enregistrer la Fusion',
        "Kinyarwanda": 'Bika Ibyavanzwe'
    },
    'Cloud Sync Queue': {
        "French": 'File de Synchro Cloud',
        "Kinyarwanda": 'Umurongo wo Guhuza Cloud'
    },
    'Operation': {
        "French": 'Opération',
        "Kinyarwanda": 'Igikorwa'
    },
    'Target': {
        "French": 'Cible',
        "Kinyarwanda": 'Abo Bireba'
    },
    'Record ID': {
        "French": 'ID Enregistrement',
        "Kinyarwanda": "Numero y'Icyakozwe"
    },
    'Attempts': {
        "French": 'Tentatives',
        "Kinyarwanda": 'Inshuro'
    },
    'Synced': {
        "French": 'Synchronisé',
        "Kinyarwanda": 'Byahujwe'
    },
    'Conflict': {
        "French": 'Conflit',
        "Kinyarwanda": 'Ikigongana'
    },
    'Queue empty.': {
        "French": 'File vide.',
        "Kinyarwanda": 'Nta biri ku murongo.'
    },
    'Warning: %(count)d column(s) without headers (%(cols)s) were skipped.': {
        "French": 'Attention : %(count)d colonne(s) sans en-tête (%(cols)s) ont été ignorées.',
        "Kinyarwanda": 'Iburira: Inkingi %(count)d zidafite umutwe (%(cols)s) zasinzwe.'
    },
    "Duplicate blocked: A student named '%(name)s' already exists in class '%(cls)s'.": {
        "French": "Doublon bloqué : Un étudiant nommé '%(name)s' existe déjà dans la classe '%(cls)s'.",
        "Kinyarwanda": "Gusubiramo byahagaritswe: Umunyeshuri witwa '%(name)s' asanzwe mu ishuri '%(cls)s'."
    },
    'Maximum of 5 custom columns allowed.': {
        "French": 'Maximum de 5 colonnes personnalisées autorisées.',
        "Kinyarwanda": 'Inkingi 5 zihariye nizo ntarengwa zemewe.'
    },
    'Important: For class group loans, this repair fee applies once to the entire class loan batch—it is not multiplied per responsible student.': {
        "French": "Important : Pour les prêts de classe, ces frais de réparation s'appliquent une seule fois à tout le lot du prêt de classe — ils ne sont pas multipliés par étudiant responsable.",
        "Kinyarwanda": "Icyitonderwa: Ku nguzanyo z'ishuri ryose, aya mafaranga yo gusana abarwa rimwe gusa ku gitabo cyose cy'ishuri—ntabwo akubwa kuri buri munyeshuri ubishinzwe."
    },
    'Important: For class group loans, this repair fee applies once to the entire class loan batch-it is not multiplied per responsible student.': {
        "French": "Important : Pour les prêts de classe, ces frais de réparation s'appliquent une seule fois à tout le lot du prêt de classe — ils ne sont pas multipliés par étudiant responsable.",
        "Kinyarwanda": "Icyitonderwa: Ku nguzanyo z'ishuri ryose, aya mafaranga yo gusana abarwa rimwe gusa ku gitabo cyose cy'ishuri—ntabwo akubwa kuri buri munyeshuri ubishinzwe."
    },
    '1. Resolved Book IDs (Optional)': {
        "French": '1. IDs de livres résolus (Facultatif)',
        "Kinyarwanda": "1. Nimero z'ibitabo byakemuwe (Si ngombwa)"
    },
    '2. Money Used for Fixing (Optional)': {
        "French": '2. Montant utilisé pour la réparation (Facultatif)',
        "Kinyarwanda": '2. Amafaranga yakoreshejwe mu gusana (Si ngombwa)'
    },
    '3. Mark Students as Resolved': {
        "French": '3. Marquer les étudiants comme résolus',
        "Kinyarwanda": '3. Emeza abanyeshuri bakemuye ikibazo'
    },
    'Accept Remote Version': {
        "French": 'Accepter la version distante',
        "Kinyarwanda": "Emeza iby'indi mudasobwa"
    },
    'Account Password': {
        "French": 'Mot de passe du compte',
        "Kinyarwanda": "Ijambo ry'ibanga rya konti"
    },
    'Add New Column': {
        "French": 'Ajouter une nouvelle colonne',
        "Kinyarwanda": 'Ongeraho inkingi nshya'
    },
    'Administrator Password': {
        "French": 'Mot de passe administrateur',
        "Kinyarwanda": "Ijambo ry'ibanga ry'umuyobozi"
    },
    'All': {
        "French": 'Tout',
        "Kinyarwanda": 'Byose'
    },
    'All Classes': {
        "French": 'Toutes les classes',
        "Kinyarwanda": 'Amashuri yose'
    },
    'All Clear!': {
        "French": 'Tout est en ordre !',
        "Kinyarwanda": 'Byose bimeze neza!'
    },
    'All Data Types': {
        "French": 'Tous les types de données',
        "Kinyarwanda": "Ubwoko bwose bw'amakuru"
    },
    'All Sources': {
        "French": 'Toutes les sources',
        "Kinyarwanda": 'Inkomoko zose'
    },
    'All selected students will be moved to this class. No spaces allowed.': {
        "French": 'Tous les étudiants sélectionnés seront déplacés dans cette classe. Aucun espace autorisé.',
        "Kinyarwanda": 'Abanyeshuri bose bahiswemo bazimurirwa muri iri shuri. Nta mwanya wemewe.'
    },
    'All system functions have been temporarily frozen. Please contact platform support immediately.': {
        "French": 'Toutes les fonctions du système ont été temporairement gelées. Veuillez contacter immédiatement le support.',
        "Kinyarwanda": "Ibikorwa byose bya sisitemu byahagaritswe by'agateganyo. Nyamuneka vugisha ubufasha ako kanya."
    },
    'An unexpected error occurred.': {
        "French": "Une erreur inattendue s'est produite.",
        "Kinyarwanda": 'Habayeho ikosa ritunguranye.'
    },
    'Apply & Restart Now': {
        "French": 'Appliquer et redémarrer maintenant',
        "Kinyarwanda": 'Shyiraho kandi utangire bundi bushya'
    },
    'Are you sure you want to delete all selected students?': {
        "French": 'Êtes-vous sûr de vouloir supprimer tous les étudiants sélectionnés ?',
        "Kinyarwanda": 'Uremeza ko ushaka gusiba abanyeshuri bose bahiswemo?'
    },
    'Assign To': {
        "French": 'Attribuer à',
        "Kinyarwanda": 'Bireba'
    },
    'Assign to New Class': {
        "French": 'Affecter à une nouvelle classe',
        "Kinyarwanda": 'Shyira mu ishuri rishya'
    },
    'At least 8 characters': {
        "French": 'Au moins 8 caractères',
        "Kinyarwanda": 'Byibura inyuguti 8'
    },
    'Auto-detect via broadcast': {
        "French": 'Détection automatique par diffusion',
        "Kinyarwanda": 'Gushakisha byikora kuri rezo'
    },
    'Auto-reconnect without OTP': {
        "French": 'Reconnexion automatique sans code PIN',
        "Kinyarwanda": 'Kwihuza byikora hatarinze PIN'
    },
    'Automated parent notifications': {
        "French": 'Notifications automatisées aux parents',
        "Kinyarwanda": 'Ubutumwa bwikora ku babyeyi'
    },
    'Available Subset': {
        "French": 'Sous-ensemble disponible',
        "Kinyarwanda": 'Ibitabo biboneka'
    },
    'Back': {
        "French": 'Retour',
        "Kinyarwanda": 'Subira inyuma'
    },
    'Back to Settings': {
        "French": 'Retour aux paramètres',
        "Kinyarwanda": 'Subira ku igenamiterere'
    },
    'Back to Sync Dashboard': {
        "French": 'Retour au tableau de synchronisation',
        "Kinyarwanda": 'Subira ku rubuga rwo guhuza'
    },
    'Backup Emails (Optional)': {
        "French": 'E-mails de secours (Facultatif)',
        "Kinyarwanda": 'Imeyili zo kugarura konti (Si ngombwa)'
    },
    'Base ID, Unique ID(s), and Title are required.': {
        "French": "L'ID de base, les ID uniques et le titre sont obligatoires.",
        "Kinyarwanda": "ID y'ibanze, nimero zihariye n'umutwe birakenewe."
    },
    'Book ID, Title, Author': {
        "French": 'ID du livre, Titre, Auteur',
        "Kinyarwanda": "ID y'igitabo, Umutwe, Umwanditsi"
    },
    'Book Issues Financials': {
        "French": 'Finances des incidents de livres',
        "Kinyarwanda": "Imari y'ibibazo by'ibitabo"
    },
    'Books': {
        "French": 'Livres',
        "Kinyarwanda": 'Ibitabo'
    },
    'Bulk Change Class': {
        "French": 'Changement de classe en masse',
        "Kinyarwanda": 'Guhindura ishuri ku bwinshi'
    },
    'Cancel Import': {
        "French": "Annuler l'importation",
        "Kinyarwanda": 'Hagarika kwinjiza'
    },
    'Category (Optional)': {
        "French": 'Catégorie (Facultatif)',
        "Kinyarwanda": 'Icyiciro (Si ngombwa)'
    },
    'Change Class': {
        "French": 'Changer de classe',
        "Kinyarwanda": 'Hindura ishuri'
    },
    'Choose a username': {
        "French": "Choisissez un nom d'utilisateur",
        "Kinyarwanda": 'Hitamo izina ukoresha'
    },
    'Choose how you want to proceed.': {
        "French": 'Choisissez comment vous souhaitez continuer.',
        "Kinyarwanda": 'Hitamo uburyo ushaka gukomeza.'
    },
    'Class Issues': {
        "French": 'Incidents de classe',
        "Kinyarwanda": "Ibibazo by'amashuri"
    },
    'Class:': {
        "French": 'Classe :',
        "Kinyarwanda": 'Ishuri:'
    },
    'Client Device (Active)': {
        "French": 'Appareil client (Actif)',
        "Kinyarwanda": "Mudasobwa y'umukiriya (Irakora)"
    },
    'Cloud Conflicts Only': {
        "French": 'Conflits Cloud uniquement',
        "Kinyarwanda": 'Ibigongana bya Cloud gusa'
    },
    'Cloud Offline': {
        "French": 'Cloud hors ligne',
        "Kinyarwanda": 'Cloud ntiri ku murongo'
    },
    'Cloud Sync Setup': {
        "French": 'Configuration de la synchro Cloud',
        "Kinyarwanda": 'Gutegura guhuza na Cloud'
    },
    'Cloud Sync Status': {
        "French": 'État de la synchro Cloud',
        "Kinyarwanda": 'Imiterere yo guhuza na Cloud'
    },
    'Columns': {
        "French": 'Colonnes',
        "Kinyarwanda": 'Inkingi'
    },
    'Columns updated successfully.': {
        "French": 'Colonnes mises à jour avec succès.',
        "Kinyarwanda": 'Inkingi zavuguruwe neza.'
    },
    'Configure': {
        "French": 'Configurer',
        "Kinyarwanda": 'Tegura'
    },
    'Configure local offline connections': {
        "French": 'Configurer les connexions locales hors ligne',
        "Kinyarwanda": 'Tegura ihuza rya hafi nta internet'
    },
    'Configured': {
        "French": 'Configuré',
        "Kinyarwanda": 'Byateguwe'
    },
    'Confirm Identity': {
        "French": "Confirmer l'identité",
        "Kinyarwanda": 'Emeza umwirondoro'
    },
    'Confirm Reset': {
        "French": 'Confirmer la réinitialisation',
        "Kinyarwanda": 'Emeza gusiba byose'
    },
    'Confirm Resolve': {
        "French": 'Confirmer la résolution',
        "Kinyarwanda": 'Emeza ikemurwa'
    },
    'Conflict Resolution Center': {
        "French": 'Centre de résolution des conflits',
        "Kinyarwanda": 'Ikigo gikemura ibigongana'
    },
    'Connect to an already established school online and download their database.': {
        "French": 'Connectez-vous à une école déjà créée en ligne et téléchargez sa base de données.',
        "Kinyarwanda": "Huza n'ishuri risanzwe kuri internet maze ukurure amakuru yaryo."
    },
    'Connect to centralized database': {
        "French": 'Se connecter à la base de données centralisée',
        "Kinyarwanda": "Huza n'ububiko rusange kuri internet"
    },
    'Connected Minor PCs': {
        "French": 'PC secondaires connectés',
        "Kinyarwanda": 'Mudasobwa nto zihujwe'
    },
    'Connected Online Librarians': {
        "French": 'Bibliothécaires en ligne connectés',
        "Kinyarwanda": "Abakozi b'isomero bahujwe kuri internet"
    },
    'Connected to an online school.': {
        "French": 'Connecté à une école en ligne.',
        "Kinyarwanda": "Uhujwe n'ishuri riri kuri internet."
    },
    'Connecting to Supabase...': {
        "French": 'Connexion à Supabase...',
        "Kinyarwanda": 'Birimo kwihuza na Supabase...'
    },
    'Connecting...': {
        "French": 'Connexion...',
        "Kinyarwanda": 'Birimo kwihuza...'
    },
    'Connectivity & Integrations': {
        "French": 'Connectivité et intégrations',
        "Kinyarwanda": "Ihuza n'imikoranire"
    },
    'Connectivity & Sync': {
        "French": 'Connectivité et synchronisation',
        "Kinyarwanda": 'Ihuza no gusangira amakuru'
    },
    'Connectivity & Synchronization': {
        "French": 'Connectivité et synchronisation',
        "Kinyarwanda": 'Ihuza no gusangira amakuru'
    },
    'Connects to the Main Server.': {
        "French": 'Se connecte au serveur principal.',
        "Kinyarwanda": 'Yihuza na seriveri nkuru.'
    },
    'Copy ID': {
        "French": "ID de l'exemplaire",
        "Kinyarwanda": "ID y'igitabo"
    },
    'Cost:': {
        "French": 'Coût :',
        "Kinyarwanda": 'Ikiguzi:'
    },
    'Create & Setup Sync': {
        "French": 'Créer et configurer la synchro',
        "Kinyarwanda": 'Kora kandi utegure guhuza'
    },
    'Create Account': {
        "French": 'Créer un compte',
        "Kinyarwanda": 'Fungura konti'
    },
    'Create New Online School': {
        "French": 'Créer une nouvelle école en ligne',
        "Kinyarwanda": 'Fungura ishuri rishya kuri internet'
    },
    'Create Profile': {
        "French": 'Créer un profil',
        "Kinyarwanda": 'Kora umwirondoro'
    },
    'Create a new school profile online. You will be the main administrator.': {
        "French": "Créez un nouveau profil d'école en ligne. Vous serez l'administrateur principal.",
        "Kinyarwanda": "Fungura umwirondoro w'ishuri rishya kuri internet. Uzaba umuyobozi mukuru."
    },
    'Creating local environment...': {
        "French": "Création de l'environnement local...",
        "Kinyarwanda": 'Birimo gutegura sisitemu...'
    },
    'Danger Zone': {
        "French": 'Zone de danger',
        "Kinyarwanda": "Agace k'ibikorwa bikomeye"
    },
    'Database Download Required': {
        "French": 'Téléchargement de la base de données requis',
        "Kinyarwanda": "Gukurura ububiko bw'amakuru birakenewe"
    },
    'Default fields (ID, Title, Author) are locked to ensure the library system functions correctly.': {
        "French": 'Les champs par défaut (ID, Titre, Auteur) sont verrouillés pour assurer le bon fonctionnement du système.',
        "Kinyarwanda": "Imyanya y'ibanze (ID, Umutwe, Umwanditsi) ifunze kugirango sisitemu ikore neza."
    },
    'Do not show this again': {
        "French": 'Ne plus afficher ceci',
        "Kinyarwanda": 'Ntuzongere kwerekana ibi'
    },
    'Download Database Now': {
        "French": 'Télécharger la base de données maintenant',
        "Kinyarwanda": "Kurura ububiko bw'amakuru ubu"
    },
    'Download failed:': {
        "French": 'Échec du téléchargement :',
        "Kinyarwanda": 'Gukurura byanze:'
    },
    'Download template': {
        "French": 'Télécharger le modèle',
        "Kinyarwanda": 'Kuramo icyitegererezo'
    },
    'EDRAZE brings order to chaos. It provides librarians with a unified, smart platform to catalogue knowledge, track circulation, and manage records instantly—leaving the paper logs behind so you can focus on education.': {
        "French": "EDRAZE met de l'ordre dans le chaos. Il offre aux bibliothécaires une plateforme unifiée et intelligente pour cataloguer, suivre les prêts et gérer les archives instantanément—laissant les registres papier derrière vous.",
        "Kinyarwanda": "EDRAZE izana gahunda mu isomero. Iha abakozi b'isomero urubuga ruhuriweho rwo kubarura ibitabo, gukurikirana itizwa, no gucunga inyandiko mu kanya gato—igasimbura ibitabo by'impapuro."
    },
    'Edit the Common ID Base or Unique IDs below (supports ranges like 1-50 and comma lists like 1, 3, 5). Save to register and continue.': {
        "French": "Modifiez l'ID de base ou les ID uniques ci-dessous (prend en charge les plages comme 1-50 et les listes comme 1, 3, 5). Enregistrez pour continuer.",
        "Kinyarwanda": "Hindura ID y'ibanze cyangwa nimero zihariye hasi (yemera nk'urugero 1-50 cyangwa 1, 3, 5). Bika kugirango ukomeze."
    },
    'Enter book title (auto-saves to catalog)': {
        "French": 'Entrez le titre du livre (enregistré automatiquement)',
        "Kinyarwanda": "Andika umutwe w'igitabo (cyibika mu bubiko)"
    },
    'Enter the exact school name': {
        "French": "Entrez le nom exact de l'école",
        "Kinyarwanda": "Andika izina nyaryo ry'ishuri"
    },
    'Entity Type': {
        "French": "Type d'entité",
        "Kinyarwanda": "Ubwoko bw'inyandiko"
    },
    'Error': {
        "French": 'Erreur',
        "Kinyarwanda": 'Ikosa'
    },
    'Factory Reset': {
        "French": "Réinitialisation d'usine",
        "Kinyarwanda": 'Gusubiza sisitemu ku ntangiriro'
    },
    'Fetching online librarians...': {
        "French": 'Chargement des bibliothécaires en ligne...',
        "Kinyarwanda": "Birimo gushaka abakozi b'isomero..."
    },
    'Filter:': {
        "French": 'Filtrer :',
        "Kinyarwanda": 'Shungura:'
    },
    'Flat View': {
        "French": 'Vue simple',
        "Kinyarwanda": 'Imbonerahamwe isanzwe'
    },
    'Generate a one-time PIN. Give it to the librarian on the other PC   they enter it in their Peers page to connect.': {
        "French": "Générez un code PIN à usage unique. Donnez-le au bibliothécaire sur l'autre PC pour qu'il se connecte depuis sa page Pairs.",
        "Kinyarwanda": "Kora kode ya PIN ikoreshwa rimwe. Yihere umukozi kuri mudasobwa yindi ayinjize kuri paji y'ihuza."
    },
    'Generated': {
        "French": 'Généré',
        "Kinyarwanda": 'Byakozwe'
    },
    'Get Started': {
        "French": 'Commencer',
        "Kinyarwanda": 'Tangira'
    },
    'Go to Welcome Page': {
        "French": "Aller à la page d'accueil",
        "Kinyarwanda": "Jya kuri paji y'ikaze"
    },
    'Hello, this is the library. An issue was reported regarding the book ...': {
        "French": 'Bonjour, ici la bibliothèque. Un incident a été signalé concernant le livre...',
        "Kinyarwanda": 'Muraho, hano ni mu isomero. Hagaragaye ikibazo ku gitabo...'
    },
    'How would you like to set up your library sync?': {
        "French": 'Comment souhaitez-vous configurer la synchronisation de votre bibliothèque ?',
        "Kinyarwanda": "Ni ubuhe buryo ushaka gutegura ihuza ry'isomero ryawe?"
    },
    'Identity Details': {
        "French": "Détails d'identité",
        "Kinyarwanda": "Amakuru y'umwirondoro"
    },
    'Idle': {
        "French": 'Inactif',
        "Kinyarwanda": 'Bituje'
    },
    'Import Class Loans': {
        "French": 'Importer les prêts de classe',
        "Kinyarwanda": "Injiza inguzanyo z'amashuri"
    },
    'Import Staff Loans': {
        "French": 'Importer les prêts du personnel',
        "Kinyarwanda": "Injiza inguzanyo z'abarimu"
    },
    'Import Student Loans': {
        "French": 'Importer les prêts des étudiants',
        "Kinyarwanda": "Injiza inguzanyo z'abanyeshuri"
    },
    'Incoming Remote Version': {
        "French": 'Version distante entrante',
        "Kinyarwanda": 'Ibyaje bivuye ku yindi mudasobwa'
    },
    'Internal Server Error': {
        "French": 'Erreur interne du serveur',
        "Kinyarwanda": "Ikosa ry'imbere muri seriveri"
    },
    'Invalid ID format.': {
        "French": "Format d'ID invalide.",
        "Kinyarwanda": 'Imiterere ya ID ntiyemewe.'
    },
    'Issue Available Subset': {
        "French": 'Prêter les exemplaires disponibles',
        "Kinyarwanda": 'Tiza ibitabo biboneka gusa'
    },
    'Join Existing': {
        "French": 'Rejoindre une école existante',
        "Kinyarwanda": 'Injira mu ishuri risanzwe'
    },
    'Join Request Update': {
        "French": "Mise à jour de la demande d'adhésion",
        "Kinyarwanda": 'Amakuru ku busabe bwo kwinjira'
    },
    'Join an Existing School': {
        "French": 'Rejoindre une école existante',
        "Kinyarwanda": 'Injira mu ishuri risanzwe'
    },
    'Keep Local Version': {
        "French": 'Conserver la version locale',
        "Kinyarwanda": "Gumana iby'iyi mudasobwa"
    },
    'LAN Conflicts Only': {
        "French": 'Conflits LAN uniquement',
        "Kinyarwanda": 'Ibigongana bya LAN gusa'
    },
    'LAN Network Setup': {
        "French": 'Configuration du réseau LAN',
        "Kinyarwanda": 'Gutegura rezo ya LAN'
    },
    'LAN Sync (Peers)': {
        "French": 'Synchro LAN (Pairs)',
        "Kinyarwanda": 'Guhuza kuri LAN'
    },
    'Last seen:': {
        "French": 'Dernière activité :',
        "Kinyarwanda": 'Igihe giheruka:'
    },
    'Library Analytics': {
        "French": 'Statistiques de la bibliothèque',
        "Kinyarwanda": "Imibare y'isomero"
    },
    'Library Management': {
        "French": 'Gestion de bibliothèque',
        "Kinyarwanda": "Imicungire y'isomero"
    },
    'Loading requests...': {
        "French": 'Chargement des demandes...',
        "Kinyarwanda": 'Birimo gutegura ubusabe...'
    },
    'Loans': {
        "French": 'Prêts',
        "Kinyarwanda": 'Inguzanyo'
    },
    'Local Database Version': {
        "French": 'Version locale de la base de données',
        "Kinyarwanda": "Iby'ububiko bw'iyi mudasobwa"
    },
    'Local Mode': {
        "French": 'Mode local',
        "Kinyarwanda": 'Uburyo bwo gukorera kuri mudasobwa gusa'
    },
    'Local Only': {
        "French": 'Local uniquement',
        "Kinyarwanda": 'Kuri mudasobwa gusa'
    },
    'Local mode enabled. You can always connect online later in Connectivity & Sync.': {
        "French": 'Mode local activé. Vous pourrez toujours vous connecter en ligne plus tard dans Connectivité et Synchronisation.',
        "Kinyarwanda": 'Uburyo bwa mudasobwa gusa bwakozwe. Ushobora kwihuza kuri internet nyuma mu Ihuza no Gusangira Amakuru.'
    },
    'Main Server (Active)': {
        "French": 'Serveur principal (Actif)',
        "Kinyarwanda": 'Seriveri nkuru (Irakora)'
    },
    'Manage': {
        "French": 'Gérer',
        "Kinyarwanda": 'Cunga'
    },
    'Manage Book Columns': {
        "French": 'Gérer les colonnes des livres',
        "Kinyarwanda": "Cunga inkingi z'ibitabo"
    },
    'Manage how your library communicates. Connect multiple computers in the same building without internet using <strong>LAN Sync</strong>, or enable <strong>Cloud Sync</strong> to securely back up data online.': {
        "French": 'Gérez la communication de votre bibliothèque. Connectez plusieurs ordinateurs sans internet via <strong>Synchro LAN</strong>, ou activez <strong>Synchro Cloud</strong> pour sauvegarder vos données en ligne.',
        "Kinyarwanda": 'Cunga uko isomero ryawe rihuza amakuru. Huza mudasobwa nyinshi nta internet ukoresheje <strong>Guhuza kuri LAN</strong>, cyangwa ukoreshe <strong>Guhuza na Cloud</strong> kubika amakuru kuri internet.'
    },
    'Max': {
        "French": 'Max',
        "Kinyarwanda": 'Ntarengwa'
    },
    'Network error occurred during download.': {
        "French": "Une erreur réseau s'est produite pendant le téléchargement.",
        "Kinyarwanda": 'Habayeho ikibazo cya rezo mu gihe cyo gukurura.'
    },
    'New Online Sync': {
        "French": 'Nouvelle synchro en ligne',
        "Kinyarwanda": 'Guhuza gushya kuri internet'
    },
    'No books selected.': {
        "French": 'Aucun livre sélectionné.',
        "Kinyarwanda": 'Nta bitabo byahiswemo.'
    },
    'No copy ID for now': {
        "French": "Pas d'ID d'exemplaire pour le moment",
        "Kinyarwanda": "Nta nimero y'igitabo ihari ubu"
    },
    'No data provided.': {
        "French": 'Aucune donnée fournie.',
        "Kinyarwanda": 'Nta makuru yatanzwe.'
    },
    'No online librarians found.': {
        "French": 'Aucun bibliothécaire en ligne trouvé.',
        "Kinyarwanda": "Nta bakozi b'isomero babonetse kuri internet."
    },
    'No system activity has been recorded yet.': {
        "French": 'Aucune activité système enregistrée pour le moment.',
        "Kinyarwanda": 'Nta gikorwa cya sisitemu kirabikwa.'
    },
    'Not Configured': {
        "French": 'Non configuré',
        "Kinyarwanda": 'Ntibyateguwe'
    },
    'Not configured': {
        "French": 'Non configuré',
        "Kinyarwanda": 'Ntibyateguwe'
    },
    'Not generated': {
        "French": 'Non généré',
        "Kinyarwanda": 'Ntibyakozwe'
    },
    'OR': {
        "French": 'OU',
        "Kinyarwanda": 'CYANGWA'
    },
    'Online Sync (Supabase)': {
        "French": 'Synchro en ligne (Supabase)',
        "Kinyarwanda": 'Guhuza kuri internet (Supabase)'
    },
    'Open Conflicts Dashboard': {
        "French": 'Ouvrir le tableau des conflits',
        "Kinyarwanda": "Fungura urubuga rw'ibigongana"
    },
    'Open Sync Dashboard': {
        "French": 'Ouvrir le tableau de synchro',
        "Kinyarwanda": 'Fungura urubuga rwo guhuza'
    },
    'Overview Snapshot': {
        "French": 'Aperçu général',
        "Kinyarwanda": 'Incamake rusange'
    },
    'Page Not Found': {
        "French": 'Page introuvable',
        "Kinyarwanda": 'Urupapuro ntirwabonetse'
    },
    'Parent Phone Numbers (comma separated)': {
        "French": 'Numéros de téléphone des parents (séparés par des virgules)',
        "Kinyarwanda": "Nimero za telefone z'ababyeyi (zitandukanyijwe n'akitso)"
    },
    'Partial Class Borrowing Interception': {
        "French": 'Interception de prêt de classe partiel',
        "Kinyarwanda": "Isuzuma ry'ibitabo biboneka ku ishuri"
    },
    'Partial Resolve (Specific Books/Students)': {
        "French": 'Résolution partielle (Livres/Étudiants spécifiques)',
        "Kinyarwanda": 'Gukemura igice (Ibitabo/Abanyeshuri bamwe)'
    },
    'Passwords do not match': {
        "French": 'Les mots de passe ne correspondent pas',
        "Kinyarwanda": "Amagambo y'ibanga ntahura"
    },
    'Peer-to-Peer (LAN) Data Sharing': {
        "French": 'Partage de données pair-à-pair (LAN)',
        "Kinyarwanda": 'Gusangira amakuru hagati ya mudasobwa (LAN)'
    },
    'Pending Join Requests': {
        "French": "Demandes d'adhésion en attente",
        "Kinyarwanda": 'Ubusabe bwo kwinjira butegereje'
    },
    'Permanently wipe all books and student records. Your admin accounts and config will remain untouched.': {
        "French": 'Effacer définitivement tous les livres et dossiers étudiants. Vos comptes administrateur et configurations resteront intacts.',
        "Kinyarwanda": "Siba burundu ibitabo byose n'abanyeshuri. Konti z'abayobozi n'igenamiterere bizagumaho."
    },
    'Please do not close this window.': {
        "French": 'Veuillez ne pas fermer cette fenêtre.',
        "Kinyarwanda": 'Nyamuneka ntufunge iri dirishya.'
    },
    'Please wait while the files are updated.': {
        "French": 'Veuillez patienter pendant la mise à jour des fichiers.',
        "Kinyarwanda": 'Nyamuneka tegereza mu gihe dosiye zirimo kuvugururwa.'
    },
    'Primary Email': {
        "French": 'E-mail principal',
        "Kinyarwanda": "Imeyili y'ibanze"
    },
    'Proceed to Dashboard': {
        "French": 'Accéder au tableau de bord',
        "Kinyarwanda": 'Komeza ku rubuga nyamukuru'
    },
    'Quick Added %(count)d book copy/copies.': {
        "French": '%(count)d exemplaire(s) ajouté(s) rapidement.',
        "Kinyarwanda": "Hongewemo kopi %(count)d z'ibitabo vuba."
    },
    'Quick-Add Book Copies': {
        "French": "Ajout rapide d'exemplaires",
        "Kinyarwanda": 'Ongeraho ibitabo vuba'
    },
    'Re-enter your password': {
        "French": 'Confirmez votre mot de passe',
        "Kinyarwanda": "Ongera wandike ijambo ry'ibanga"
    },
    'Register Missing Book Copies': {
        "French": 'Enregistrer les exemplaires manquants',
        "Kinyarwanda": 'Andikisha ibitabo bitari mu bubiko'
    },
    'Remind Me Later': {
        "French": 'Me le rappeler plus tard',
        "Kinyarwanda": 'Uzanyibutse nyuma'
    },
    'Report Issue': {
        "French": 'Signaler un incident',
        "Kinyarwanda": 'Menyesha ikibazo'
    },
    'Report Issue (Class)': {
        "French": 'Signaler un incident (Classe)',
        "Kinyarwanda": 'Menyesha ikibazo (Ishuri)'
    },
    'Resolve All (Close Issue)': {
        "French": "Tout résoudre (Fermer l'incident)",
        "Kinyarwanda": 'Kemura byose (Funga ikibazo)'
    },
    'Resolve Class Issue': {
        "French": "Résoudre l'incident de classe",
        "Kinyarwanda": "Kemura ikibazo cy'ishuri"
    },
    'Resolve Collision': {
        "French": 'Résoudre le conflit',
        "Kinyarwanda": 'Kemura ikigongana'
    },
    'Restarting Application...': {
        "French": "Redémarrage de l'application...",
        "Kinyarwanda": 'Porogaramu irimo gutangira bundi bushya...'
    },
    'Review': {
        "French": 'Examiner',
        "Kinyarwanda": 'Reba'
    },
    'Review and manually resolve synchronization collisions between LAN and Cloud databases.': {
        "French": 'Examinez et résolvez manuellement les conflits de synchronisation entre les bases LAN et Cloud.',
        "Kinyarwanda": "Reba kandi ukemure ibigongana by'amakuru hagati ya LAN na Cloud."
    },
    'Review recent activity and audit history across your library.': {
        "French": "Consultez les activités récentes et l'historique d'audit de votre bibliothèque.",
        "Kinyarwanda": "Reba ibikorwa biheruka n'amateka y'isomero ryawe."
    },
    "Revoke this device\\'s session? They will need to re-enter a PIN.": {
        "French": 'Révoquer la session de cet appareil ? Il devra ressaisir un code PIN.',
        "Kinyarwanda": "Hagarika ihuza ry'iyi mudasobwa? Izakenera kongera kwinjiza PIN."
    },
    'Save & Add': {
        "French": 'Enregistrer et ajouter',
        "Kinyarwanda": 'Bika & Ongeraho'
    },
    'Save & Refresh': {
        "French": 'Enregistrer et actualiser',
        "Kinyarwanda": 'Bika & Kuvugurura'
    },
    'Save & Resume Import': {
        "French": "Enregistrer et reprendre l'importation",
        "Kinyarwanda": 'Bika kandi ukomeze kwinjiza'
    },
    'Saving...': {
        "French": 'Enregistrement...',
        "Kinyarwanda": 'Birimo kubikwa...'
    },
    'School Name to Join': {
        "French": "Nom de l'école à rejoindre",
        "Kinyarwanda": "Izina ry'ishuri ushaka kwinjiramo"
    },
    'Security Center': {
        "French": 'Centre de sécurité',
        "Kinyarwanda": "Ikigo cy'umutekano"
    },
    'Select': {
        "French": 'Sélectionner',
        "Kinyarwanda": 'Hitamo'
    },
    'Select Book(s)': {
        "French": 'Sélectionner le(s) livre(s)',
        "Kinyarwanda": 'Hitamo igitabo/ibitabo'
    },
    'Send Join Request': {
        "French": "Envoyer la demande d'adhésion",
        "Kinyarwanda": 'Ohereza ubusabe bwo kwinjira'
    },
    'Send SMS Notification to Parent(s)': {
        "French": 'Envoyer une notification SMS aux parents',
        "Kinyarwanda": 'Ohereza ubutumwa bwa SMS ku babyeyi'
    },
    'Set Up New Library': {
        "French": 'Configurer une nouvelle bibliothèque',
        "Kinyarwanda": 'Tegura isomero rishya'
    },
    'Set up your local workspace in seconds.': {
        "French": 'Configurez votre espace local en quelques secondes.',
        "Kinyarwanda": "Tegura urubuga rw'isomero mu masegonda make."
    },
    'Setup Cloud Sync': {
        "French": 'Configurer la synchro Cloud',
        "Kinyarwanda": 'Tegura guhuza na Cloud'
    },
    'Sign In to Existing': {
        "French": 'Se connecter à un compte existant',
        "Kinyarwanda": 'Injira muri konti isanzwe'
    },
    'Skip this screen next time': {
        "French": 'Ignorer cet écran la prochaine fois',
        "Kinyarwanda": 'Simbuka iyi paji ubutaha'
    },
    'Smart Conflict Resolution': {
        "French": 'Résolution intelligente des conflits',
        "Kinyarwanda": 'Gukemura ibigongana mu buryo bugezweho'
    },
    'Some copies in the requested class range are currently unavailable. Do you want to issue the available subset?': {
        "French": 'Certains exemplaires de la plage demandée sont indisponibles. Voulez-vous prêter les exemplaires disponibles ?',
        "Kinyarwanda": 'Bimwe mu bitabo byasabwe ntibiboneka ubu. Urashaka gutiza ibiboneka gusa?'
    },
    'Something went wrong': {
        "French": 'Une erreur est survenue',
        "Kinyarwanda": 'Hari ikitagenze neza'
    },
    'Source': {
        "French": 'Source',
        "Kinyarwanda": 'Inkomoko'
    },
    'Specific Students': {
        "French": 'Étudiants spécifiques',
        "Kinyarwanda": 'Abanyeshuri bamwe gusa'
    },
    'Student Issues': {
        "French": "Incidents d'étudiants",
        "Kinyarwanda": "Ibibazo by'abanyeshuri"
    },
    'Success! Downloaded': {
        "French": 'Succès ! Téléchargé',
        "Kinyarwanda": 'Byagenze neza! Hakuruwe'
    },
    'Supabase Cloud Backup & Sync': {
        "French": 'Sauvegarde et synchro Cloud Supabase',
        "Kinyarwanda": 'Kubika no guhuza kuri Cloud Supabase'
    },
    'Swipe through the numbers that matter most.': {
        "French": 'Parcourez les chiffres les plus importants.',
        "Kinyarwanda": "Reba imibare y'ingenzi kurusha indi."
    },
    'Syncing': {
        "French": 'Synchronisation',
        "Kinyarwanda": 'Birimo guhuzwa'
    },
    'System Settings & Profile': {
        "French": 'Paramètres système et profil',
        "Kinyarwanda": "Igenamiterere n'umwirondoro"
    },
    'Tailor the dashboard to your preferred workflow.': {
        "French": 'Adaptez le tableau de bord à votre méthode de travail.',
        "Kinyarwanda": "Hindura urubuga ruhuze n'uko ukora."
    },
    'TextBee SMS': {
        "French": 'TextBee SMS',
        "Kinyarwanda": 'TextBee SMS'
    },
    'The following Book IDs from your Excel file were not found in the catalog. Please provide their details to register them now, or leave them blank to skip importing those rows.': {
        "French": 'Les ID de livres suivants de votre fichier Excel sont introuvables dans le catalogue. Renseignez leurs détails pour les enregistrer maintenant ou laissez vide pour ignorer ces lignes.',
        "Kinyarwanda": "Izi nimero z'ibitabo ziri muri Excel ntizabonetse mu bubiko. Tanga amakuru yabyo ubyandikishe ubu cyangwa ubireke bisimbukwe."
    },
    'The page you are looking for does not exist or has been moved.': {
        "French": "La page que vous recherchez n'existe pas ou a été déplacée.",
        "Kinyarwanda": 'Urupapuro ushakisha ntirubaho cyangwa rwimuwe.'
    },
    'There are currently no pending synchronization conflicts.': {
        "French": "Il n'y a actuellement aucun conflit de synchronisation en attente.",
        "Kinyarwanda": 'Nta bigongana byo guhuza amakuru bihari ubu.'
    },
    'This action is permanent. All catalog data, loans, and issues will be wiped.': {
        "French": 'Cette action est définitive. Tout le catalogue, les prêts et les incidents seront effacés.',
        "Kinyarwanda": "Iki gikorwa ntigisubirwaho. Ibitabo, inguzanyo n'ibibazo byose bizasibwa."
    },
    'This amount will be deducted from the repair cost.': {
        "French": 'Ce montant sera déduit du coût de réparation.',
        "Kinyarwanda": 'Aya mafaranga azakurwa ku kiguzi cyo gusana.'
    },
    "This is the Head Librarian's PC.": {
        "French": 'Ceci est le PC du bibliothécaire principal.',
        "Kinyarwanda": "Iyi ni mudasobwa y'umuyobozi mukuru w'isomero."
    },
    'Time of Collision': {
        "French": 'Heure du conflit',
        "Kinyarwanda": 'Igihe byagonganiye'
    },
    'Too many books selected (max 1000).': {
        "French": 'Trop de livres sélectionnés (max 1000).',
        "Kinyarwanda": 'Wahisemo ibitabo byinshi cyane (ntarengwa 1000).'
    },
    'Total Accumulated': {
        "French": 'Total accumulé',
        "Kinyarwanda": 'Igiteranyo cyose'
    },
    'Total accumulated fines (RWF) from book issues (Students vs Classes).': {
        "French": 'Total des amendes accumulées (RWF) liées aux incidents (Étudiants vs Classes).',
        "Kinyarwanda": "Igiteranyo cy'amande (RWF) y'ibibazo by'ibitabo (Abanyeshuri n'Amashuri)."
    },
    'Track circulation health, borrower activity and class trends.': {
        "French": "Suivez la circulation, l'activité des emprunteurs et les tendances par classe.",
        "Kinyarwanda": "Kurikirana itizwa ry'ibitabo, ibikorwa by'abatira n'imibare y'amashuri."
    },
    'Unavailable Copies': {
        "French": 'Exemplaires indisponibles',
        "Kinyarwanda": 'Ibitabo bitaboneka'
    },
    'Unique ID(s) (Ranges or Commas)': {
        "French": 'ID uniques (Plages ou virgules)',
        "Kinyarwanda": 'Nimero zihariye (Urutonde cyangwa akitso)'
    },
    'Unknown error': {
        "French": 'Erreur inconnue',
        "Kinyarwanda": 'Ikosa ritazwi'
    },
    'Unrecognized Books Found': {
        "French": 'Livres non reconnus détectés',
        "Kinyarwanda": 'Habonetse ibitabo bitazwi'
    },
    'Update': {
        "French": 'Mettre à jour',
        "Kinyarwanda": 'Vugurura'
    },
    'Update Ready to Install': {
        "French": 'Mise à jour prête à être installée',
        "Kinyarwanda": 'Ivugurura ririteguye gushyirwaho'
    },
    'Update downloaded and applying. The application will reload automatically as soon as the server is ready.': {
        "French": "Mise à jour téléchargée et en cours d'application. L'application se rechargera automatiquement dès que le serveur sera prêt.",
        "Kinyarwanda": 'Ivugurura ryakuruwe kandi ririmo gushyirwaho. Porogaramu izongera ifunguke seriveri niboneka.'
    },
    'Update your login credentials': {
        "French": 'Mettez à jour vos identifiants de connexion',
        "Kinyarwanda": 'Vugurura amakuru yo kwinjira'
    },
    'Use the app locally. You can configure peer-to-peer LAN syncing later.': {
        "French": "Utilisez l'application localement. Vous pourrez configurer la synchro LAN pair-à-pair plus tard.",
        "Kinyarwanda": 'Koresha porogaramu kuri mudasobwa gusa. Ushobora gutegura ihuza rya LAN nyuma.'
    },
    'Use the class loan template and include Class, Responsibles, Base ID, Unique IDs, and Condition.': {
        "French": 'Utilisez le modèle de prêt de classe et incluez Classe, Responsables, ID de base, ID uniques et État.',
        "Kinyarwanda": "Koresha icyitegererezo cy'inguzanyo y'ishuri ushyiremo Ishuri, Ababishinzwe, ID y'ibanze, Nimero n'Imiterere."
    },
    'Use the staff loan template and include Staff Name, Book ID, and Condition.': {
        "French": 'Utilisez le modèle de prêt du personnel et incluez Nom du personnel, ID du livre et État.',
        "Kinyarwanda": "Koresha icyitegererezo cy'inguzanyo y'abarimu ushyiremo Izina, ID y'igitabo n'Imiterere."
    },
    'Use the student loan template and include Student Name, Book ID, and Condition.': {
        "French": "Utilisez le modèle de prêt étudiant et incluez Nom de l'étudiant, ID du livre et État.",
        "Kinyarwanda": "Koresha icyitegererezo cy'inguzanyo y'abanyeshuri ushyiremo Izina ry'umunyeshuri, ID y'igitabo n'Imiterere."
    },
    'View Codes': {
        "French": 'Voir les codes',
        "Kinyarwanda": 'Reba kode'
    },
    'View Sync Queue': {
        "French": 'Voir la file de synchronisation',
        "Kinyarwanda": 'Reba umurongo wo guhuza'
    },
    'Waiting': {
        "French": 'En attente',
        "Kinyarwanda": 'Bitegereje'
    },
    'Warning': {
        "French": 'Avertissement',
        "Kinyarwanda": 'Iburira'
    },
    'We encountered an unexpected condition that prevented us from fulfilling your request.': {
        "French": 'Nous avons rencontré une erreur inattendue qui a empêché le traitement de votre demande.',
        "Kinyarwanda": 'Habayeho ikibazo gitunguranye cyabujije igikorwa cyawe kurangira.'
    },
    'Welcome Page': {
        "French": "Page d'accueil",
        "Kinyarwanda": "Urupapuro rw'ikaze"
    },
    'Welcome to Smart Library': {
        "French": 'Bienvenue dans Smart Library',
        "Kinyarwanda": 'Ikaze muri Smart Library'
    },
    "What's New:": {
        "French": 'Nouveautés :',
        "Kinyarwanda": 'Ibishya:'
    },
    'When librarians edit the same record simultaneously across different devices or networks, it creates a synchronization collision. Review and manually resolve pending LAN and Cloud conflicts here.': {
        "French": 'Lorsque des bibliothécaires modifient le même enregistrement simultanément sur différents appareils, cela crée un conflit de synchronisation. Examinez et résolvez ici les conflits LAN et Cloud.',
        "Kinyarwanda": 'Iyo abakozi bahinduye inyandiko imwe icyarimwe kuri mudasobwa zitandukanye, habaho ikigongana. Reba kandi ukemure ibigongana bya LAN na Cloud hano.'
    },
    'Whole Class': {
        "French": 'Toute la classe',
        "Kinyarwanda": 'Ishuri ryose'
    },
    'Workspace ready! Redirecting...': {
        "French": 'Espace prêt ! Redirection...',
        "Kinyarwanda": 'Urubuga ruriteguye! Birimo kwimuka...'
    },
    'You have been approved to join this school! Before you can start using the system, you must download the initial database from the cloud.': {
        "French": "Votre demande d'adhésion à cette école a été approuvée ! Avant de commencer, vous devez télécharger la base de données initiale depuis le cloud.",
        "Kinyarwanda": "Wemerewe kwinjira muri iri shuri! Mbere yo gutangira gukoresha sisitemu, ugomba gukurura ububiko bw'amakuru kuri cloud."
    },
    'You have chosen not to connect to Supabase right now. Are you sure?': {
        "French": 'Vous avez choisi de ne pas vous connecter à Supabase pour le moment. Êtes-vous sûr ?',
        "Kinyarwanda": 'Wahisemo kudahuza na Supabase ubu. Uremeza?'
    },
    'Your School Name': {
        "French": 'Nom de votre école',
        "Kinyarwanda": "Izina ry'ishuri ryawe"
    },
    'Your account is not linked to any online school.': {
        "French": "Votre compte n'est lié à aucune école en ligne.",
        "Kinyarwanda": "Konti yawe ntihujwe n'ishuri na rimwe kuri internet."
    },
    'Your school library, fully digital.': {
        "French": 'La bibliothèque de votre école, entièrement numérique.',
        "Kinyarwanda": "Isomero ry'ishuri ryawe mu buryo bw'ikoranabuhanga."
    },
    'e.g. +25078..., +25072...': {
        "French": 'ex. +25078..., +25072...',
        "Kinyarwanda": 'urugero +25078..., +25072...'
    },
    'e.g. Novels': {
        "French": 'ex. Romans',
        "Kinyarwanda": "urugero Ibitabo by'inkuru"
    },
    'e.g. S4MSIIC': {
        "French": 'ex. S4MSIIC',
        "Kinyarwanda": 'urugero S4MSIIC'
    },
    'records. Refreshing...': {
        "French": 'enregistrements. Actualisation...',
        "Kinyarwanda": 'inyandiko. Birimo kuvugururwa...'
    },
    'the app stays connected automatically. You only need to enter the PIN again if the Major PC disconnects you.': {
        "French": "l'application reste connectée automatiquement. Vous n'aurez besoin de saisir le PIN à nouveau que si le PC principal vous déconnecte.",
        "Kinyarwanda": 'porogaramu iguma ihujwe byikora. Uzakenera kongera kwinjiza PIN gusa niba mudasobwa nkuru igukuyeho.'
    },
    'unknown': {
        "French": 'inconnu',
        "Kinyarwanda": 'ntibizwi'
    }
}

from flask import session, has_request_context

for _phrase, _lang_dict in list(TRANSLATIONS.items()):
    if isinstance(_lang_dict, dict) and ("French" in _lang_dict or "Kinyarwanda" in _lang_dict):
        TRANSLATIONS.setdefault("en", {})[_phrase] = _phrase
        TRANSLATIONS.setdefault("English", {})[_phrase] = _phrase
        if "French" in _lang_dict:
            TRANSLATIONS.setdefault("fr", {})[_phrase] = _lang_dict["French"]
            TRANSLATIONS.setdefault("French", {})[_phrase] = _lang_dict["French"]
        if "Kinyarwanda" in _lang_dict:
            TRANSLATIONS.setdefault("rw", {})[_phrase] = _lang_dict["Kinyarwanda"]
            TRANSLATIONS.setdefault("Kinyarwanda", {})[_phrase] = _lang_dict["Kinyarwanda"]


def translate(text, **kwargs):
    lang = session.get('lang', 'en') if has_request_context() else 'en'
    if lang == 'en' and has_request_context():
        try:
            from .utils import load_config
            cfg_lang = load_config().get('language', 'en')
            if cfg_lang and cfg_lang != 'English':
                lang = cfg_lang
        except Exception:
            pass
    translated = TRANSLATIONS.get(lang, {}).get(text, text)
    return translated % kwargs if kwargs else translated

_ = translate
