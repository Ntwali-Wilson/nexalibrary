// Basic welcome site logic and Supabase integration
(function(){
  const SUPABASE_URL = (window.SUPABASE_URL || "");
  const SUPABASE_ANON_KEY = (window.SUPABASE_ANON_KEY || "");

  // DOM
  const dontShow = document.getElementById('dontShow');
  const loginBtn = document.getElementById('loginBtn');
  const signupBtn = document.getElementById('signupBtn');
  const signupPanel = document.getElementById('signupPanel');
  const cancelBtn = document.getElementById('cancelBtn');
  const form = document.getElementById('signupForm');
  const submitBtn = document.getElementById('submitBtn');
  const status = document.getElementById('status');

  // Hide again control
  if (localStorage.getItem('edraze_hide_welcome') === '1') {
    // if hidden, show minimal content (user can still open site manually)
    document.querySelector('.panel')?.classList.add('hidden');
  }

  dontShow.addEventListener('change', ()=>{
    if (dontShow.checked) localStorage.setItem('edraze_hide_welcome','1'); else localStorage.removeItem('edraze_hide_welcome');
  });

  // routing
  loginBtn.addEventListener('click', ()=>{ window.location.href = '/login'; });
  signupBtn.addEventListener('click', ()=>{ signupPanel.classList.remove('hidden'); window.scrollTo({top:document.body.scrollHeight,behavior:'smooth'}); });
  cancelBtn.addEventListener('click', ()=>{ signupPanel.classList.add('hidden'); status.textContent=''; });

  // form validation
  const inputs = ['school','fullname','username','password','confirm'].map(id=>document.getElementById(id));
  inputs.forEach(i=>i.addEventListener('input', checkForm));
  function checkForm(){
    const [school,fullname,username,password,confirm] = inputs.map(i=>i.value.trim());
    const ok = school && fullname && username && password && confirm && (password===confirm) && password.length>=6;
    submitBtn.disabled = !ok;
    if(password!==confirm && confirm.length>0) status.textContent = 'Passwords do not match'; else status.textContent='';
  }

  // Signup submit
  form.addEventListener('submit', async (e)=>{
    e.preventDefault();
    submitBtn.disabled = true; status.textContent='Submitting...';

    const payload = {
      school_name: document.getElementById('school').value.trim(),
      username: document.getElementById('username').value.trim(),
      full_name: document.getElementById('fullname').value.trim()
    };

    if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
      status.textContent = 'Supabase credentials not configured. Set SUPABASE_URL and SUPABASE_ANON_KEY on Vercel.';
      submitBtn.disabled = false; return;
    }

    try {
      // Prefer local server endpoint when running via run.py (stores locally and forwards when possible)
      const res = await fetch('/welcome/signup', {
        method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(payload)
      });

      if (!res.ok) {
        // fallback to direct Supabase write if local endpoint unavailable
        if (!SUPABASE_URL || !SUPABASE_ANON_KEY || !window.supabase) {
          throw new Error('Local endpoint failed and Supabase not configured');
        }
        const supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
        const { data, error } = await supabase.from('join_requests').insert({ school_name: payload.school_name, username: payload.username, full_name: payload.full_name, status: 'pending' });
        if (error) throw error;
      }

      // show message for 40 seconds then redirect to login
      status.textContent = 'You have finished to create your account wait for approval';
      setTimeout(()=>{ window.location.href = '/login'; }, 40000);
    } catch(err){
      console.error(err); status.textContent = 'Error submitting: '+(err.message||err);
      submitBtn.disabled = false;
    }
  });

  // small helper to expose supabase constants for deployments that prefer inline
  window.ED_SUPABASE = { SUPABASE_URL, SUPABASE_ANON_KEY };

})();
