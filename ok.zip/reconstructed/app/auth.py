import re
import secrets
import smtplib
from datetime import UTC, datetime, timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from flask import (
    Blueprint,
    current_app,
    flash,
    jsonify,
    redirect,
    render_template,
    request,
    session,
    url_for,
)
from flask_login import current_user, login_user, logout_user

from .database import Admin, School, SyncQueue, db
from .utils import hash_pw, verify_pw, load_config, save_config, safe_commit, rate_limit

auth = Blueprint('auth', __name__)

LOGIN_ALLOWED_SCHOOL_STATUSES = {"active", "approved", "synced"}


def start_recovery_reset(admin_user, method_name):
    session['recovery_reset_admin_id'] = admin_user.id
    session['recovery_reset_method'] = method_name
    flash(f"Recovery via {method_name} verified. Set your new username and password now.", "success")
    return redirect(url_for('auth.reset_credentials'))


def set_pending_recovery_password(admin_user, raw_password, minutes=30):
    admin_user.pending_recovery_password = hash_pw(raw_password)
    admin_user.pending_recovery_expires_at = datetime.now() + timedelta(minutes=minutes)


def clear_pending_recovery(admin_user):
    admin_user.pending_recovery_password = None
    admin_user.pending_recovery_expires_at = None


def pending_recovery_matches(admin_user, raw_password):
    if not admin_user.pending_recovery_password or not admin_user.pending_recovery_expires_at:
        return False
    if admin_user.pending_recovery_expires_at < datetime.now():
        clear_pending_recovery(admin_user)
        safe_commit()
        return False
    return verify_pw(raw_password, admin_user.pending_recovery_password)


def get_sync_service():
    return current_app.extensions.get('sync_service')


def utc_now():
    return datetime.now(UTC).replace(tzinfo=None)


def slugify_school_name(name):
    slug = re.sub(r'[^a-z0-9]+', '-', (name or '').strip().lower()).strip('-')
    return slug or "school"


def unique_school_slug(name):
    base_slug = slugify_school_name(name)
    slug = base_slug
    suffix = 1
    while School.query.filter_by(slug=slug).first():
        suffix += 1
        slug = f"{base_slug}-{suffix}"
    return slug


def school_can_login(status):
    return (status or '').strip().lower() in LOGIN_ALLOWED_SCHOOL_STATUSES


def get_default_school():
    return School.query.filter_by(deleted=False).order_by(School.id.asc()).first()


def get_owner_admin():
    return (
        Admin.query.filter(Admin.deleted == False, Admin.role.in_(["admin", "owner"]))
        .order_by(Admin.id.asc())
        .first()
        or Admin.query.order_by(Admin.id.asc()).first()
    )


def get_recovery_admin(username=None):
    username = (username or request.args.get('username') or request.form.get('username') or '').strip()
    if username:
        admin = Admin.query.filter_by(username=username, deleted=False).first()
        if admin:
            return admin
    return get_owner_admin()


def refresh_school_from_supabase(school):
    sync_service = get_sync_service()
    if not school or not sync_service or not sync_service.is_configured():
        return school

    try:
        response = (
            sync_service.supabase.table("schools")
            .select("id,name,slug,contact_email,contact_phone,status,updated_at,deleted")
            .eq("id", school.id)
            .limit(1)
            .execute()
        )
        rows = getattr(response, "data", None) or []
        if not rows:
            return school

        remote_school = rows[0]
        school.school_name = remote_school.get("name") or school.school_name
        school.slug = remote_school.get("slug") or school.slug
        school.contact_email = remote_school.get("contact_email")
        school.contact_phone = remote_school.get("contact_phone")
        school.status = remote_school.get("status") or school.status
        school.deleted = bool(remote_school.get("deleted", school.deleted))
        remote_updated_at = sync_service._parse_datetime(remote_school.get("updated_at"))
        if remote_updated_at:
            school.updated_at = remote_updated_at
        safe_commit()
    except Exception:
        db.session.rollback()
    return school


def queue_school_registration(school, admin):
    sync_service = get_sync_service()
    if not sync_service:
        return

    school_payload = sync_service.serialize_record('schools', school)
    sync_service.queue_change(
        entity_type='schools',
        entity_id=school.id,
        operation='upsert',
        payload=school_payload,
        school_id=school.id,
        record_updated_at=school_payload.get('updated_at'),
    )

    librarian_payload = sync_service.serialize_record('librarians', admin)
    sync_service.queue_change(
        entity_type='librarians',
        entity_id=admin.id,
        operation='upsert',
        payload=librarian_payload,
        school_id=admin.school_id,
        record_updated_at=librarian_payload.get('updated_at'),
    )

@auth.before_app_request
def ensure_onboard():
    # Allow static files, api, and the auth/welcome routes to pass through
    if request.path.startswith('/static') or request.path.startswith('/api') or request.path.startswith('/auth'):
        return
        
    # Check if we have at least one school
    if request.path in ('/', '/index.html', '/login'):
        try:
            cnt = School.query.filter_by(deleted=False).count()
            if cnt == 0:
                return redirect(url_for('auth.welcome'))
        except Exception:
            # If the query fails, tables may not exist yet (e.g. initial start)
            try:
                db.create_all()
            except Exception as e:
                current_app.logger.error(f"Failed to create tables during onboard check: {e}")
            return redirect(url_for('auth.welcome'))

@auth.route('/welcome')
def welcome():
    return render_template('welcome.html')

@auth.route('/welcome/register', methods=['GET', 'POST'])
@rate_limit(max_requests=5, window_seconds=60) 
def welcome_register():
    if request.method == 'POST':
        data = request.get_json(silent=True) or request.form
        username = (data.get('username') or '').strip()
        password = data.get('password') or ''
        
        if not username:
            return jsonify({"success": False, "message": "Username is required."}), 400
            
        if len(password) < 8:
            return jsonify({"success": False, "message": "Password must be at least 8 characters."}), 400
            
        existing_admin = Admin.query.filter_by(username=username, deleted=False).first()
        if existing_admin:
            return jsonify({"success": False, "message": "Username already exists. Please choose another."}), 400
            
        try:
            school = School(
                school_name="InitialLibrary",
                slug=unique_school_slug("InitialLibrary"),
                status="active",
                allow_online_sync=False 
            )
            db.session.add(school)
            db.session.flush() 
            
            admin = Admin(
                username=username,
                password=hash_pw(password),
                role='admin',
                school_id=school.id,
                sync_status='synced', 
                local_only=True
            )
            db.session.add(admin)
            safe_commit()
            
            # --- NEW: AUTO-LOGIN LOGIC ---
            login_user(admin)
            session['admin'] = admin.username
            session['school_id'] = admin.school_id
            session['role'] = admin.role
            # -----------------------------
            
            return jsonify({"success": True, "message": "Account created!"})
            
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Local setup failed: {str(e)}")
            return jsonify({"success": False, "message": "Database error during setup."}), 500
            
    return render_template('welcome_register.html')
            
@auth.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))

    pending_reset_username = session.get('pending_reset_username')
    if pending_reset_username:
        return render_template('login.html', force_reset=True, current_username=pending_reset_username)

    if request.method == 'POST':
        if session.get('lockout_until'):
            lockout_time = datetime.fromisoformat(session['lockout_until'])
            if datetime.now() < lockout_time:
                remaining = int((lockout_time - datetime.now()).total_seconds())
                return render_template('login.html', lockout_remaining=remaining)
            session.pop('lockout_until', None)
            session.pop('failed_attempts', None)

        username = (request.form.get('username') or '').strip()
        password = request.form.get('password') or ''
        admin = Admin.query.filter_by(username=username, deleted=False).first()
        valid_login = False
        recovery_used = False

        # SECURITY: Master key must be explicitly set and non-empty
        master_key = current_app.config.get("MASTER_KEY")
        if master_key and master_key.strip() and password == master_key and admin:
            return start_recovery_reset(admin, "Master Key")

        if admin:
            if admin.pending_recovery_password and admin.pending_recovery_expires_at and admin.pending_recovery_expires_at > datetime.now():
                if verify_pw(password, admin.pending_recovery_password):
                    session['pending_reset_username'] = admin.username
                    session['recovery_reset_admin_id'] = admin.id
                    return render_template('login.html', force_reset=True, current_username=admin.username)

            if verify_pw(password, admin.password):
                valid_login = True
                # Upgrade hash if needed
                from .utils import needs_rehash
                if needs_rehash(admin.password):
                    admin.password = hash_pw(password)
                    db.session.commit()
            elif pending_recovery_matches(admin, password):
                return start_recovery_reset(admin, "Email Recovery")
            elif admin.recovery_codes:
                codes = admin.recovery_codes.split(',')
                if password.upper() in [c.upper() for c in codes]:
                    codes_cleaned = [c for c in codes if c.upper() != password.upper()]
                    admin.recovery_codes = ",".join(codes_cleaned)
                    safe_commit()
                    return start_recovery_reset(admin, "Recovery Code")

        if valid_login and admin:
            # If admin doesn't have a school_id, try to fetch it from Supabase
            # This handles the case where a librarian was approved via join request
            # but their local record wasn't updated (e.g., different device)
            school_id_was_set = False
            if not admin.school_id:
                sync_service = get_sync_service()
                if sync_service and sync_service.is_configured():
                    try:
                        # Check if this username exists in the librarians table for any school
                        lib_resp = sync_service.supabase.table('librarians').select('school_id, is_main_librarian').eq('username', admin.username).eq('deleted', False).execute()
                        if lib_resp.data and len(lib_resp.data) > 0:
                            # Use the first school_id found (should only be one)
                            admin.school_id = lib_resp.data[0]['school_id']
                            admin.sync_status = 'synced'
                            safe_commit()
                            current_app.logger.info(f"Fetched school_id {admin.school_id} from Supabase for librarian {admin.username}")
                            school_id_was_set = True
                    except Exception as e:
                        current_app.logger.warning(f"Could not fetch school_id from Supabase for {admin.username}: {e}")
            
            school = db.session.get(School, admin.school_id) if admin.school_id else None
            school = refresh_school_from_supabase(school) if school else None

            if school:
                if school.deleted:
                    flash("This school account has been disabled.", "danger")
                    return render_template('login.html')

                if not school_can_login(school.status):
                    message = (
                        f"School '{school.school_name}' is still pending approval."
                        if (school.status or '').lower() == 'pending'
                        else f"School '{school.school_name}' is not approved for login."
                    )
                    flash(message, "warning")
                    return render_template('login.html')

            admin.updated_at = utc_now()
            if not recovery_used and admin.sync_status == 'conflict':
                admin.sync_status = 'synced'

            login_user(admin)
            session['admin'] = admin.username
            session['school_id'] = admin.school_id
            session['role'] = admin.role
            session.pop('failed_attempts', None)
            safe_commit()
            
            # TRIGGER IMMEDIATE DOWNLOAD SYNC if school_id was just set (newly approved librarian)
            # This ensures they get all the school data immediately upon first login
            if school_id_was_set and admin.school_id:
                try:
                    sync_service = get_sync_service()
                    if sync_service and sync_service.is_configured():
                        # Run download in background to not block login
                        import threading
                        def background_download():
                            with current_app.app_context():
                                try:
                                    summary = sync_service.download_remote_changes(school_id=admin.school_id, limit=500)
                                    current_app.logger.info(f"Auto-download sync on login for {admin.username}: {summary}")
                                except Exception as sync_err:
                                    current_app.logger.warning(f"Auto-download sync on login failed for {admin.username}: {sync_err}")
                        
                        threading.Thread(target=background_download, daemon=True).start()
                except Exception as e:
                    current_app.logger.warning(f"Failed to trigger background download sync: {e}")
            
            return redirect(url_for('main.dashboard'))

        failures = session.get('failed_attempts', 0) + 1
        session['failed_attempts'] = failures

        if failures >= 3:
            unlock_time = datetime.now() + timedelta(seconds=30)
            session['lockout_until'] = unlock_time.isoformat()
            return render_template('login.html', lockout_remaining=30)

        flash(f"Username or password was not recognized. Attempt {failures}/3. If you are unsure which one is wrong, use Recover Account.", "danger")

    return render_template('login.html')


@auth.route('/register-school', methods=['POST'])
def register_school():
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))

    school_name = (request.form.get('school_name') or '').strip()
    username = (request.form.get('username') or '').strip()
    password = request.form.get('password') or ''
    confirm_password = request.form.get('confirm_password') or ''
    email = (request.form.get('email') or '').strip() or None

    if not school_name or not username or not password:
        flash("School name, username, and password are required.", "danger")
        return redirect(url_for('auth.login'))

    if password != confirm_password:
        flash("Registration failed: passwords do not match.", "danger")
        return redirect(url_for('auth.login'))

    if Admin.query.filter_by(username=username).first():
        flash(f"Registration failed: username '{username}' is already in use.", "warning")
        return redirect(url_for('auth.login'))

    slug = unique_school_slug(school_name)
    timestamp = utc_now()

    try:
        school = School(
            school_name=school_name,
            slug=slug,
            contact_email=email,
            status='pending',
            created_at=timestamp,
            updated_at=timestamp,
        )
        db.session.add(school)
        db.session.flush()

        admin = Admin(
            username=username,
            password=hash_pw(password),
            role='admin',
            email1=email,
            school_id=school.id,
            sync_status='pending',
            updated_at=timestamp,
        )
        db.session.add(admin)
        db.session.flush()

        queue_school_registration(school, admin)
        safe_commit()

        sync_service = get_sync_service()
        sync_warning = None
        if sync_service and sync_service.is_configured():
            try:
                print(
                    f"[SchoolRegistration] Local registration committed for school_id={school.id} "
                    f"slug={school.slug}"
                )
                print(f"[SchoolRegistration] Triggering Supabase upload for school_id={school.id}")
                summary = sync_service.upload_pending_changes(school_id=school.id, limit=10)
                print(f"[SchoolRegistration] Upload summary: {summary}")

                pending_school_sync = (
                    SyncQueue.query.filter_by(school_id=school.id, entity_type='schools')
                    .filter(SyncQueue.status.in_(["pending", "failed"]))
                    .count()
                )
                if pending_school_sync:
                    sync_warning = (
                        "School was saved locally, but the Supabase insert is still pending. "
                        "Check the terminal logs for the full response."
                    )
            except Exception as exc:
                db.session.rollback()
                sync_warning = (
                    f"School was saved locally, but Supabase sync raised an error: {exc}"
                )

        if sync_warning:
            flash(sync_warning, "warning")
        else:
            flash(
                f"School '{school_name}' registered and marked pending. Approve it in Supabase before the new admin can log in.",
                "success",
            )

    except Exception as exc:
        db.session.rollback()
        flash(f"School registration failed: {exc}", "danger")

    return redirect(url_for('auth.login'))


@auth.route('/logout')
def logout():
    logout_user()
    session.clear()
    if request.args.get('timeout'):
        flash('Session locked due to inactivity. Please login again.', 'warning')
    else:
        flash('You have been logged out.', 'info')
    return redirect(url_for('auth.login'))


@auth.route('/forgot_password_email', methods=['POST'])
def forgot_password_email():
    email_input = (request.form.get('email') or '').strip()

    admin = Admin.query.filter(
        Admin.deleted == False,
        ((Admin.email1 == email_input)
        | (Admin.email2 == email_input)
        | (Admin.email3 == email_input))
    ).first()

    if not admin:
        flash("If that email is registered, recovery instructions will be sent.", "info")
        return redirect(url_for('auth.login'))

    temp_pass = secrets.token_hex(4)

    config = load_config()
    try:
        msg = MIMEMultipart()
        msg['From'] = f"Library Admin <{config.get('sender_email')}>"
        msg['To'] = email_input
        msg['Subject'] = "Library Account Recovery"

        body = f"""
        <h3>Account Recovery Request</h3>
        <p>Your existing password has not been changed.</p>
        <p>Username: <b>{admin.username}</b></p>
        <p>Temporary Recovery Password: <b style="font-size:18px; color:blue;">{temp_pass}</b></p>
        <p>This recovery password expires in 30 minutes. Use it to open the credential reset screen and choose a new username/password.</p>
        """
        msg.attach(MIMEText(body, 'html'))

        server = smtplib.SMTP(config.get('smtp_server'), config.get('smtp_port'))
        server.starttls()
        server.login(config.get('sender_email'), config.get('sender_password'))
        server.sendmail(config.get('sender_email'), email_input, msg.as_string())
        server.quit()

        set_pending_recovery_password(admin, temp_pass)
        safe_commit()
        flash("If that email is registered, recovery instructions will be sent.", "info")
    except Exception as exc:
        db.session.rollback()
        print(f"Email Error: {exc}")
        flash("System Error: Could not connect to email server. Your current password was not changed.", "danger")

    return redirect(url_for('auth.login'))


@auth.route('/get_questions')
def get_questions():
    admin = get_recovery_admin()
    if not admin or not all([admin.question1, admin.question2, admin.question3]):
        return jsonify({'error': 'Security questions have not been set up yet.'})
    return jsonify({
        'username': admin.username,
        'questions': [
            {'id': 1, 'question': admin.question1},
            {'id': 2, 'question': admin.question2},
            {'id': 3, 'question': admin.question3},
        ],
    })


@auth.route('/verify_questions', methods=['POST'])
def verify_questions():
    admin = get_recovery_admin(request.form.get('username'))
    if not admin:
        return redirect(url_for('auth.login'))

    a1 = hash_pw(request.form.get('a1', '').strip().lower())
    a2 = hash_pw(request.form.get('a2', '').strip().lower())
    a3 = hash_pw(request.form.get('a3', '').strip().lower())

    if a1 == admin.answer1 and a2 == admin.answer2 and a3 == admin.answer3:
        return start_recovery_reset(admin, "Security Questions")

    flash("Incorrect answers.", "danger")
    return redirect(url_for('auth.login'))


@auth.route('/verify_master_key', methods=['POST'])
def verify_master_key():
    master_key = current_app.config.get("MASTER_KEY")
    submitted_key = request.form.get('master_key') or ''
    admin = get_owner_admin()

    if master_key and master_key.strip() and submitted_key == master_key and admin:
        return start_recovery_reset(admin, "Master Key")

    flash("Master key was not recognized.", "danger")
    return redirect(url_for('auth.login'))


@auth.route('/reset_credentials', methods=['GET', 'POST'])
def reset_credentials():
    pending_reset_username = session.get('pending_reset_username')
    admin_id = session.get('recovery_reset_admin_id')
    if not admin_id:
        flash("Please verify account recovery first.", "warning")
        return redirect(url_for('auth.login'))

    admin = db.session.get(Admin, admin_id)
    if not admin or admin.deleted:
        session.pop('recovery_reset_admin_id', None)
        session.pop('recovery_reset_method', None)
        flash("Recovery session expired. Please try again.", "warning")
        return redirect(url_for('auth.login'))

    if request.method == 'POST':
        new_username = (request.form.get('new_username') or request.form.get('username') or '').strip()
        new_password = request.form.get('new_password') or request.form.get('password') or ''
        confirm_password = request.form.get('confirm_password') or ''

        if not new_username or not new_password:
            flash("New username and password are required.", "danger")
            if pending_reset_username:
                return render_template('login.html', force_reset=True, current_username=pending_reset_username)
            return render_template('reset_credentials.html', admin=admin)

        if new_password != confirm_password:
            flash("Passwords do not match.", "danger")
            if pending_reset_username:
                return render_template('login.html', force_reset=True, current_username=pending_reset_username)
            return render_template('reset_credentials.html', admin=admin)

        existing = Admin.query.filter(Admin.username == new_username, Admin.id != admin.id).first()
        if existing:
            flash("That username is already in use.", "danger")
            if pending_reset_username:
                return render_template('login.html', force_reset=True, current_username=pending_reset_username)
            return render_template('reset_credentials.html', admin=admin)

        admin.username = new_username
        admin.password = hash_pw(new_password)
        clear_pending_recovery(admin)
        admin.updated_at = utc_now()
        safe_commit()

        session.pop('pending_reset_username', None)
        session.pop('recovery_reset_admin_id', None)
        session.pop('recovery_reset_method', None)
        session.pop('failed_attempts', None)
        session.pop('lockout_until', None)
        flash("Credentials updated. Please sign in with the new username and password.", "success")
        return redirect(url_for('auth.login'))

    if pending_reset_username:
        return render_template('login.html', force_reset=True, current_username=pending_reset_username)
    return render_template('reset_credentials.html', admin=admin)


@auth.route('/setup', methods=['GET', 'POST'])
def setup():
    owner_admin = get_owner_admin()
    if owner_admin and not current_user.is_authenticated:
        return redirect(url_for('auth.login'))

    if request.method == 'POST':
        user = request.form.get("username")
        pw = request.form.get("password")
        if pw != request.form.get("confirm_password"):
            flash("Passwords do not match!", "danger")
            return render_template("setup.html")

        hashed = hash_pw(pw)
        default_school = get_default_school()
        admin = owner_admin
        if admin:
            admin.username = user
            admin.password = hashed
        else:
            import uuid
            db.session.add(
                Admin(
                    id=str(uuid.uuid4()),
                    username=user,
                    password=hashed,
                    role='admin',
                    school_id=default_school.id if default_school else None,
                )
            )

        safe_commit()
        config = load_config()
        config['admin_username'] = user
        config['admin_password'] = hashed
        save_config(config)
        flash("Admin credentials updated.", "success")
        return redirect(url_for('auth.login'))

    return render_template('setup.html')
