"""
Security utilities for the Library Management System.
Provides cryptographic functions, secure password hashing, and security helpers.
"""
import os
import secrets
import hashlib
import hmac
import logging
from datetime import datetime
from functools import wraps
from typing import Optional, Tuple, List

try:
    import bcrypt
except ImportError:
    bcrypt = None

try:
    from flask import current_app, request, session, abort
    from flask_login import current_user
except ImportError:
    current_app = request = session = current_user = None
    def abort(code): raise Exception(f"HTTP {code}")

logger = logging.getLogger(__name__)

# --- Password Hashing (bcrypt with configurable work factor) ---

BCRYPT_ROUNDS = 12
MIN_PASSWORD_LENGTH = 12
MAX_PASSWORD_LENGTH = 128

def hash_password(password: str) -> str:
    """
    Hash a password using bcrypt with configurable work factor.
    Returns a bcrypt hash string that includes salt and work factor.
    """
    if not password or not isinstance(password, str):
        raise ValueError("Password must be a non-empty string")
    
    if len(password) > MAX_PASSWORD_LENGTH:
        raise ValueError(f"Password exceeds maximum length of {MAX_PASSWORD_LENGTH}")
    
    if bcrypt is None:
        # Fallback to PBKDF2 if bcrypt unavailable (should not happen in production)
        logger.warning("bcrypt not available, falling back to PBKDF2")
        return _hash_password_pbkdf2(password)
    
    # bcrypt handles salt generation internally
    password_bytes = password.encode('utf-8')
    hashed = bcrypt.hashpw(password_bytes, bcrypt.gensalt(rounds=BCRYPT_ROUNDS))
    return hashed.decode('utf-8')


def verify_password(password: str, hashed: str) -> bool:
    """
    Verify a password against a bcrypt hash.
    Handles both bcrypt and legacy SHA256 hashes for migration.
    """
    if not password or not hashed:
        return False
    
    try:
        if bcrypt is not None and hashed.startswith(('$2b$', '$2a$', '$2y$')):
            # bcrypt hash
            return bcrypt.checkpw(password.encode('utf-8'), hashed.encode('utf-8'))
        elif len(hashed) == 64 and all(c in '0123456789abcdef' for c in hashed.lower()):
            # Legacy SHA256 hash - verify and flag for migration
            legacy_hash = hashlib.sha256(password.encode('utf-8')).hexdigest()
            return hmac.compare_digest(legacy_hash, hashed)
        else:
            logger.warning(f"Unknown hash format: {hashed[:10]}...")
            return False
    except Exception as e:
        logger.error(f"Password verification error: {e}")
        return False


def _hash_password_pbkdf2(password: str) -> str:
    """Fallback PBKDF2 hashing if bcrypt unavailable."""
    salt = secrets.token_bytes(32)
    iterations = 100000
    key = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, iterations)
    return f"pbkdf2$sha256${iterations}${salt.hex()}${key.hex()}"


def _verify_password_pbkdf2(password: str, hashed: str) -> bool:
    """Verify PBKDF2 hash."""
    try:
        parts = hashed.split('$')
        if len(parts) != 5 or parts[0] != 'pbkdf2' or parts[1] != 'sha256':
            return False
        iterations = int(parts[2])
        salt = bytes.fromhex(parts[3])
        key = bytes.fromhex(parts[4])
        new_key = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, iterations)
        return hmac.compare_digest(key, new_key)
    except Exception:
        return False


def needs_rehash(hashed: str) -> bool:
    """Check if a hash needs to be updated (legacy or weak work factor)."""
    if not hashed:
        return True
    if bcrypt is not None and hashed.startswith(('$2b$', '$2a$', '$2y$')):
        try:
            # Extract rounds from bcrypt hash
            rounds = int(hashed.split('$')[2])
            return rounds < BCRYPT_ROUNDS
        except Exception:
            return True
    # Legacy hash (SHA256 or PBKDF2)
    return True


def migrate_password_hash(password: str, old_hash: str) -> Optional[str]:
    """Migrate a legacy password hash to bcrypt if verification succeeds."""
    if verify_password(password, old_hash):
        return hash_password(password)
    return None


# --- Secure Token Generation ---

def generate_secure_token(length: int = 32) -> str:
    """Generate a cryptographically secure random token."""
    return secrets.token_urlsafe(length)


def generate_api_key(prefix: str = "lib") -> str:
    """Generate an API key with prefix."""
    return f"{prefix}_{secrets.token_urlsafe(32)}"


def generate_recovery_codes(count: int = 10, length: int = 8) -> List[str]:
    """Generate secure recovery codes."""
    return [secrets.token_hex(length // 2).upper() for _ in range(count)]


def generate_otp(digits: int = 6) -> str:
    """Generate a numeric OTP (for LAN sync only - prefer TOTP)."""
    return ''.join(secrets.choice('0123456789') for _ in range(digits))


# --- Encryption for Sensitive Config ---

class ConfigEncryption:
    """Encrypt/decrypt sensitive configuration values using Fernet (AES-128-GCM)."""
    
    def __init__(self, key: Optional[bytes] = None):
        self._key = key or self._derive_key()
        try:
            from cryptography.fernet import Fernet
            self._fernet = Fernet(self._key)
        except ImportError:
            self._fernet = None
            logger.warning("cryptography not available, config encryption disabled")
    
    def _derive_key(self) -> bytes:
        """Derive encryption key from app secret."""
        if current_app and current_app.config.get('SECRET_KEY'):
            secret = current_app.config['SECRET_KEY'].encode()
        else:
            secret = os.environ.get('FLASK_SECRET_KEY', 'fallback-secret').encode()
        return base64.urlsafe_b64encode(hashlib.sha256(secret).digest()[:32])
    
    def encrypt(self, value: str) -> str:
        """Encrypt a string value."""
        if self._fernet is None:
            return value  # No encryption if library unavailable
        if not value:
            return value
        return self._fernet.encrypt(value.encode()).decode()
    
    def decrypt(self, value: str) -> str:
        """Decrypt a string value."""
        if self._fernet is None:
            return value
        if not value:
            return value
        try:
            return self._fernet.decrypt(value.encode()).decode()
        except Exception:
            logger.warning("Failed to decrypt config value")
            return value


import base64
_config_encryption = None

def get_config_encryption() -> ConfigEncryption:
    global _config_encryption
    if _config_encryption is None:
        _config_encryption = ConfigEncryption()
    return _config_encryption


def encrypt_config_value(value: str) -> str:
    """Encrypt a sensitive configuration value."""
    return get_config_encryption().encrypt(value)


def decrypt_config_value(value: str) -> str:
    """Decrypt a sensitive configuration value."""
    return get_config_encryption().decrypt(value)


# --- Input Validation & Sanitization ---

class InputValidator:
    """Validate and sanitize user inputs."""
    
    # Allowlist patterns
    USERNAME_PATTERN = r'^[a-zA-Z0-9_-]{3,50}$'
    EMAIL_PATTERN = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    SAFE_STRING_PATTERN = r'^[a-zA-Z0-9\s\-_.,()\[\]{}:;@!?/\\\'"]{0,500}$'
    BOOK_ID_PATTERN = r'^[a-zA-Z0-9\-/]{1,100}$'
    CLASS_NAME_PATTERN = r'^[a-zA-Z0-9\s\-_]{1,50}$'
    
    @classmethod
    def validate_username(cls, username: str) -> Tuple[bool, str]:
        """Validate username format."""
        import re
        if not username or not isinstance(username, str):
            return False, "Username is required"
        username = username.strip()
        if len(username) < 3 or len(username) > 50:
            return False, "Username must be 3-50 characters"
        if not re.match(cls.USERNAME_PATTERN, username):
            return False, "Username may only contain letters, numbers, underscore, and hyphen"
        return True, username
    
    @classmethod
    def validate_email(cls, email: str) -> Tuple[bool, str]:
        """Validate email format."""
        import re
        if not email:
            return True, ""  # Optional field
        email = email.strip().lower()
        if not re.match(cls.EMAIL_PATTERN, email):
            return False, "Invalid email format"
        if len(email) > 120:
            return False, "Email too long"
        return True, email
    
    @classmethod
    def validate_password(cls, password: str, confirm: str = None) -> Tuple[bool, str]:
        """Validate password strength."""
        if not password:
            return False, "Password is required"
        if len(password) < MIN_PASSWORD_LENGTH:
            return False, f"Password must be at least {MIN_PASSWORD_LENGTH} characters"
        if len(password) > MAX_PASSWORD_LENGTH:
            return False, f"Password must not exceed {MAX_PASSWORD_LENGTH} characters"
        if confirm is not None and password != confirm:
            return False, "Passwords do not match"
        # Check for basic complexity
        has_upper = any(c.isupper() for c in password)
        has_lower = any(c.islower() for c in password)
        has_digit = any(c.isdigit() for c in password)
        has_special = any(c in '!@#$%^&*()_+-=[]{}|;:,.<>?' for c in password)
        if not (has_upper and has_lower and has_digit and has_special):
            return False, "Password must contain uppercase, lowercase, number, and special character"
        return True, password
    
    @classmethod
    def sanitize_string(cls, value: str, max_length: int = 500, allow_html: bool = False) -> str:
        """Sanitize a string for safe storage/display."""
        if not value or not isinstance(value, str):
            return ""
        value = value.strip()
        if len(value) > max_length:
            value = value[:max_length]
        if not allow_html:
            # Basic HTML entity encoding for safety
            value = value.replace('&', '&').replace('<', '<').replace('>', '>')
            value = value.replace('"', '"').replace("'", "&apos;")
        return value
    
    @classmethod
    def validate_book_id(cls, book_id: str) -> Tuple[bool, str]:
        """Validate book ID format."""
        import re
        if not book_id or not isinstance(book_id, str):
            return False, "Book ID is required"
        book_id = book_id.strip()
        if not re.match(cls.BOOK_ID_PATTERN, book_id):
            return False, "Invalid book ID format"
        return True, book_id
    
    @classmethod
    def validate_class_name(cls, class_name: str) -> Tuple[bool, str]:
        """Validate class name format."""
        import re
        if not class_name or not isinstance(class_name, str):
            return False, "Class name is required"
        class_name = class_name.strip().upper()
        if not re.match(cls.CLASS_NAME_PATTERN, class_name):
            return False, "Invalid class name format"
        return True, class_name


# --- Authorization Decorators ---

def require_admin(f):
    """Decorator to require admin role."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user or not current_user.is_authenticated:
            abort(401)
        if not getattr(current_user, 'role', '') in ('admin', 'owner'):
            abort(403)
        return f(*args, **kwargs)
    return decorated_function


def require_school_access(school_id_param: str = 'school_id'):
    """Decorator to verify user has access to the specified school."""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user or not current_user.is_authenticated:
                abort(401)
            
            requested_school_id = kwargs.get(school_id_param)
            if requested_school_id is None:
                requested_school_id = request.args.get(school_id_param) or request.form.get(school_id_param)
            
            if requested_school_id is not None:
                try:
                    requested_school_id = int(requested_school_id)
                except (ValueError, TypeError):
                    abort(400, "Invalid school ID")
                
                user_school_id = getattr(current_user, 'school_id', None)
                if user_school_id != requested_school_id and getattr(current_user, 'role', '') != 'owner':
                    abort(403, "Access denied: school mismatch")
            
            return f(*args, **kwargs)
        return decorated_function
    return decorator


def rate_limit(max_requests: int = 60, window_seconds: int = 60, key_func=None):
    """Simple in-memory rate limiter (use Redis in production)."""
    from collections import defaultdict
    import time
    
    requests = defaultdict(list)
    
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if key_func:
                key = key_func()
            else:
                key = request.remote_addr if request else 'unknown'
            
            now = time.time()
            # Clean old entries
            requests[key] = [t for t in requests[key] if now - t < window_seconds]
            
            if len(requests[key]) >= max_requests:
                abort(429, "Rate limit exceeded")
            
            requests[key].append(now)
            return f(*args, **kwargs)
        return decorated_function
    return decorator


# --- Security Headers ---

def add_security_headers(response):
    """Add security headers to response."""
    # Content Security Policy
    response.headers['Content-Security-Policy'] = (
        "default-src 'self'; "
        "script-src 'self' 'unsafe-inline' 'unsafe-eval'; "
        "style-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com; "
        "font-src 'self' https://cdnjs.cloudflare.com data:; "
        "img-src 'self' data: https:; "
        "connect-src 'self'; "
        "frame-ancestors 'none'; "
        "base-uri 'self'; "
        "form-action 'self'"
    )
    
    # Other security headers
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
    response.headers['Permissions-Policy'] = 'geolocation=(), microphone=(), camera=()'
    
    # HSTS (only if HTTPS)
    if request and request.is_secure:
        response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
    
    return response


# --- Secure File Upload ---

ALLOWED_IMAGE_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp', 'svg'}
ALLOWED_IMAGE_MIME_TYPES = {
    'image/png', 'image/jpeg', 'image/gif', 'image/webp', 'image/svg+xml'
}
MAX_UPLOAD_SIZE = 5 * 1024 * 1024  # 5MB

def validate_image_upload(file_storage) -> Tuple[bool, str, Optional[str]]:
    """
    Validate an uploaded image file.
    Returns: (is_valid, error_message, safe_filename)
    """
    if not file_storage or not file_storage.filename:
        return False, "No file provided", None
    
    filename = file_storage.filename
    if not filename or '.' not in filename:
        return False, "Invalid filename", None
    
    ext = filename.rsplit('.', 1)[1].lower()
    if ext not in ALLOWED_IMAGE_EXTENSIONS:
        return False, f"File type not allowed. Allowed: {', '.join(ALLOWED_IMAGE_EXTENSIONS)}", None
    
    # Check content type
    content_type = file_storage.content_type or ''
    if content_type not in ALLOWED_IMAGE_MIME_TYPES:
        return False, "Invalid file content type", None
    
    # Check file size (seek to end)
    file_storage.seek(0, os.SEEK_END)
    size = file_storage.tell()
    file_storage.seek(0)
    
    if size > MAX_UPLOAD_SIZE:
        return False, f"File too large. Maximum size: {MAX_UPLOAD_SIZE // (1024*1024)}MB", None
    
    if size == 0:
        return False, "Empty file", None
    
    # Generate safe filename
    safe_name = f"{secrets.token_urlsafe(16)}.{ext}"
    return True, "", safe_name


def validate_backup_file(file_storage) -> Tuple[bool, str]:
    """Validate an uploaded backup file."""
    if not file_storage or not file_storage.filename:
        return False, "No file provided"
    
    filename = file_storage.filename
    if not filename.endswith('.json'):
        return False, "Backup file must be a JSON file"
    
    # Check size (max 50MB for backups)
    file_storage.seek(0, os.SEEK_END)
    size = file_storage.tell()
    file_storage.seek(0)
    
    if size > 50 * 1024 * 1024:
        return False, "Backup file too large (max 50MB)"
    
    if size == 0:
        return False, "Empty file"
    
    return True, ""


# --- Audit Logging ---

def log_security_event(event_type: str, details: str, severity: str = 'info', user_id: Optional[int] = None):
    """Log a security-relevant event."""
    from flask import request
    
    log_data = {
        'event_type': event_type,
        'details': details,
        'severity': severity,
        'user_id': user_id or (current_user.id if current_user and current_user.is_authenticated else None),
        'ip': request.remote_addr if request else None,
        'user_agent': request.user_agent.string if request and request.user_agent else None,
        'timestamp': datetime.utcnow().isoformat(),
    }
    
    if severity in ('warning', 'error', 'critical'):
        logger.warning(f"SECURITY EVENT [{severity.upper()}]: {event_type} - {details}", extra=log_data)
    else:
        logger.info(f"SECURITY EVENT: {event_type} - {details}", extra=log_data)


# --- Session Security ---

def secure_session_config(app):
    """Configure secure session settings based on environment."""
    is_production = not app.debug and not app.testing
    is_electron = os.environ.get('ELECTRON_APP') == '1'
    
    app.config.update(
        SESSION_COOKIE_SECURE=is_production and not is_electron,  # False for Electron (localhost HTTP)
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE='Lax' if is_electron else 'Strict',
        SESSION_COOKIE_NAME='library_session',
        PERMANENT_SESSION_LIFETIME=timedelta(hours=8),
        SESSION_REFRESH_EACH_REQUEST=True,
    )
    
    # Generate strong secret if not set
    if not app.config.get('SECRET_KEY') or app.config['SECRET_KEY'] in ('strong_random_secret_key', 'dev-secret'):
        app.config['SECRET_KEY'] = secrets.token_urlsafe(32)
        logger.warning("Generated new SECRET_KEY - set FLASK_SECRET_KEY in production!")


# --- CORS Configuration ---

def configure_cors(app):
    """Configure CORS with restricted origins."""
    try:
        from flask_cors import CORS
        
        # Determine allowed origins
        allowed_origins = []
        
        # Electron app origin
        if os.environ.get('ELECTRON_APP') == '1':
            allowed_origins.append('http://localhost:5000')
            allowed_origins.append('http://127.0.0.1:5000')
        
        # Configured origins from env
        cors_origins = os.environ.get('CORS_ORIGINS', '')
        if cors_origins:
            allowed_origins.extend([o.strip() for o in cors_origins.split(',')])
        
        if not allowed_origins:
            # Default to same-origin only for security
            allowed_origins = []
        
        CORS(app, 
             origins=allowed_origins if allowed_origins else None,
             supports_credentials=True,
             allow_headers=['Content-Type', 'Authorization', 'X-Requested-With'],
             methods=['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
             max_age=3600)
        
    except ImportError:
        logger.warning("flask-cors not installed, skipping CORS configuration")


# Initialize security on app creation
def init_security(app):
    """Initialize all security features for the Flask app."""
    secure_session_config(app)
    configure_cors(app)
    
    # Add security headers to all responses
    app.after_request(add_security_headers)
    
    # Log security events
    @app.before_request
    def log_request():
        if request.path.startswith('/api/') or request.path in ('/login', '/auth/login'):
            log_security_event('api_access', f'{request.method} {request.path}', 'info')
    
    logger.info("Security initialization complete")
