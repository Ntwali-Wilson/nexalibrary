from werkzeug.exceptions import HTTPException
from flask import Blueprint, render_template, request, flash, redirect, url_for, jsonify, current_app, send_file
from flask_login import login_required, current_user,logout_user
from datetime import UTC, datetime, timedelta
import logging
import threading
import time
from functools import wraps
from itertools import groupby
from operator import attrgetter

logger = logging.getLogger(__name__)

try:
    import pandas as pd
except ImportError:
    pd = None

import csv

import os
import json
import random
import string
import secrets
import subprocess
import requests
import sys
import time
from packaging import version
from io import BytesIO
from werkzeug.utils import secure_filename
from flask import send_from_directory, session
from sqlalchemy import or_, func


# ReportLab Imports
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet

from .database import (
    Admin,
    Announcement,
    Book,
    BookIssue,
    BorrowedBook,
    ClassBorrowing,
    GraduateBorrowing,
    GraduateClassBorrowing,
    Log,
    Note,
    PeerSession,
    PeerSyncLog,
    PeerSyncQueue,  
    School,
    Student,
    SyncConflict,
    SyncMetadata,
    SyncQueue,
    TeacherBorrowedBook,
    UpdateHistory,
    db,
    utc_now,
)
from .auth import unique_school_slug
from .utils import (
    BACKUP_DIR,
    hash_pw,
    verify_pw,
    is_admin_role,
    load_config,
    normalize_analytics_settings,
    normalize_role,
    get_analytics_period_bounds,
    normalize_analytics_date,
    role_label,
    safe_percentage,
    save_config,
    safe_commit,
    safe_rollback,
    validate_image_upload,
    validate_backup_file,
    InputValidator,
    rate_limit,
    expand_unique_ids,
    check_unnamed_excel_columns,
    build_grouped_catalog_export,
    build_pdf_table,
)
from .translations import translate, _

if not hasattr(Student, 'class_name'):
    Student.class_name = Student.student_class

main = Blueprint('main', __name__)

VERSION = "1.0.0"
UPDATE_URL = "https://raw.githubusercontent.com/Ntwali-Wilson/nexalibrary/main/version.json"

# ============================================================================
# SECURITY: Input Validation
# ===========================================================================

def validate_json_schema(schema: dict):
    """
    Decorator to validate JSON request against a schema.
    Schema format: {'field_name': {'type': 'str', 'required': True, 'max_length': 100}}
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not request.is_json:
                return jsonify({"success": False, "message": "Content-Type must be application/json"}), 400
            
            data = request.get_json(silent=True) or {}
            
            for field, rules in schema.items():
                required = rules.get('required', False)
                field_type = rules.get('type', 'str')
                max_length = rules.get('max_length')
                allowed_values = rules.get('allowed_values')
                
                value = data.get(field)
                
                if required and (value is None or value == ''):
                    return jsonify({"success": False, "message": f"Missing required field: {field}"}), 400
                
                if value is not None:
                    # Type check
                    if field_type == 'str' and not isinstance(value, str):
                        return jsonify({"success": False, "message": f"Field {field} must be a string"}), 400
                    elif field_type == 'int' and not isinstance(value, int):
                        try:
                            value = int(value)
                        except (ValueError, TypeError):
                            return jsonify({"success": False, "message": f"Field {field} must be an integer"}), 400
                    elif field_type == 'bool' and not isinstance(value, bool):
                        return jsonify({"success": False, "message": f"Field {field} must be a boolean"}), 400
                    
                    # Length check
                    if max_length and isinstance(value, str) and len(value) > max_length:
                        return jsonify({"success": False, "message": f"Field {field} exceeds maximum length of {max_length}"}), 400
                    
                    # Allowed values check
                    if allowed_values and value not in allowed_values:
                        return jsonify({"success": False, "message": f"Field {field} has invalid value"}), 400
                    
                    # Security checks
                    if isinstance(value, str):
                        if InputValidator.detect_sql_injection(value):
                            current_app.logger.warning(f"SQL injection attempt detected in field {field}: {value[:50]}")
                            return jsonify({"success": False, "message": "Invalid input detected"}), 400
                        if InputValidator.detect_xss(value):
                            current_app.logger.warning(f"XSS attempt detected in field {field}: {value[:50]}")
                            return jsonify({"success": False, "message": "Invalid input detected"}), 400
            
            return f(*args, **kwargs)
        return decorated_function
    return decorator


# ============================================================================
# GLOBAL CONTEXT
# ============================================================================
# This allows {{ config.theme }} or {{ config.auto_lock_minutes }} to work in ALL templates
# 1. Inject the new background flags into all templates
@main.app_context_processor
def inject_globals():
    sys_config = load_config()
    try:
        session['lang'] = sys_config.get('language', 'en')
    except Exception:
        pass

    return dict(
        current_version=VERSION,
        is_admin_role=is_admin_role,
        role_label=role_label,
        sys_config=sys_config,
        _=translate,
        # NEW: Inject update flags for UI banners
        update_ready=sys_config.get('update_ready', False),
        update_version=sys_config.get('update_version', ''),
        update_changelog=sys_config.get('update_changelog', [])
    )   

@main.before_app_request
def enforce_superadmin_directives():
    # 1. Expand whitelist to let ALL auth/registration routes bypass the lockdown
    if request.path.startswith('/static') or request.path.startswith('/auth') or request.path in ['/welcome', '/oneauth/welcome/register', '/system/health']:
        return
        
    # 2. Enforce Account Suspensions
    if current_user.is_authenticated and getattr(current_user, 'deleted', False):
        from flask_login import logout_user
        logout_user()
        flash("Your account has been suspended by the platform administrator.", "danger")
        return redirect(url_for('auth.login'))

    # 3. Enforce System Lockdown (ONLY IF AUTHENTICATED)
    if current_user.is_authenticated:
        from app.utils import load_config
        config = load_config()
        directive = config.get('sa_directive', 'none')
        
        if directive in ['lockdown', 'wipe']:
            # Block ALL data modification (POST requests)
            if request.method == 'POST':
                if wants_json_response():
                    return jsonify({"success": False, "message": "System is currently locked by the Super Admin."}), 403
                flash("System is currently locked. Actions are disabled.", "danger")
                return redirect(url_for('main.dashboard'))

# --- HELPER: LOGGING ---
def log_action(route, method, details, status_code=200):
    try:
        now = datetime.now(UTC).replace(tzinfo=None)

        # Safe username resolution
        username = "System"
        librarian_username = None
        try:
            if current_user and getattr(current_user, 'is_authenticated', False):
                username = getattr(current_user, 'username', 'System')
                librarian_username = username
        except Exception:
            pass

        # Safe route resolution
        resolved_route = "system"
        if route:
            resolved_route = route
        else:
            try:
                resolved_route = request.path or "system"
            except Exception:
                pass

        # Safe method resolution
        resolved_method = "SYSTEM"
        if method:
            resolved_method = method
        else:
            try:
                resolved_method = request.method or "SYSTEM"
            except Exception:
                pass

        new_log = Log(
            username=username,
            librarian_username=librarian_username,
            route=resolved_route[:255],
            method=resolved_method[:20],
            status_code=status_code or 200,
            details=details,
            timestamp=now.strftime("%Y-%m-%d %H:%M:%S"),
            created_at=now,
            school_id=get_current_school_id(),
            sync_status='pending',
            updated_at=now,
        )
        db.session.add(new_log)
        db.session.flush()
        queue_record_change('logs', new_log, operation='upsert')
        safe_commit()
    except Exception as exc:
        safe_rollback()
        current_app.logger.warning("Failed to save audit log: %s", exc)


def get_current_school_id():
    try:
        if current_user and getattr(current_user, 'is_authenticated', False) and getattr(current_user, 'school_id', None):
            return current_user.school_id
    except Exception:
        pass

    return None


def school_query(model, include_deleted=False):
    query = model.query
    school_id = get_current_school_id()
    if hasattr(model, 'school_id') and school_id is not None:
        query = query.filter(model.school_id == school_id)
    if hasattr(model, 'deleted') and not include_deleted:
        query = query.filter(model.deleted == False)
    return query


def school_get(model, record_id, pk_name='id', include_deleted=False):
    query = school_query(model, include_deleted=include_deleted)
    return query.filter(getattr(model, pk_name) == record_id).first()


def school_get_or_404(model, record_id, pk_name='id', include_deleted=False):
    record = school_get(model, record_id, pk_name=pk_name, include_deleted=include_deleted)
    if record is None:
        from flask import abort
        abort(404)
    return record


def current_role(user=None):
    return normalize_role(getattr(user or current_user, 'role', 'admin'))


def is_admin(user=None):
    return current_role(user) == 'admin'


def can_manage_librarians(user=None):
    return is_admin(user)


def can_clear_logs(user=None):
    return is_admin(user)


def wants_json_response():
    if request.is_json:
        return True
    best = request.accept_mimetypes.best
    if not best:
        return False
    return request.accept_mimetypes[best] >= request.accept_mimetypes['text/html'] and best == 'application/json'


def serialize_librarian(librarian):
    return {
        "id": librarian.id,
        "username": librarian.username,
        "role": current_role(librarian),
        "role_label": role_label(librarian.role),
        "school_id": librarian.school_id,
        "email": librarian.email1 or librarian.email2 or librarian.email3,
        "deleted": bool(getattr(librarian, "deleted", False)),
    }


def admin_access_denied(message="Only an admin can access librarian management."):
    if wants_json_response():
        return jsonify({"success": False, "message": message}), 403
    flash(message, "danger")
    return redirect(url_for('main.profile'))


def get_sync_service():
    return current_app.extensions.get('sync_service')


def stamp_sync_fields(record, deleted=False):
    school_id = get_current_school_id()
    if hasattr(record, 'school_id') and not getattr(record, 'school_id', None):
        record.school_id = school_id
    if hasattr(record, 'updated_at'):
        record.updated_at = datetime.now(UTC).replace(tzinfo=None)
    if hasattr(record, 'sync_status'):
        record.sync_status = 'pending'
    if hasattr(record, 'deleted') and deleted:
        record.deleted = True
    return record


def queue_record_change(entity_type, record, operation='upsert', payload=None):
    sync_service = get_sync_service()
    if not sync_service:
        return None

    try:
        payload = payload or sync_service.serialize_record(entity_type, record)
        payload.setdefault('school_id', get_current_school_id())

        entity_id = payload.get('book_id') or payload.get('id')

        # Queue for online sync
        result = sync_service.queue_change(
            entity_type=entity_type,
            entity_id=entity_id,
            operation=operation,
            payload=payload,
            school_id=payload.get('school_id'),
            record_updated_at=payload.get('updated_at'),
        )

        # Queue for online background cloud sync (Delta Event-Sourcing)
        try:
            config = sync_service.ENTITY_CONFIG.get(entity_type, {})
            table_name = config.get("table", entity_type)
            sync_service.push_to_cloud_sync_queue(
                table_name=table_name,
                record_id=entity_id,
                payload=payload,
                school_id=payload.get('school_id') or get_current_school_id()
            )
        except Exception as e:
            current_app.logger.error(f"Error queueing background cloud sync: {e}")

        # Queue for LAN peer sync
        try:
            import peer_sync
            from flask_login import current_user

            # Get the actual table name for backward compatibility
            config = sync_service.ENTITY_CONFIG.get(entity_type, {})
            table_name = config.get("table", entity_type)

            # Map upsert to update to not break older peers
            # Older peers only understand 'insert', 'update', 'delete'
            mapped_operation = operation
            if mapped_operation == 'upsert':
                mapped_operation = 'update'

            performed_by = current_user.username if current_user and current_user.is_authenticated else "system"
            peer_sync.queue(mapped_operation, table_name, entity_id, payload, performed_by=performed_by)
        except Exception as e:
            current_app.logger.error(f"Error queueing peer sync: {e}")

        return result
    except Exception as exc:
        safe_rollback()
        current_app.logger.warning("Failed to queue sync change for %s: %s", entity_type, exc)
        return None


_push_sync_lock = threading.Lock()

def safe_push_sync(limit=100, force=False):
    sync_service = get_sync_service()
    if not sync_service or not sync_service.is_configured():
        return

    school_id = get_current_school_id()
    if not force and not sync_service.should_upload_now(school_id=school_id):
        return

    # Avoid spawning a pile of overlapping background sync threads (e.g. one
    # per book in a bulk add) — only one push runs at a time.
    if not _push_sync_lock.acquire(blocking=False):
        return

    app = current_app._get_current_object()
    def background_sync(app, school_id, limit):
        try:
            with app.app_context():
                try:
                    sync_service.upload_pending_changes(
                        school_id=school_id,
                        limit=limit,
                    )
                except Exception as exc:
                    safe_rollback()
                    app.logger.warning("Deferred background sync push failed: %s", exc)
        finally:
            _push_sync_lock.release()

    threading.Thread(target=background_sync, args=(app, school_id, limit), daemon=True).start()

# --- HELPER: Generate Unique Numeric ID ---
def _register_no_id_books(title, author='Unknown', category='Uncategorized', qty=1):
    """Registers occasional book(s) without a physical copy ID into Book catalog with a NO-ID-XXXX/1..N key."""
    while True:
        code = ''.join(random.choices(string.digits, k=4))
        base_id = f"NO-ID-{code}"
        if not Book.query.filter(Book.book_id.like(f"{base_id}/%")).first():
            break
    now_str = datetime.now().strftime("%Y-%m-%d")
    created_ids = []
    created_books = []
    for i in range(1, max(1, int(qty)) + 1):
        fid = f"{base_id}/{i}"
        book = Book(
            book_id=fid,
            title=title.strip(),
            author=(author or 'Unknown').strip() or 'Unknown',
            category=(category or 'Uncategorized').strip() or 'Uncategorized',
            added_at=now_str,
        )
        stamp_sync_fields(book)
        db.session.add(book)
        created_books.append(book)
        created_ids.append(fid)
    db.session.flush()
    for b in created_books:
        queue_record_change('books', b, operation='upsert')
    return base_id, created_ids


def generate_unique_base_id():
    while True:
        nums = ''.join(random.choices(string.digits, k=8))
        formatted_id = f"{nums[:4]}-{nums[4:]}"
        exists = Book.query.filter(Book.book_id.like(f"{formatted_id}/%")).first()
        if not exists:
            return formatted_id

# --- HELPER: Parse Range String to Set of Integers ---
def parse_range_to_set(range_str):
    """Converts '1-5, 8' into set({1, 2, 3, 4, 5, 8}) (Integers only)"""
    res = set()
    if not range_str: return res

    # Split by comma first
    parts = range_str.split(',')
    for p in parts:
        p = p.strip()
        if not p: continue
        if '-' in p:
            try:
                # Handle cases like "1 - 5" or "1-5"
                start, end = map(int, p.split('-'))
                if start > end: start, end = end, start
                res.update(range(start, end + 1))
            except: pass
        else:
            try: res.add(int(p))
            except: pass
    return res


def normalize_unique_ids(range_str):
    """Normalize various user-entered unique id formats into a comma/range string.
    Handles inputs like:
      - "1,2,3"
      - "1-5"
      - "100-20/1,100-20/2" (strips base prefix)
      - "1;2;3" (treats semicolon as comma)
    Returns an empty string if nothing found.
    """
    if not range_str:
        return ''
    # Replace semicolons and whitespace around commas
    s = str(range_str).replace(';', ',')
    parts = [p.strip() for p in s.split(',') if p and p.strip()]
    out_parts = []
    for p in parts:
        # If full id like base/num, take numeric part
        if '/' in p:
            try:
                _, num = p.split('/', 1)
                out_parts.append(num.strip())
                continue
            except:
                pass
        out_parts.append(p)
    return ','.join(out_parts)

# --- HELPER: CHECK IF BOOK IS BORROWED ---
def is_book_active(book_id, school_id=None):
    """Returns True if book is currently in any active loan table."""
    school_id = school_id or get_current_school_id()
    # 1. Student Loans
    if school_query(BorrowedBook).filter_by(book_id=book_id, returned=False).first(): return True
    # 2. Staff Loans
    if school_query(TeacherBorrowedBook).filter_by(book_id=book_id, returned=False).first(): return True
    # 3. Graduate Debtors (Archived but still owed)
    for grad in school_query(GraduateBorrowing).filter_by(book_id=book_id).all():
        if not grad.notes or '[RETURNED]' not in str(grad.notes):
            return True

    # 4. Graduate Class Archives: check ranges (e.g., base/1-5)
    for class_archive in school_query(GraduateClassBorrowing).all():
        if class_archive.condition and '[RETURNED]' in str(class_archive.condition):
            continue
        try:
            if _book_id_in_range(book_id, class_archive.book_ids):
                return True
        except Exception:
            continue

    # 4. Class Loans (Complex Check)
    # This is resource intensive but necessary for strict safety
    all_class_loans = school_query(ClassBorrowing).filter_by(returned=False).all()
    for cl in all_class_loans:
        # Check if book_id is in this class loan range
        # Format of cl.book_ids is "base/range" (e.g. "100-20/1-50")
        # Format of book_id is "base/id" (e.g. "100-20/5")
        try:
            cl_base, cl_range = cl.book_ids.split('/')
            b_base, b_num = book_id.split('/')

            if cl_base == b_base:
                # Parse range to see if number is included
                # We reuse a simplified logic here:
                for part in cl_range.split(','):
                    if '-' in part:
                        s, e = map(int, part.split('-'))
                        if s <= int(b_num) <= e: return True
                    elif int(part) == int(b_num): return True
        except:
            continue

    return False

def _book_id_in_range(book_id, loan_range):
    try:
        if '/' not in (book_id or '') or '/' not in (loan_range or ''):
            return False
        loan_base, loan_numbers = loan_range.split('/', 1)
        book_base, book_number = book_id.split('/', 1)
        if loan_base != book_base:
            return False
        return int(book_number) in parse_range_to_set(loan_numbers)
    except Exception:
        return False

def _borrowed_tab_url(tab, book_id):
    return url_for('main.borrowed', tab=tab, book_id=book_id) + f"#{tab}"

def get_book_status_info(book_id):
    student_loan = school_query(BorrowedBook).filter_by(book_id=book_id, returned=False).first()
    if student_loan:
        return {
            'label': 'Unavailable',
            'detail': f"Student: {student_loan.student_name}",
            'tone': 'danger',
            'url': _borrowed_tab_url('students', book_id),
            'search_text': 'unavailable borrowed student',
        }

    staff_loan = school_query(TeacherBorrowedBook).filter_by(book_id=book_id, returned=False).first()
    if staff_loan:
        return {
            'label': 'Unavailable',
            'detail': f"Staff: {staff_loan.teacher_name}",
            'tone': 'danger',
            'url': _borrowed_tab_url('staff', book_id),
            'search_text': 'unavailable borrowed staff teacher',
        }

    graduate_loan = school_query(GraduateBorrowing).filter_by(book_id=book_id).first()
    if graduate_loan and not (graduate_loan.notes and str(graduate_loan.notes).startswith('[RETURNED]')):
        return {
            'label': 'Unavailable',
            'detail': f"Graduate archive: {graduate_loan.student_name}",
            'tone': 'warning',
            'url': _borrowed_tab_url('graduates', book_id),
            'search_text': 'unavailable borrowed graduate archive archived',
        }

    for class_loan in school_query(ClassBorrowing).filter_by(returned=False).all():
        if _book_id_in_range(book_id, class_loan.book_ids):
            return {
                'label': 'Unavailable',
                'detail': f"Class: {class_loan.class_name}",
                'tone': 'danger',
                'url': _borrowed_tab_url('classes', book_id),
                'search_text': 'unavailable borrowed class',
            }

    for class_archive in school_query(GraduateClassBorrowing).all():
        if _book_id_in_range(book_id, class_archive.book_ids) and not (class_archive.condition and str(class_archive.condition).startswith('[RETURNED]')):
            return {
                'label': 'Unavailable',
                'detail': f"Class archive: {class_archive.class_name}",
                'tone': 'warning',
                'url': _borrowed_tab_url('archived_classes', book_id),
                'search_text': 'unavailable class archive archived',
            }

    pending_issues = school_query(BookIssue).filter(BookIssue.status != 'Resolved').all()
    for issue in pending_issues:
        linked_book_id = None
        if issue.loan_type == 'student':
            loan = school_get(BorrowedBook, issue.loan_id)
            linked_book_id = loan.book_id if loan else None
        elif issue.loan_type == 'staff':
            loan = school_get(TeacherBorrowedBook, issue.loan_id)
            linked_book_id = loan.book_id if loan else None
        elif issue.loan_type == 'graduate':
            loan = school_get(GraduateBorrowing, issue.loan_id)
            linked_book_id = loan.book_id if loan else None
        elif issue.loan_type == 'class':
            loan = school_get(ClassBorrowing, issue.loan_id)
            if loan and _book_id_in_range(book_id, loan.book_ids):
                linked_book_id = book_id

        if linked_book_id == book_id:
            return {
                'label': 'Available',
                'detail': 'Pending issue',
                'tone': 'warning',
                'url': _borrowed_tab_url('issues', book_id),
                'search_text': 'available issue damaged repair pending',
            }

    return {
        'label': 'Available',
        'detail': 'Ready to borrow',
        'tone': 'success',
        'url': '',
        'search_text': 'available ready',
    }

def get_book_status_info_fast(book_id, student_loans_dict, staff_loans_dict, graduate_loans_dict, class_loans_list, graduate_class_loans_list, pending_issues_list, student_loans_issues, staff_loans_issues, grad_loans_issues, class_loans_issues):
    student_loan = student_loans_dict.get(book_id)
    if student_loan:
        return {
            'label': 'Unavailable',
            'detail': f"Student: {student_loan.student_name}",
            'tone': 'danger',
            'url': _borrowed_tab_url('students', book_id),
            'search_text': 'unavailable borrowed student',
        }

    staff_loan = staff_loans_dict.get(book_id)
    if staff_loan:
        return {
            'label': 'Unavailable',
            'detail': f"Staff: {staff_loan.teacher_name}",
            'tone': 'danger',
            'url': _borrowed_tab_url('staff', book_id),
            'search_text': 'unavailable borrowed staff teacher',
        }

    graduate_loan = graduate_loans_dict.get(book_id)
    if graduate_loan and not (graduate_loan.notes and str(graduate_loan.notes).startswith('[RETURNED]')):
        return {
            'label': 'Unavailable',
            'detail': f"Graduate archive: {graduate_loan.student_name}",
            'tone': 'warning',
            'url': _borrowed_tab_url('graduates', book_id),
            'search_text': 'unavailable borrowed graduate archive archived',
        }

    for class_loan in class_loans_list:
        if _book_id_in_range(book_id, class_loan.book_ids):
            return {
                'label': 'Unavailable',
                'detail': f"Class: {class_loan.class_name}",
                'tone': 'danger',
                'url': _borrowed_tab_url('classes', book_id),
                'search_text': 'unavailable borrowed class',
            }

    for class_archive in graduate_class_loans_list:
        if _book_id_in_range(book_id, class_archive.book_ids) and not (class_archive.condition and str(class_archive.condition).startswith('[RETURNED]')):
            return {
                'label': 'Unavailable',
                'detail': f"Class archive: {class_archive.class_name}",
                'tone': 'warning',
                'url': _borrowed_tab_url('archived_classes', book_id),
                'search_text': 'unavailable class archive archived',
            }

    for issue in pending_issues_list:
        linked_book_id = None
        if issue.loan_type == 'student':
            linked_book_id = student_loans_issues.get(issue.loan_id)
        elif issue.loan_type == 'staff':
            linked_book_id = staff_loans_issues.get(issue.loan_id)
        elif issue.loan_type == 'graduate':
            linked_book_id = grad_loans_issues.get(issue.loan_id)
        elif issue.loan_type == 'class':
            loan_book_ids = class_loans_issues.get(issue.loan_id)
            if loan_book_ids and _book_id_in_range(book_id, loan_book_ids):
                linked_book_id = book_id

        if linked_book_id == book_id:
            return {
                'label': 'Available',
                'detail': 'Pending issue',
                'tone': 'warning',
                'url': _borrowed_tab_url('issues', book_id),
                'search_text': 'available issue damaged repair pending',
            }

    return {
        'label': 'Available',
        'detail': 'Ready to borrow',
        'tone': 'success',
        'url': '',
        'search_text': 'available ready',
    }

# --- HELPER: Convert Set back to Range String ---
def set_to_range_string(num_set):
    """Converts set({1,2,3,5}) into '1-3, 5'"""
    if not num_set: return ""
    sorted_nums = sorted(list(num_set))
    ranges = []
    start = sorted_nums[0]
    prev = sorted_nums[0]

    for x in sorted_nums[1:]:
        if x == prev + 1:
            prev = x
        else:
            ranges.append(f"{start}-{prev}" if start != prev else f"{start}")
            start = x
            prev = x
    ranges.append(f"{start}-{prev}" if start != prev else f"{start}")
    return ", ".join(ranges)

# --- DASHBOARD ---
@main.route('/')
@login_required
def dashboard():
    # First-time visitors / unauthenticated users go to welcome page
    if not current_user.is_authenticated:
        return redirect('/welcome')
    books_q = school_query(Book)
    students_q = school_query(Student)
    student_loans_q = school_query(BorrowedBook)
    staff_loans_q = school_query(TeacherBorrowedBook)
    class_loans_q = school_query(ClassBorrowing)
    announcements = Announcement.query.order_by(Announcement.created_at.desc()).limit(5).all()

    total_books = books_q.count()
    total_students = students_q.count()
    
    # Active Loans
    student_loans = student_loans_q.filter_by(returned=False).count()
    staff_loans = staff_loans_q.filter_by(returned=False).count()
    # Class loans should count the total quantity (e.g., a class borrowing 10 books counts as 10)
    class_loans = 0
    for cl in class_loans_q.filter_by(returned=False).all():
        try:
            class_loans += int(getattr(cl, 'quantity', 0) or 0)
        except:
            class_loans += 0
    active_loans = student_loans + staff_loans + class_loans

    # Calculate Overdue (Simple logic: Due date < Today)
    today_str = datetime.now().strftime("%Y-%m-%d")
    overdue_count = student_loans_q.filter(BorrowedBook.returned==False, BorrowedBook.due_date < today_str).count()

    # Recent Activity (Combined)
    recent_activities = []
    
    # Fetch last 3 from each category to mix
    r_students = student_loans_q.order_by(BorrowedBook.timestamp.desc()).limit(3).all()
    r_staff = staff_loans_q.order_by(TeacherBorrowedBook.timestamp.desc()).limit(3).all()

    for item in r_students:
        recent_activities.append({
            'user': item.student_name, 'type': 'Student', 'book': item.book_title, 'time': item.timestamp, 'status': 'Returned' if item.returned else 'Borrowed'
        })
    for item in r_staff:
        recent_activities.append({
            'user': item.teacher_name, 'type': 'Staff', 'book': item.book_title, 'time': item.timestamp, 'status': 'Returned' if item.returned else 'Borrowed'
        })

    # Sort by time
    recent_activities.sort(key=lambda x: x['time'], reverse=True)

    return render_template('dashboard.html', 
                         total_books=total_books, 
                         total_students=total_students, 
                         active_loans=active_loans,
                         overdue_count=overdue_count,
                         recent_activities=recent_activities[:6],
                         announcements=announcements) # Show top 6 mixed


@main.route('/admin')
@login_required
def admin_home():
    if not can_manage_librarians():
        return admin_access_denied()
    return redirect(url_for('main.admin_librarians'))

# --- ANALYTICS DASHBOARD ---
def get_analytics_data():

    config = load_config()
    analytics_settings = normalize_analytics_settings(config.get('analytics_settings'))

    school_id = get_current_school_id()
    school = db.session.get(School, school_id) if school_id else None
    books_q = school_query(Book)
    students_q = school_query(Student)
    librarians_q = school_query(Admin)
    student_loans_q = school_query(BorrowedBook)
    staff_loans_q = school_query(TeacherBorrowedBook)
    class_loans_q = school_query(ClassBorrowing)
    logs_q = school_query(Log)

    total_books = books_q.count()

    total_students = students_q.count()
    total_teachers = 0
    total_borrowers = total_students + total_teachers

    total_users = students_q.count()

    total_librarians = librarians_q.count()

    active_student_loans = student_loans_q.filter_by(returned=False).count()
    active_staff_loans = staff_loans_q.filter_by(returned=False).count()
    class_loans = class_loans_q.filter_by(returned=False).all()
    active_class_quantity = sum(int(getattr(item, 'quantity', 0) or 0) for item in class_loans)
    active_loans = active_student_loans + active_staff_loans + active_class_quantity
    available_books = max(total_books - active_loans, 0)

    total_borrowed = student_loans_q.count() + staff_loans_q.count()
    total_returns = student_loans_q.filter_by(returned=True).count() + staff_loans_q.filter_by(returned=True).count()

    return_rate = safe_percentage(total_returns, total_borrowed)
    avg_books = round(active_loans / total_students, 2) if total_students else 0

    today_str = datetime.now().strftime("%Y-%m-%d")
    overdue_count = student_loans_q.filter(BorrowedBook.returned == False, BorrowedBook.due_date < today_str).count()
    active_borrowers = student_loans_q.with_entities(db.func.count(db.func.distinct(BorrowedBook.student_name))).filter(BorrowedBook.returned == False).scalar() or 0
    overdue_percentage = safe_percentage(overdue_count, active_borrowers)

    period = request.args.get('period', analytics_settings.get('date_range', 'month'))
    year = request.args.get('year') or str(datetime.now().year)
    month = request.args.get('month') or str(datetime.now().month)
    day = request.args.get('day')
    class_filter = request.args.get('class')
    category_filter = request.args.get('category')
    borrower_type = request.args.get('borrower_type')
    borrower = request.args.get('borrower')
    librarian = request.args.get('librarian')

    start_date, end_date = get_analytics_period_bounds(period, year=year, month=month, day=day)

    student_loans_q = student_loans_q.filter(BorrowedBook.timestamp >= start_date) if period != 'all' else student_loans_q
    staff_loans_q = staff_loans_q.filter(TeacherBorrowedBook.timestamp >= start_date) if period != 'all' else staff_loans_q
    class_loans_q = class_loans_q.filter(ClassBorrowing.borrow_time >= start_date) if period != 'all' else class_loans_q

    if period in {'day', 'week', 'month', 'year', 'range'} and end_date:
        student_loans_q = student_loans_q.filter(BorrowedBook.timestamp <= end_date)
        staff_loans_q = staff_loans_q.filter(TeacherBorrowedBook.timestamp <= end_date)
        class_loans_q = class_loans_q.filter(ClassBorrowing.borrow_time <= end_date)

    if class_filter:
        student_loans_q = student_loans_q.filter(BorrowedBook.student_class == class_filter)
    if category_filter:
        student_loans_q = student_loans_q.filter(BorrowedBook.book_title.isnot(None))
    if borrower_type:
        if borrower_type == 'students':
            student_loans_q = student_loans_q.filter(BorrowedBook.student_name.isnot(None))
        elif borrower_type == 'teachers':
            staff_loans_q = staff_loans_q.filter(TeacherBorrowedBook.teacher_name.isnot(None))
    if borrower:
        student_loans_q = student_loans_q.filter(BorrowedBook.student_name == borrower)
        staff_loans_q = staff_loans_q.filter(TeacherBorrowedBook.teacher_name == borrower)
    if librarian:
        student_loans_q = student_loans_q.filter(BorrowedBook.performed_by == librarian)
        staff_loans_q = staff_loans_q.filter(TeacherBorrowedBook.teacher_name == librarian)

    active_student_loans = student_loans_q.filter_by(returned=False).count()
    active_staff_loans = staff_loans_q.filter_by(returned=False).count()
    class_loans = class_loans_q.filter_by(returned=False).all()
    active_class_quantity = sum(int(getattr(item, 'quantity', 0) or 0) for item in class_loans)
    active_loans = active_student_loans + active_staff_loans + active_class_quantity
    available_books = max(total_books - active_loans, 0)

    total_borrowed = student_loans_q.count() + staff_loans_q.count()
    total_returns = student_loans_q.filter_by(returned=True).count() + staff_loans_q.filter_by(returned=True).count()
    return_rate = safe_percentage(total_returns, total_borrowed)
    borrowed_today = student_loans_q.filter(BorrowedBook.timestamp >= today_str).count() + staff_loans_q.filter(TeacherBorrowedBook.timestamp >= today_str).count()
    borrowed_week = student_loans_q.filter(BorrowedBook.timestamp >= (datetime.now() - timedelta(days=7)).strftime('%Y-%m-%d')).count() + staff_loans_q.filter(TeacherBorrowedBook.timestamp >= (datetime.now() - timedelta(days=7)).strftime('%Y-%m-%d')).count()
    borrowed_month = student_loans_q.filter(BorrowedBook.timestamp >= (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')).count() + staff_loans_q.filter(TeacherBorrowedBook.timestamp >= (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')).count()
    returns_today = student_loans_q.filter(BorrowedBook.returned == True, BorrowedBook.return_date >= today_str).count() + staff_loans_q.filter(TeacherBorrowedBook.returned == True).count()
    returns_month = student_loans_q.filter(BorrowedBook.returned == True, BorrowedBook.return_date >= (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')).count()

    return_rate = round((total_returns / total_borrowed) * 100, 1) if total_borrowed else 0
    avg_books = round(active_loans / total_users, 2) if total_users else 0

    today_str = datetime.now().strftime("%Y-%m-%d")
    overdue_count = student_loans_q.filter(BorrowedBook.returned == False, BorrowedBook.due_date < today_str).count()
    active_borrowers = (
        student_loans_q.with_entities(db.func.count(db.func.distinct(BorrowedBook.student_name))).filter(BorrowedBook.returned == False).scalar() or 0
    )
    overdue_percentage = round((overdue_count / active_borrowers) * 100, 1) if active_borrowers else 0

    top_books_rows = (
        student_loans_q.with_entities(BorrowedBook.book_title, db.func.count(BorrowedBook.id).label('total'))
        .group_by(BorrowedBook.book_title)
        .order_by(db.desc('total'), BorrowedBook.book_title.asc())
        .limit(10)
        .all()
    )
    least_books_rows = (
        student_loans_q.with_entities(BorrowedBook.book_title, db.func.count(BorrowedBook.id).label('total'))
        .group_by(BorrowedBook.book_title)
        .order_by(db.asc('total'), BorrowedBook.book_title.asc())
        .limit(5)
        .all()
    )
    top_classes_rows = (
        student_loans_q.with_entities(BorrowedBook.student_class, db.func.count(BorrowedBook.id).label('total'))
        .filter(BorrowedBook.returned == False)
        .group_by(BorrowedBook.student_class)
        .order_by(db.desc('total'))
        .limit(6)
        .all()
    )
    top_borrowers_rows = (
        student_loans_q.with_entities(BorrowedBook.student_name, db.func.count(BorrowedBook.id).label('total'))
        .filter(BorrowedBook.returned == False)
        .group_by(BorrowedBook.student_name)
        .order_by(db.desc('total'))
        .limit(10)
        .all()
    )
    category_rows = (
        student_loans_q.with_entities(BorrowedBook.student_class, db.func.count(BorrowedBook.id).label('total'))
        .group_by(BorrowedBook.student_class)
        .order_by(db.desc('total'))

        .limit(4)
        .all()
    )

    loan_mix = [
        {"label": "Student Loans", "count": active_student_loans, "tone": "primary"},
        {"label": "Staff Loans", "count": active_staff_loans, "tone": "success"},
        {"label": "Class Loans", "count": active_class_quantity, "tone": "warning"},
    ]
    loan_mix_total = sum(item["count"] for item in loan_mix) or 1
    for item in loan_mix:

        item["percentage"] = safe_percentage(item["count"], loan_mix_total)

        item["percentage"] = round((item["count"] / loan_mix_total) * 100, 1)

    day_counts = {}
    for offset in range(6, -1, -1):
        day = (datetime.now() - timedelta(days=offset)).strftime("%Y-%m-%d")
        day_counts[day] = 0

    recent_student_loans = student_loans_q.filter(BorrowedBook.timestamp >= min(day_counts.keys())).all()
    recent_staff_loans = staff_loans_q.filter(TeacherBorrowedBook.timestamp >= min(day_counts.keys())).all()
    recent_class_loans = class_loans_q.filter(ClassBorrowing.borrow_time >= min(day_counts.keys())).all()

    for loan in recent_student_loans:
        day = (loan.timestamp or '')[:10]
        if day in day_counts:
            day_counts[day] += 1
    for loan in recent_staff_loans:
        day = (loan.timestamp or '')[:10]
        if day in day_counts:
            day_counts[day] += 1
    for loan in recent_class_loans:
        day = (loan.borrow_time or '')[:10]
        if day in day_counts:
            day_counts[day] += int(getattr(loan, 'quantity', 0) or 0)

    peak_day = max(day_counts.values()) if day_counts else 1
    weekly_activity = [
        {
            "label": datetime.strptime(day, "%Y-%m-%d").strftime("%a"),
            "value": value,
            "height": max(18, round((value / peak_day) * 100)) if peak_day else 18,
        }
        for day, value in day_counts.items()
    ]

    trend_peak = max((item["value"] for item in weekly_activity), default=0)

    recent_activity = logs_q.order_by(Log.id.desc()).limit(8).all()
    recent_activity = [
        {
            "username": item.username or "System",
            "details": item.details or "No details recorded",
            "timestamp": normalize_analytics_date(getattr(item, 'timestamp', None) or getattr(item, 'created_at', None)),
            "method": item.method or "ACTION",
        }
        for item in recent_activity
    ]
    most_borrowed_book = top_books_rows[0][0] if top_books_rows else "None"
    most_active_student = top_borrowers_rows[0][0] if top_borrowers_rows else "None"
    most_active_class = top_classes_rows[0][0] if top_classes_rows else "Unclassified"
    most_borrowed_category = category_rows[0][0] if category_rows else "Uncategorized"
    least_borrowed_category = "Uncategorized"

    health_insights = []
    if overdue_count:
        health_insights.append(f"{overdue_count} overdue loan(s) need immediate attention.")
    else:
        health_insights.append("No overdue loans right now.")
    if total_borrowed:
        health_insights.append(f"Borrowing volume changed {('up' if borrowed_month > borrowed_week else 'down')} compared with the previous period.")
    else:
        health_insights.append("No borrowing activity recorded for the selected period.")
    health_insights.append(f"Most active class: {most_active_class}.")
    health_insights.append(f"Most borrowed category: {most_borrowed_category}.")

    borrowed_percentage = safe_percentage(active_loans, total_books)
    availability_percentage = max(100 - borrowed_percentage, 0)

    recent_activity = logs_q.order_by(Log.id.desc()).limit(6).all()

    health_insights = []
    if overdue_count:
        health_insights.append(f"{overdue_count} student loan(s) are overdue and need follow-up.")
    else:
        health_insights.append("No overdue student loans right now.")

    if total_librarians > 1:
        health_insights.append(f"{total_librarians} librarians are attached to this school and share the same catalog.")
    else:
        health_insights.append("Add more librarians to enable true shared school operations.")

    if available_books < max(5, round(total_books * 0.1)):
        health_insights.append("Available stock is getting tight compared to active borrowing.")
    else:
        health_insights.append("Book availability looks healthy for the current borrowing pace.")

    from .database import BookIssue
    total_issues_cost = db.session.query(db.func.sum(BookIssue.repair_cost)).filter(BookIssue.school_id == school_id).scalar() or 0.0
    student_issues_cost = db.session.query(db.func.sum(BookIssue.repair_cost)).filter(BookIssue.school_id == school_id, BookIssue.loan_type == 'student').scalar() or 0.0
    class_issues_cost = db.session.query(db.func.sum(BookIssue.repair_cost)).filter(BookIssue.school_id == school_id, BookIssue.loan_type == 'class').scalar() or 0.0

    dashboard_data = {
        "school": {
            "name": school.school_name if school else "Default School",
            "librarians": total_librarians,
        },
        "issues_cost": {
            "total": total_issues_cost,
            "students": student_issues_cost,
            "classes": class_issues_cost
        },
        "headline": {
            "total_books": total_books,
            "available_books": available_books,

            "borrowed_percentage": borrowed_percentage,
            "availability_percentage": availability_percentage,
            "total_students": total_students,
            "total_teachers": total_teachers,
            "total_borrowers": total_borrowers,
            "active_borrowers": active_borrowers,
            "new_members": total_students,
            "borrowings_today": borrowed_today,
            "borrowings_this_week": borrowed_week,
            "borrowings_this_month": borrowed_month,
            "returns_today": returns_today,
            "returns_this_month": returns_month,
            "most_borrowed_book": most_borrowed_book,
            "most_active_student": most_active_student,
            "most_active_teacher": "None",
            "most_active_class": most_active_class,
            "total_users": total_users,
            "active_borrowers": active_borrowers,
            "return_rate": return_rate,
            "avg_books": avg_books,
        },
        "overdue": {"count": overdue_count, "percentage": overdue_percentage},
        "loan_mix": loan_mix,
        "weekly_activity": weekly_activity,

        "trend_peak": trend_peak,
        "most_borrowed": [{"title": row[0] or "Unknown", "count": row[1]} for row in top_books_rows],
        "least_borrowed": [{"title": row[0] or "Unknown", "count": row[1]} for row in least_books_rows],
        "top_classes": [{"name": row[0] or "Unclassified", "count": row[1]} for row in top_classes_rows],
        "top_borrowers": [{"name": row[0] or "Unknown", "count": row[1]} for row in top_borrowers_rows],
        "recent_activity": recent_activity,
        "health_insights": health_insights,
        "filters": {
            "period": period,
            "year": year,
            "month": month,
            "day": day,
            "class": class_filter,
            "category": category_filter,
            "borrower_type": borrower_type,
            "borrower": borrower,
            "librarian": librarian,
        },
        "settings": analytics_settings,
        "most_borrowed": [{"title": row[0] or "Unknown", "count": row[1]} for row in top_books_rows],
        "least_borrowed": [{"title": row[0] or "Unknown", "count": row[1]} for row in least_books_rows],
        "top_classes": [{"name": row[0] or "Unclassified", "count": row[1]} for row in top_classes_rows],
        "recent_activity": [
            {
                "username": item.username,
                "details": item.details,
                "timestamp": item.timestamp,
                "method": item.method,
            }
            for item in recent_activity
        ],
        "health_insights": health_insights,
    }

    return dashboard_data

@main.route('/analytics')
@login_required
def analytics():
    dashboard_data = get_analytics_data()
    return render_template('analytics.html', dashboard_data=dashboard_data)



@main.route('/analytics/settings', methods=['POST'])
@login_required
def analytics_settings_save():
    config = load_config()
    payload = request.get_json(silent=True) or {}
    settings = normalize_analytics_settings(payload.get('settings') or {})
    config['analytics_settings'] = settings
    save_config(config)
    flash('Analytics settings updated.', 'success')
    log_action('/analytics/settings', 'UPDATE_ANALYTICS_SETTINGS', 'Updated analytics preferences')
    return jsonify({'success': True, 'settings': settings})


@main.route('/analytics/export', methods=['GET'])
@login_required
def analytics_export():
    export_format = request.args.get('format', 'csv')
    dashboard_data = get_analytics_data()
    
    # Pre-process data
    hl = dashboard_data.get('headline', {})
    ic = dashboard_data.get('issues_cost', {})
    
    overview_data = [
        ('Metric', 'Value'),
        ('Total Books', hl.get('total_books', 0)),
        ('Available Books', hl.get('available_books', 0)),
        ('Borrowed Percentage', f"{hl.get('borrowed_percentage', 0)}%"),
        ('Availability Percentage', f"{hl.get('availability_percentage', 0)}%"),
        ('Total Borrowers', hl.get('total_borrowers', 0)),
        ('Active Borrowers', hl.get('active_borrowers', 0)),
        ('Return Rate', f"{hl.get('return_rate', 0)}%"),
        ('Overdue Books', dashboard_data.get('overdue', {}).get('count', 0)),
        ('Borrowings This Month', hl.get('borrowings_this_month', 0)),
        ('Returns This Month', hl.get('returns_this_month', 0)),
        ('Total Issues Fines (RWF)', ic.get('total', 0)),
        ('Student Issues Fines (RWF)', ic.get('students', 0)),
        ('Class Issues Fines (RWF)', ic.get('classes', 0)),
    ]
    
    if export_format == 'csv':
        from io import StringIO
        text_output = StringIO()
        writer = csv.writer(text_output)
        
        # Overview
        writer.writerow(['--- OVERVIEW METRICS ---'])
        for row in overview_data:
            writer.writerow(row)
            
        writer.writerow([])
        writer.writerow(['--- MOST BORROWED BOOKS ---'])
        writer.writerow(['Book Title', 'Borrow Count'])
        for b in dashboard_data.get('most_borrowed', []):
            writer.writerow([b.get('title', ''), b.get('count', 0)])
            
        writer.writerow([])
        writer.writerow(['--- TOP BORROWERS ---'])
        writer.writerow(['Borrower Name', 'Borrow Count'])
        for b in dashboard_data.get('top_borrowers', []):
            writer.writerow([b.get('name', ''), b.get('count', 0)])
            
        writer.writerow([])
        writer.writerow(['--- TOP CLASSES ---'])
        writer.writerow(['Class Name', 'Borrow Count'])
        for b in dashboard_data.get('top_classes', []):
            writer.writerow([b.get('name', ''), b.get('count', 0)])
            
        output = BytesIO(text_output.getvalue().encode('utf-8'))
        return send_file(output, as_attachment=True, download_name='analytics.csv', mimetype='text/csv')
        
    if export_format == 'excel':
        output = BytesIO()
        
        df_overview = pd.DataFrame(overview_data[1:], columns=overview_data[0])
        df_books = pd.DataFrame(dashboard_data.get('most_borrowed', []))
        if not df_books.empty: df_books.columns = ['Book Title', 'Borrow Count']
        df_borrowers = pd.DataFrame(dashboard_data.get('top_borrowers', []))
        if not df_borrowers.empty: df_borrowers.columns = ['Borrower Name', 'Borrow Count']
        df_classes = pd.DataFrame(dashboard_data.get('top_classes', []))
        if not df_classes.empty: df_classes.columns = ['Class Name', 'Borrow Count']
        
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            df_overview.to_excel(writer, sheet_name='Overview', index=False)
            if not df_books.empty: df_books.to_excel(writer, sheet_name='Top Books', index=False)
            if not df_borrowers.empty: df_borrowers.to_excel(writer, sheet_name='Top Borrowers', index=False)
            if not df_classes.empty: df_classes.to_excel(writer, sheet_name='Top Classes', index=False)
            
        output.seek(0)
        return send_file(output, as_attachment=True, download_name='analytics.xlsx', mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        
    if export_format == 'pdf':
        pdf_buffer = BytesIO()
        doc = SimpleDocTemplate(pdf_buffer, pagesize=letter)
        elements = [Paragraph('Analytics Detailed Report', getSampleStyleSheet()['Title']), Spacer(1, 12)]
        
        styles = getSampleStyleSheet()
        
        # 1. Overview Table
        elements.append(Paragraph('Overview Metrics', styles['Heading2']))
        from reportlab.platypus import Table, TableStyle
        from reportlab.lib import colors
        t_style = TableStyle([
            ('BACKGROUND', (0,0), (-1,0), colors.grey),
            ('TEXTCOLOR', (0,0), (-1,0), colors.whitesmoke),
            ('ALIGN', (0,0), (-1,-1), 'LEFT'),
            ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
            ('BOTTOMPADDING', (0,0), (-1,0), 12),
            ('BACKGROUND', (0,1), (-1,-1), colors.beige),
            ('GRID', (0,0), (-1,-1), 1, colors.black)
        ])
        t_overview = build_pdf_table(doc, overview_data[0], overview_data[1:], weights=[3, 2])
        elements.append(t_overview)
        elements.append(Spacer(1, 20))
        
        # 2. Top Books Table
        elements.append(Paragraph('Most Borrowed Books', styles['Heading2']))
        books_rows = [[b.get('title',''), b.get('count',0)] for b in dashboard_data.get('most_borrowed', [])[:15]]
        t_books = build_pdf_table(doc, ['Book Title', 'Borrow Count'], books_rows, weights=[4, 1])
        elements.append(t_books)
        elements.append(Spacer(1, 20))
        
        # 3. Top Borrowers
        elements.append(Paragraph('Top Borrowers', styles['Heading2']))
        borrowers_rows = [[b.get('name',''), b.get('count',0)] for b in dashboard_data.get('top_borrowers', [])[:15]]
        t_borrowers = build_pdf_table(doc, ['Borrower Name', 'Borrow Count'], borrowers_rows, weights=[4, 1])
        elements.append(t_borrowers)
        elements.append(Spacer(1, 20))
        
        doc.build(elements)
        pdf_buffer.seek(0)
        return send_file(pdf_buffer, as_attachment=True, download_name='analytics.pdf', mimetype='application/pdf')
        
    return jsonify({'success': False, 'message': 'Unsupported export format'})



def clean_excel_val(val):
    if val is None or (isinstance(val, float) and pd and pd.isna(val)):
        return ""
    if isinstance(val, float):
        if val.is_integer():
            return str(int(val))
        return str(val)
    val_str = str(val).strip()
    if val_str.endswith('.0'):
        try:
            return str(int(float(val_str)))
        except:
            return val_str[:-2]
    return val_str

# --- BOOK CATALOG ---
@main.route('/books', methods=['GET', 'POST'])
@login_required
def books():
    if request.method == 'POST':
        action = request.form.get('action')

        # BULK ADD
        if action == 'add':
            common_id = request.form.get('common_id')
            unique_ids = request.form.get('unique_ids')
            title = request.form.get('title')
            author = request.form.get('author') or "Unknown"
            category = request.form.get('category') or "Uncategorized"
            
            if not title: flash("Title is mandatory.", "danger"); return redirect(url_for('main.books'))
            
            id_list = expand_unique_ids(unique_ids)
            if not id_list:
                flash(_("Invalid ID format."), "danger"); return redirect(url_for('main.books'))
            if len(id_list) > 1000:
                flash(_("Too many books selected (max 1000)."), "warning")
                return redirect(url_for('main.books'))

            config = load_config()
            added_count = 0
            skipped = []
            queued_books = []
            for part in id_list:
                full_id = f"{common_id}/{part}"
                if school_get(Book, full_id, pk_name='book_id'):
                    skipped.append({'id': full_id, 'reason': 'Exists'})
                else:
                    # Collect custom fields from the form based on config
                    custom_data = {}
                    for col in config.get('custom_book_columns', []):
                        custom_data[col] = request.form.get(f'custom_{col}', '')

                    book = Book(
                        book_id=full_id,
                        title=title,
                        author=author,
                        category=category,
                        added_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        custom_fields=json.dumps(custom_data)
                    )
                    stamp_sync_fields(book)
                    db.session.add(book)
                    queued_books.append(book)
                    added_count += 1

            db.session.flush()
            for book in queued_books:
                queue_record_change('books', book, operation='upsert')
            safe_commit()

            # LOG WITH DETAILS
            details = f"Added {added_count} books ({common_id}). Titles: {title}, Category: {category}"
            log_action("/books", "ADD_BULK", details)

            flash(f"Added {added_count} books.", "success")
            return redirect(url_for('main.books'))

        # BULK DELETE (UPDATED: Strict Protection)
        elif action == 'delete_bulk':
            selected_ids = request.form.getlist('selected_books')
            blocked_count = 0
            deleted_count = 0

            for bid in selected_ids:
                book = school_get(Book, bid, pk_name='book_id')
                if not book:
                    continue
                if is_book_active(bid):
                    blocked_count += 1
                    continue
                    
                stamp_sync_fields(book, deleted=True)
                queue_record_change('books', book, operation='delete')
                db.session.delete(book)
                deleted_count += 1

            safe_commit()
            msg = f"Deleted {deleted_count} books."
            if blocked_count > 0:
                flash(f"{msg} {blocked_count} books were skipped because they are currently borrowed (Student, Staff, Class, or Graduate list).", "warning")
            else:
                flash(msg, "success")
            return redirect(url_for('main.books'))

        # BULK EDIT (UPDATED: Strict Protection)
        # BULK EDIT (UPDATED: Cascading Updates + Archives)
        elif action == 'edit_bulk':
            selected_ids = request.form.getlist('selected_books')
            new_title = request.form.get('edit_title')
            new_author = request.form.get('edit_author')
            new_category = request.form.get('edit_category')
            
            updated_count = 0
            change_details = []
            
            config = load_config()
            for old_id in selected_ids:
                book = school_get(Book, old_id, pk_name='book_id')
                if book:
                    # 1. Update Book Registry
                    book.title = new_title
                    book.author = new_author
                    if new_category:
                        book.category = new_category
                    # Update custom fields if edit form provided values
                    try:
                        custom_data = book.custom_data
                    except Exception:
                        custom_data = {}
                    for col in config.get('custom_book_columns', []):
                        key = f'custom_{col}'
                        if key in request.form:
                            custom_data[col] = request.form.get(key)
                    try:
                        book.custom_fields = json.dumps(custom_data)
                    except Exception:
                        pass
                    stamp_sync_fields(book)

                    # 2. Update Active Individual Loans
                    BorrowedBook.query.filter_by(book_id=old_id).update({'book_title': new_title})
                    TeacherBorrowedBook.query.filter_by(book_id=old_id).update({'book_title': new_title})
                    GraduateBorrowing.query.filter_by(book_id=old_id).update({'book_title': new_title})

                    # 3. Update Group Loans (Active & Archived)
                    # We extract the base ID (e.g., '100-20') to find the matching group loans
                    if '/' in old_id:
                        base_id = old_id.split('/')[0]
                        # Update Active Class Loans
                        ClassBorrowing.query.filter(ClassBorrowing.book_ids.like(f"{base_id}/%")).update({'book_title': new_title}, synchronize_session=False)
                        # Update Archived Class Loans (The Fix)
                        GraduateClassBorrowing.query.filter(GraduateClassBorrowing.book_ids.like(f"{base_id}/%")).update({'book_title': new_title}, synchronize_session=False)

                    updated_count += 1

                    queue_record_change('books', book, operation='upsert')

            safe_commit()
            if change_details:
                log_action("/books", "EDIT_BULK", f"{current_user.username} updated {updated_count} books: {'; '.join(change_details)}")
            else:
                log_action("/books", "EDIT_BULK", f"{current_user.username} updated {updated_count} books (no field changes detected)")
            flash(f"Updated {updated_count} books and synced title changes to all active and archived loans.", "success")
            return redirect(url_for('main.books'))

        # IMPORT
        elif 'excel' in request.files:
            try:
                df = pd.read_excel(request.files['excel'])
                check_unnamed_excel_columns(df)
                c = 0
                new_books = []
                for _, row in df.iterrows():
                    base = clean_excel_val(row.get('base_id'))
                    ids_raw = clean_excel_val(row.get('ids'))
                    title = clean_excel_val(row.get('title'))
                    author = clean_excel_val(row.get('author')) or "Unknown"
                    category = clean_excel_val(row.get('category')) or "Uncategorized"
                    if base and ids_raw and title:
                        for single_id in expand_unique_ids(ids_raw):
                            fid = f"{base}/{single_id}"
                            if school_get(Book, fid, pk_name='book_id'):
                                continue
                            # Collect custom columns from dataframe if present
                            config = load_config()
                            custom_data = {}
                            for col in config.get('custom_book_columns', []):
                                custom_data[col] = clean_excel_val(row.get(col))

                            book = Book(
                                book_id=fid,
                                title=title,
                                author=author,
                                category=category,
                                added_at=datetime.now().strftime("%Y-%m-%d"),
                                custom_fields=json.dumps(custom_data)
                            )
                            stamp_sync_fields(book)
                            db.session.add(book)
                            new_books.append(book)
                            c += 1
                db.session.flush()
                # Queue record change requires IDs which flush provides.
                for b in new_books:
                    queue_record_change('books', b, operation='upsert')
                safe_commit()
                log_action("/books", "IMPORT", f"Imported {c} books from Excel.")
                flash(f"Imported {c} books.", "success")
            except Exception as e: flash(str(e), "danger")
            return redirect(url_for('main.books'))

# GET (Grouped Books Logic)
    search_query = request.args.get('q', '').strip()
    category_filter = request.args.get('category_filter', '').strip()
    sort_by = request.args.get('sort', 'date_desc')
    
    q = school_query(Book)
    if search_query:
        search_pattern = f"%{search_query}%"
        q = q.filter(
            db.or_(
                Book.book_id.ilike(search_pattern),
                Book.title.ilike(search_pattern),
                Book.author.ilike(search_pattern),
                Book.category.ilike(search_pattern),
                Book.custom_fields.ilike(search_pattern)
            )
        )
    if category_filter:
        if category_filter == 'Uncategorized':
            q = q.filter(or_(Book.category == None, Book.category == '', func.lower(func.trim(Book.category)) == 'uncategorized'))
        else:
            q = q.filter(func.lower(func.trim(Book.category)) == category_filter.strip().lower())
    
    if sort_by == 'title_asc': q = q.order_by(Book.title.asc())
    elif sort_by == 'title_desc': q = q.order_by(Book.title.desc())
    elif sort_by == 'date_asc': q = q.order_by(Book.added_at.asc())
    else: q = q.order_by(Book.added_at.desc())
        
    candidate_books = q.all()

    # Fast status resolution in memory (Eliminates N+1 query bottleneck)
    student_loans_dict = {loan.book_id: loan for loan in school_query(BorrowedBook).filter_by(returned=False).all()}
    staff_loans_dict = {loan.book_id: loan for loan in school_query(TeacherBorrowedBook).filter_by(returned=False).all()}
    graduate_loans_dict = {loan.book_id: loan for loan in school_query(GraduateBorrowing).all()}
    class_loans_list = school_query(ClassBorrowing).filter_by(returned=False).all()
    graduate_class_loans_list = school_query(GraduateClassBorrowing).all()
    pending_issues_list = school_query(BookIssue).filter(BookIssue.status != 'Resolved').all()

    student_loan_ids = [issue.loan_id for issue in pending_issues_list if issue.loan_type == 'student']
    staff_loan_ids = [issue.loan_id for issue in pending_issues_list if issue.loan_type == 'staff']
    grad_loan_ids = [issue.loan_id for issue in pending_issues_list if issue.loan_type == 'graduate']
    class_loan_ids = [issue.loan_id for issue in pending_issues_list if issue.loan_type == 'class']

    student_loans_issues = {l.id: l.book_id for l in school_query(BorrowedBook).filter(BorrowedBook.id.in_(student_loan_ids)).all()} if student_loan_ids else {}
    staff_loans_issues = {l.id: l.book_id for l in school_query(TeacherBorrowedBook).filter(TeacherBorrowedBook.id.in_(staff_loan_ids)).all()} if staff_loan_ids else {}
    grad_loans_issues = {l.id: l.book_id for l in school_query(GraduateBorrowing).filter(GraduateBorrowing.id.in_(grad_loan_ids)).all()} if grad_loan_ids else {}
    class_loans_issues = {l.id: l.book_ids for l in school_query(ClassBorrowing).filter(ClassBorrowing.id.in_(class_loan_ids)).all()} if class_loan_ids else {}

    book_statuses = {}
    for book in candidate_books:
        book_statuses[book.book_id] = get_book_status_info_fast(
            book.book_id,
            student_loans_dict,
            staff_loans_dict,
            graduate_loans_dict,
            class_loans_list,
            graduate_class_loans_list,
            pending_issues_list,
            student_loans_issues,
            staff_loans_issues,
            grad_loans_issues,
            class_loans_issues
        )

    if search_query:
        query_lower = search_query.lower()
        all_books = []
        for book in candidate_books:
            status = book_statuses.get(book.book_id, {})
            status_label = (status.get('label') or '').lower()
            if query_lower in {'available', 'unavailable'}:
                if status_label == query_lower:
                    all_books.append(book)
                continue
            haystack = " ".join([
                book.book_id or '',
                book.title or '',
                book.author or '',
                book.category or '',
                status.get('label', ''),
                status.get('detail', ''),
                status.get('search_text', ''),
            ]).lower()
            if query_lower in haystack:
                all_books.append(book)
    else:
        all_books = candidate_books
    
    # Group books by Base ID
    grouped_books = {}
    for b in all_books:
        base_id = b.book_id.split('/')[0] if '/' in b.book_id else b.book_id
        if base_id not in grouped_books:
            grouped_books[base_id] = {
                'base_id': base_id,
                'title': b.title,
                'author': b.author,
                'category': b.category,
                'total': 0,
                'available': 0,
                'added_at': b.added_at,
                'copies': []
            }
        grouped_books[base_id]['total'] += 1
        if book_statuses.get(b.book_id, {}).get('label') == 'Available':
            grouped_books[base_id]['available'] += 1
        grouped_books[base_id]['copies'].append(b)
    grouped_list = list(grouped_books.values())
    result_count = len(all_books)

    return render_template(
        'manage_books.html',
        categories=get_unique_categories(),
        books=all_books,
        grouped_books=grouped_list,
        book_statuses=book_statuses,
        result_count=result_count,
        suggested_id=generate_unique_base_id(),
        search_query=search_query,
        category_filter=category_filter,
        sort_by=sort_by,
        sys_config=load_config(),
    )

def _compute_book_statuses_bulk(books_list):
    student_loans_dict = {loan.book_id: loan for loan in school_query(BorrowedBook).filter_by(returned=False).all()}
    staff_loans_dict = {loan.book_id: loan for loan in school_query(TeacherBorrowedBook).filter_by(returned=False).all()}
    graduate_loans_dict = {loan.book_id: loan for loan in school_query(GraduateBorrowing).all()}
    class_loans_list = school_query(ClassBorrowing).filter_by(returned=False).all()
    graduate_class_loans_list = school_query(GraduateClassBorrowing).all()
    pending_issues_list = school_query(BookIssue).filter(BookIssue.status != 'Resolved').all()

    student_loan_ids = [issue.loan_id for issue in pending_issues_list if issue.loan_type == 'student']
    staff_loan_ids = [issue.loan_id for issue in pending_issues_list if issue.loan_type == 'staff']
    grad_loan_ids = [issue.loan_id for issue in pending_issues_list if issue.loan_type == 'graduate']
    class_loan_ids = [issue.loan_id for issue in pending_issues_list if issue.loan_type == 'class']

    student_loans_issues = {l.id: l.book_id for l in school_query(BorrowedBook).filter(BorrowedBook.id.in_(student_loan_ids)).all()} if student_loan_ids else {}
    staff_loans_issues = {l.id: l.book_id for l in school_query(TeacherBorrowedBook).filter(TeacherBorrowedBook.id.in_(staff_loan_ids)).all()} if staff_loan_ids else {}
    grad_loans_issues = {l.id: l.book_id for l in school_query(GraduateBorrowing).filter(GraduateBorrowing.id.in_(grad_loan_ids)).all()} if grad_loan_ids else {}
    class_loans_issues = {l.id: l.book_ids for l in school_query(ClassBorrowing).filter(ClassBorrowing.id.in_(class_loan_ids)).all()} if class_loan_ids else {}

    statuses = {}
    for book in books_list:
        statuses[book.book_id] = get_book_status_info_fast(
            book.book_id,
            student_loans_dict,
            staff_loans_dict,
            graduate_loans_dict,
            class_loans_list,
            graduate_class_loans_list,
            pending_issues_list,
            student_loans_issues,
            staff_loans_issues,
            grad_loans_issues,
            class_loans_issues
        )
    return statuses


# --- EXPORT ROUTES ---
@main.route('/books/export/excel')
@login_required
def export_books_excel():
    config = load_config()
    custom_cols = config.get('custom_book_columns', [])
    books = school_query(Book).all()
    book_statuses = _compute_book_statuses_bulk(books)
    grouped_rows = build_grouped_catalog_export(books, book_statuses=book_statuses, custom_columns=custom_cols)
    data = []
    for item in grouped_rows:
        row = {
            'Base ID': item['base_id'],
            'Title': item['title'],
            'Author': item['author'],
            'Category': item.get('category', 'Uncategorized'),
            'Quantity': item['quantity'],
            'Available': item['available'],
        }
        for col in custom_cols:
            row[col] = item.get(col, '')
        data.append(row)
    df = pd.DataFrame(data)
    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False)
    output.seek(0)
    return send_file(output, download_name="Library_Books.xlsx", as_attachment=True)

@main.route('/books/locate/<path:book_id>')
@login_required
def locate_book(book_id):
    """Smart router to find exactly who has the unavailable book."""
    if school_query(BorrowedBook).filter_by(book_id=book_id, returned=False, deleted=False).first():
        return redirect(url_for('main.borrowed', tab='students', book_id=book_id))
    if school_query(TeacherBorrowedBook).filter_by(book_id=book_id, returned=False, deleted=False).first():
        return redirect(url_for('main.borrowed', tab='staff', book_id=book_id))
    if school_query(GraduateBorrowing).filter_by(book_id=book_id, deleted=False).first():
        return redirect(url_for('main.borrowed', tab='graduates', book_id=book_id))
    if school_query(ClassBorrowing).filter(ClassBorrowing.book_ids.like(f"%{book_id}%"), ClassBorrowing.returned == False, ClassBorrowing.deleted == False).first():
        return redirect(url_for('main.borrowed', tab='classes', book_id=book_id))
    if school_query(GraduateClassBorrowing).filter(GraduateClassBorrowing.book_ids.like(f"%{book_id}%"), GraduateClassBorrowing.deleted == False).first():
        return redirect(url_for('main.borrowed', tab='archived_classes', book_id=book_id))

    flash("This book is marked unavailable but couldn't be located in active loans.", "warning")
    return redirect(url_for('main.books'))

@main.route('/books/export/pdf')
@login_required
def export_books_pdf():
    config = load_config()
    custom_cols = config.get('custom_book_columns', [])
    books = school_query(Book).all()
    book_statuses = _compute_book_statuses_bulk(books)
    grouped_rows = build_grouped_catalog_export(books, book_statuses=book_statuses, custom_columns=custom_cols)

    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    elements = []

    styles = getSampleStyleSheet()
    elements.append(Paragraph("Library Book Catalog", styles['Title']))
    elements.append(Spacer(1, 12))

    headers = ['Base ID', 'Title', 'Author', 'Category', 'Quantity', 'Available'] + list(custom_cols)
    rows_data = []
    for item in grouped_rows:
        row = [
            item['base_id'],
            item['title'],
            item['author'],
            item.get('category', 'Uncategorized'),
            str(item['quantity']),
            str(item['available']),
        ]
        for col in custom_cols:
            row.append(str(item.get(col, '') or ''))
        rows_data.append(row)

    base_weights = [1.3, 3.0, 1.8, 1.5, 0.9, 0.9] + [1.2] * len(custom_cols)
    pdf_table = build_pdf_table(doc, headers, rows_data, weights=base_weights)
    elements.append(pdf_table)
    doc.build(elements)
    buffer.seek(0)
    return send_file(buffer, download_name="Library_Books.pdf", as_attachment=True)

@main.route('/download_books_template')
@login_required
def download_books_template():
    config = load_config()
    data = {
        "base_id": ["321-54-100"],
        "ids": ["1-50"],
        "title": ["Math S1"],
        "author": ["REB"],
        "category": ["Student Books"],
    }
    # Add Category if not hidden
    if "Category" not in config.get('hidden_book_columns', []):
        data["category"] = ["Student Books"]
    # Add all custom columns
    for col in config.get('custom_book_columns', []):
        data[col] = ["Example Data"]
    df = pd.DataFrame(data)
    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False)
    output.seek(0)
    return send_file(output, as_attachment=True, download_name="books_import_template.xlsx")

# API: Save Book Columns (custom + hidden)
MAX_CUSTOM_COLUMNS = 5

@main.route('/api/books/columns/save', methods=['POST'])
@login_required
def save_book_columns():
    data = request.get_json() or {}
    raw_custom = data.get('custom_columns', [])
    cleaned_custom = []
    for col in raw_custom:
        c_str = str(col).strip()
        if c_str and c_str not in cleaned_custom and c_str.lower() != 'category':
            cleaned_custom.append(c_str)
    if len(cleaned_custom) > MAX_CUSTOM_COLUMNS:
        return jsonify({'success': False, 'message': _('Maximum of 5 custom columns allowed.')}), 400
    config = load_config()
    config['custom_book_columns'] = cleaned_custom
    config['hidden_book_columns'] = data.get('hidden_columns', [])
    save_config(config)
    return jsonify({"success": True, "message": _("Columns updated successfully.")})

# --- STUDENTS / CLASSES MANAGEMENT ---
@main.route('/students', methods=['GET', 'POST'])
@login_required
def students():
    skipped_students = []

    # Helper to clean class names (remove spaces, uppercase)
    def clean_cls(c):
        return str(c).strip().replace(" ", "").upper()

    # 1. HANDLE ALL POST ACTIONS
    if request.method == 'POST':
        action = request.form.get('action')

        # --- A. IMPORT EXCEL ---
        if 'excel' in request.files:
            file = request.files['excel']
            if file.filename:
                try:
                    df = pd.read_excel(file)
                    valid_cols = check_unnamed_excel_columns(df)
                    added_count = 0
                    new_students = []

                    for class_name in valid_cols:
                        clean_class = clean_cls(class_name)
                        # Skip empty or unnamed columns
                        if not clean_class or "UNNAMED" in clean_class: continue

                        students_in_class = df[class_name].dropna().astype(str).tolist()

                        for student_name in students_in_class:
                            clean_name = student_name.strip()
                            if not clean_name: continue

                            # Check duplicates (case-insensitive + trimmed)
                            exists = Student.query.filter(
                                func.lower(func.trim(Student.name)) == clean_name.lower(),
                                func.lower(func.trim(Student.class_name)) == clean_class.lower()
                            ).first()
                            if not exists:
                                student = Student(name=clean_name, student_class=clean_class)
                                stamp_sync_fields(student)
                                db.session.add(student)
                                new_students.append(student)
                                added_count += 1
                            else:
                                skipped_students.append({'name': clean_name, 'class': clean_class, 'reason': 'Already exists'})

                    db.session.flush()
                    for s in new_students:
                        queue_record_change('members', s, operation='upsert')
                    safe_commit()
                    log_action("/students", "IMPORT_STUDENTS", f"{current_user.username} imported {added_count} students from Excel.")

                    if skipped_students:
                        flash(f"Imported {added_count} students. Some duplicates were skipped.", "warning")
                    else:
                        flash(f"Successfully imported {added_count} students.", "success")
                        return redirect(url_for('main.students'))

                except Exception as e:
                    flash(f"Error processing file: {str(e)}", "danger")
                    return redirect(url_for('main.students'))

        # --- B. ADD / EDIT STUDENT WITH DUPLICATE PREVENTION (Task 4) ---
        elif action in ('add', 'add_student', 'edit', 'edit_student'):
            clean_name = (request.form.get('name') or '').strip()
            clean_class = clean_cls(request.form.get('student_class') or request.form.get('class_name') or '')
            student_id = request.form.get('student_id')

            if action == 'edit':
                action = 'edit_student'

            dup_query = Student.query.filter(
                func.lower(func.trim(Student.name)) == clean_name.lower(),
                func.lower(func.trim(Student.class_name)) == clean_class.lower()
            )
            if action == 'edit_student' and student_id:
                cmp_id = int(student_id) if str(student_id).isdigit() else student_id
                dup_query = dup_query.filter(Student.id != cmp_id)
            if dup_query.first():
                flash(_("Duplicate blocked: A student named '%(name)s' already exists in class '%(cls)s'.", name=clean_name, cls=clean_class), "danger")
                return redirect(url_for('main.students'))

            if action in ('add', 'add_student'):
                student = Student(name=clean_name, student_class=clean_class)
                stamp_sync_fields(student)
                db.session.add(student)
                db.session.flush()
                queue_record_change('members', student, operation='upsert')
                safe_commit()
                log_action("/students", "ADD_STUDENT", f"{current_user.username} added student {clean_name} to class {clean_class}")
                flash(f"Added {clean_name} to {clean_class}.", "success")
                return redirect(url_for('main.students'))

            student = school_get(Student, student_id)
            if student:
                old_name = student.name
                old_class = student.student_class
                new_name = clean_name
                new_class = clean_class

                # Update student record
                student.name = new_name
                student.student_class = new_class
                stamp_sync_fields(student)

                # Propagate changes to active and archived loan records
                BorrowedBook.query.filter_by(student_name=old_name).update({ 'student_name': new_name, 'student_class': new_class })
                GraduateBorrowing.query.filter_by(student_name=old_name).update({ 'student_name': new_name })

                # Also update responsibles in ClassBorrowing rows where this student is listed
                for cl in school_query(ClassBorrowing).filter(ClassBorrowing.responsibles.like(f"%{old_name}%")): 
                    try:
                        resp = cl.responsibles
                        updated = ", ".join([new_name if x.strip()==old_name else x for x in [r.strip() for r in resp.split(',')]])
                        cl.responsibles = updated
                    except:
                        continue

                queue_record_change('members', student, operation='upsert')
                safe_commit()
                log_action("/students", "EDIT_STUDENT", f"{current_user.username} updated student {old_name} ({old_class}) to {new_name} ({new_class}) and propagated changes to borrow records.")
                flash("Student details updated and propagated to borrow records.", "success")
            return redirect(url_for('main.students'))

        # DELETE STUDENT (UPDATED: Strict Protection)
        elif action == 'delete':
            sid = request.form.get('student_id')
            student = school_get(Student, sid)
            if student:
                # Check Student Loans
                if school_query(BorrowedBook).filter_by(student_name=student.name, returned=False).first():
                    flash(f"Cannot delete {student.name}. Active student loans exist.", "danger")
                # Check Graduate Debt (Unlikely if in student list, but possible if re-added)
                elif school_query(GraduateBorrowing).filter_by(student_name=student.name).first():
                    flash(f"Cannot delete {student.name}. They have archived debts.", "danger")
                else:
                    stamp_sync_fields(student, deleted=True)
                    queue_record_change('members', student, operation='delete')
                    db.session.delete(student)
                    safe_commit()
                    log_action("/students", "DELETE_STUDENT", f"{current_user.username} deleted student {student.name} from class {student.student_class}")
                    flash("Student removed.", "success")
            return redirect(url_for('main.students'))

        # RENAME CLASS (UPDATED: Strict Protection)
        elif action == 'edit_class':
            old_class = request.form.get('old_class_name')
            new_class = clean_cls(request.form.get('new_class_name'))

            # Update students
            students_to_move = school_query(Student).filter_by(student_class=old_class).all()
            for s in students_to_move:
                s.student_class = new_class
                stamp_sync_fields(s)
                queue_record_change('members', s, operation='upsert')

            # Update borrowed book records for students
            school_query(BorrowedBook).filter_by(student_class=old_class).update({ 'student_class': new_class })

            # Update class borrowings that reference this class name
            for cl in school_query(ClassBorrowing).filter_by(class_name=old_class).all():
                cl.class_name = new_class

            # Update archived graduate class borrowings as well
            for gcl in school_query(GraduateClassBorrowing).filter_by(class_name=old_class).all():
                gcl.class_name = new_class

            safe_commit()
            log_action("/students", "EDIT_CLASS", f"{current_user.username} renamed class {old_class} to {new_class} and updated related loan records.")
            flash(f"Renamed class {old_class} to {new_class} and updated related loan records.", "success")
            return redirect(url_for('main.students'))

        # DELETE CLASS (UPDATED: Strict Protection)
        elif action == 'delete_class':
            cls_name = request.form.get('class_name')
            if ClassBorrowing.query.filter_by(class_name=cls_name, returned=False).first():
                flash(f"Cannot delete {cls_name}. Active class loans exist.", "danger")
            elif BorrowedBook.query.filter_by(student_class=cls_name, returned=False).first():
                flash(f"Cannot delete {cls_name}. Students in this class have active loans.", "danger")
            else:
                Student.query.filter_by(student_class=cls_name).delete()
                safe_commit()
                log_action("/students", "DELETE_CLASS", f"{current_user.username} deleted class {cls_name} and all its students.")
                flash(f"Deleted Class {cls_name}.", "success")
            return redirect(url_for('main.students'))

        # --- G. PROMOTE LOGIC ---
        elif action == 'promote':
            promo_name = request.form.get('promotion_name')

            # --- STEP 1: Handle Class Loans FIRST ---
            all_class_loans = ClassBorrowing.query.all()
            active_class_loans = []
            for cloan in all_class_loans:
                if not cloan.returned:
                    active_class_loans.append(cloan)
                else:
                    if BookIssue.query.filter_by(loan_id=cloan.id, loan_type='class').first():
                        active_class_loans.append(cloan)

            for cloan in active_class_loans:
                cls = cloan.class_name.upper()

                # Check if this class is graduating
                if cls.startswith('S3') or cls.startswith('S6'):

                    # 1. Fetch Full Roster
                    all_members = Student.query.filter_by(student_class=cloan.class_name).all()

                    if all_members:
                        full_roster_str = ", ".join([s.name for s in all_members])
                    else:
                        full_roster_str = cloan.responsibles # Fallback

                    # 2. FORMAT: "Monitor Name || Full Student List"
                    # This keeps the monitor separate for the table view
                    combined_responsibles = f"{cloan.responsibles}||{full_roster_str}"

                    # Prefix with ex-
                    archived_class_name = f"ex-{cloan.class_name} ({promo_name})"

                    condition = cloan.condition
                    if cloan.returned:
                        condition = f"[RETURNED] {condition}" if condition else "[RETURNED]"

                    archive_class = GraduateClassBorrowing(
                        promotion_name=promo_name,
                        class_name=archived_class_name,
                        responsibles=combined_responsibles, # <--- SAVES BOTH
                        book_title=cloan.book_title,
                        book_ids=cloan.book_ids,
                        quantity=cloan.quantity,
                        condition=condition,
                        borrow_time=cloan.borrow_time
                    )
                    # Ensure archived class record is associated with the current school
                    archive_class.school_id = get_current_school_id()
                    db.session.add(archive_class)
                    db.session.flush()

                    # Migrate any unresolved BookIssues to the new GraduateClassBorrowing
                    issues = BookIssue.query.filter_by(loan_id=cloan.id, loan_type='class').all()
                    for issue in issues:
                        issue.loan_id = archive_class.id
                        issue.loan_type = 'graduate_class'
                        queue_record_change('book_issues', issue, operation='upsert')

                    queue_record_change('graduates_class', archive_class, operation='upsert')
                    stamp_sync_fields(cloan, deleted=True)
                    queue_record_change('class_checkouts', cloan, operation='delete')
                    db.session.delete(cloan)

                # B. Handle Promotion for non-graduating classes (Rename S1->S2, etc.)
                else:
                    new_cls = cls
                    if cls.startswith('S1'): new_cls = cls.replace('S1', 'S2', 1)
                    elif cls.startswith('S2'): new_cls = cls.replace('S2', 'S3', 1)
                    elif cls.startswith('S4'): new_cls = cls.replace('S4', 'S5', 1)
                    elif cls.startswith('S5'): new_cls = cls.replace('S5', 'S6', 1)

                    if new_cls != cls:
                        cloan.class_name = new_cls

            # --- STEP 1.5: Sweep Orphaned Loans for Graduating Classes ---
            all_borrowed = BorrowedBook.query.all()
            for loan in all_borrowed:
                cls = loan.student_class.upper()
                if cls.startswith('S3') or cls.startswith('S6'):
                    if not loan.returned or BookIssue.query.filter_by(loan_id=loan.id, loan_type='student').first():
                        archived_student_class = f"ex-{loan.student_class} ({promo_name})"
                        
                        notes = loan.condition
                        if loan.returned:
                            notes = f"[RETURNED] {notes}" if notes else "[RETURNED]"

                        archive = GraduateBorrowing(
                            promotion_name=promo_name,
                            student_name=loan.student_name,
                            original_class=archived_student_class,
                            book_id=loan.book_id,
                            book_title=loan.book_title,
                            notes=notes,
                            timestamp=loan.timestamp,
                            due_date=loan.due_date
                        )
                        archive.school_id = get_current_school_id()
                        db.session.add(archive)
                        db.session.flush()

                        issues = BookIssue.query.filter_by(loan_id=loan.id, loan_type='student').all()
                        for issue in issues:
                            issue.loan_id = archive.id
                            issue.loan_type = 'graduate'
                            queue_record_change('book_issues', issue, operation='upsert')

                        queue_record_change('graduates_borrowed', archive, operation='upsert')
                        stamp_sync_fields(loan, deleted=True)
                        queue_record_change('checkouts', loan, operation='delete')
                        db.session.delete(loan)

            # --- STEP 2: Handle Individual Students (Promote or Delete) ---
            all_students = Student.query.all()
            graduates_moved = 0
            promoted_count = 0

            for s in all_students:
                cls = s.student_class.upper()

                # Graduating Students
                if cls.startswith('S3') or cls.startswith('S6'):
                    # Archive their active loans
                    all_student_loans = BorrowedBook.query.filter_by(student_name=s.name, student_class=s.student_class).all()
                    active_loans = []
                    for loan in all_student_loans:
                        if not loan.returned:
                            active_loans.append(loan)
                        else:
                            if BookIssue.query.filter_by(loan_id=loan.id, loan_type='student').first():
                                active_loans.append(loan)

                    archived_student_class = f"ex-{s.student_class} ({promo_name})"

                    for loan in active_loans:
                        archive = GraduateBorrowing(
                            promotion_name=promo_name,
                            student_name=s.name,
                            original_class=archived_student_class,
                            book_id=loan.book_id,
                            book_title=loan.book_title,
                            notes=loan.condition,
                            timestamp=loan.timestamp,
                            due_date=loan.due_date
                        )
                        # Associate archived individual graduate loans with the current school
                        archive.school_id = get_current_school_id()
                        db.session.add(archive)
                        db.session.flush()

                        # Migrate any unresolved BookIssues to the new GraduateBorrowing
                        issues = BookIssue.query.filter_by(loan_id=loan.id, loan_type='student').all()
                        for issue in issues:
                            issue.loan_id = archive.id
                            issue.loan_type = 'graduate'
                            queue_record_change('book_issues', issue, operation='upsert')

                        queue_record_change('graduates_borrowed', archive, operation='upsert')
                        stamp_sync_fields(loan, deleted=True)
                        queue_record_change('checkouts', loan, operation='delete')
                        db.session.delete(loan)
                        graduates_moved += 1

                    # DELETE THE STUDENT (Now safe, as class roster is already saved)
                    stamp_sync_fields(s, deleted=True)
                    queue_record_change('members', s, operation='delete')
                    db.session.delete(s)

                # Promoting Students
                else:
                    new_cls = cls
                    if cls.startswith('S1'): new_cls = cls.replace('S1', 'S2', 1)
                    elif cls.startswith('S2'): new_cls = cls.replace('S2', 'S3', 1)
                    elif cls.startswith('S4'): new_cls = cls.replace('S4', 'S5', 1)
                    elif cls.startswith('S5'): new_cls = cls.replace('S5', 'S6', 1)

                    if new_cls != cls:
                        s.student_class = new_cls
                        # Update their active loans
                        loans = BorrowedBook.query.filter_by(student_name=s.name, student_class=cls, returned=False).all()
                        for l in loans: l.student_class = new_cls
                        promoted_count += 1

            safe_commit()
            log_action("/students", "PROMOTE", f"{current_user.username} executed promotion '{promo_name}': {promoted_count} students promoted, {graduates_moved} graduate loans archived.")
            flash(f"Promotion Complete! {promoted_count} promoted. {graduates_moved} student loans archived.", "success")
            return redirect(url_for('main.students'))

    # 2. HANDLE DISPLAY (GET Logic)
    # This runs for GET requests AND for Import POST requests that had duplicates

    # A. Filtering & Search
    search_query = request.args.get('q', '').strip()
    sort_by = request.args.get('sort', 'class_asc') # Default sort

    query = Student.query
    if search_query:
        query = query.filter(
            (Student.name.ilike(f"%{search_query}%")) |
            (Student.student_class.ilike(f"%{search_query}%"))
        )

    # B. Sorting (Restored!)
    if sort_by == 'class_asc':
        query = query.order_by(Student.student_class.asc(), Student.name.asc())
    elif sort_by == 'class_desc':
        query = query.order_by(Student.student_class.desc(), Student.name.asc())
    elif sort_by == 'name_asc':
        query = query.order_by(Student.name.asc())
    elif sort_by == 'name_desc':
        query = query.order_by(Student.name.desc())

    students_list = query.all()

    # C. Class List Calculation (Fixed!)
    # We calculate this fresh every time so it appears immediately after import
    unique_classes = sorted(list(set([s.student_class for s in Student.query.all()])))
    class_stats = []
    for c in unique_classes:
        count = Student.query.filter_by(student_class=c).count()
        class_stats.append({'name': c, 'count': count})

    unique_classes = db.session.query(Student.student_class).distinct().order_by(Student.student_class).all()
    available_classes = sorted(list(set([c[0].strip() for c in unique_classes if c[0]]))) 

    query = Student.query
    class_filter = request.args.get('class_filter', '').strip()
    if class_filter:
        query = query.filter(Student.student_class == class_filter)
    search_query = request.args.get('q', '').strip()
    if search_query:
        query = query.filter(Student.name.ilike(f"%{search_query}%")) 
    students_list = query.all()          

    return render_template('students.html',
                         students=students_list,
                         classes=class_stats,
                         available_classes=available_classes,
                         search_query=search_query,
                         class_filter=class_filter,
                         sort_by=sort_by,
                         skipped_students=skipped_students)

# --- EXPORT: EXCEL (Formatted by Class Column) ---
@main.route('/students/export/excel')
@login_required
def export_students_excel():
    # 1. Get all students and group them by class
    students = Student.query.all()
    data_map = {}

    for s in students:
        if s.student_class not in data_map:
            data_map[s.student_class] = []
        data_map[s.student_class].append(s.name)

    # 2. Sort Classes (optional, makes columns A-Z)
    sorted_classes = sorted(data_map.keys())

    # 3. Find max length to pad columns (pandas requires equal length)
    max_len = 0
    if data_map:
        max_len = max(len(v) for v in data_map.values())

    final_dict = {}
    for cls in sorted_classes:
        # Pad list with empty strings so all columns are same length
        students_list = data_map[cls]
        padded_list = students_list + [''] * (max_len - len(students_list))
        final_dict[cls] = padded_list

    # 4. Create DataFrame
    df = pd.DataFrame(final_dict)

    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False)
    output.seek(0)

    return send_file(output, download_name="students_list.xlsx", as_attachment=True)

# --- EXPORT: PDF (Grouped Tables) ---
@main.route('/students/export/pdf')
@login_required
def export_students_pdf():
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    elements = []
    styles = getSampleStyleSheet()

    # Title
    elements.append(Paragraph("Students List", styles['Title']))
    elements.append(Spacer(1, 20))

    # Get all distinct classes
    classes = db.session.query(Student.student_class).distinct().order_by(Student.student_class).all()
    classes = [c[0] for c in classes] # flatten result

    for class_name in classes:
        # Header for the Class
        elements.append(Paragraph(f"<b>Class: {class_name}</b>", styles['Heading2']))
        elements.append(Spacer(1, 5))

        # Get students for this class
        students = Student.query.filter_by(student_class=class_name).order_by(Student.name).all()

        if not students: continue

        rows_data = [[str(i), s.name] for i, s in enumerate(students, 1)]
        table = build_pdf_table(doc, ['No.', 'Student Name'], rows_data, weights=[1, 7])
        elements.append(table)
        elements.append(Spacer(1, 20)) # Space between tables

    doc.build(elements)
    buffer.seek(0)
    return send_file(buffer, download_name="students_list.pdf", as_attachment=True)

# --- NEW: STUDENT LIVE SEARCH API ---

@main.route('/download_student_template')
@login_required
def download_student_template():
    data = { "S1 A": ["MUGISHA"], "S5 MPC": ["ISHIMWE"] }
    df = pd.DataFrame(data)
    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False)
    output.seek(0)
    return send_file(output, as_attachment=True, download_name="student_import_template.xlsx")

# --- BORROW TRANSACTION ---
def get_unique_categories():
    raw_rows = db.session.query(Book.category).distinct().all()
    cleaned = {r[0].strip() for r in raw_rows if r[0] and r[0].strip() and r[0].strip().lower() != 'uncategorized'}
    return ['Uncategorized'] + sorted(cleaned, key=lambda s: s.lower())

@main.route('/borrow', methods=['GET', 'POST'])
@login_required
def borrow():
    # Helper to calculate missing subset for display
    def get_missing_parts(base_id, id_set):
        missing_set = set()
        for i in id_set:
            if not Book.query.get(f"{base_id}/{i}"):
                missing_set.add(i)
        return set_to_range_string(missing_set)

    if request.method == 'POST':
        action = request.form.get('action')
        config = load_config()

        # --- IMPORT LOAN EXCEL ---
        if action == 'import_loan' and 'excel' in request.files:
            file = request.files.get('excel')
            import_type = request.form.get('loan_import_type', '').lower()
            is_ajax = request.form.get('ajax') == '1'
            missing_books_data = request.form.get('missing_books_data')
            
            if file and file.filename:
                try:
                    df = pd.read_excel(file)
                    check_unnamed_excel_columns(df)
                    columns_lower = [str(c).strip().lower() for c in df.columns]
                    if import_type not in ('student', 'staff', 'class'):
                        if 'student name' in columns_lower:
                            import_type = 'student'
                        elif 'staff name' in columns_lower or 'teacher name' in columns_lower:
                            import_type = 'staff'
                        elif 'class' in columns_lower and 'base id' in columns_lower:
                            import_type = 'class'

                    # Phase 1: Register missing books if resolution data provided
                    if missing_books_data:
                        try:
                            import json
                            new_books = json.loads(missing_books_data)
                            for b in new_books:
                                b_id = b.get('book_id')
                                title = b.get('title')
                                category = b.get('category') or 'Uncategorized'
                                # only create if title was provided (user might have skipped some)
                                if b_id and title and title.strip() and not school_get(Book, b_id, pk_name='book_id'):
                                    new_book = Book(
                                        book_id=b_id,
                                        title=title.strip(),
                                        category=category.strip(),
                                        added_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                                    )
                                    stamp_sync_fields(new_book)
                                    db.session.add(new_book)
                                    queue_record_change('books', new_book, operation='upsert')
                            db.session.flush()
                        except Exception as e:
                            current_app.logger.error(f"Error parsing missing_books_data: {e}")

                    # Phase 2: Pre-flight check for missing books
                    if is_ajax and not missing_books_data and request.form.get('resolution_attempted') != '1':
                        missing_ids = set()
                        for _, row in df.iterrows():
                            if import_type == 'class':
                                base_id = clean_excel_val(row.get('Base ID') or row.get('Book ID'))
                                unique_ids = clean_excel_val(row.get('Unique IDs') or row.get('IDs') or row.get('Numbers'))
                                if base_id and unique_ids:
                                    try:
                                        id_set = parse_range_to_set(normalize_unique_ids(unique_ids))
                                        for n in id_set:
                                            fid = f"{base_id}/{n}"
                                            if not school_get(Book, fid, pk_name='book_id'):
                                                missing_ids.add(fid)
                                    except:
                                        pass
                            else:
                                book_id = clean_excel_val(row.get('Book ID') or row.get('Book'))
                                if book_id and not school_get(Book, book_id, pk_name='book_id'):
                                    missing_ids.add(book_id)
                        
                        if missing_ids:
                            return jsonify({'status': 'missing_books', 'missing': sorted(list(missing_ids))})

                    imported_count = 0
                    skipped_count = 0
                    new_loans = []

                    if import_type == 'student':
                        for _, row in df.iterrows():
                            student_name = clean_excel_val(row.get('Student Name') or row.get('Student') or row.get('Name'))
                            book_id = clean_excel_val(row.get('Book ID') or row.get('Book'))
                            condition = clean_excel_val(row.get('Condition')) or 'Good'
                            if not student_name or not book_id:
                                skipped_count += 1
                                continue
                            student = school_query(Student).filter(Student.name.ilike(f"{student_name}")).first()
                            if not student:
                                skipped_count += 1
                                continue
                            book = school_get(Book, book_id, pk_name='book_id')
                            if not book or is_book_active(book_id):
                                skipped_count += 1
                                continue
                            loan = BorrowedBook(
                                book_id=book.book_id,
                                book_title=book.title,
                                student_name=student.name,
                                student_class=student.student_class,
                                condition=condition,
                                timestamp=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                                due_date=(datetime.now() + timedelta(days=config.get('default_borrow_days', 14))).strftime('%Y-%m-%d')
                            )
                            stamp_sync_fields(loan)
                            db.session.add(loan)
                            new_loans.append(loan)
                            imported_count += 1

                        db.session.flush()
                        for loan in new_loans:
                            queue_record_change('checkouts', loan, operation='upsert')

                    elif import_type == 'staff':
                        for _, row in df.iterrows():
                            teacher_name = clean_excel_val(row.get('Staff Name') or row.get('Teacher Name') or row.get('Name'))
                            book_id = clean_excel_val(row.get('Book ID') or row.get('Book'))
                            notes = clean_excel_val(row.get('Condition'))
                            if not teacher_name or not book_id:
                                skipped_count += 1
                                continue
                            book = school_get(Book, book_id, pk_name='book_id')
                            if not book or is_book_active(book_id):
                                skipped_count += 1
                                continue
                            loan = TeacherBorrowedBook(
                                book_id=book.book_id,
                                book_title=book.title,
                                teacher_name=teacher_name,
                                notes=notes,
                                timestamp=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                            )
                            stamp_sync_fields(loan)
                            db.session.add(loan)
                            new_loans.append(loan)
                            imported_count += 1

                        db.session.flush()
                        for loan in new_loans:
                            queue_record_change('staff_checkouts', loan, operation='upsert')

                    elif import_type == 'class':
                        for _, row in df.iterrows():
                            class_name = clean_excel_val(row.get('Class'))
                            responsibles = clean_excel_val(row.get('Responsibles'))
                            base_id = clean_excel_val(row.get('Base ID'))
                            unique_ids = clean_excel_val(row.get('Unique IDs') or row.get('IDs'))
                            notes = clean_excel_val(row.get('Condition'))
                            if not class_name or not base_id or not unique_ids:
                                skipped_count += 1
                                continue
                            try:
                                normalized = normalize_unique_ids(unique_ids)
                                id_set = parse_range_to_set(normalized)
                            except Exception:
                                skipped_count += 1
                                continue
                            full_ids = [f"{base_id}/{i}" for i in id_set]
                            if any(not school_get(Book, fid, pk_name='book_id') or is_book_active(fid) for fid in full_ids):
                                skipped_count += 1
                                continue
                            ref_book = school_query(Book).filter(Book.book_id.like(f"{base_id}/%")).first()
                            title = ref_book.title if ref_book else 'Unknown'
                            class_loan = ClassBorrowing(
                                class_name=class_name,
                                responsibles=responsibles,
                                book_title=title,
                                book_ids=f"{base_id}/{unique_ids}",
                                quantity=len(id_set),
                                condition=notes,
                                borrow_time=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                            )
                            stamp_sync_fields(class_loan)
                            db.session.add(class_loan)
                            new_loans.append(class_loan)
                            imported_count += 1

                        db.session.flush()
                        for loan in new_loans:
                            queue_record_change('class_checkouts', loan, operation='upsert')

                    else:
                        if is_ajax:
                            return jsonify({'status': 'error', 'message': 'Could not determine loan import type.'})
                        flash('Could not determine loan import type. Please choose the correct template.', 'danger')
                        return redirect(url_for('main.borrow'))

                    safe_commit()
                    
                    if is_ajax:
                        return jsonify({
                            'status': 'success',
                            'imported': imported_count,
                            'skipped': skipped_count,
                            'message': f'Imported {imported_count} {import_type} loan(s).' + (f' Skipped {skipped_count} row(s).' if skipped_count else '')
                        })
                    else:
                        if imported_count:
                            flash(f'Imported {imported_count} {import_type} loan(s).', 'success')
                        if skipped_count:
                            flash(f'Skipped {skipped_count} rows due to missing borrowers, books, or unavailable items.', 'warning')
                except Exception as e:
                    if is_ajax:
                        return jsonify({'status': 'error', 'message': f'Error importing file: {str(e)}'})
                    flash(f'Error importing excel: {str(e)}', 'danger')
            
            if is_ajax:
                return jsonify({'status': 'error', 'message': 'No file uploaded'})
            return redirect(url_for('main.borrow'))

        # --- 0. SPECIAL: QUICK ADD & BORROW HANDLER ---
        if action == 'quick_add_and_borrow':
            # A. Add ONLY the New (Missing) Books using expand_unique_ids (Task 2)
            common_id = (request.form.get('qa_common_id') or '').strip().rstrip('/')
            unique_ids_to_create = (request.form.get('qa_unique_ids') or '').strip()
            title = (request.form.get('qa_title') or '').strip()
            author = (request.form.get('qa_author') or '').strip() or "Unknown"
            category = (request.form.get('qa_category') or '').strip() or "Uncategorized"

            expanded_uids = expand_unique_ids(unique_ids_to_create)
            created_full_ids = []
            try:
                added_count = 0
                created_books = []
                for uid in expanded_uids:
                    full_id = f"{common_id}/{uid}" if common_id else str(uid)
                    created_full_ids.append(full_id)
                    if not school_get(Book, full_id, pk_name='book_id'):
                        book = Book(
                            book_id=full_id,
                            title=title,
                            author=author,
                            category=category,
                            added_at=datetime.now().strftime("%Y-%m-%d"),
                        )
                        stamp_sync_fields(book)
                        db.session.add(book)
                        created_books.append(book)
                        added_count += 1
                db.session.flush()
                for book in created_books:
                    queue_record_change('books', book, operation='upsert')
                safe_commit()
                flash(f"Quick Added {added_count} new books.", "success")
            except Exception as e:
                flash(f"Error creating book: {str(e)}", "danger")
                return redirect(url_for('main.borrow'))

            # B. Resume Original Borrow Action (Using the FULL list + any edited quick-add IDs)
            original_action = (request.form.get('original_action') or '').strip()
            if not original_action:
                return redirect(url_for('main.borrow'))

            if original_action == 'student_borrow':
                s_name = request.form.get('qa_borrower')
                raw_ids = request.form.get('qa_ids_raw') or ''
                existing_raw_list = [x.strip() for x in raw_ids.split(',') if x.strip() and school_get(Book, x.strip(), pk_name='book_id')]
                for cid in created_full_ids:
                    if cid not in existing_raw_list:
                        existing_raw_list.append(cid)
                raw_ids = ", ".join(existing_raw_list)
                condition = request.form.get('qa_notes')

                student = Student.query.filter(Student.name.ilike(f"{s_name}")).first()
                student = school_query(Student).filter(Student.name.ilike(f"{s_name}")).first()
                if not student:
                    flash("Student not found during resume.", "danger"); return redirect(url_for('main.borrow'))

                id_list = [x.strip() for x in raw_ids.split(',') if x.strip()]

                success_count = 0
                days = config.get('default_borrow_days', 14)
                due = (datetime.now() + timedelta(days=days)).strftime("%Y-%m-%d")
                new_loans = []

                for b_id in id_list:
                    if not is_book_active(b_id): # Check availability
                        book = school_get(Book, b_id, pk_name='book_id') # Should exist now
                        if book:
                            loan = BorrowedBook(
                                book_id=book.book_id,
                                book_title=book.title,
                                student_name=student.name,
                                student_class=student.student_class,
                                condition=condition,
                                timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                                due_date=due,
                            )
                            stamp_sync_fields(loan)
                            db.session.add(loan)
                            new_loans.append(loan)
                            success_count += 1
                db.session.flush()
                for l in new_loans:
                    queue_record_change('checkouts', l, operation='upsert')
                safe_commit()
                ids_str = ", ".join([l.book_id for l in new_loans])
                log_action("/borrow", "STUDENT_BORROW", f"{current_user.username} issued {success_count} book(s) ({ids_str}) to {s_name}")
                safe_push_sync()
                flash(f"Complete! Issued {success_count} books to {s_name}.", "success")
                return redirect(url_for('main.borrow'))

            elif original_action == 'staff_borrow':
                t_name = request.form.get('qa_borrower')
                raw_ids = request.form.get('qa_ids_raw') or ''
                notes = request.form.get('qa_notes')

                id_list = [x.strip() for x in raw_ids.split(',') if x.strip() and school_get(Book, x.strip(), pk_name='book_id')]
                for cid in created_full_ids:
                    if cid not in id_list:
                        id_list.append(cid)
                c = 0
                unavailable_ids = []
                new_teacher_loans = []
                for b_id in id_list:
                    if not is_book_active(b_id):
                        book = school_get(Book, b_id, pk_name='book_id')
                        if book:
                            loan = TeacherBorrowedBook(
                                book_id=book.book_id,
                                book_title=book.title,
                                teacher_name=t_name,
                                notes=notes,
                                timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                            )
                            stamp_sync_fields(loan)
                            db.session.add(loan)
                            new_teacher_loans.append(loan)
                            c += 1
                    else:
                        unavailable_ids.append(b_id)
                db.session.flush()
                for l in new_teacher_loans:
                    queue_record_change('staff_checkouts', l, operation='upsert')
                safe_commit()
                if c:
                    ids_str = ", ".join([l.book_id for l in new_teacher_loans])
                    log_action("/borrow", "STAFF_BORROW", f"{current_user.username} issued {c} book(s) ({ids_str}) to {t_name}")
                    safe_push_sync()
                    flash(f"Complete! Issued {c} books to {t_name}.", "success")
                if unavailable_ids:
                    shown = ", ".join(unavailable_ids[:8])
                    extra = f" and {len(unavailable_ids) - 8} more" if len(unavailable_ids) > 8 else ""
                    flash(f"Could not issue {len(unavailable_ids)} book(s) because they are already borrowed/unavailable: {shown}{extra}.", "warning")
                return redirect(url_for('main.borrow'))

            elif original_action == 'class_borrow':
                c_name = request.form.get('qa_borrower')
                responsibles = request.form.get('qa_responsibles')
                notes = request.form.get('qa_notes')
                full_range_str = request.form.get('qa_ids_raw') or f"{common_id}/{unique_ids_to_create}"

                if '/' in full_range_str:
                    orig_base, orig_uniques = full_range_str.split('/', 1)
                else:
                    orig_base, orig_uniques = common_id, full_range_str
                base_id = common_id or orig_base
                combined_uids = expand_unique_ids(orig_uniques)
                for u in expanded_uids:
                    if u not in combined_uids:
                        combined_uids.append(u)
                id_set = {int(x) for x in combined_uids if str(x).isdigit()} or set(combined_uids)
                num_set_only = {int(x) for x in combined_uids if str(x).isdigit()}
                unique_ids = set_to_range_string(num_set_only) if num_set_only else ",".join(combined_uids)
                full_range_str = f"{base_id}/{unique_ids}"

                # Fetch title from one of the books (now they all exist)
                ref_book = school_query(Book).filter(Book.book_id.like(f"{base_id}/%")).first()
                title = ref_book.title if ref_book else "Unknown"

                class_loan = ClassBorrowing(
                    class_name=c_name,
                    responsibles=responsibles,
                    book_title=title,
                    book_ids=full_range_str,
                    quantity=len(id_set),
                    condition=notes,
                    borrow_time=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                )
                stamp_sync_fields(class_loan)
                db.session.add(class_loan)
                db.session.flush()
                queue_record_change('class_checkouts', class_loan, operation='upsert')
                safe_commit()
                log_action("/borrow", "CLASS_BORROW", f"{current_user.username} issued {len(id_set)} class book(s) ({full_range_str}) to {c_name}")
                safe_push_sync()
                flash(f"Complete! Issued to class {c_name}.", "success")
                return redirect(url_for('main.borrow'))


        # --- 1. STUDENT BORROW ---
        if action == 'student_borrow':
            s_name = request.form.get('student_name')
            raw_ids = request.form.get('book_ids_hidden', '')
            condition = request.form.get('condition') or "Good"

            student = school_query(Student).filter(Student.name.ilike(f"{s_name}")).first()
            if not student:
                flash(f"Error: Student '{s_name}' not found.", "danger")
                return redirect(url_for('main.borrow'))

            id_list = [x.strip() for x in raw_ids.split(',') if x.strip()]
            if request.form.get('no_id_book') == '1' and (request.form.get('no_id_title') or '').strip():
                _, new_fids = _register_no_id_books(
                    title=request.form.get('no_id_title'),
                    author=request.form.get('no_id_author'),
                    category=request.form.get('no_id_category'),
                    qty=1,
                )
                for fid in new_fids:
                    if fid not in id_list:
                        id_list.append(fid)
            if not id_list:
                flash(_("No books selected."), "warning"); return redirect(url_for('main.borrow'))

            # CHECK FOR MISSING BOOKS
            missing_ids = [bid for bid in id_list if not school_get(Book, bid, pk_name='book_id')]

            if missing_ids:
                first_missing = missing_ids[0]
                base_id = first_missing.split('/')[0] if '/' in first_missing else first_missing

                # Calculate ONLY the unique parts that are missing
                missing_uniques_set = set()
                for m in missing_ids:
                    if '/' in m: missing_uniques_set.add(int(m.split('/')[1]))
                    else: missing_uniques_set.add(int(m)) # Fallback

                missing_range_str = set_to_range_string(missing_uniques_set)

                qa_data = {
                    'original_action': 'student_borrow',
                    'borrower': s_name,
                    'ids_raw': raw_ids, # Keep FULL list for resume
                    'notes': condition,
                    'base_id': base_id,
                    'unique_ids': missing_range_str, # Show ONLY missing range
                    'responsibles': ''
                }
                return render_template('borrow.html', quick_add_data=qa_data, categories=get_unique_categories())

            # Normal Processing
            current_loans = school_query(BorrowedBook).filter_by(student_name=student.name, returned=False).count()
            limit = config.get('max_books_per_student', 3)
            if current_loans + len(id_list) > limit:
                flash(f"Limit Reached: Student has {current_loans}/{limit} books.", "danger")
                return redirect(url_for('main.borrow'))

            count = 0
            due = (datetime.now() + timedelta(days=config.get('default_borrow_days', 14))).strftime("%Y-%m-%d")
            new_student_loans = []
            for b_id in id_list:
                if not is_book_active(b_id):
                    book = school_get(Book, b_id, pk_name='book_id')
                    loan = BorrowedBook(
                        book_id=b_id,
                        book_title=book.title,
                        student_name=student.name,
                        student_class=student.student_class,
                        condition=condition,
                        timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        due_date=due,
                    )
                    stamp_sync_fields(loan)
                    db.session.add(loan)
                    new_student_loans.append(loan)
                    count += 1
                else:
                    flash(f"Book {b_id} is already borrowed.", "warning")
            
            db.session.flush()
            for l in new_student_loans:
                queue_record_change('checkouts', l, operation='upsert')
            safe_commit()
            if count:
                ids_str = ", ".join([l.book_id for l in new_student_loans])
                log_action("/borrow", "STUDENT_BORROW", f"{current_user.username} issued {count} book(s) ({ids_str}) to {student.name}")
                safe_push_sync()
            if count: flash(f"Issued {count} books.", "success")

        # --- 2. STAFF BORROW ---
        elif action == 'staff_borrow':
            t_name = request.form.get('staff_name')
            raw_ids = request.form.get('book_ids_hidden_staff') or request.form.get('book_ids_hidden', '')
            notes = request.form.get('notes', '')

            id_list = [x.strip() for x in raw_ids.split(',') if x.strip()]
            if request.form.get('no_id_book') == '1' and (request.form.get('no_id_title') or '').strip():
                _, new_fids = _register_no_id_books(
                    title=request.form.get('no_id_title'),
                    author=request.form.get('no_id_author'),
                    category=request.form.get('no_id_category'),
                    qty=1,
                )
                for fid in new_fids:
                    if fid not in id_list:
                        id_list.append(fid)
            if not id_list:
                flash(_("No books selected."), "warning")
                return redirect(url_for('main.borrow'))

            # CHECK MISSING
            missing_ids = [bid for bid in id_list if not school_get(Book, bid, pk_name='book_id')]
            if missing_ids:
                first_missing = missing_ids[0]
                base_id = first_missing.split('/')[0] if '/' in first_missing else first_missing

                missing_uniques_set = set()
                for m in missing_ids:
                    if '/' in m: missing_uniques_set.add(int(m.split('/')[1]))
                missing_range_str = set_to_range_string(missing_uniques_set)

                qa_data = {
                    'original_action': 'staff_borrow',
                    'borrower': t_name,
                    'ids_raw': raw_ids,
                    'notes': notes,
                    'base_id': base_id,
                    'unique_ids': missing_range_str,
                    'responsibles': ''
                }
                return render_template('borrow.html', quick_add_data=qa_data, categories=get_unique_categories())

            count = 0
            unavailable_ids = []
            new_staff_loans = []
            for b_id in id_list:
                book = school_get(Book, b_id, pk_name='book_id')
                if book and not is_book_active(b_id):
                    loan = TeacherBorrowedBook(
                        book_id=book.book_id,
                        book_title=book.title,
                        teacher_name=t_name,
                        notes=notes,
                        timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    )
                    stamp_sync_fields(loan)
                    db.session.add(loan)
                    new_staff_loans.append(loan)
                    count += 1
                elif book:
                    unavailable_ids.append(b_id)
            db.session.flush()
            for l in new_staff_loans:
                queue_record_change('staff_checkouts', l, operation='upsert')
            safe_commit()
            if count:
                ids_str = ", ".join([l.book_id for l in new_staff_loans])
                log_action("/borrow", "STAFF_BORROW", f"{current_user.username} issued {count} book(s) ({ids_str}) to {t_name}")
                safe_push_sync()
            if count: flash(f"Issued {count} books.", "success")
            if unavailable_ids:
                shown = ", ".join(unavailable_ids[:8])
                extra = f" and {len(unavailable_ids) - 8} more" if len(unavailable_ids) > 8 else ""
                flash(f"Could not issue {len(unavailable_ids)} book(s) because they are already borrowed/unavailable: {shown}{extra}.", "warning")

        # --- 3. CLASS BORROW ---
        elif action == 'class_borrow':
            c_name = request.form.get('class_name', '').strip()
            responsibles = request.form.get('responsibles', '')
            base_id = request.form.get('base_id', '').strip().rstrip('/')
            unique_ids = request.form.get('unique_ids', '').strip()
            notes = request.form.get('condition')

            if request.form.get('no_id_book') == '1' and (request.form.get('no_id_title') or '').strip() and not base_id:
                try:
                    qty = max(1, int(request.form.get('no_id_qty') or 1))
                except (ValueError, TypeError):
                    qty = 1
                base_id, _ = _register_no_id_books(
                    title=request.form.get('no_id_title'),
                    author=request.form.get('no_id_author'),
                    category=request.form.get('no_id_category'),
                    qty=qty,
                )
                unique_ids = f"1-{qty}" if qty > 1 else "1"

            if not base_id:
                flash("Base ID is required for class borrow.", "danger"); return redirect(url_for('main.borrow'))
            if not unique_ids:
                flash("Unique ID(s) are required for class borrow.", "danger"); return redirect(url_for('main.borrow'))

            if not school_query(Student).filter(Student.student_class.ilike(c_name)).first():
                flash(f"Class '{c_name}' not found.", "danger"); return redirect(url_for('main.borrow'))

            normalized = normalize_unique_ids(unique_ids)
            id_set = parse_range_to_set(normalized)
            if not id_set:
                flash("Invalid class book range. Use numbers or ranges like 1-5.", "danger"); return redirect(url_for('main.borrow'))

            # CHECK MISSING (PARTIAL LOGIC)
            missing_set = set()
            for i in id_set:
                if not school_get(Book, f"{base_id}/{i}", pk_name='book_id'):
                    missing_set.add(i)

            if missing_set:
                # We found some missing books!
                missing_range = set_to_range_string(missing_set) # e.g. "3-5"

                qa_data = {
                    'original_action': 'class_borrow',
                    'borrower': c_name,
                    'ids_raw': f"{base_id}/{unique_ids}", # FULL range for resume
                    'notes': notes,
                    'base_id': base_id,
                    'unique_ids': missing_range, # ONLY missing ones for creation
                    'responsibles': responsibles
                }
                # Also pass 'preserved_input' to repopulate the form
                qa_data['input_unique_ids'] = unique_ids
                return render_template('borrow.html', quick_add_data=qa_data, categories=get_unique_categories())

            # Normal Processing & Partial Class Borrowing Interception (Task 8)
            confirm_partial = request.form.get('confirm_partial') in ('1', 'true', 'yes', True)
            categories = get_unique_categories()
            available_ids = []
            available_num_set = set()
            unavailable_items = []
            for num in sorted(id_set):
                fid = f"{base_id}/{num}"
                if is_book_active(fid):
                    st = get_book_status_info(fid)
                    unavailable_items.append({
                        'book_id': fid,
                        'detail': st.get('detail', 'Already borrowed'),
                    })
                else:
                    available_ids.append(fid)
                    available_num_set.add(num)

            if unavailable_items and available_ids and not confirm_partial:
                return render_template('borrow.html', partial_loan_data={'available_ids': available_ids, 'unavailable_items': unavailable_items, 'available_unique_ids': set_to_range_string(available_num_set), 'class_name': c_name, 'responsibles': responsibles, 'base_id': base_id, 'unique_ids': unique_ids, 'notes': notes}, categories=categories)

            if unavailable_items and not available_ids:
                shown = ", ".join([item['book_id'] for item in unavailable_items[:5]])
                extra = f" and {len(unavailable_items)-5} more" if len(unavailable_items) > 5 else ""
                flash(f"Could not issue {len(unavailable_items)} book(s) because all requested copies are already borrowed: {shown}{extra}.", "danger")
            else:
                final_num_set = available_num_set if confirm_partial else id_set
                final_unique_range = set_to_range_string(final_num_set)
                ref_book = school_query(Book).filter(Book.book_id.like(f"{base_id}/%")).first()
                title = ref_book.title if ref_book else "Unknown"
                class_loan = ClassBorrowing(
                    class_name=c_name,
                    responsibles=responsibles,
                    book_title=title,
                    book_ids=f"{base_id}/{final_unique_range}",
                    quantity=len(final_num_set),
                    condition=notes,
                    borrow_time=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                )
                stamp_sync_fields(class_loan)
                db.session.add(class_loan)
                db.session.flush()
                queue_record_change('class_checkouts', class_loan, operation='upsert')
                safe_commit()
                log_action("/borrow", "CLASS_BORROW", f"{current_user.username} issued {len(final_num_set)} class book(s) to {c_name}")
                safe_push_sync()
                flash(f"Issued {len(final_num_set)} books to {c_name}.", "success")

        return redirect(url_for('main.borrow'))

    return render_template('borrow.html', categories=get_unique_categories())

# --- TEMPLATE DOWNLOADS FOR LOANS ---
@main.route('/borrow/template/<type>')
@login_required
def download_loan_template(type):
    output = BytesIO()
    if type == 'student':
        data = {"Student Name": ["MUGISHA"], "Book ID": ["100-20/1"], "Condition": ["Good"]}
        name = "student_loan_template.xlsx"
    elif type == 'staff':
        data = {"Staff Name": ["Teacher John"], "Book ID": ["100-20/5"], "Condition": ["Good"]}
        name = "staff_loan_template.xlsx"
    elif type == 'class':
        data = {"Class": ["S3MPC"], "Responsibles": ["Alice"], "Base ID": ["100-20"], "Unique IDs": ["1-50"], "Condition": ["Good"]}
        name = "class_loan_template.xlsx"
    else:
        return redirect(url_for('main.borrow'))

    df = pd.DataFrame(data)
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False)
    output.seek(0)
    return send_file(output, as_attachment=True, download_name=name)

# --- AUTOCOMPLETE APIs ---
@main.route('/api/search_students')
@login_required
def search_students_api():
    query = request.args.get('q', '').strip()
    class_filter = request.args.get('class', '').strip()
    if not query: 
        return jsonify([])
        
    db_query = school_query(Student)
    if class_filter:
        db_query = db_query.filter(Student.student_class == class_filter)
        
    # FIX: Group by name and class to completely eliminate duplicates
    results = db_query.with_entities(Student.name, Student.student_class).filter(
        Student.name.ilike(f"%{query}%")
    ).distinct().limit(8).all()
    
    suggestions = [{'name': r.name, 'class': r.student_class} for r in results]
    return jsonify(suggestions)


@main.route('/api/search_books')
@login_required
def search_books_api():
    query = request.args.get('q', '').strip()
    if not query: return jsonify([])

    search_pattern = f"%{query}%"
    results = school_query(Book).filter(
        db.or_(
            Book.book_id.ilike(search_pattern),
            Book.title.ilike(search_pattern),
            Book.author.ilike(search_pattern),
            Book.category.ilike(search_pattern),
            Book.custom_fields.ilike(search_pattern)
        )
    ).limit(50).all()
    
    book_ids = [b.book_id for b in results]

    # Pre-fetch active status lookups in bulk to avoid N+1 query issue
    active_student_loans = {l.book_id for l in school_query(BorrowedBook).filter(BorrowedBook.book_id.in_(book_ids), BorrowedBook.returned == False).all()} if book_ids else set()
    active_staff_loans = {l.book_id for l in school_query(TeacherBorrowedBook).filter(TeacherBorrowedBook.book_id.in_(book_ids), TeacherBorrowedBook.returned == False).all()} if book_ids else set()
    active_grad_loans = {l.book_id for l in school_query(GraduateBorrowing).filter(GraduateBorrowing.book_id.in_(book_ids)).all()} if book_ids else set()
    active_class_loans = school_query(ClassBorrowing).filter_by(returned=False).all() if book_ids else []
    archived_class_loans = school_query(GraduateClassBorrowing).all() if book_ids else []

    # Group results by Base ID
    grouped = {}
    for b in results:
        base = b.book_id.split('/')[0] if '/' in b.book_id else b.book_id
        if base not in grouped:
            grouped[base] = {'id': base, 'title': b.title, 'author': b.author, 'total': 0, 'available': 0}
        grouped[base]['total'] += 1
        is_active = (
            b.book_id in active_student_loans or
            b.book_id in active_staff_loans or
            b.book_id in active_grad_loans or
            any(_book_id_in_range(b.book_id, cl.book_ids) for cl in active_class_loans) or
            any(_book_id_in_range(b.book_id, cl.book_ids) for cl in archived_class_loans)
        )
        if not is_active:
            grouped[base]['available'] += 1
            
    # Return top 8 grouped results
    out = list(grouped.values())[:8]
    return jsonify(out)

@main.route('/api/available_book_numbers')
@login_required
def available_book_numbers_api():
    base_id = request.args.get('base_id', '').strip()
    if not base_id: 
        return jsonify([])
    
    # 1. Fetch all books that belong to this Base ID
    books = school_query(Book).filter(Book.book_id.like(f"{base_id}/%")).all()
    book_ids = [b.book_id for b in books]
    
    active_student_loans = {l.book_id for l in school_query(BorrowedBook).filter(BorrowedBook.book_id.in_(book_ids), BorrowedBook.returned == False).all()} if book_ids else set()
    active_staff_loans = {l.book_id for l in school_query(TeacherBorrowedBook).filter(TeacherBorrowedBook.book_id.in_(book_ids), TeacherBorrowedBook.returned == False).all()} if book_ids else set()
    active_grad_loans = {l.book_id for l in school_query(GraduateBorrowing).filter(GraduateBorrowing.book_id.in_(book_ids)).all()} if book_ids else set()
    active_class_loans = school_query(ClassBorrowing).filter_by(returned=False).all() if book_ids else []
    archived_class_loans = school_query(GraduateClassBorrowing).all() if book_ids else []

    available_numbers = []
    for b in books:
        # 2. Only add to list if the book is NOT actively borrowed or still owed in class archives/graduates
        is_active = (
            b.book_id in active_student_loans or
            b.book_id in active_staff_loans or
            b.book_id in active_grad_loans or
            any(_book_id_in_range(b.book_id, cl.book_ids) for cl in active_class_loans) or
            any(_book_id_in_range(b.book_id, cl.book_ids) for cl in archived_class_loans)
        )
        if not is_active:
            try:
                # Extract the suffix number (e.g., the '5' from '100-20/5')
                num = b.book_id.split('/')[1]
                available_numbers.append(int(num))
            except (IndexError, ValueError):
                # Fallback just in case a number is formatted weirdly
                available_numbers.append(b.book_id.split('/')[-1])

    available_numbers.sort(key=lambda x: int(x) if isinstance(x, int) else 999999)
    return jsonify([str(n) for n in available_numbers])
@main.route('/api/search_staff')
@login_required
def search_staff_api():
    query = request.args.get('q', '').strip()
    if not query: return jsonify([])
    # Search unique names from previous teacher loans
    results = school_query(TeacherBorrowedBook).with_entities(TeacherBorrowedBook.teacher_name).filter(TeacherBorrowedBook.teacher_name.ilike(f"%{query}%")).distinct().limit(8).all()
    return jsonify([{'name': r[0]} for r in results])

@main.route('/api/search_classes')
@login_required
def search_classes_api():
    query = request.args.get('q', '').strip()
    if not query: return jsonify([])
    # Search distinct classes from Student table
    results = school_query(Student).with_entities(Student.student_class).filter(Student.student_class.ilike(f"%{query}%")).distinct().limit(8).all()
    return jsonify([{'name': r[0]} for r in results])


# New: Student suggestions requiring class_name filter
@main.route('/api/students/suggestions')
@login_required
def student_suggestions_api():
    query = request.args.get('q', '').strip()
    class_name = request.args.get('class_name', '').strip()
    # Require class_name to be provided
    if not class_name:
        return jsonify([])

    students_query = school_query(Student)
    # ensure non-deleted and same class
    students_query = students_query.filter(
        Student.student_class == class_name,
        Student.deleted == False
    )

    if query:
        students_query = students_query.filter(Student.name.ilike(f"%{query}%"))

    results = students_query.limit(10).all()

    return jsonify([
        {"id": s.id, "name": s.name, "class": s.student_class}
        for s in results
    ])


@main.route('/api/books/search')
@login_required
def books_search_api():
    query = request.args.get('q', '').strip()
    if not query:
        return jsonify([])

    books = school_query(Book).filter(
        Book.deleted == False,
        (Book.book_id.ilike(f"%{query}%")) | (Book.title.ilike(f"%{query}%"))
    ).limit(50).all()

    grouped = {}
    for b in books:
        base_id = b.book_id.split('/')[0] if '/' in b.book_id else b.book_id
        if base_id not in grouped:
            grouped[base_id] = {
                "book_id": base_id,
                "title": b.title,
                "category": b.category,
            }

    return jsonify(list(grouped.values())[:10])

@main.route('/api/sync/upload', methods=['POST'])
@login_required
def sync_upload():
    sync_service = get_sync_service()
    if not sync_service:
        return jsonify({"success": False, "message": "Sync service unavailable."}), 503

    school_id = get_current_school_id()
    if not school_id:
        return jsonify({"success": False, "message": "Set up your school first before enabling online sync."}), 400

    if not sync_service.school_allows_online_sync(school_id):
        return jsonify({"success": False, "message": "Online sync is not enabled for this school yet."}), 400

    # SECURITY: Validate content type and input
    if not request.is_json:
        return jsonify({"success": False, "message": "Content-Type must be application/json"}), 400
    
    payload = request.get_json(silent=True) or {}
    
    # Validate payload structure
    if not isinstance(payload, dict):
        return jsonify({"success": False, "message": "Invalid payload format"}), 400
    
    items = payload.get('items', [])
    if not isinstance(items, list):
        return jsonify({"success": False, "message": "Items must be an array"}), 400
    
    # Limit items to prevent DoS
    if len(items) > 500:
        return jsonify({"success": False, "message": "Too many items (max 500)"}), 400
    
    limit = payload.get('limit', current_app.config.get('SYNC_BATCH_SIZE', 100))
    try:
        limit = max(1, min(int(limit), 500))
    except (ValueError, TypeError):
        limit = current_app.config.get('SYNC_BATCH_SIZE', 100)
    
    imported = 0

    try:
        # Valid entity types allowlist
        VALID_ENTITY_TYPES = {
            'books', 'members', 'checkouts', 'staff_checkouts', 
            'class_checkouts', 'book_issues', 'librarians', 'schools', 'logs'
        }
        VALID_OPERATIONS = {'upsert', 'update', 'delete', 'insert'}
        
        if items:
            for item in items:
                if not isinstance(item, dict):
                    continue
                    
                entity_type = item.get('entity_type')
                operation = item.get('operation')
                operation_id = item.get('operation_id')
                item_payload = item.get('payload') or {}
                
                # SECURITY: Validate against allowlist
                if entity_type not in VALID_ENTITY_TYPES:
                    logger.warning(f"Sync upload rejected invalid entity_type: {entity_type}")
                    continue
                if operation not in VALID_OPERATIONS:
                    logger.warning(f"Sync upload rejected invalid operation: {operation}")
                    continue
                if not item_payload or not isinstance(item_payload, dict):
                    continue
                
                # SECURITY: Ensure school_id matches current user's school
                school_id = get_current_school_id()
                item_payload['school_id'] = school_id
                
                entity_id = (
                    item_payload.get('book_id')
                    or item_payload.get('id')
                    or item.get('entity_id')
                    or operation_id
                )
                
                if not entity_id:
                    continue
                
                # Check for duplicate operation_id
                if operation_id and SyncQueue.query.filter_by(operation_id=operation_id).first():
                    continue

                sync_service.queue_change(
                    entity_type=entity_type,
                    entity_id=entity_id,
                    operation=operation,
                    payload=item_payload,
                    school_id=school_id,
                    record_updated_at=item_payload.get('updated_at'),
                    operation_id=operation_id,
                )
                imported += 1
            safe_commit()

        summary = sync_service.upload_pending_changes(school_id=school_id, limit=limit)

        return jsonify({
            "success": True,
            "imported": imported,
            "summary": {
                "uploaded": summary.get("uploaded", 0),
                "failed": summary.get("failed", 0),
                "conflicts": summary.get("conflicts", 0),
                "skipped": summary.get("skipped", 0),
                "duration_seconds": round(summary.get("duration_seconds", 0), 2),
                "message": summary.get("message", "Upload completed"),
            },
            "status": sync_service.get_status(school_id),
        })
    except Exception as exc:
        db.session.rollback()
        current_app.logger.exception("Sync upload failed")
        return jsonify({"success": False, "message": "Sync upload failed"}), 500


@main.route('/api/sync/mark_db_downloaded', methods=['POST'])
@login_required
def mark_db_downloaded():
    try:
        active_school = current_user.school_id
        if not active_school:
            return jsonify({"success": False, "message": "No active school found."}), 400

        # --- THE FIX: PURGE GHOST RECORDS ---
        # Delete any local records that don't belong to the newly joined school
        models_to_clean = [
            Book, Student, BorrowedBook, TeacherBorrowedBook, 
            ClassBorrowing, BookIssue, Note, Log, 
            GraduateBorrowing, GraduateClassBorrowing
        ]
        
        for model in models_to_clean:
            if hasattr(model, 'school_id'):
                model.query.filter((model.school_id != active_school) | (model.school_id.is_(None))).delete(synchronize_session=False)

        current_user.has_downloaded_db = True
        safe_commit()
        
        current_app.logger.info(f"Ghost data purged. DB marked as downloaded for user {current_user.username}.")
        return jsonify({"success": True})
        
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Failed to clean ghost data and mark db as downloaded: {e}")
        return jsonify({"success": False, "message": "Failed to finalize download."}), 500

    
@main.route('/api/sync/download', methods=['POST'])
@login_required
def sync_download():
    sync_service = get_sync_service()
    if not sync_service:
        return jsonify({"success": False, "message": "Sync service unavailable."}), 503

    school_id = get_current_school_id()
    if not school_id:
        return jsonify({"success": False, "message": "Set up your school first before enabling online sync."}), 400

    force_initial = not current_user.has_downloaded_db
    if not force_initial and not sync_service.school_allows_online_sync(school_id):
        return jsonify({"success": False, "message": "Online sync is not enabled for this school yet."}), 400

    # SECURITY: Validate content type and input
    if not request.is_json:
        return jsonify({"success": False, "message": "Content-Type must be application/json"}), 400
    
    payload = request.get_json(silent=True) or {}
    
    # Validate limit parameter
    try:
        limit = max(1, min(int(payload.get('limit', 250)), 1000))
    except (ValueError, TypeError):
        limit = 250

    try:
        summary = sync_service.download_remote_changes(school_id=school_id, limit=limit, force_initial=force_initial)

        return jsonify({
            "success": True,
            "summary": {
                "downloaded": summary.get("downloaded", 0),
                "conflicts": summary.get("conflicts", 0),
                "duration_seconds": round(summary.get("duration_seconds", 0), 2),
                "message": summary.get("message", "Download completed"),
            },
            "status": sync_service.get_status(school_id),
        })
    except Exception as exc:
        current_app.logger.exception("Sync download failed")
        return jsonify({"success": False, "message": "Sync download failed"}), 500


@main.route('/api/sync/status')
@login_required
def sync_status():
    sync_service = get_sync_service()
    if not sync_service:
        return jsonify({"success": False, "message": "Sync service unavailable."}), 503

    school_id = get_current_school_id()
    status = sync_service.get_status(school_id)
    config = load_config()
    school = School.query.get(school_id) if school_id else None
    is_local_only = bool(
        getattr(current_user, 'local_only', False)
        or config.get('local_only', False)
        or (school and not school.allow_online_sync)
    )
    status["local_only"] = is_local_only

    try:
        import peer_sync
        p_status = peer_sync.get_status()
        peers_dict = p_status.get("peers", {}) or {}
        role = p_status.get("role")
        lan_peers_count = len(peers_dict) if role == "major" else (1 if p_status.get("connected") else 0)
        status["lan_connected"] = bool(p_status.get("connected"))
        status["lan_running"] = bool(p_status.get("running"))
        status["lan_role"] = role
        status["lan_peers_count"] = lan_peers_count
        status["lan_major_ip"] = p_status.get("major_ip")
        status["lan_pending_count"] = p_status.get("pending_count", 0)
    except Exception:
        status["lan_connected"] = False
        status["lan_running"] = False
        status["lan_role"] = None
        status["lan_peers_count"] = 0

    recent_queue = (
        SyncQueue.query.filter_by(school_id=school_id)
        .order_by(SyncQueue.created_at.desc())
        .limit(20)
        .all()
    )
    status["recent_queue"] = [
        {
            "entity_type": item.entity_type,
            "entity_id": item.entity_id,
            "operation": item.operation,
            "status": item.status,
            "attempt_count": item.attempt_count,
            "last_error": item.last_error,
            "created_at": item.created_at.isoformat() if item.created_at else None,
        }
        for item in recent_queue
    ]
    status["success"] = True
    return jsonify(status)



@main.route('/api/cloud-sync/status', methods=['GET'])
@login_required
def cloud_sync_status():
    return sync_status()


@main.route('/api/cloud-sync/upload', methods=['POST'])
@login_required
def cloud_sync_upload():
    return sync_upload()


@main.route('/api/cloud-sync/download', methods=['POST'])
@login_required
def cloud_sync_download():
    return sync_download()



# --- ACTIVE LOANS (4 SECTIONS) ---
@main.route('/borrowed')
@login_required
def borrowed():
    # 1. Students
    students = school_query(BorrowedBook).filter_by(returned=False).order_by(BorrowedBook.id.desc()).all()
    # 2. Graduates (Individual)
    all_grads = school_query(GraduateBorrowing).all()
    graduates = [g for g in all_grads if not g.notes or "[RETURNED]" not in g.notes]
    
    # 3. Staff
    staff = school_query(TeacherBorrowedBook).filter_by(returned=False).all()
    
    # 4. Classes (Active)
    classes = school_query(ClassBorrowing).filter_by(returned=False).all()
    
    # 5. NEW: Archived Class Loans
    all_grad_classes = school_query(GraduateClassBorrowing).all()
    grad_classes = [c for c in all_grad_classes if not c.condition or "[RETURNED]" not in c.condition]
    # 6. Issues (if any)
    try:
        issues = school_query(BookIssue).order_by(BookIssue.created_at.desc()).all()
    except Exception:
        issues = []

    # Build issue_map and issue_details similar to the newer implementation
    from collections import defaultdict
    issue_map = defaultdict(list)
    issue_details = []
    if issues:
        for issue in issues:
            key = f"{issue.loan_type}_{issue.loan_id}"
            issue_map[key].append(issue)

            borrower = 'Unknown'
            extra = ''
            issue_book_id = ''
            if issue.loan_type == 'student':
                loan = school_get(BorrowedBook, issue.loan_id)
                if loan:
                    borrower = loan.student_name
                    extra = loan.student_class
                    issue_book_id = loan.book_id
            elif issue.loan_type == 'staff':
                loan = school_get(TeacherBorrowedBook, issue.loan_id)
                if loan:
                    borrower = loan.teacher_name
                    issue_book_id = loan.book_id
            elif issue.loan_type == 'class':
                loan = school_get(ClassBorrowing, issue.loan_id)
                if loan:
                    borrower = loan.class_name
                    issue_book_id = loan.book_ids
            elif issue.loan_type == 'graduate':
                loan = school_get(GraduateBorrowing, issue.loan_id)
                if loan:
                    borrower = loan.student_name
                    extra = loan.original_class
                    issue_book_id = loan.book_id
            elif issue.loan_type == 'graduate_class':
                loan = school_get(GraduateClassBorrowing, issue.loan_id)
                if loan:
                    borrower = loan.class_name
                    issue_book_id = loan.book_ids

            issue_details.append({'issue': issue, 'borrower': borrower, 'extra': extra, 'book_id': issue_book_id, 'loan': loan})

    return render_template('borrowed_list.html',
                         students=students,
                         graduates=graduates,
                         staff=staff,
                         classes=classes,
                         grad_classes=grad_classes,
                         issues=issues,
                         issue_map=issue_map,
                         issue_details=issue_details)


@main.route('/api/class_students')
@login_required
def api_class_students():
    class_name = request.args.get('class_name', '').strip()
    if not class_name:
        return jsonify([])
    students = school_query(Student).filter(Student.student_class == class_name).all()
    return jsonify([{'id': s.id, 'name': s.name} for s in students])


@main.route('/report_class_issue/<id>', methods=['POST'])
@login_required
def report_class_issue(id):
    clean_id = str(id).strip()
    loan = school_get_or_404(ClassBorrowing, clean_id)
    base_id = loan.book_ids.split('/', 1)[0] if '/' in loan.book_ids else loan.book_ids

    raw_book_nums = request.form.get('issue_book_nums', '').strip()
    selected_nums = []

    if raw_book_nums:
        try:
            id_set = parse_range_to_set(raw_book_nums)
            selected_nums = [str(n) for n in sorted(id_set)]
        except Exception:
            pass
    else:
        if '/' in loan.book_ids:
            nums_part = loan.book_ids.split('/', 1)[1]
            try:
                nums = parse_range_to_set(nums_part)
                selected_nums = [str(n) for n in sorted(nums)]
            except Exception:
                selected_nums = []

    if not selected_nums:
        flash("No unique book IDs were selected for this class issue.", "warning")
        return redirect(url_for('main.borrowed'))

    assign_mode = request.form.get(f'assign_mode_{id}', 'all')
    issue_description = request.form.get('issue_description', '').strip()
    repair_cost = 0.0
    try:
        repair_cost = float(request.form.get('repair_cost') or 0)
    except Exception:
        repair_cost = 0.0

    selected_students = []
    if assign_mode == 'select':
        raw_list = request.form.getlist('student_names')
        if raw_list:
            selected_students = [s.strip() for s in raw_list if s and s.strip()]
    else:
        # Fetch current class roster for "Whole Class"
        from .database import Student
        class_members = Student.query.filter_by(student_class=loan.class_name, school_id=current_user.school_id).all()
        selected_students = [m.name for m in class_members]

    created = 0
    try:
        nums_set = set(int(n) for n in selected_nums)
        range_str = set_to_range_string(nums_set)
        book_id = f"{base_id}/{range_str}"
        
        students_str = ", ".join(selected_students)
        new_issue = BookIssue(
            loan_id=loan.id,
            loan_type='class',
            issue_description=f"{issue_description} (Books: {book_id}, Students: {students_str})" if issue_description else f"Class issue for books {book_id}, students: {students_str}",
            repair_cost=repair_cost,
            status='Pending',
            created_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        )
        stamp_sync_fields(new_issue)
        db.session.add(new_issue)
        db.session.flush()
        queue_record_change('book_issues', new_issue, operation='upsert')
        created += 1

        send_sms = request.form.get('send_sms')
        if send_sms == 'yes':
            parent_phones = request.form.get('parent_phones', '').strip()
            sms_message = request.form.get('sms_message', '').strip()
            if parent_phones and sms_message:
                receivers = [p.strip() for p in parent_phones.split(',') if p.strip()]
                if receivers:
                    if current_user.textbee_device_id and current_user.textbee_api_key:
                        try:
                            url = f"https://api.textbee.dev/api/v1/gateway/devices/{current_user.textbee_device_id}/sendSMS"
                            payload = {"receivers": receivers, "smsBody": sms_message}
                            headers = {"x-api-key": current_user.textbee_api_key}
                            response = requests.post(url, json=payload, headers=headers, timeout=10)
                            if response.status_code == 200:
                                flash("SMS notification(s) sent successfully.", "success")
                            else:
                                flash(f"Issue recorded, but SMS failed. TextBee returned status: {response.status_code}", "warning")
                        except Exception as e:
                            flash(f"Issue recorded, but SMS failed to send due to an error: {str(e)}", "warning")
                    else:
                        flash("Issue recorded. SMS not sent because TextBee is not configured in your profile.", "warning")
                else:
                    flash("Issue recorded. SMS not sent because no valid phone numbers were provided.", "warning")

        # --- NEW LOGIC: Remove reported books from active loan ---
        if selected_nums and '/' in loan.book_ids:
            try:
                base_id_part, current_range_str = loan.book_ids.split('/', 1)
                current_set = parse_range_to_set(current_range_str)
                returning_set = set(int(n) for n in selected_nums)
                new_set = current_set - returning_set

                if len(new_set) == 0:
                    loan.returned = True
                    loan.return_date = datetime.now().strftime("%Y-%m-%d")
                    loan.quantity = 0
                    loan.book_ids = f"{base_id_part}/(Returned)"
                else:
                    new_range_str = set_to_range_string(new_set)
                    loan.book_ids = f"{base_id_part}/{new_range_str}"
                    loan.quantity = len(new_set)

                # Update responsibles with the students who caused the issue (counted as returned)
                if selected_students:
                    existing_responsibles = []
                    if loan.responsibles:
                        try:
                            import json
                            existing_responsibles = json.loads(loan.responsibles)
                            if not isinstance(existing_responsibles, list):
                                existing_responsibles = [s.strip() for s in loan.responsibles.split(',') if s.strip()]
                        except Exception:
                            existing_responsibles = [s.strip() for s in loan.responsibles.split(',') if s.strip()]
                    
                    for student in selected_students:
                        if student not in existing_responsibles:
                            existing_responsibles.append(student)
                    import json
                    loan.responsibles = ', '.join(existing_responsibles)

                stamp_sync_fields(loan)
                queue_record_change('class_checkouts', loan, operation='upsert')
            except Exception as e:
                pass # Safe fallback, issues still recorded

        safe_commit()
        flash(f"Reported {created} issue(s) for class {loan.class_name}.", "success")
    except Exception as exc:
        safe_rollback()
        current_app.logger.exception(exc)
        flash("Error recording class issues.", "danger")

    safe_push_sync()
    return redirect(url_for('main.borrowed'))

# --- RETURN ROUTES ---


@main.route('/return/<id>', methods=['POST'])
@login_required
def return_book(id):
    # 1. FETCH LOAN
    clean_id = str(id).strip()
    loan = school_get_or_404(BorrowedBook, clean_id)

    # 2. CHECK FOR ISSUE FLAG (The "Split" Logic)
    has_issue = request.form.get('has_issue')

    if has_issue == 'yes':
        # --- BRANCH A: RETURN WITH ISSUES ---
        try:
            description = request.form.get('issue_description')
            cost_input = request.form.get('repair_cost', '0').strip()
            cost = float(cost_input) if cost_input else 0.0

            new_issue = BookIssue(
                loan_id=loan.id,
                loan_type='student',
                issue_description=description,
                repair_cost=cost,
                status='Pending',
                created_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            )
            stamp_sync_fields(new_issue)
            db.session.add(new_issue)
            db.session.flush()
            queue_record_change('book_issues', new_issue, operation='upsert')
            log_action("/return", "ISSUE_CREATED", f"{current_user.username} created issue for book '{loan.book_title}' (student: {loan.student_name}): {description} (Cost: {cost})")
            flash("Book returned and issue recorded.", "success")

            # --- SMS NOTIFICATION LOGIC (TEXTBEE) ---
            send_sms = request.form.get('send_sms')
            if send_sms == 'yes':
                parent_phone = request.form.get('parent_phone', '').strip()
                sms_message = request.form.get('sms_message', '').strip()

                if parent_phone and sms_message:
                    device_id = current_user.textbee_device_id
                    api_key = current_user.textbee_api_key
                    if not device_id or not api_key:
                        flash("Issue recorded. SMS not sent because TextBee is not configured in your profile.", "warning")
                    else:
                        # Capture app and user context before entering the background thread
                        app = current_app._get_current_object()
                        username = current_user.username
                        
                        def send_with_notification(app_obj, user_name, dev_id, key, phone, msg):
                            # Initialize app context so database and logger work inside the thread
                            with app_obj.app_context():
                                success = False
                                attempts = 0
                                max_retries = 3
                                error_msg = ""
                                
                                # 1. Send SMS with Retry Logic
                                while attempts < max_retries and not success:
                                    attempts += 1
                                    try:
                                        url = "https://api.textbee.dev/api/v1/gateway/send-sms"
                                        headers = {"x-api-key": key}
                                        payload = {
                                            "deviceId": dev_id,
                                            "recipients": [phone],
                                            "message": msg
                                        }
                                        
                                        import requests
                                        import time
                                        resp = requests.post(url, headers=headers, json=payload, timeout=15)
                                        
                                        # Accept HTTP 200 (OK) or 201 (Created) as success
                                        if resp.status_code in (200, 201):
                                            try:
                                                resp_data = resp.json()
                                                if resp_data.get("data", {}).get("success") or resp.status_code == 201:
                                                    success = True
                                                    break
                                            except ValueError:
                                                # If response is not JSON but status is 200/201, treat as success
                                                success = True
                                                break
                                        
                                        error_msg = f"HTTP {resp.status_code}: {resp.text}"
                                    except Exception as e:
                                        error_msg = str(e)
                                    
                                    # Wait before retrying if failed
                                    if not success and attempts < max_retries:
                                        import time
                                        time.sleep(5)
                                
                                # 2. Create notification for SMS status
                                try:
                                    import json
                                    from .database import Log, db
                                    from .utils import safe_commit
                                    
                                    if success:
                                        details = {
                                            'type': 'sms_status',
                                            'status': 'sent',
                                            'phone': phone,
                                            'attempts': attempts,
                                            'message': f"SMS sent successfully to {phone} (attempt {attempts})",
                                            'timestamp': datetime.now().isoformat()
                                        }
                                    else:
                                        details = {
                                            'type': 'sms_status',
                                            'status': 'failed',
                                            'phone': phone,
                                            'attempts': attempts,
                                            'error': error_msg,
                                            'message': f"SMS failed after {attempts} attempts to {phone}: {error_msg}",
                                            'timestamp': datetime.now().isoformat()
                                        }
                                        
                                    notification = Log(
                                        username=user_name,
                                        method='SMS_NOTIFICATION',
                                        details=json.dumps(details),
                                        timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                                    )
                                    db.session.add(notification)
                                    safe_commit()
                                except Exception as e:
                                    app_obj.logger.warning(f"Failed to create SMS notification log: {e}")
                        
                        # Start background thread
                        import threading
                        threading.Thread(
                            target=send_with_notification,
                            args=(app, username, device_id, api_key, parent_phone, sms_message),
                            daemon=True
                        ).start()
                        
                        flash("Issue recorded. SMS notification has been queued to send.", "success")
                else:
                    flash("Issue recorded. SMS not sent because phone number or message body was empty.", "warning")

        except ValueError:
            flash("Error: Invalid repair cost format.", "danger")
            return redirect(url_for('main.borrowed'))

    else:
        # --- BRANCH B: NORMAL RETURN ---
        flash("Book returned successfully (Good Condition).", "success")

    # 3. CLOSE THE LOAN (Common Action)
    loan.returned = True
    loan.return_date = datetime.now().strftime("%Y-%m-%d")
    stamp_sync_fields(loan)
    queue_record_change('checkouts', loan, operation='upsert')
    
    safe_commit()
    log_action("/return", "RETURN_BOOK", f"{current_user.username} returned {loan.book_title} for {loan.student_name}")
    safe_push_sync()
    return redirect(url_for('main.borrowed'))

@main.route('/return_graduate/<id>', methods=['POST'])
@login_required
def return_graduate(id):
    clean_id = str(id).strip()
    loan = school_get_or_404(GraduateBorrowing,clean_id)

    # We could implement issue recording here similar to return_book if needed,
    # but the current template just submits a simple form without has_issue field.
    # For now, we will just delete the record from the archive upon return.

    stamp_sync_fields(loan, deleted=True)
    queue_record_change('graduates_borrowed', loan, operation='delete')
    db.session.delete(loan)
    safe_commit()

    log_action("/return_graduate", "RETURN_GRADUATE", f"{current_user.username} returned graduate book '{loan.book_title}' (student: {loan.student_name})")
    safe_push_sync()

    flash("Graduate book returned.", "success")
    return redirect(url_for('main.borrowed'))

@main.route('/return_grad_class/<id>', methods=['POST'])
@login_required
def return_grad_class(id):
    clean_id = str(id).strip()
    loan = school_get_or_404(GraduateClassBorrowing,clean_id)
    return_type = request.form.get('return_type')
    returned_names = request.form.getlist('returned_members')

    # 1. PARTIAL RETURN
    if return_type == 'partial':
        ids_to_return_str = request.form.get('return_ids', '')

        if '/' in loan.book_ids:
            base_id, current_range_str = loan.book_ids.split('/', 1)
            prefix = base_id + '/'
        else:
            base_id = ''
            prefix = ''
            current_range_str = loan.book_ids

        current_set = parse_range_to_set(current_range_str)
        returning_set = parse_range_to_set(ids_to_return_str)
        new_set = current_set - returning_set

        # --- A. UPDATE MEMBER LIST ---
        if returned_names:
            # 1. Extract Monitor and List
            raw_data = loan.responsibles or ""
            if '||' in raw_data:
                monitor_part, list_part = raw_data.split('||', 1)
            else:
                monitor_part = raw_data # Fallback for old data
                list_part = raw_data

            # 2. Process List
            current_list = [s.strip() for s in list_part.split(',') if s.strip()]
            updated_list = []

            for member in current_list:
                clean_name = member.replace('(Returned)', '').strip()
                if clean_name in returned_names or f"{clean_name} (Returned)" in list_part:
                    updated_list.append(f"{clean_name} (Returned)")
                else:
                    updated_list.append(clean_name)

            # 3. Save Back (Monitor || Updated List)
            # If we had a split, preserve it. If not, just save the list.
            if '||' in raw_data:
                loan.responsibles = f"{monitor_part}||{', '.join(updated_list)}"
            else:
                loan.responsibles = ", ".join(updated_list)

        # --- B. UPDATE BOOKS ---
        if len(new_set) == 0:
            queue_record_change('graduates_class', loan, operation='delete')
            db.session.delete(loan)
            flash("All books returned. Class debt cleared.", "success")
        else:
            if returning_set:
                new_range_str = set_to_range_string(new_set)
                loan.book_ids = f"{prefix}{new_range_str}"
                loan.quantity = len(new_set)
                stamp_sync_fields(loan)
                queue_record_change('graduates_class', loan, operation='upsert')
                flash(f"Returned {len(returning_set)} books. Records updated.", "success")
            else:
                stamp_sync_fields(loan)
                queue_record_change('graduates_class', loan, operation='upsert')
                flash("Student list updated.", "info")

    # 2. FULL RETURN
    elif return_type == 'full':
        loan_id = loan.id
        stamp_sync_fields(loan, deleted=True)
        queue_record_change('graduates_class', loan, operation='delete')
        # GraduateClassBorrowing has no `returned` attribute.
        # It's an archive table. We delete it when fully returned.
        db.session.delete(loan)
        has_issue = request.form.get('has_issue')
        if has_issue == 'yes':
            try:
                issue = BookIssue(
                    loan_id=loan_id,
                    loan_type='graduate',
                    issue_description=request.form.get('issue_description'),
                    repair_cost=float(request.form.get('repair_cost') or 0)
                )
                stamp_sync_fields(issue)
                db.session.add(issue)
                db.session.flush()
                queue_record_change('book_issues', issue, operation='upsert')
                log_action("/return_grad_class", "ISSUE_CREATED", f"{current_user.username} created issue for graduate class book (class: {loan.class_name}): {request.form.get('issue_description')}")
            except Exception:
                pass

        flash("Graduate class book returned.", "success")

    safe_commit()
    log_action("/return_grad_class", "RETURN_GRAD_CLASS", f"{current_user.username} updated return for graduate class {loan.class_name}")
    safe_push_sync()
    return redirect(url_for('main.borrowed'))

@main.route('/return_class/<id>', methods=['POST'])
@login_required
def return_class(id):
    clean_id = str(id).strip()
    loan = school_get_or_404(ClassBorrowing,clean_id)
    return_type = request.form.get('return_type')

    # NEW: Capture checked students from the "View Class List" modal
    returned_names = request.form.getlist('returned_members')

    if return_type == 'partial':
        ids_to_return_str = request.form.get('return_ids', '')

        if '/' in loan.book_ids:
            base_id, current_range_str = loan.book_ids.split('/', 1)
            prefix = base_id + '/'
        else:
            base_id = ''
            prefix = ''
            current_range_str = loan.book_ids

        current_set = parse_range_to_set(current_range_str)
        returning_set = parse_range_to_set(ids_to_return_str)

        # Calculate Remaining
        new_set = current_set - returning_set

        # --- NEW LOGIC: Update Responsibles with Checkmarks ---
        if returned_names:
            current_text = loan.responsibles or ""
            # Fetch ALL students in this class to build the full tracking list
            all_students = school_query(Student).filter_by(student_class=loan.class_name).order_by(Student.name).all()
            all_names = [s.name for s in all_students]

            # Fallback if class roster is empty (e.g., deleted class)
            if not all_names:
                all_names = [x.strip() for x in current_text.split(',') if x.strip()]

            new_resp_list = []
            for name in all_names:
                clean = name.strip()
                # Mark as (Returned) if checked now OR already marked previously
                if clean in returned_names or (f"{clean} (Returned)" in current_text):
                     new_resp_list.append(f"{clean} (Returned)")
                else:
                     new_resp_list.append(clean)

            loan.responsibles = ", ".join(new_resp_list)
        # ------------------------------------------------------

        if len(new_set) == len(current_set):
            if returned_names:
                flash("Student tracking updated.", "success")
            else:
                flash("No matching IDs found to return.", "warning")
                return redirect(url_for('main.borrowed'))
        elif len(new_set) == 0:
            loan.returned = True
            loan.return_date = datetime.now().strftime("%Y-%m-%d")
            loan.quantity = 0
            loan.book_ids = f"{prefix}(Returned)"
            flash("All books returned.", "success")
        else:
            # FIX: Call the global helper function directly
            new_range_str = set_to_range_string(new_set)
            loan.book_ids = f"{prefix}{new_range_str}"
            loan.quantity = len(new_set)
            flash(f"Returned {len(returning_set)} books. {loan.quantity} remaining.", "success")

    else:
        # Full Return (Keeps your existing Issue logic)
        loan.returned = True
        loan.return_date = datetime.now().strftime("%Y-%m-%d")

        # For class returns, allow form to indicate issue
        has_issue = request.form.get('has_issue')
        if has_issue == 'yes':
            try:
                # Ensure BookIssue is imported or available
                from .database import BookIssue
                issue = BookIssue(
                    loan_id=loan.id,
                    loan_type='class',
                    issue_description=request.form.get('issue_description'),
                    repair_cost=float(request.form.get('repair_cost') or 0),
                    status='Pending',
                    created_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                )
                stamp_sync_fields(issue)
                db.session.add(issue)
                db.session.flush()
                queue_record_change('book_issues', issue, operation='upsert')
                log_action("/return_class", "ISSUE_CREATED", f"{current_user.username} created issue for class '{loan.class_name}' (book: {loan.book_title}): {request.form.get('issue_description')} (Cost: {request.form.get('repair_cost') or 0})")
            except Exception:
                pass
        flash("All class books returned.", "success")

    stamp_sync_fields(loan)
    queue_record_change('class_checkouts', loan, operation='upsert')
    safe_commit()
    log_action("/return_class", "RETURN_CLASS", f"{current_user.username} updated class return for {loan.class_name}")
    safe_push_sync()
    return redirect(url_for('main.borrowed'))

# --- CLASS BORROWING ---
@main.route('/class_borrowing')
@login_required
def class_borrowing():
    records = school_query(ClassBorrowing).order_by(ClassBorrowing.borrow_time.desc()).all()
    return render_template('class_borrowing.html', borrowings=records)

@main.route('/class_borrowing/add', methods=['POST'])
@login_required
def class_borrowing_add():
    class_name = (request.form.get('class_name') or '').strip()
    book_title = (request.form.get('book_title') or '').strip()
    if not class_name or not book_title:
        flash("Class name and book title are required.", "warning")
        return redirect(url_for('main.class_borrowing'))

    try:
        quantity = max(1, int(request.form.get('quantity', 1) or 1))
    except ValueError:
        flash("Quantity must be a whole number.", "warning")
        return redirect(url_for('main.class_borrowing'))

    cb = ClassBorrowing(
        class_name=class_name,
        responsibles=(request.form.get('responsibles') or '').strip(),
        book_title=book_title,
        book_ids=(request.form.get('book_ids') or '').strip(),
        quantity=quantity,
        condition=(request.form.get('condition') or 'Good').strip(),
        borrow_time=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    )
    stamp_sync_fields(cb)
    db.session.add(cb)
    db.session.flush()
    queue_record_change('class_checkouts', cb, operation='upsert')
    safe_commit()
    log_action("/class_borrowing/add", "CLASS_BORROW", f"{current_user.username} added class borrowing: {class_name} - {book_title} ({quantity} books)")
    safe_push_sync()
    flash("Class borrowing added.", "success")
    return redirect(url_for('main.class_borrowing'))

# --- LOGS ---
@main.route('/logs')
@login_required
def logs():
    # Changed Log.id.desc() to Log.timestamp.desc()
    records = school_query(Log).order_by(Log.timestamp.desc()).limit(100).all()
    return render_template('logs.html', records=records, can_clear_logs=can_clear_logs())


@main.route('/resolve_issue', methods=['POST'])
@login_required
def resolve_issue():
    issue_id = request.form.get('issue_id')
    resolve_type = request.form.get('resolve_type', 'full')
    if not issue_id:
        flash('No issue specified.', 'warning')
        return redirect(url_for('main.borrowed'))
    try:
        issue = BookIssue.query.get(issue_id)
        if issue:
            if resolve_type == 'partial' and issue.loan_type in ['class', 'graduate_class']:
                resolve_book_nums = request.form.get('resolve_book_nums', '').strip()
                money_used_str = request.form.get('money_used', '').strip()
                student_names = request.form.getlist('student_names')
                
                try:
                    money_used = float(money_used_str) if money_used_str else 0.0
                except ValueError:
                    money_used = 0.0
                
                if issue.repair_cost:
                    issue.repair_cost = max(0.0, issue.repair_cost - money_used)
                
                if resolve_book_nums:
                    import re
                    match = re.search(r'\(Books:\s*([^,)]+)', issue.issue_description)
                    if match:
                        book_id_full = match.group(1)
                        if '/' in book_id_full:
                            base_id, range_str = book_id_full.split('/', 1)
                            try:
                                current_set = parse_range_to_set(range_str)
                                resolve_set = parse_range_to_set(resolve_book_nums)
                                new_set = current_set - resolve_set
                                if len(new_set) == 0:
                                    new_book_id_full = f"{base_id}/(Resolved)"
                                else:
                                    new_range = set_to_range_string(new_set)
                                    new_book_id_full = f"{base_id}/{new_range}"
                                
                                issue.issue_description = issue.issue_description.replace(f'Books: {book_id_full}', f'Books: {new_book_id_full}')
                            except Exception:
                                pass
                
                if student_names:
                    students_str = ", ".join(selected_student.strip() for selected_student in student_names if selected_student.strip())
                    issue.issue_description += f"\n[Partially Resolved for: {students_str}]"
                
                log_action("/resolve_issue", "ISSUE_PARTIALLY_RESOLVED", f"{current_user.username} partially resolved issue #{issue.id}")
                queue_record_change('book_issues', issue, operation='upsert')
                stamp_sync_fields(issue)
                safe_commit()
                flash('Issue partially resolved.', 'success')
            else:
                log_action("/resolve_issue", "ISSUE_RESOLVED", f"{current_user.username} resolved issue #{issue.id} (Loan: {issue.loan_id}, Type: {issue.loan_type}): {issue.issue_description} (Cost: {issue.repair_cost})")
                db.session.delete(issue)
                safe_commit()
                flash('Issue marked as resolved and removed.', 'success')
        else:
            flash('Issue not found.', 'danger')
    except Exception as e:
        flash(f'Error resolving issue: {str(e)}', 'danger')
    return redirect(url_for('main.borrowed'))

# --- IMPORT BORROWERS ---
@main.route('/import_borrowers')
@login_required
def import_borrowers():
    return render_template('import_borrowers.html')

# --- NOTES ---
@main.route('/notes')
@login_required
def notes():
    all_notes = school_query(Note).order_by(Note.id.desc()).all()
    return render_template('notes.html', notes=all_notes)

@main.route('/add_note', methods=['POST'])
@login_required
def add_note():
    title = (request.form.get('note_title') or '').strip()
    content = (request.form.get('note_content') or '').strip()
    if content or title:
        note = Note(
            title=title or None,
            content=content or '',
            timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        )
        stamp_sync_fields(note)
        db.session.add(note)
        safe_commit()
        queue_record_change('notes', note, operation='upsert')
        log_action("/notes", "ADD_NOTE", f"{current_user.username} added note: '{title or 'Untitled'}'")
        flash("Note saved.", "success")
    else:
        flash("Add a title or note content before saving.", "warning")
    return redirect(url_for('main.notes'))


@main.route('/api/notes/add', methods=['POST'])
@login_required
def api_add_note():
    try:
        data = request.get_json() or {}
        title = (data.get('title') or '').strip()
        content = (data.get('content') or '').strip()
        if not content and not title:
            return jsonify({'success': False, 'error': 'No content'}), 400
        # Store title and content in separate columns
        note = Note(title=title if title else None, content=content, timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        stamp_sync_fields(note)
        db.session.add(note)
        safe_commit()
        queue_record_change('notes', note, operation='upsert')
        log_action("/api/notes/add", "ADD_NOTE", f"{current_user.username} added note titled : '{title or 'Untitled'}'")
        return jsonify({'success': True, 'id': note.id})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@main.route('/api/notes/recent')
@login_required
def api_get_notes():
    # return most recent 8 notes as JSON
    notes = school_query(Note).order_by(Note.id.desc()).limit(8).all()
    out = [{'id': n.id, 'title': n.title or '', 'content': n.content or '', 'timestamp': n.timestamp} for n in notes]
    return jsonify(out)


@main.route('/api/notes/update', methods=['POST'])
@login_required
def api_update_note():
    try:
        data = request.get_json() or {}
        nid = data.get('id')
        if not nid:
            return jsonify({'success': False, 'error': 'Missing id'}), 400
        note = school_get(Note,(nid))
        if not note:
            return jsonify({'success': False, 'error': 'Not found'}), 404
        title = (data.get('title') or '').strip()
        content = (data.get('content') or '').strip()
        
        # Track changes for logging
        changes = []
        if note.title != (title if title else None):
            changes.append(f"title: '{note.title}' -> '{title if title else None}'")
        if note.content != content:
            changes.append(f"content: '{note.content[:50]}...' -> '{content[:50]}...'")
        
        note.title = title if title else None
        note.content = content
        stamp_sync_fields(note)
        safe_commit()
        queue_record_change('notes', note, operation='upsert')
        
        if changes:
            log_action("/api/notes/update", "UPDATE_NOTE", f"{current_user.username} updated note {nid}: {', '.join(changes)}")
        else:
            log_action("/api/notes/update", "UPDATE_NOTE", f"{current_user.username} updated note {nid} (no changes detected)")
        
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@main.route('/api/notes/delete', methods=['POST'])
@login_required
def api_delete_notes():
    try:
        data = request.get_json() or {}
        ids = data.get('ids') or []
        if not isinstance(ids, list):
            return jsonify({'success': False, 'error': 'ids must be a list'}), 400
        deleted_titles = []
        for nid in ids:
            n = school_get(Note,(nid))
            if n:
                deleted_titles.append(n.title or 'Untitled')
                queue_record_change('notes', n, operation='delete')
                db.session.delete(n)
        safe_commit()
        if deleted_titles:
            log_action("/api/notes/delete", "DELETE_NOTES", f"{current_user.username} deleted {len(deleted_titles)} notes: {', '.join(deleted_titles)}")
        else:
            log_action("/api/notes/delete", "DELETE_NOTES", f"{current_user.username} attempted to delete notes (none found)")
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@main.route('/api/notes/clear', methods=['POST'])
@login_required
def api_clear_notes():
    try:
        # Get count before deletion for logging
        notes_to_delete = school_query(Note).all()
        note_count = len(notes_to_delete)
        for n in notes_to_delete:
            queue_record_change('notes', n, operation='delete')
        school_query(Note).delete(synchronize_session=False)
        safe_commit()
        log_action("/api/notes/clear", "CLEAR_NOTES", f"{current_user.username} cleared all {note_count} notes")
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

# --- TEACHER BORROW ---

@main.route('/return_staff/<id>', methods=['POST'])
@login_required
def return_staff(id):
    clean_id = str(id).strip()
    loan = school_get_or_404(TeacherBorrowedBook,clean_id)

    loan.returned = True
    loan.timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    stamp_sync_fields(loan)
    queue_record_change('staff_checkouts', loan, operation='upsert')

    safe_commit()
    log_action("/return_staff", "RETURN_STAFF", f"{current_user.username} returned staff book '{loan.book_title}' (teacher: {loan.teacher_name})")
    safe_push_sync()

    flash("Staff book returned.", "success")
    return redirect(request.referrer or url_for('main.teacher_borrow'))


@main.route('/teacher_borrow', methods=['GET', 'POST'])
@login_required
def teacher_borrow():
    if request.method == 'POST':
        book_id = (request.form.get('book_id') or '').strip()
        teacher_name = (request.form.get('teacher_name') or '').strip()
        notes = (request.form.get('notes') or '').strip()
        condition = (request.form.get('condition') or 'Good').strip()

        if not teacher_name or not book_id:
            flash("Teacher name and book ID are required.", "warning")
            return redirect(url_for('main.teacher_borrow'))

        book = school_get(Book, book_id, pk_name='book_id')
        if not book:
            flash("That book ID was not found in this school catalog.", "danger")
            return redirect(url_for('main.teacher_borrow'))

        if is_book_active(book_id):
            flash("That book is already issued.", "warning")
            return redirect(url_for('main.teacher_borrow'))

        tb = TeacherBorrowedBook(
            book_id=book.book_id,
            book_title=book.title,
            teacher_name=teacher_name,
            notes=notes,
            condition=condition,
            timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        )
        stamp_sync_fields(tb)
        db.session.add(tb)
        db.session.flush()
        queue_record_change('staff_checkouts', tb, operation='upsert')
        safe_commit()
        log_action("/teacher_borrow", "STAFF_BORROW", f"{current_user.username} issued {book.book_id} to {teacher_name}")
        safe_push_sync()
        flash("Teacher borrow recorded.", "success")
        return redirect(url_for('main.teacher_borrow'))

    recent_loans = (
        school_query(TeacherBorrowedBook)
        .order_by(TeacherBorrowedBook.id.desc())
        .limit(12)
        .all()
    )
    return render_template('teacher_borrow.html', recent_loans=recent_loans)

# --- BACKUPS ---
@main.route('/backups')
@login_required
def backups():
    files = []
    if os.path.exists(BACKUP_DIR):
        for f in sorted(os.listdir(BACKUP_DIR), reverse=True):
            if f.endswith(".json"):
                files.append(f)
    return render_template('backups.html', files=files)

def backup_redirect():
    return redirect(url_for('main.settings', _anchor='backup'))

@main.route('/export/borrowed/<type>/<format>')
@login_required
def export_borrowed(type, format):
    # 1. FETCH DATA & SET TITLES
    pdf_data = []
    excel_data = []
    title = ""

    if type == 'students':
        title = "ACTIVE STUDENT BOOK LOANS"
        # Sort by Class (A-Z), then Name (A-Z)
        data_query = BorrowedBook.query.filter_by(returned=False).order_by(
            BorrowedBook.student_class.asc(),
            BorrowedBook.student_name.asc()
        ).all()
        # Excel remains standard flat list
        excel_data = [{'Class': d.student_class, 'Name': d.student_name, 'Book': d.book_title, 'Book ID': d.book_id, 'Date': d.timestamp, 'Notes': d.condition} for d in data_query]

    elif type == 'staff':
        title = "ACTIVE STAFF BOOK LOANS"
        data_query = TeacherBorrowedBook.query.filter_by(returned=False).order_by(TeacherBorrowedBook.teacher_name.asc()).all()

        # Staff PDF Data (Standard Single Table)
        # New Columns: No, Staff Name, Book Title, Book ID, Notes
        pdf_data = [['No', 'Staff Name', 'Book Title', 'Book ID', 'Notes']]
        for i, d in enumerate(data_query, 1):
            pdf_data.append([str(i), d.teacher_name, d.book_title, d.book_id, d.notes])

        excel_data = [{'Name': d.teacher_name, 'Book': d.book_title, 'Book ID': d.book_id, 'Date': d.timestamp, 'Notes': d.notes} for d in data_query]

    elif type == 'graduates':
        title = "ACTIVE GRADUATE BOOK LOANS"
        # Sort by Promotion, then Original Class, then Name
        data_query = GraduateBorrowing.query.order_by(
            GraduateBorrowing.promotion_name.asc(),
            GraduateBorrowing.original_class.asc(),
            GraduateBorrowing.student_name.asc()
        ).all()

        # Excel Data
        excel_data = [{'Promotion': d.promotion_name, 'Class': d.original_class, 'Name': d.student_name, 'Book': d.book_title, 'Book ID': d.book_id, 'Notes': d.notes} for d in data_query]

    elif type == 'classes':
        title = "ACTIVE CLASS BOOK LOANS"
        data_query = ClassBorrowing.query.filter_by(returned=False).order_by(ClassBorrowing.class_name.asc()).all()

        # Classes PDF Data (Standard Single Table)
        pdf_data = [['Class', 'Book Title', 'Range', 'Qty', 'Responsibles']]
        for d in data_query:
            pdf_data.append([d.class_name, d.book_title, d.book_ids, str(d.quantity), d.responsibles])

        excel_data = [{'Class': d.class_name, 'Responsibles': d.responsibles, 'Book Title': d.book_title, 'IDs Range': d.book_ids, 'Qty': d.quantity, 'Notes': d.condition} for d in data_query]

    elif type == 'archived_classes':
        title = "ARCHIVED CLASS LOANS"
        data_query = GraduateClassBorrowing.query.order_by(GraduateClassBorrowing.promotion_name.asc()).all()

        pdf_data = [['Promotion', 'Class', 'Book Title', 'Range', 'Qty', 'Responsibles']]
        for d in data_query:
            pdf_data.append([d.promotion_name, d.class_name, d.book_title, d.book_ids, str(d.quantity), d.responsibles])

        excel_data = [{'Promotion': d.promotion_name, 'Class': d.class_name, 'Book Title': d.book_title, 'IDs Range': d.book_ids, 'Qty': d.quantity, 'Responsibles': d.responsibles} for d in data_query]

    elif type == 'issues':
        title = "REPORTED BOOK ISSUES"
        data_query = BookIssue.query.order_by(BookIssue.created_at.desc()).all()

        pdf_data = [['Date', 'Type', 'Borrower', 'Extra', 'Description', 'Cost']]
        excel_data = []
        for issue in data_query:
            borrower = 'N/A'
            extra = ''
            try:
                if issue.loan_type == 'student':
                    lb = BorrowedBook.query.get(issue.loan_id)
                    if lb:
                        borrower = lb.student_name
                        extra = lb.student_class
                elif issue.loan_type == 'graduate':
                    gb = GraduateBorrowing.query.get(issue.loan_id)
                    if gb:
                        borrower = gb.student_name
                        extra = gb.original_class
                    else:
                        gcl = GraduateClassBorrowing.query.get(issue.loan_id)
                        if gcl:
                            borrower = gcl.promotion_name
                            extra = gcl.class_name
                elif issue.loan_type == 'staff':
                    tb = TeacherBorrowedBook.query.get(issue.loan_id)
                    if tb:
                        borrower = tb.teacher_name
                elif issue.loan_type == 'class':
                    cb = ClassBorrowing.query.get(issue.loan_id)
                    if cb:
                        borrower = cb.class_name
                        extra = cb.book_ids
            except Exception:
                pass

            pdf_data.append([issue.created_at, issue.loan_type.capitalize(), borrower, extra or '—', issue.issue_description or '', issue.repair_cost or '—'])
            excel_data.append({'Date': issue.created_at, 'Type': issue.loan_type, 'Borrower': borrower, 'Extra': extra, 'Description': issue.issue_description, 'Cost': issue.repair_cost})

    # 2. GENERATE OUTPUT
    output = BytesIO()

    if format == 'pdf':
        doc = SimpleDocTemplate(output, pagesize=letter)
        elements = []
        styles = getSampleStyleSheet()

        # Main Document Title
        elements.append(Paragraph(f"<b>{title}</b>", styles['Title']))
        elements.append(Spacer(1, 12))

        # --- MULTI-TABLE LOGIC (Students & Graduates) ---
        if type == 'students' or type == 'graduates':

            # 1. Group Data
            grouped_data = {}
            for item in data_query:
                # Group by Class (Students) or Promotion (Graduates)
                key = item.student_class if type == 'students' else item.promotion_name
                if key not in grouped_data:
                    grouped_data[key] = []
                grouped_data[key].append(item)

            # 2. Loop through Groups (Sorted A-Z)
            for group_name in sorted(grouped_data.keys()):
                # Section Header
                header_text = f"Class: {group_name}" if type == 'students' else f"Promotion: {group_name}"
                elements.append(Paragraph(f"<b>{header_text}</b>", styles['Heading2']))
                elements.append(Spacer(1, 6))

                headers = ['No', 'Student Name', 'Book Title', 'Book ID']
                rows_data = []
                for idx, row in enumerate(grouped_data[group_name], 1):
                    name_display = row.student_name
                    if type == 'graduates':
                        name_display += f" ({row.original_class})"
                    rows_data.append([str(idx), name_display, row.book_title, row.book_id])

                t = build_pdf_table(doc, headers, rows_data, weights=[0.7, 3.0, 4.3, 2.0])
                elements.append(t)
                elements.append(Spacer(1, 20))

        # --- STANDARD SINGLE TABLE LOGIC (Staff, Classes, Archived Classes, Issues) ---
        else:
            if pdf_data:
                headers = pdf_data[0]
                rows_data = pdf_data[1:]
                if type == 'staff':
                    weights = [0.6, 2.2, 3.4, 1.5, 2.3]
                elif type == 'classes':
                    weights = [1.2, 3.0, 1.8, 0.8, 3.2]
                elif type == 'archived_classes':
                    weights = [1.5, 1.2, 2.5, 1.5, 0.8, 2.5]
                elif type == 'issues':
                    weights = [1.5, 1.0, 1.8, 1.2, 3.3, 1.2]
                else:
                    weights = [1] * len(headers)
                table = build_pdf_table(doc, headers, rows_data, weights=weights)
                elements.append(table)

        doc.build(elements)
        fname = f"{title.replace(' ', '_')}.pdf"
        mimetype = 'application/pdf'

    else: # Excel Export logic (unchanged structure)
        df = pd.DataFrame(excel_data)
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            df.to_excel(writer, index=False)
        fname = f"{title.replace(' ', '_')}.xlsx"
        mimetype = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'

    output.seek(0)
    return send_file(output, as_attachment=True, download_name=fname, mimetype=mimetype)


@main.route('/settings', methods=['GET', 'POST'])
@login_required
def settings():
    config = load_config()
    
    if request.method == 'POST':
        action = request.form.get('action')
        old_auto = config.get('auto_backup', False)
        
        if action == 'save_defaults':
            try:
                config['max_books_per_student'] = int(request.form.get('max_books', 3))
                config['default_borrow_days'] = int(request.form.get('borrow_days', 14))
                config['auto_lock_minutes'] = int(request.form.get('auto_lock', 5))
                config['lockout_wait_time'] = int(request.form.get('lockout_time', 30))
                config['theme'] = request.form.get('theme', 'light')
                config['language'] = request.form.get('language', 'English')
                config['auto_backup'] = 'auto_backup' in request.form
                if request.form.get('backup_freq'):
                    config['backup_frequency'] = int(request.form.get('backup_freq'))

                save_config(config)
                flash("System configuration updated successfully.", "success")
                log_action("/settings", "UPDATE_CONFIG", "Modified system defaults")
            except ValueError:
                flash("Error: Please enter valid numbers for timers and limits.", "danger")
            else:
                if config.get('auto_backup') and not old_auto:
                    try:
                        from .utils import create_auto_backup_if_due
                        filename = create_auto_backup_if_due(force=True)
                        if filename:
                            flash(f"Auto-backup enabled and first backup created: {filename}", "success")
                    except Exception as e:
                        flash(f"Auto-backup was enabled, but the first backup failed: {e}", "warning")
            if 'auto_backup' in request.form or 'backup_freq' in request.form:
                return redirect(url_for('main.settings', _anchor='backup'))
            return redirect(url_for('main.settings'))

        if action == 'save_connectivity':
            config['supabase_url'] = (request.form.get('supabase_url') or '').strip()
            config['supabase_key'] = (request.form.get('supabase_key') or '').strip()
            config['supabase_service_role_key'] = (request.form.get('supabase_service_role_key') or '').strip()
            try:
                config['sync_batch_size'] = int(
                    request.form.get('sync_batch_size', config.get('sync_batch_size', 100)) or 100
                )
            except ValueError:
                config['sync_batch_size'] = config.get('sync_batch_size', 100)
            save_config(config)

            current_app.config['SUPABASE_URL'] = config.get('supabase_url', '')
            current_app.config['SUPABASE_KEY'] = config.get('supabase_service_role_key') or config.get('supabase_key', '')
            current_app.config['SUPABASE_ANON_KEY'] = config.get('supabase_key', '')
            current_app.config['SYNC_BATCH_SIZE'] = config.get('sync_batch_size', 100)

            sync_service = get_sync_service()
            if sync_service:
                sync_service.init_app(current_app)

            flash("Connectivity settings saved.", "success")
            log_action("/settings", "UPDATE_CONNECTIVITY", "Updated Supabase and cloud sync settings")
            return redirect(url_for('main.settings'))

    backups = []
    if os.path.exists(BACKUP_DIR):
        try:
            files = sorted(os.listdir(BACKUP_DIR), reverse=True)
            for f in files:
                if f.endswith('.json'):
                    path = os.path.join(BACKUP_DIR, f)
                    size_kb = os.path.getsize(path) / 1024
                    mod_time = os.path.getmtime(path)
                    timestamp = datetime.fromtimestamp(mod_time).strftime('%Y-%m-%d %H:%M')
                    backup_type = 'auto' if 'auto' in f.lower() else 'manual'
                    try:
                        with open(path, 'r') as backup_file:
                            metadata = json.load(backup_file)
                        backup_type = str(metadata.get('type') or backup_type).lower()
                    except Exception:
                        pass
                    
                    backups.append({
                        'name': f, 
                        'size': f"{size_kb:.1f} KB", 
                        'date': timestamp,
                        'raw_date': mod_time,
                        'type': backup_type,
                    })
        except Exception as e:
            print(f"Error listing backups: {e}")

    return render_template('settings.html', config=config, backups=backups)

@main.route('/system/health', methods=['GET'])
def system_health():
    return jsonify({"status": "ok", "version": VERSION}), 200


@main.route('/system/update/check', methods=['POST'])
@login_required
def check_update():
    print("\n--- UPDATE CHECK STARTED ---")
    
    # 1. Verify the URL is correct
    UPDATE_URL = "https://raw.githubusercontent.com/Ntwali-Wilson/nexalibrary/refs/heads/main/version.json"
    clean_url = f"{UPDATE_URL}?t={int(time.time())}"
    print(f"Attempting to fetch: {clean_url}")

    try:
        # 2. Make the request
        response = requests.get(clean_url, timeout=15)
        print(f"GitHub responded with HTTP Status: {response.status_code}")
        
        # This will trigger an error if the status is 404 Not Found
        response.raise_for_status() 
        
        # 3. Parse JSON
        data = response.json()
        print(f"Successfully parsed JSON: {data}")

        remote_v = data.get('version')
        if not remote_v:
            raise ValueError("The version.json file is missing the 'version' key.")

        is_critical = data.get('is_critical', False)
        download_url = data.get('download_url') 

        # 4. Compare versions
        if version.parse(remote_v) > version.parse(VERSION):
            print(f"Update found! Remote: {remote_v} > Local: {VERSION}")
            config = load_config()
            config['pending_manual_download_url'] = download_url
            config['update_version'] = remote_v
            config['update_changelog'] = data.get('changelog', [])
            save_config(config)

            return jsonify({
                "update_available": True,
                "new_version": remote_v,
                "is_critical": is_critical,
                "changelog": data.get('changelog', []),
                "message": "🚨 CRITICAL SECURITY PATCH AVAILABLE" if is_critical else f"🚀 New Version v{remote_v} is ready for install!"
            })

        print("No update needed.")
        return jsonify({
            "update_available": False,
            "message": "✅ You are running the latest stable version of Edraze."
        })

    except Exception as e:
        import traceback
        print("\n!!! UPDATE CHECK FAILED !!!")
        traceback.print_exc()  # This prints the exact line of code that crashed
        print("---------------------------\n")
        return jsonify({"error": f"Failed: {str(e)}"}), 400

def download_with_retries(url, headers, destination_path, max_retries=3, timeout_seconds=90):
    """
    Downloads raw files in chunks with automatic retries, compatible with GitHub raw endpoints.
    """
    for attempt in range(1, max_retries + 1):
        try:
            print(f"Download attempt {attempt} of {max_retries} for URL: {url}")
            
            response = requests.get(url, headers=headers, stream=True, timeout=timeout_seconds)
            response.raise_for_status()
            
            total_size = int(response.headers.get('content-length', 0))
            downloaded_size = 0
            
            with open(destination_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=16384): # 16KB chunks
                    if chunk:
                        f.write(chunk)
                        downloaded_size += len(chunk)
            
            if total_size > 0 and downloaded_size < total_size:
                raise IOError(f"Incomplete download: received {downloaded_size} of {total_size} bytes.")
                
            print(f"Successfully downloaded {downloaded_size} bytes.")
            return True
            
        except Exception as e:
            print(f"Download attempt {attempt} failed: {e}")
            if attempt == max_retries:
                print("Max retries reached. Download failed.")
                raise
            print("Retrying in 3 seconds...")
            time.sleep(3)
            
    return False        

@main.route('/system/update/run', methods=['POST'])
@login_required
def run_update():
    print("\n--- UPDATE RUN STARTED ---")
    try:
        config = load_config()
        new_v = config.get('update_version', 'Unknown')
        changelog = config.get('update_changelog', [])

        # --- 1. FIXED PATH RESOLUTION FOR COMPILED EXE ---
        if getattr(sys, 'frozen', False):
            app_root = os.path.dirname(sys.executable)
        else:
            current_dir = os.path.dirname(os.path.abspath(__file__))
            app_root = os.path.dirname(current_dir)

        staging_dir = os.path.join(app_root, 'staging')
        os.makedirs(staging_dir, exist_ok=True)
        staging_file = os.path.join(staging_dir, 'update.zip')

        backup_dir = os.path.join(app_root, 'backups')
        os.makedirs(backup_dir, exist_ok=True)

        # Only treat as ready if BOTH the flag is True AND the zip file actually exists on disk
        is_ready = bool(config.get('update_ready', False)) and os.path.exists(staging_file)
        print(f"Background update ready flag: {is_ready} (File exists: {os.path.exists(staging_file)})")

        # If the background poller hasn't downloaded it to app_root/staging, download it now
        if not is_ready:
            download_api_url = (
                config.get('pending_manual_download_url')
                or config.get('download_url')
            )
            GITHUB_PAT = config.get('PAT')

            print(f"Download API URL: {download_api_url}")
            print(f"GITHUB PAT found: {'YES' if GITHUB_PAT else 'NO'}")

            if not download_api_url or not GITHUB_PAT:
                raise ValueError(f"CRASH: Missing requirements! URL={download_api_url}, PAT_EXISTS={bool(GITHUB_PAT)}")

            dl_headers = {
                "Authorization": f"Bearer {GITHUB_PAT}",
                "Accept": "application/vnd.github.v3.raw"
            }

            print("Starting authenticated raw download with retries...")
            download_with_retries(download_api_url, dl_headers, staging_file, max_retries=3, timeout_seconds=90)
            print("Download complete and saved to staging.")

        import zipfile as _zipfile
        if not os.path.exists(staging_file) or not _zipfile.is_zipfile(staging_file):
            raise ValueError("Staged update archive is missing or corrupted.")

        # 1. Reset flags ONLY after we are 100% sure staging_file is valid and ready
        config['update_ready'] = False
        config['pending_manual_download_url'] = ""
        save_config(config)

        # 2. Log history as Pending (updater.py flips to Success or Failed after extraction)
        history = UpdateHistory(
            version=new_v,
            changelog="\n".join(changelog) if isinstance(changelog, list) else changelog,
            status="Pending",
            timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        )
        db.session.add(history)
        safe_commit()

        # --- PORT & SHUTDOWN LOGIC ---
        current_port = request.host.split(':')[1] if ':' in request.host else '5000'

        # 3. TRIGGER EXTERNAL UPDATER SILENTLY (never opens console, GUI, or associated apps)
        creationflags = 0
        if sys.platform == "win32":
            creationflags = (
                getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
                | getattr(subprocess, "DETACHED_PROCESS", 0x00000008)
            )

        if getattr(sys, 'frozen', False):
            updater_cmd = [sys.executable, "--updater", staging_file, app_root, backup_dir, str(current_port)]
        else:
            updater_script = os.path.join(app_root, "updater.py")
            updater_cmd = [sys.executable, updater_script, staging_file, app_root, backup_dir, str(current_port)]

        print(f"Launching silent updater on port {current_port}: {updater_cmd}")
        subprocess.Popen(
            updater_cmd,
            cwd=app_root,
            creationflags=creationflags,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            close_fds=(sys.platform != "win32"),
        )

        log_action("/system/update/run", "EXECUTE_UPDATE", f"Migrating to v{new_v}")

        # 4. FORCE FLASK TO SHUT DOWN SO FILES ARE UNLOCKED FOR REPLACEMENT
        def kill_server():
            time.sleep(1.2)
            os._exit(0)
        threading.Thread(target=kill_server, daemon=True).start()

        return jsonify({"message": _("Update downloaded and applying. The application will reload automatically as soon as the server is ready.")})

    except Exception as e:
        import traceback
        print(f"UPDATE ROUTE ERROR: {e}")
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500

@main.route('/system/update/history')
@login_required
def get_history():
    # Fetch all logs, newest first, to populate the "Pretty Div"
    history = UpdateHistory.query.order_by(UpdateHistory.id.desc()).all()
    return jsonify([{
        'version': h.version,
        'changelog': h.changelog,
        'status': h.status,
        'timestamp': h.timestamp
    } for h in history])

# 2. Add this specific function to make it GLOBAL
@main.app_context_processor
def inject_version():
    """Makes {{ current_version }} available to all templates (sidebar, footer, etc.)"""
    return dict(current_version=VERSION)

# --- PROFILE MANAGEMENT ROUTES ---
def sorted_librarians(records):
    return sorted(records, key=lambda item: (0 if current_role(item) == 'admin' else 1, item.username.lower()))


def librarian_listing_response():
    school = db.session.get(School, current_user.school_id) if current_user.school_id else None
    librarians = sorted_librarians(school_query(Admin).order_by(Admin.username.asc()).all())
    if wants_json_response():
        return jsonify(
            {
                "success": True,
                "school": {
                    "id": school.id if school else None,
                    "name": school.school_name if school else None,
                },
                "librarians": [serialize_librarian(librarian) for librarian in librarians],
            }
        )
    return render_template(
        'admin_librarians.html',
        librarians=librarians,
        school=school,
        can_manage_librarians=can_manage_librarians(),
    )


def create_librarian_account(username, password, confirm_password=None, email=None):
    username = (username or '').strip()
    password = password or ''
    confirm_password = confirm_password or password
    email = (email or '').strip() or None

    if not can_manage_librarians():
        return False, "Only an admin can add another librarian.", None, 403

    if not current_user.school_id:
        return False, "Your admin account is not linked to a school yet.", None, 400

    if not username or not password:
        return False, "Username and password are required.", None, 400

    if password != confirm_password:
        return False, "Librarian passwords do not match.", None, 400

    existing = Admin.query.filter_by(username=username).first()
    if existing:
        return False, f"Username '{username}' already exists. Choose a different librarian username.", None, 409

    try:
        librarian = Admin(
            username=username,
            password=hash_pw(password),
            role='librarian',
            email1=email,
            school_id=current_user.school_id,
        )
        stamp_sync_fields(librarian)
        db.session.add(librarian)
        db.session.flush()
        queue_record_change('librarians', librarian, operation='upsert')
        safe_commit()

        log_action(
            "/admin/add-librarian",
            "POST",
            f"{current_user.username} added librarian {username} for school {current_user.school_id}",
            status_code=201,
        )
        safe_push_sync(limit=10, force=True)
        return True, f"Librarian '{username}' created successfully.", librarian, 201
    except Exception as exc:
        db.session.rollback()
        current_app.logger.exception("Failed to create librarian account.")
        return False, f"Could not create librarian: {exc}", None, 500


def remove_librarian_account(librarian_id):
    if not can_manage_librarians():
        return False, "Only an admin can remove librarians.", None, 403

    librarian = school_get(Admin, librarian_id, include_deleted=True)
    if not librarian or librarian.deleted:
        return False, "Librarian not found.", None, 404

    if librarian.id == current_user.id:
        return False, "You cannot delete your own account.", librarian, 400

    if current_role(librarian) == 'admin':
        return False, "You cannot delete another admin account.", librarian, 403

    try:
        stamp_sync_fields(librarian, deleted=True)
        queue_record_change('librarians', librarian, operation='upsert')
        safe_commit()

        log_action(
            f"/admin/delete-librarian/{librarian_id}",
            "POST",
            f"{current_user.username} removed librarian {librarian.username} from school {current_user.school_id}",
        )
        safe_push_sync(limit=10, force=True)
        return True, f"Librarian '{librarian.username}' removed successfully.", librarian, 200
    except Exception as exc:
        db.session.rollback()
        current_app.logger.exception("Failed to delete librarian account.")
        return False, f"Could not remove librarian: {exc}", librarian, 500


@main.route('/profile')
@login_required
def profile():
    school = db.session.get(School, current_user.school_id) if current_user.school_id else None
    librarians = sorted_librarians(school_query(Admin).order_by(Admin.username.asc()).all())
    return render_template(
        'profile.html',
        user=current_user,
        school=school,
        librarians=librarians,
        can_manage_librarians=can_manage_librarians(),
        timestamp=int(datetime.now().timestamp()),
    )

@main.route('/profile/textbee', methods=['POST'])
@login_required
def update_textbee():
    device_id = request.form.get('textbee_device_id', '').strip()
    api_key = request.form.get('textbee_api_key', '').strip()

    current_user.textbee_device_id = device_id if device_id else None
    current_user.textbee_api_key = api_key if api_key else None

    stamp_sync_fields(current_user)
    safe_commit()
    queue_record_change('admin', current_user, operation='update')
    flash("TextBee SMS integration settings updated.", "success")
    return redirect(url_for('main.profile'))

@main.route('/profile/security', methods=['POST'])
@login_required
def update_security():
    action = request.form.get('action')
    current_pw = request.form.get('current_password')
    should_sync_admin = False
    
    # 1. Verify Current Password
    if not verify_pw(current_pw or '', current_user.password):
        flash("Incorrect current password.", "danger")
        return redirect(url_for('main.profile'))

    if action == 'update_info':
        new_username = request.form.get('username').strip()

        # 2. DUPLICATE USERNAME CHECK
        # If username is changing, check if the new one already exists
        if new_username != current_user.username:
            existing_user = Admin.query.filter_by(username=new_username).first()
            if existing_user:
                flash(f"Error: The username '{new_username}' is already taken.", "warning")
                return redirect(url_for('main.profile'))

        # If safe, update details
        current_user.username = new_username
        current_user.email1 = request.form.get('email1')
        current_user.email2 = request.form.get('email2')
        current_user.email3 = request.form.get('email3')
        stamp_sync_fields(current_user)
        queue_record_change('librarians', current_user, operation='upsert')
        should_sync_admin = True
        safe_commit()
        flash("Profile info updated successfully.", "success")
        log_action("/profile/security", "UPDATE_INFO", f"{current_user.username} updated account details")
        
    elif action == 'change_password':
        new = request.form.get('new_password')
        confirm = request.form.get('confirm_password')
        
        if new != confirm:
            flash("New passwords do not match.", "danger")
        else:
            current_user.password = hash_pw(new)
            stamp_sync_fields(current_user)
            queue_record_change('librarians', current_user, operation='upsert')
            should_sync_admin = True
            safe_commit()
            flash("Password changed successfully.", "success")
            log_action("/profile/security", "CHANGE_PASSWORD", f"{current_user.username} changed account password")

    if should_sync_admin:
        safe_push_sync()
            
    return redirect(url_for('main.profile'))




@main.route('/profile/librarians/add', methods=['POST'])
@login_required
def add_librarian():
    if not can_manage_librarians():
        flash("Only an admin can add another librarian.", "danger")
        return redirect(url_for('main.profile'))

    current_pw = request.form.get('current_password')
    if not verify_pw(current_pw or '', current_user.password):
        flash("Incorrect password. Librarian account not created.", "danger")
        return redirect(url_for('main.profile'))

    success, message, _librarian, _status_code = create_librarian_account(
        username=request.form.get('username'),
        password=request.form.get('password'),
        confirm_password=request.form.get('confirm_password'),
        email=request.form.get('email'),
    )
    flash(message, "success" if success else "danger")
    return redirect(url_for('main.profile'))

@main.route('/profile/generate_codes', methods=['POST'])
@login_required
def generate_codes():
    password = request.form.get('password_for_codes')

    # PASSWORD GATE
    if not verify_pw(password or '', current_user.password):
        flash("Incorrect password. Cannot generate codes.", "danger")
        return redirect(url_for('main.profile'))

    # Generate 10 codes (8 chars each)
    import secrets
    codes = [secrets.token_hex(4).upper() for _ in range(10)]
    current_user.recovery_codes = ",".join(codes)
    safe_commit()

    flash("New recovery codes generated. Please save them immediately.", "success")
    return redirect(url_for('main.profile'))

# --- FIX PROFILE PICTURE VISIBILITY ---
@main.route('/uploads/<filename>')
def uploaded_file(filename):
    """Serves uploaded profile images and falls back to a bundled default avatar."""
    safe_name = secure_filename(filename or "")
    upload_folder = current_app.config['UPLOAD_FOLDER']
    file_path = os.path.join(upload_folder, safe_name)
    default_avatar = os.path.join(current_app.static_folder, 'img', 'default_profile.svg')

    if safe_name and os.path.exists(file_path):
        return send_from_directory(upload_folder, safe_name)
    return send_file(default_avatar, mimetype='image/svg+xml')

# --- PROFILE: SETUP QUESTIONS ---
@main.route('/profile/setup_questions', methods=['POST'])
@login_required
def setup_questions():
    current_pw = request.form.get('current_password')
    if not verify_pw(current_pw or '', current_user.password):
        flash("Incorrect password.", "danger")
        return redirect(url_for('main.profile'))

    current_user.question1 = request.form.get('q1')
    current_user.answer1 = hash_pw(request.form.get('a1').strip().lower())

    current_user.question2 = request.form.get('q2')
    current_user.answer2 = hash_pw(request.form.get('a2').strip().lower())

    current_user.question3 = request.form.get('q3')
    current_user.answer3 = hash_pw(request.form.get('a3').strip().lower())

    safe_commit()
    flash("Questions updated.", "success")
    return redirect(url_for('main.profile'))

# --- PROFILE: UPDATE PICTURE (SECURED) ---
@main.route('/profile/update_picture', methods=['POST'])
@login_required
def update_picture():
    if 'profile_image' not in request.files:
        return jsonify({'status': 'error', 'message': 'No image uploaded.'}), 400

    file = request.files['profile_image']
    if not file.filename:
        return jsonify({'status': 'error', 'message': 'Empty filename.'}), 400

    # SECURITY: Validate image upload
    from .utils import validate_image_upload
    is_valid, error_msg, safe_filename = validate_image_upload(file)
    if not is_valid:
        return jsonify({'status': 'error', 'message': error_msg}), 400

    try:
        upload_folder = current_app.config['UPLOAD_FOLDER']
        os.makedirs(upload_folder, exist_ok=True)
        filename = secure_filename(f"{current_user.id}_{int(datetime.now().timestamp())}.png")
        file_path = os.path.join(upload_folder, filename)
        file.save(file_path)

        with open(file_path, 'rb') as f:
            header = f.read(16)
            if not _is_valid_image_header(header):
                os.remove(file_path)
                return jsonify({'status': 'error', 'message': 'Invalid image file'}), 400

        current_user.profile_image = filename
        safe_commit()
        return jsonify({'status': 'success', 'filename': filename})
    except Exception as exc:
        db.session.rollback()
        current_app.logger.exception("Profile image upload failed.")
        return jsonify({'status': 'error', 'message': 'Upload failed'}), 500


def _is_valid_image_header(header: bytes) -> bool:
    """Check if file header matches known image formats."""
    if len(header) < 12:
        return False
    # PNG
    if header.startswith(b'\x89PNG\r\n\x1a\n'):
        return True
    # JPEG
    if header.startswith(b'\xff\xd8\xff'):
        return True
    # GIF
    if header.startswith(b'GIF87a') or header.startswith(b'GIF89a'):
        return True
    # WebP
    if header.startswith(b'RIFF') and header[8:12] == b'WEBP':
        return True
    # SVG (text-based, check for XML/SVG tags)
    if header.lstrip().startswith(b'<svg') or header.lstrip().startswith(b'<?xml'):
        return True
    return False

# --- PROFILE: DELETE PICTURE ---
@main.route('/profile/delete_picture', methods=['POST'])
@login_required
def delete_picture():
    try:
        if current_user.profile_image and 'default' not in current_user.profile_image:
            file_path = os.path.join(current_app.config['UPLOAD_FOLDER'], current_user.profile_image)
            if os.path.exists(file_path):
                os.remove(file_path)

        current_user.profile_image = 'default_profile.png'
        safe_commit()
        flash("Profile picture removed.", "info")
    except Exception as exc:
        db.session.rollback()
        current_app.logger.exception("Profile image delete failed.")
        flash(f"Could not remove profile picture: {exc}", "danger")
    return redirect(url_for('main.profile'))

    # --- BACKUP MANAGEMENT ROUTES ---

@main.route('/settings/backup/create', methods=['POST'])
@login_required
def create_backup():
    try:
        from .utils import create_backup_file
        filename = create_backup_file(manual=True)
        flash(f"Backup created successfully: {filename}", "success")
        log_action("/settings/backup", "CREATE_BACKUP", f"Created {filename}")
    except Exception as e:
        flash(f"Error creating backup: {str(e)}", "danger")
    return backup_redirect()

@main.route('/settings/backup/delete/<filename>', methods=['POST'])
@login_required
def delete_backup(filename):
    try:
        path = os.path.join(BACKUP_DIR, secure_filename(filename))
        if os.path.exists(path):
            os.remove(path)
            flash("Backup file deleted.", "success")
            log_action("/settings/backup", "DELETE_BACKUP", f"{current_user.username} deleted backup file: {filename}")
    except Exception as e:
        flash(f"Error deleting file: {str(e)}", "danger")
    return backup_redirect()

@main.route('/settings/backup/verify/<filename>', methods=['GET'])
@login_required
def verify_backup(filename):
    from .utils import verify_backup_file
    path = os.path.join(BACKUP_DIR, secure_filename(filename))
    is_valid, msg = verify_backup_file(path)
    if is_valid:
        flash(f"Integrity Check Passed: {msg}", "success")
        log_action("/settings/backup", "VERIFY_BACKUP", f"{current_user.username} verified backup file: {filename} - {msg}")
    else:
        flash(f"Integrity Check FAILED: {msg}", "danger")
        log_action("/settings/backup", "VERIFY_BACKUP_FAILED", f"{current_user.username} attempted to verify backup file: {filename} - {msg}")
    return backup_redirect()

@main.route('/settings/backup/download/<filename>')
@login_required
def download_backup(filename):
    safe_name = secure_filename(filename)
    path = os.path.join(BACKUP_DIR, safe_name)
    if not safe_name or not os.path.exists(path):
        flash("Backup file was not found.", "danger")
        return backup_redirect()
    log_action("/settings/backup", "DOWNLOAD_BACKUP", f"{current_user.username} downloaded backup file: {filename}")
    return send_from_directory(BACKUP_DIR, safe_name, as_attachment=True, mimetype='application/json')

@main.route('/settings/backup/upload', methods=['POST'])
@login_required
def upload_backup():
    if 'backup_file' not in request.files:
        flash("No file selected.", "warning")
        return backup_redirect()

    file = request.files['backup_file']
    
    # SECURITY: Validate backup file
    from .utils import validate_backup_file
    is_valid, error_msg = validate_backup_file(file)
    if not is_valid:
        flash(f"Upload rejected: {error_msg}", "danger")
        return backup_redirect()

    if file.filename:
        filename = secure_filename(file.filename)
        path = os.path.join(BACKUP_DIR, filename)
        file.save(path)

        # Auto-Verify on upload
        from .utils import verify_backup_file
        is_valid, msg = verify_backup_file(path)

        if is_valid:
            flash(f"Backup uploaded and verified successfully.", "success")
            log_action("/settings/backup", "UPLOAD_BACKUP", f"{current_user.username} uploaded backup file: {filename}")
        else:
            os.remove(path) # Delete bad file immediately
            flash(f"Upload rejected: File corrupted or invalid signature.", "danger")
            log_action("/settings/backup", "UPLOAD_BACKUP_FAILED", f"{current_user.username} attempted to upload invalid backup file: {filename} - {msg}")

    return backup_redirect()

@main.route('/settings/backup/restore/<filename>', methods=['POST'])
@login_required
def restore_backup(filename):
    # Security: Ensure Admin Password confirmation was passed if you want extra security,
    # but for now we trust the login session.
    from .utils import restore_backup_file
    success, msg = restore_backup_file(secure_filename(filename))
    if success:
        flash(msg, "success")
        log_action("/settings/restore", "RESTORE_DB", f"Restored from {filename}")
    else:
        flash(f"Restore Failed: {msg}", "danger")
    return backup_redirect()

@main.route('/settings/backup/bulk_action', methods=['POST'])
@login_required
def bulk_backup_action():
    action = request.form.get('bulk_action')
    selected_files = request.form.getlist('selected_backups')

    if not selected_files:
        flash("No files selected.", "warning")
        return backup_redirect()

    # 1. BULK DELETE
    if action == 'delete':
        count = 0
        for fname in selected_files:
            path = os.path.join(BACKUP_DIR, secure_filename(fname))
            if os.path.exists(path):
                os.remove(path)
                count += 1
        flash(f"Deleted {count} backup files.", "success")
        log_action("/settings/backup", "BULK_DELETE_BACKUPS", f"{current_user.username} bulk deleted {count} backup files: {', '.join(selected_files)}")

    # 2. BULK VERIFY
    elif action == 'verify':
        from .utils import verify_backup_file
        passed = 0
        failed = 0
        for fname in selected_files:
            path = os.path.join(BACKUP_DIR, secure_filename(fname))
            is_valid, _ = verify_backup_file(path)
            if is_valid: passed += 1
            else: failed += 1

        if failed > 0:
            flash(f"Verification Results: {passed} Valid, {failed} Corrupted.", "warning")
        else:
            flash(f"All {passed} files verified successfully.", "success")
        log_action("/settings/backup", "BULK_VERIFY_BACKUPS", f"{current_user.username} bulk verified {len(selected_files)} backup files: {passed} passed, {failed} failed")

    # 3. BULK DOWNLOAD (ZIP)
    elif action == 'download':
        from .utils import create_zip_of_backups
        zip_buffer = create_zip_of_backups(selected_files)
        timestamp = datetime.now().strftime("%Y%m%d")
        log_action("/settings/backup", "BULK_DOWNLOAD_BACKUPS", f"{current_user.username} bulk downloaded {len(selected_files)} backup files as ZIP")
        return send_file(
            zip_buffer,
            mimetype='application/zip',
            as_attachment=True,
            download_name=f"backups_archive_{timestamp}.zip"
        )

    return backup_redirect()

# --- NEW API: FETCH CLASS MEMBERS ---
@main.route('/api/class_members/<class_name>')
@login_required
def get_class_members(class_name):
    # Fetch all students in this class
    students = school_query(Student).filter_by(student_class=class_name).order_by(Student.name).all()
    names = [s.name for s in students]
    return jsonify(names)

@main.route('/system/logs/reset', methods=['POST'])
@login_required
def reset_logs():
    """
    Securely clears the Log table after verifying the admin password.
    Uses the app's internal hash_pw utility for consistency.
    """
    data = request.get_json(silent=True) or {}
    password = data.get('password', '')

    if not can_clear_logs():
        return jsonify({
            "success": False,
            "message": "Only an admin can clear logs."
        }), 403
    
    # 1. SECURITY CHECK
    if not verify_pw(password or '', current_user.password):
        return jsonify({
            "success": False,
            "message": "Security Alert: Incorrect administrative password."
        }), 403

    try:
        # 2. DATABASE OPERATION
        # Deletes all rows in the Log table
        school_query(Log, include_deleted=True).delete()
        safe_commit()

        # 3. AUDIT TRAIL
        # We immediately log the reset so the 'empty' table has its first entry
        log_action("/system/logs/reset", "RESET_LOGS", f"Complete audit log wipe performed by {current_user.username}")

        return jsonify({
            "success": True,
            "message": "System logs cleared. Audit trail restarted."
        })

    except Exception as e:
        db.session.rollback()
        return jsonify({
            "success": False, 
            "message": f"Database Error: {str(e)}"
        }), 500


@main.route("/sync")
@login_required
def sync_page():
    return redirect(url_for('main.peers_page'))


@main.route("/sync/start", methods=["POST"])
@login_required
def start_sync():
    import peer_sync
    config = load_config()
    role = config.get("role")
    if not role:
        return jsonify({"status": "error", "message": "Role not set. Go to setup."})
    
    status = peer_sync.get_status()
    if status.get("running"):
        return jsonify({"status": "error", "message": "Server already running."})
        
    peer_sync.start(role, current_app._get_current_object(), sync_interval=int(config.get("sync_interval", 5) or 5))
    return jsonify({"status": "success", "message": "Sync engine started."})

@main.route("/sync/stop", methods=["POST"])
@login_required
def stop_sync():
    import peer_sync
    peer_sync.stop()
    return jsonify({"status": "success"})


@main.route("/sync/status", methods=["GET"])
@login_required
def sync_status_api():
    import peer_sync
    status = peer_sync.get_status()
    return jsonify({
        "state": "syncing" if status.get("connected") else "idle",
        "otp": None,
        "server_ip": status.get("my_ip") if status.get("role") == "major" else status.get("major_ip"),
        "clients": list(status.get("peers", {}).keys()),
        "last_result": status.get("last_sync")
    })

@main.route("/sync/reset", methods=["POST"])
@login_required
def reset_sync():
    import peer_sync
    peer_sync.stop()
    return jsonify({"status": "success"})





@main.route("/bluetooth")
@login_required
def bluetooth_page():
    return redirect(url_for("main.sync_page"))


@main.route("/setup/role", methods=["GET"])
@login_required
def role_wizard():
    from .utils import load_config
    config = load_config()
    return render_template("role_wizard.html", config=config)


@main.route("/setup/role", methods=["POST"])
@login_required
def role_wizard_save():
    import socket as _socket
    import peer_sync

    role = request.form.get("role", "").strip()
    device_label = request.form.get("device_label", _socket.gethostname()).strip()

    if role not in ("major", "minor"):
        flash("Please choose a role.", "warning")
        return redirect(url_for("main.profile"))

    config = load_config()
    config["role"] = role
    config["device_label"] = device_label
    config["show_wizard_at_startup"] = "show_at_startup" in request.form
    if not config.get("device_id"):
        config["device_id"] = f"{role}_{secrets.token_hex(4)}"
    save_config(config)

    peer_sync.start(
        role,
        current_app._get_current_object(),
        sync_interval=int(config.get("sync_interval", 5) or 5),
    )
    flash(f"Role set to {role.upper()}. Sync engine started.", "success")
    return redirect(url_for("main.profile"))


@main.route("/peers")
@login_required
def peers_page():
    import peer_sync

    status = peer_sync.get_status()
    sessions = PeerSession.query.filter(PeerSession.device_id != "self").all()
    return render_template("peers_sync.html", status=status, sessions=sessions, cfg=load_config())


@main.route("/peers/status", methods=["GET"])
@login_required
def peers_status_api():
    import peer_sync

    return jsonify(peer_sync.get_status())


@main.route("/peers/otp/create", methods=["POST"])
@login_required
def create_peer_otp():
    import peer_sync

    config = load_config()
    if config.get("role") != "major":
        return jsonify({"status": "error", "message": "Only the Major PC can create OTPs."})
    return jsonify({"status": "ok", "otp": peer_sync.create_otp()})


@main.route("/peers/connect", methods=["POST"])
@login_required
def connect_minor_peer():
    import peer_sync

    config = load_config()
    if config.get("role") != "minor":
        return jsonify({"status": "error", "message": "Only a Minor PC can use this action."})
    data = request.get_json(silent=True) or {}
    otp = str(data.get("otp", "")).strip()
    major_ip = (data.get("major_ip") or "").strip() or None
    if len(otp) != 6 or not otp.isdigit():
        return jsonify({"status": "error", "message": "OTP must be exactly 6 digits."})
    return jsonify(peer_sync.submit_otp_and_connect(otp, major_ip))


@main.route("/peers/disconnect/<device_id>", methods=["POST"])
@login_required
def disconnect_peer(device_id):
    import peer_sync

    config = load_config()
    if config.get("role") != "major":
        return jsonify({"status": "error", "message": "Only the Major PC can disconnect peers."})
    peer_sync.disconnect_peer(device_id)
    return jsonify({"status": "ok"})


@main.route("/peers/trust/<device_id>", methods=["POST"])
@login_required
def toggle_peer_trust(device_id):
    config = load_config()
    if config.get("role") != "major":
        return jsonify({"status": "error", "message": "Only the Major PC can change trust settings."})
    peer_session = PeerSession.query.filter_by(device_id=device_id).first()
    if not peer_session:
        return jsonify({"status": "error", "message": "Device not found."}), 404
    payload = request.get_json(silent=True) or {}
    peer_session.trusted = bool(payload.get("trusted", True))
    safe_commit()
    return jsonify({"status": "ok", "trusted": peer_session.trusted})

@main.route("/peers/diagnostics")
@login_required
def peer_diagnostics():
    from .database import PeerSyncQueue
    import peer_sync
    
    # Calculate Queue Statistics
    pending_count = PeerSyncQueue.query.filter(PeerSyncQueue.delivered == False, PeerSyncQueue.attempt_count < 15).count()
    failed_count = PeerSyncQueue.query.filter(PeerSyncQueue.delivered == False, PeerSyncQueue.attempt_count >= 15).count()
    delivered_count = PeerSyncQueue.query.filter_by(delivered=True).count()
    
    # Fetch the 50 most recent sync activities
    recent_activity = PeerSyncQueue.query.order_by(PeerSyncQueue.timestamp.desc()).limit(50).all()
    status = peer_sync.get_status()

    return render_template("peer_diagnostics.html", 
                           pending_count=pending_count, 
                           failed_count=failed_count, 
                           delivered_count=delivered_count,
                           recent_activity=recent_activity,
                           sync_status=status)

@main.route("/peers/diagnostics/retry_failed", methods=["POST"])
@login_required
def retry_failed_syncs():
    from .database import PeerSyncQueue
    # Reset attempt counts so the engine tries to send them again
    PeerSyncQueue.query.filter(PeerSyncQueue.attempt_count >= 15).update({"attempt_count": 0}, synchronize_session=False)
    safe_commit()
    flash("Failed sync items have been pushed back into the active queue.", "success")
    return redirect(url_for('main.peer_diagnostics'))

    
@main.route('/system/database/reset', methods=['POST'])
@login_required
def reset_database():
    """
    Securely wipes all operational data for testing or distribution.
    Requires admin role and password verification.
    """
    if not is_admin_role(current_user.role):
        return jsonify({"success": False, "message": "Only an admin can perform a factory reset."}), 403

    data = request.get_json(silent=True) or {}
    password = data.get('password', '')

    # 1. SECURITY CHECK
    if not verify_pw(password or '', current_user.password):
        return jsonify({"success": False, "message": "Security Alert: Incorrect administrative password."}), 403

    try:
        # 2. WIPE OPERATIONAL DATA
        school_query(BorrowedBook, include_deleted=True).delete()
        school_query(TeacherBorrowedBook, include_deleted=True).delete()
        school_query(ClassBorrowing, include_deleted=True).delete()
        school_query(GraduateBorrowing, include_deleted=True).delete()
        school_query(GraduateClassBorrowing, include_deleted=True).delete()
        school_query(BookIssue, include_deleted=True).delete()
        school_query(Book, include_deleted=True).delete()
        school_query(Student, include_deleted=True).delete()
        school_query(Note, include_deleted=True).delete()
        school_query(Log, include_deleted=True).delete()
        
        # 3. WIPE SYNC QUEUES (Prevents ghost data from syncing to the cloud/peers)
        SyncQueue.query.delete()
        SyncConflict.query.delete()
        PeerSyncQueue.query.delete()
        PeerSyncLog.query.delete()

        safe_commit()

        # 4. START A FRESH AUDIT TRAIL
        log_action("/system/database/reset", "FACTORY_RESET", f"Complete database wipe performed by {current_user.username}. System ready for fresh data.")
        
        return jsonify({"success": True, "message": "Database wiped successfully. Ready for distribution."})

    except Exception as e:
        db.session.rollback()
        return jsonify({
            "success": False, 
            "message": f"Database Error: {str(e)}"
        }), 500



@main.route("/admin/provision-worker", methods=["POST"])
@login_required
def provision_worker():
    from .utils import load_config
    config = load_config()

    # Restrict to major librarians (admins)
    if current_user.role != 'admin':
        return jsonify({"success": False, "message": "Unauthorized"}), 403

    data = request.get_json(silent=True) or {}
    email = data.get("email")
    password = data.get("password")

    if not email or not password:
        return jsonify({"success": False, "message": "Email and password required"}), 400

    sync_service = current_app.extensions.get("sync_service")
    if not sync_service or not sync_service.supabase:
        return jsonify({"success": False, "message": "Supabase not configured"}), 500

    try:
        # Create user via admin API to bypass RLS, attach school_id
        res = sync_service.supabase.auth.admin.create_user({
            "email": email,
            "password": password,
            "user_metadata": {"school_id": current_user.school_id}
        })

        user_id = res.user.id

        # Insert into profiles table
        sync_service.supabase.table("profiles").insert({
            "id": user_id,
            "school_id": current_user.school_id,
            "email": email,
            "role": "librarian"
        }).execute()

        log_action("/admin/provision-worker", "PROVISION_WORKER", f"{current_user.username} provisioned a new worker: {email}")

        return jsonify({"success": True, "message": "Worker provisioned successfully"})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500


@main.route("/peers/sync-interval", methods=["POST"])
@login_required
def set_peer_sync_interval():
    import peer_sync

    payload = request.get_json(silent=True) or {}
    seconds = max(1, min(int(payload.get("seconds", 5)), 300))
    peer_sync.set_sync_interval(seconds)
    config = load_config()
    config["sync_interval"] = seconds
    save_config(config)
    return jsonify({"status": "ok", "sync_interval": seconds})

_MINIMAL_ERROR_HTML = """<!DOCTYPE html><html><head><meta charset="utf-8">
<title>Error {code}</title></head><body style="font-family: sans-serif; padding: 2rem;">
<h1>Error {code}</h1><p>{message}</p>
<p><a href="/">Return to homepage</a></p></body></html>"""


@main.app_errorhandler(404)
def page_not_found(e):
    safe_rollback()
    try:
        return render_template('error_page.html', code=404, message=str(e)), 404
    except Exception:
        return _MINIMAL_ERROR_HTML.format(code=404, message="Page not found."), 404

@main.app_errorhandler(500)
def internal_server_error(e):
    safe_rollback()
    try:
        return render_template('error_page.html', code=500, message="An internal server error occurred. Please try again later or contact support."), 500
    except Exception:
        return _MINIMAL_ERROR_HTML.format(code=500, message="An internal server error occurred. Please try again later or contact support."), 500

@main.app_errorhandler(Exception)
def handle_exception(e):
    import traceback
    # Pass through HTTP errors
    if isinstance(e, HTTPException):
        return e

    safe_rollback()
    try:
        return render_template('error_page.html', code=500, message=str(e)), 500
    except Exception:
        return _MINIMAL_ERROR_HTML.format(code=500, message=str(e)), 500

@main.route("/api/sync/setup/join", methods=["POST"])
@login_required
def sync_setup_join():
    school_name = (request.form.get("school_name") or "").strip()
    if not school_name:
        flash("School name is required.", "danger")
        return redirect(url_for("main.dashboard"))
        
    try:
        sync_service = get_sync_service()
        online_sync_available = bool(sync_service and sync_service.is_configured())

        if online_sync_available:
            data, count = sync_service.supabase.table('join_requests').insert({
                "school_name": school_name,
                "username": current_user.username,
                "status": "pending"
            }).execute()
            flash("Join request sent! Awaiting approval from the main librarian.", "success")
        else:
            flash("Online Sync is not configured, so the join request was not sent online. You can continue using the app locally.", "warning")
    except Exception as e:
        current_app.logger.exception("Failed to send join request")
        flash(f"Error: {e}", "danger")
        
    return redirect(url_for("main.dashboard"))


@main.route("/api/sync/setup/new", methods=["POST"])
@login_required
def sync_setup_new():
    school_name = (request.form.get("school_name") or "").strip()
    if not school_name:
        flash("School name is required.", "danger")
        return redirect(url_for("main.dashboard"))
        
    try:
        sync_service = get_sync_service()
        online_sync_available = bool(sync_service and sync_service.is_configured())

        # 1. Create school in local DB first
        slug = unique_school_slug(school_name)
        school = School(school_name=school_name, slug=slug, allow_online_sync=True)
        db.session.add(school)
        db.session.flush() # Flush to get the ID

        # --- THE FIX: MIGRATE & QUEUE EXISTING LOCAL DATA TO NEW SCHOOL ---
        old_school_id = current_user.school_id
        
        # Map your SQLAlchemy models to the Sync Service entity names
        entity_mapping = {
            Book: 'books', 
            Student: 'members', 
            BorrowedBook: 'checkouts',
            TeacherBorrowedBook: 'staff_checkouts', 
            ClassBorrowing: 'class_checkouts',
            BookIssue: 'book_issues', 
            Note: 'notes', 
            Log: 'logs',
            GraduateBorrowing: 'graduates_borrowed', 
            GraduateClassBorrowing: 'graduates_class'
        }

        for model, entity_type in entity_mapping.items():
            if hasattr(model, 'school_id'):
                # Fetch records tied to the old ID or no ID
                if old_school_id:
                    records = model.query.filter((model.school_id == old_school_id) | (model.school_id.is_(None))).all()
                else:
                    records = model.query.filter(model.school_id.is_(None)).all()
                    
                for record in records:
                    # Assign the new cloud-ready school ID
                    record.school_id = school.id
                    
                    # Force a new timestamp so the sync engine registers it as a fresh change
                    if hasattr(record, 'updated_at'):
                        record.updated_at = datetime.now()
                    
                    # Queue it directly for Supabase upload
                    queue_record_change(entity_type, record, operation='upsert')

        if online_sync_available:
            sb_school_id = school.id
            sync_service.supabase.table('schools').insert({
                "id": str(sb_school_id),
                "school_name": school_name,
                "slug": slug,
                "status": "active"
            }).execute()

            sync_service.supabase.table('librarians').insert({
                "school_id": str(sb_school_id),
                "username": current_user.username,
                "is_main_librarian": True
            }).execute()

        current_user.school_id = school.id
        current_user.local_only = False
        safe_commit()
        cfg = load_config()
        cfg['local_only'] = False
        save_config(cfg)
        if sync_service and hasattr(sync_service, '_stop_event'):
            sync_service._stop_event.clear()

        # Trigger immediate background upload of the newly claimed data
        if online_sync_available:
            safe_push_sync(limit=1000, force=True)

        if online_sync_available:
            flash(f"School '{school_name}' created successfully. Your existing data is syncing to the cloud.", "success")
        else:
            flash(f"School '{school_name}' created locally. Configure online sync later to enable cloud sharing.", "success")
            
    except Exception as e:
        db.session.rollback()
        current_app.logger.exception("Failed to create new school")
        flash(f"Error: {e}", "danger")
        
    return redirect(url_for("main.dashboard"))


@main.route("/api/sync/setup/local", methods=["POST"])
@login_required
def sync_setup_local():
    current_user.local_only = True
    if current_user.school_id:
        school = School.query.get(current_user.school_id)
        if school:
            school.allow_online_sync = False
    safe_commit()

    config = load_config()
    config['local_only'] = True
    save_config(config)

    sync_service = get_sync_service()
    if sync_service and hasattr(sync_service, 'stop_immediately'):
        sync_service.stop_immediately()

    try:
        import peer_sync
        if request.form.get('stop_lan') == '1':
            peer_sync.stop_immediately()
    except Exception:
        pass

    flash(_("Local mode enabled. You can always connect online later in Connectivity & Sync."), "info")
    return redirect(url_for("main.dashboard"))


@main.route("/api/sync/cloud_librarians", methods=["GET"])
@login_required
def get_cloud_librarians():
    sync_service = get_sync_service()
    if not sync_service or not sync_service.supabase:
        return jsonify({"error": "Supabase not configured."})
        
    try:
        # get our sb school
        school = School.query.get(current_user.school_id)
        if not school:
            return jsonify({"error": "Not connected to any school."})
            
        sb_school_id = school.id
        
        # Check if current user is main librarian
        user_resp = sync_service.supabase.table('librarians').select('is_main_librarian').eq('school_id', sb_school_id).eq('username', current_user.username).execute()
        is_main = False
        if user_resp.data and len(user_resp.data) > 0:
            is_main = user_resp.data[0]['is_main_librarian']
            
        # Get all librarians
        libs_resp = sync_service.supabase.table('librarians').select('*').eq('school_id', sb_school_id).execute()
        return jsonify({
            "librarians": libs_resp.data,
            "is_current_main": is_main
        })
    except Exception as e:
        return jsonify({"error": str(e)})


@main.route("/api/sync/revoke/<uuid:librarian_id>", methods=["POST"])
@login_required
def revoke_cloud_librarian(librarian_id):
    sync_service = get_sync_service()
    if not sync_service or not sync_service.supabase:
        return jsonify({"success": False, "message": "Supabase not configured."})
        
    try:
        school = School.query.get(current_user.school_id)
        if not school:
            return jsonify({"success": False, "message": "Not connected to any school."})
            
        sb_school_id = school.id
        
        # Verify current user is main librarian
        user_resp = sync_service.supabase.table('librarians').select('is_main_librarian').eq('school_id', sb_school_id).eq('username', current_user.username).execute()
        if not user_resp.data or not user_resp.data[0]['is_main_librarian']:
            return jsonify({"success": False, "message": "Only main librarian can revoke access."})
            
        sync_service.supabase.table('librarians').delete().eq('id', str(librarian_id)).execute()
        return jsonify({"success": True})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)})


@main.route("/api/sync/join_requests", methods=["GET"])
@login_required
def get_join_requests():
    sync_service = get_sync_service()
    if not sync_service or not sync_service.supabase:
        return jsonify({"error": "Supabase not configured."})
        
    try:
        # get our sb school
        school = School.query.get(current_user.school_id)
        if not school:
            return jsonify({"requests": []})
            
        sb_school_id = school.id
        
        # Verify current user is main librarian
        user_resp = sync_service.supabase.table('librarians').select('is_main_librarian').eq('school_id', sb_school_id).eq('username', current_user.username).execute()
        if not user_resp.data or not user_resp.data[0]['is_main_librarian']:
            return jsonify({"requests": []})
            
        # Get pending requests for this school
        req_resp = sync_service.supabase.table('join_requests').select('*').eq('school_name', school.school_name).eq('status', 'pending').execute()
        
        return jsonify({"requests": req_resp.data})
    except Exception as e:
        current_app.logger.error(f"Error fetching join requests: {e}")
        return jsonify({"error": str(e)})


@main.route("/api/sync/join_requests/<uuid:request_id>/<action>", methods=["POST"])
@login_required
def handle_join_request(request_id, action):
    if action not in ['approve', 'reject']:
        return jsonify({"success": False, "message": "Invalid action"})
        
    sync_service = get_sync_service()
    if not sync_service or not sync_service.supabase:
        return jsonify({"success": False, "message": "Supabase not configured."})
        
    try:
        # Security checks
        school = School.query.get(current_user.school_id)
        sb_school_id = school.id
        user_resp = sync_service.supabase.table('librarians').select('is_main_librarian').eq('school_id', sb_school_id).eq('username', current_user.username).execute()
        if not user_resp.data or not user_resp.data[0]['is_main_librarian']:
            return jsonify({"success": False, "message": "Unauthorized"})
            
        # Get the request
        req_resp = sync_service.supabase.table('join_requests').select('*').eq('id', str(request_id)).execute()
        if not req_resp.data:
            return jsonify({"success": False, "message": "Request not found"})
            
        req_data = req_resp.data[0]
        target_username = req_data['username']
        
        if action == 'approve':
            # Check if librarian already exists in the librarians table
            existing = sync_service.supabase.table('librarians').select('id, is_main_librarian').eq('school_id', sb_school_id).eq('username', target_username).execute()
            
            if existing.data:
                # Librarian already exists - update their status if needed
                librarian_id = existing.data[0]['id']
                # Only update if they're not already a main librarian (preserve main librarian status)
                if not existing.data[0]['is_main_librarian']:
                    sync_service.supabase.table('librarians').update({
                        "is_main_librarian": False
                    }).eq('id', librarian_id).execute()
            else:
                # Librarian doesn't exist - create new entry with school_id
                # This gives the librarian access to the school's data
                # The new librarian's system will then automatically sync/download from Supabase
                sync_service.supabase.table('librarians').insert({
                    "school_id": sb_school_id,
                    "username": target_username,
                    "is_main_librarian": False
                }).execute()
            
        # Update request status in Supabase so the requesting librarian's client can pick it up
        sync_service.supabase.table('join_requests').update({"status": "approved" if action == 'approve' else "rejected"}).eq('id', str(request_id)).execute()
        
        return jsonify({"success": True})
        
    except Exception as e:
        current_app.logger.exception("Error handling join request")
        return jsonify({"success": False, "message": str(e)})


def _create_join_notification(username, status, school_name):
    """Create a persistent notification for a librarian about their join request status."""
    try:
        from .database import Log
        # Use the Log table to store notifications (type='join_notification')
        # We'll store it with the target username so they can retrieve it on login
        notification = Log(
            username=username,  # Target librarian username
            method='JOIN_NOTIFICATION',
            details=json.dumps({
                'type': 'join_request',
                'status': status,  # 'approved' or 'rejected'
                'school_name': school_name,
                'timestamp': utc_now().isoformat()
            }),
            timestamp=utc_now().strftime("%Y-%m-%d %H:%M:%S")
        )
        db.session.add(notification)
        safe_commit()
        current_app.logger.info(f"Created join notification for {username}: {status}")
    except Exception as e:
        current_app.logger.warning(f"Failed to create join notification for {username}: {e}")


@main.route("/api/sync/join_notifications", methods=["GET"])
@login_required
def get_join_notifications():
    """Get pending join request notifications for the current user by actively polling Supabase."""
    try:
        from .database import Log

        sync_service = get_sync_service()
        if not sync_service or not sync_service.is_configured():
            return jsonify({"success": True, "notifications": []})

        # Do not poll if the current user is a main librarian (main librarians do not request to join schools)
        if current_user.school_id:
            try:
                user_resp = sync_service.supabase.table('librarians').select('is_main_librarian').eq('school_id', current_user.school_id).eq('username', current_user.username).execute()
                if user_resp.data and user_resp.data[0]['is_main_librarian']:
                    return jsonify({"success": True, "notifications": []})
            except Exception as e:
                current_app.logger.warning(f"Failed to verify main librarian status in get_join_notifications: {e}")

        # 1. Active Poll: Check Supabase for any non-pending join requests for THIS user
        try:
            req_resp = sync_service.supabase.table('join_requests').select('*').eq('username', current_user.username).neq('status', 'pending').execute()
            if req_resp.data:
                for req in req_resp.data:
                    # Ensure we don't duplicate notifications
                    existing_notification = Log.query.filter(Log.details.like(f'%"join_request_id": "{req["id"]}"%')).first()

                    if not existing_notification:
                        # Apply the changes to the local admin record if approved
                        if req['status'] == 'approved':
                            # Fetch the school by name or we can query the school ID from Supabase
                            # For safety, we query the school from Supabase
                            sb_school_resp = sync_service.supabase.table('schools').select('id').eq('school_name', req['school_name']).limit(1).execute()
                            if sb_school_resp.data:
                                sb_school_id = sb_school_resp.data[0]['id']
                                current_user.school_id = sb_school_id
                                current_user.has_downloaded_db = False # Force download!
                                current_user.sync_status = 'synced'
                                current_user.updated_at = utc_now()
                                safe_commit()

                        # Create notification locally for the user
                        notification = Log(
                            username=current_user.username,
                            method='JOIN_NOTIFICATION',
                            details=json.dumps({
                                'type': 'join_request',
                                'status': req['status'],
                                'school_name': req['school_name'],
                                'timestamp': utc_now().isoformat(),
                                'join_request_id': req['id']
                            }),
                            timestamp=utc_now().strftime("%Y-%m-%d %H:%M:%S")
                        )
                        db.session.add(notification)
                        safe_commit()

                    # Delete the request from Supabase once we've processed it
                    sync_service.supabase.table('join_requests').delete().eq('id', req['id']).execute()
        except Exception as sb_err:
            current_app.logger.warning(f"Failed to poll Supabase for join requests: {sb_err}")

        # 2. Return local notifications
        notifications = Log.query.filter_by(
            username=current_user.username,
            method='JOIN_NOTIFICATION'
        ).order_by(Log.id.desc()).all()
        
        result = []
        for n in notifications:
            try:
                data = json.loads(n.details)
                result.append({
                    'id': n.id,
                    'type': data.get('type'),
                    'status': data.get('status'),
                    'school_name': data.get('school_name'),
                    'timestamp': data.get('timestamp')
                })
            except:
                continue
                
        return jsonify({"success": True, "notifications": result})
    except Exception as e:
        current_app.logger.exception("Error fetching join notifications")
        return jsonify({"success": False, "message": str(e)})


@main.route("/api/sync/sms_notifications", methods=["GET"])
@login_required
def get_sms_notifications():
    """Get SMS delivery notifications for the current user."""
    try:
        from .database import Log
        notifications = Log.query.filter_by(
            username=current_user.username,
            method='SMS_NOTIFICATION'
        ).order_by(Log.id.desc()).limit(20).all()
        
        result = []
        for n in notifications:
            try:
                data = json.loads(n.details)
                result.append({
                    'id': n.id,
                    'type': data.get('type'),
                    'status': data.get('status'),
                    'phone': data.get('phone'),
                    'attempts': data.get('attempts'),
                    'error': data.get('error'),
                    'message': data.get('message'),
                    'timestamp': data.get('timestamp')
                })
            except:
                continue
                
        return jsonify({"success": True, "notifications": result})
    except Exception as e:
        current_app.logger.exception("Error fetching SMS notifications")
        return jsonify({"success": False, "message": str(e)})


@main.route("/api/sync/sms_notifications/<string:notification_id>/dismiss", methods=["POST"])
@login_required
def dismiss_sms_notification(notification_id):
    """Dismiss an SMS notification."""
    try:
        from .database import Log
        notification = Log.query.filter_by(
            id=notification_id,
            username=current_user.username,
            method='SMS_NOTIFICATION'
        ).first()
        
        if notification:
            db.session.delete(notification)
            safe_commit()
            return jsonify({"success": True})
        else:
            return jsonify({"success": False, "message": "Notification not found"})
    except Exception as e:
        current_app.logger.exception("Error dismissing SMS notification")
        return jsonify({"success": False, "message": str(e)})


@main.route("/api/sync/join_notifications/<string:notification_id>/dismiss", methods=["POST"])
@login_required
def dismiss_join_notification(notification_id):
    """Dismiss a join request notification."""
    try:
        from .database import Log
        notification = Log.query.filter_by(
            id=notification_id,
            username=current_user.username,
            method='JOIN_NOTIFICATION'
        ).first()
        
        if notification:
            db.session.delete(notification)
            safe_commit()
            return jsonify({"success": True})
        else:
            return jsonify({"success": False, "message": "Notification not found"})
    except Exception as e:
        current_app.logger.exception("Error dismissing join notification")
        return jsonify({"success": False, "message": str(e)})



@main.route('/sync/queue')
@login_required
def view_sync_queue():
    school_id = get_current_school_id()
    if not school_id:
        flash("You must be associated with a school to view sync queue.", "warning")
        return redirect(url_for('main.index'))

    # Optional filtering by status
    status_filter = request.args.get('status')

    query = SyncQueue.query.filter_by(school_id=school_id)
    if status_filter:
        query = query.filter_by(status=status_filter)

    queue_items = query.order_by(SyncQueue.created_at.desc()).all()

    return render_template('sync_queue.html', queue_items=queue_items, current_filter=status_filter)

from .database import SyncConflict, PeerSyncConflict
# 1. THE UNIFIED DASHBOARD ROUTE (GET)
@main.route("/sync/conflicts", methods=["GET"])
@login_required
def unified_conflicts():
    school_id = current_user.school_id
    
    # Fetch all pending conflicts from both tables
    cloud_conflicts = SyncConflict.query.filter_by(school_id=school_id, resolution='pending').all()
    lan_conflicts = PeerSyncConflict.query.filter_by(school_id=school_id, resolution='pending').all()
    
    # Combine and tag them for the frontend UI
    all_conflicts = []
    for c in cloud_conflicts:
        c.source_type = 'Cloud (Supabase)'
        c.badge_color = 'primary'
        all_conflicts.append(c)
        
    for c in lan_conflicts:
        c.source_type = 'LAN (Peer)'
        c.badge_color = 'success'
        all_conflicts.append(c)
        
    # Sort by most recent conflicts first
    all_conflicts.sort(key=lambda x: x.created_at, reverse=True)
    
    return render_template("conflicts.html", conflicts=all_conflicts)


# 2. THE UNIFIED RESOLVER ROUTE (POST)
@main.route("/api/sync/resolve_conflict", methods=["POST"])
@login_required
def resolve_unified_conflict():
    data = request.json
    conflict_id = data.get('id')
    source = data.get('source') # 'Cloud (Supabase)' or 'LAN (Peer)'
    decision = data.get('decision') # 'local', 'remote', or 'manual'
    manual_payload = data.get('manual_payload')

    try:
        sync_service = get_sync_service()
        if not sync_service:
            return jsonify({"success": False, "message": "Sync service unavailable."}), 503
            
        # Determine which database table we are targeting based on the source
        conflict_model = SyncConflict if 'Cloud' in source else PeerSyncConflict
        conflict = conflict_model.query.get_or_404(conflict_id)
        
        # Figure out which payload won the conflict
        if decision == 'local':
            winner_payload = json.loads(conflict.local_payload) if isinstance(conflict.local_payload, str) else conflict.local_payload
        elif decision == 'remote':
            winner_payload = json.loads(conflict.remote_payload) if isinstance(conflict.remote_payload, str) else conflict.remote_payload
        elif decision == 'manual':
            winner_payload = manual_payload
        else:
            return jsonify({"success": False, "message": "Invalid resolution type"}), 400

        # 1. Apply the winning payload to the actual core tables (e.g., books, students)
        sync_service._apply_remote_record(conflict.entity_type, winner_payload, force=True)
        
        # 2. Mark the conflict itself as resolved in the ledger
        conflict.resolution = decision
        conflict.resolved_at = datetime.now()
        conflict.resolved_payload = json.dumps(winner_payload) if isinstance(winner_payload, dict) else winner_payload
        
        safe_commit()

        # 3. Log the human intervention
        log_action(
            "/api/sync/resolve_conflict",
            "RESOLVE_CONFLICT",
            f"{current_user.username} resolved {source} conflict for {conflict.entity_type} (ID: {conflict.entity_id}) using '{decision}'",
            status_code=200
        )

        return jsonify({"success": True})
        
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Failed to resolve unified conflict: {e}")
        return jsonify({"success": False, "message": str(e)}), 500
@main.route('/bulk_delete_students', methods=['POST'])
def bulk_delete_students():
    student_ids = request.form.getlist('student_ids')
    
    if not student_ids:
        flash("No students selected.", "warning")
        return redirect(url_for('main.students'))
        
    # Delete all students whose IDs are in the selected list
    Student.query.filter(Student.id.in_(student_ids)).delete(synchronize_session=False)
    db.session.commit()
    
    flash(f"Successfully deleted {len(student_ids)} students.", "success")
    return redirect(url_for('main.students'))


@main.route('/bulk_edit_students', methods=['POST'])
def bulk_edit_students():
    student_ids = request.form.getlist('student_ids')
    new_class_name = request.form.get('new_class_name', '').strip()
    
    if not student_ids:
        flash("No students selected.", "warning")
        return redirect(url_for('main.students'))
        
    if not new_class_name:
        flash("You must provide a new class name.", "danger")
        return redirect(url_for('main.students'))

    # Update the student_class for all selected students
    Student.query.filter(Student.id.in_(student_ids)).update(
        {Student.student_class: new_class_name}, synchronize_session=False
    )
    db.session.commit()
    
    flash(f"Successfully moved {len(student_ids)} students to class {new_class_name}.", "success")
    return redirect(url_for('main.students'))

@main.route('/api/quick_add_book', methods=['POST'])
@login_required
def quick_add_book():
    data = request.get_json(silent=True) or {}
    if not data:
        return jsonify({'success': False, 'message': _('No data provided.')}), 400

    common_id = (data.get('qa_common_id') or data.get('common_id') or data.get('base_id') or '').strip().rstrip('/')
    raw_unique_ids = (data.get('qa_unique_ids') or data.get('unique_ids') or '').strip()
    raw_book_id = (data.get('book_id') or '').strip()
    title = (data.get('qa_title') or data.get('title') or '').strip()
    author = (data.get('qa_author') or data.get('author') or 'Unknown').strip() or 'Unknown'
    category = (data.get('qa_category') or data.get('category') or 'Uncategorized').strip() or 'Uncategorized'

    if not common_id and raw_book_id:
        if '/' in raw_book_id:
            common_id, fallback_u = raw_book_id.split('/', 1)
            common_id = common_id.strip()
            if not raw_unique_ids:
                raw_unique_ids = fallback_u.strip()
        else:
            common_id = raw_book_id

    if not raw_unique_ids and raw_book_id and '/' not in raw_book_id:
        raw_unique_ids = '1'

    expanded_uids = expand_unique_ids(raw_unique_ids)
    if not common_id or not expanded_uids or not title:
        return jsonify({'success': False, 'message': _('Base ID, Unique ID(s), and Title are required.')}), 400

    try:
        created_books = []
        created_ids = []
        all_full_ids = []
        now_str = datetime.now().strftime("%Y-%m-%d")
        for uid in expanded_uids:
            full_id = f"{common_id}/{uid}"
            all_full_ids.append(full_id)
            if not school_get(Book, full_id, pk_name='book_id'):
                new_book = Book(
                    book_id=full_id,
                    title=title,
                    author=author,
                    category=category,
                    added_at=now_str,
                )
                stamp_sync_fields(new_book)
                db.session.add(new_book)
                created_books.append(new_book)
                created_ids.append(full_id)

        db.session.flush()
        for b in created_books:
            queue_record_change('books', b, operation='upsert')
        safe_commit()

        return jsonify({
            'success': True,
            'message': _('Quick Added %(count)d book copy/copies.', count=len(created_books)),
            'added_count': len(created_books),
            'book': {
                'id': common_id,
                'book_id': common_id,
                'base_id': common_id,
                'unique_ids': expanded_uids,
                'full_ids': all_full_ids,
                'created_ids': created_ids,
                'title': title,
                'author': author,
                'category': category,
            }
        }), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': f'Database error: {str(e)}'}), 500
