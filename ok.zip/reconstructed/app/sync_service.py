import json
import sys
import threading
import uuid
from datetime import UTC, datetime, timedelta

from flask import current_app

from .database import (
    Admin,
    Announcement,
    Book,
    BookIssue,
    BorrowedBook,
    ClassBorrowing,
    GraduateBorrowing,
    GraduateClassBorrowing,
    Log,
    Note,
    School,
    Student,
    SyncConflict,
    SyncMetadata,
    SyncQueue,
    CloudSyncQueue,
    TeacherBorrowedBook,
    UpdateHistory,
    PeerSyncQueue,
    PeerSyncLog,
    PeerSession,
    JoinRequest,
    db,
)
from .utils import load_config, safe_commit, safe_rollback

# ── Supabase import (optional dependency) ──────────────────────────────────
try:
    from supabase import create_client, Client
except ImportError:  # pragma: no cover - optional in local dev
    create_client = None
    Client = None
# ───────────────────────────────────────────────────────────────────────────


def utc_now():
    return datetime.now(UTC).replace(tzinfo=None)


class SyncService:
    DEFAULT_REMOTE_SCHEMA = "public"

    ENTITY_CONFIG = {
        "announcements": {
            "model": Announcement,
            "table": "announcements",
            "schema": "public",
            "pk": "id",
            "on_conflict": "id",
            "remote_school_column": None,
            "supports_sync_status": False,
            "download_enabled": True,
            "timestamp_column": "created_at",
        },
        "books": {
            "model": Book,
            "table": "bookstable",
            "pk": "book_id",
            "on_conflict": "school_id,book_id",
            "exclude_columns": ["added_at"],
            "composite_key": ["school_id", "book_id"]
        },
        "members": {
            "model": Student,
            "table": "students",
            "pk": "id",
            "on_conflict": "school_id,id",
            "exclude_columns": ["combination"],
            "composite_key": ["school_id", "id"],
        },
        "checkouts": {
            "model": BorrowedBook,
            "table": "borrowed_books",
            "pk": "id",
            "on_conflict": "school_id,id",
            "exclude_columns": ["performed_by"],
            "composite_key": ["school_id", "id"],
        },
        "staff_checkouts": {
            "model": TeacherBorrowedBook,
            "table": "teacher_borrowed_books",
            "pk": "id",
            "on_conflict": "school_id,id",
            "composite_key": ["school_id", "id"],
        },
        "class_checkouts": {
            "model": ClassBorrowing,
            "table": "class_borrowing",
            "pk": "id",
            "on_conflict": "school_id,id",
            "composite_key": ["school_id", "id"],
        },
        "book_issues": {
            "model": BookIssue,
            "table": "book_issues",
            "pk": "id",
            "on_conflict": "school_id,id",
            "composite_key": ["school_id", "id"],
        },
        "librarians": {
            "model": Admin,
            "table": "admin",
            "pk": "id",
            "on_conflict": "school_id,id",
            "exclude_columns": [
                "email1",
                "email2",
                "email3",
                "profile_image",
                "recovery_codes",
                "question1",
                "answer1",
                "question2",
                "answer3",
                "pending_recovery_password",
                "pending_recovery_expires_at",
            ],
            "composite_key": ["school_id", "id"],
        },
        "logs": {
            "model": Log,
            "table": "logs",
            "schema": "public",
            "pk": "id",
            "on_conflict": "school_id,id",
            "remote_school_column": "school_id",
            "supports_sync_status": True,
            "download_enabled": True,
            "remote_columns": [
                "id",
                "school_id",
                "timestamp",
                "route",
                "username",
                "librarian_username",
                "method",
                "status_code",
                "details",
                "created_at",
                "updated_at",
                "deleted",
                "sync_status",
            ],
            "composite_key": ["school_id", "id"],
        },
        "schools": {
            "model": School,
            "table": "schools",
            "schema": "public",
            "pk": "id",
            "on_conflict": "id",
            "remote_school_column": None,
            "supports_sync_status": False,
            "download_enabled": False,
        },
        "notes": {
            "model": Note,
            "table": "notes",
            "schema": "public",
            "pk": "id",
            "on_conflict": "school_id,id",
            "remote_school_column": "school_id",
            "supports_sync_status": True,
            "download_enabled": True,
            "composite_key": ["school_id", "id"],
        },
        "graduates_borrowed": {
            "model": GraduateBorrowing,
            "table": "graduates_borrowed_books",
            "schema": "public",
            "pk": "id",
            "on_conflict": "school_id,id",
            "remote_school_column": "school_id",
            "supports_sync_status": True,
            "download_enabled": True,
            "composite_key": ["school_id", "id"],
        },
        "graduates_class": {
            "model": GraduateClassBorrowing,
            "table": "graduates_class_borrowing",
            "schema": "public",
            "pk": "id",
            "on_conflict": "school_id,id",
            "remote_school_column": "school_id",
            "supports_sync_status": True,
            "download_enabled": True,
            "composite_key": ["school_id", "id"],
        },
        "update_history": {
            "model": UpdateHistory,
            "table": "update_history",
            "pk": "id",
            "on_conflict": "school_id,id",
            "composite_key": ["school_id", "id"],
        },
        "sync_metadata": {
            "model": SyncMetadata,
            "table": "sync_metadata",
            "pk": "id",
            "on_conflict": "device_id",
            "composite_key": ["school_id", "device_id"],
        },
        "sync_queue": {
            "model": SyncQueue,
            "table": "sync_queue",
            "pk": "id",
            "on_conflict": "operation_id",
            "composite_key": ["school_id", "operation_id"],
        },
        "sync_conflicts": {
            "model": SyncConflict,
            "table": "sync_conflicts",
            "pk": "id",
            "on_conflict": "school_id,entity_type,entity_id",
            "composite_key": ["school_id", "entity_type", "entity_id"],
        },
        "cloud_sync_queue": {
            "model": CloudSyncQueue,
            "table": "cloud_sync_queue",
            "pk": "id",
            "on_conflict": "school_id,table_name,record_id",
            "composite_key": ["school_id", "table_name", "record_id"],
            "download_enabled": False,
        },
        "peer_sync_queue": {
            "model": PeerSyncQueue,
            "table": "peer_sync_queue",
            "pk": "id",
            "on_conflict": "change_id",
            "composite_key": ["change_id"],
            "download_enabled": False,
        },
        "sync_logs": {
            "model": PeerSyncLog,
            "table": "sync_logs",
            "pk": "id",
            "on_conflict": "change_id",
            "composite_key": ["change_id"],
            "download_enabled": False,
        },
        "peer_sessions": {
            "model": PeerSession,
            "table": "peer_sessions",
            "pk": "id",
            "on_conflict": "device_id",
            "composite_key": ["device_id"],
            "download_enabled": False,
        },
        "join_requests": {
            "model": JoinRequest,
            "table": "join_requests",
            "pk": "id",
            "on_conflict": "id",
            "remote_school_column": None,
            "supports_sync_status": False,
            "download_enabled": False,
        },
    }

    def __init__(self, app=None):
        self.supabase = None
        self._stop_event = threading.Event()
        self.is_running = False
        if app is not None:
            self.init_app(app)

    def stop_immediately(self):
        self._stop_event.set()
        self.is_running = False

    def start_background_loop(self, app, callback=None):
        self._stop_event.clear()
        self.is_running = True
        threading.Thread(target=self._run_loop, args=(app, callback), daemon=True).start()

    def _run_loop(self, app, callback=None):
        self.is_running = True
        while not self._stop_event.is_set():
            # perform sync work...
            try:
                with app.app_context():
                    if callback:
                        callback()
                    else:
                        self._background_cloud_sync()
            except Exception as exc:
                self._log_supabase_debug(f"Background sync loop error: {exc}")
            if self._stop_event.wait(timeout=15.0): break
        self.is_running = False

    def init_app(self, app):
        config = load_config()
        app.config["SUPABASE_URL"] = config.get("supabase_url", app.config.get("SUPABASE_URL", ""))
        app.config["SUPABASE_KEY"] = (
            config.get("supabase_service_role_key")
            or config.get("supabase_key", app.config.get("SUPABASE_KEY", ""))
        )
        app.config["SUPABASE_ANON_KEY"] = config.get("supabase_key", app.config.get("SUPABASE_ANON_KEY", ""))
        app.config["DEVICE_ID"] = config.get("device_id", app.config.get("DEVICE_ID", "desktop-device"))
        app.config["SYNC_BATCH_SIZE"] = int(config.get("sync_batch_size", app.config.get("SYNC_BATCH_SIZE", 100)) or 100)
        app.config["SYNC_MIN_INTERVAL_SECONDS"] = int(
            config.get("sync_min_interval_seconds", app.config.get("SYNC_MIN_INTERVAL_SECONDS", 20)) or 20
        )
        self.supabase = self._build_client(
            app.config.get("SUPABASE_URL", ""),
            app.config.get("SUPABASE_KEY", ""),
        )
        app.extensions["sync_service"] = self

    def _build_client(self, url, key):
        if not create_client or not url or not key:
            return None
        try:
            return create_client(url, key)
        except Exception as exc:
            try:
                current_app.logger.warning("Supabase client initialization failed: %s", exc)
            except RuntimeError:
                pass
            return None

    def is_configured(self):
        return self.supabase is not None

    def _remote_school_column(self, entity_type):
        config = self.ENTITY_CONFIG.get(entity_type, {})
        return config.get("remote_school_column", "school_id")

    def _entity_schema(self, entity_type):
        config = self.ENTITY_CONFIG.get(entity_type, {})
        return config.get("schema", self.DEFAULT_REMOTE_SCHEMA)

    def _supports_sync_status(self, entity_type):
        config = self.ENTITY_CONFIG.get(entity_type, {})
        return config.get("supports_sync_status", True)

    def _downloads_enabled(self, entity_type):
        config = self.ENTITY_CONFIG.get(entity_type, {})
        return config.get("download_enabled", True)

    def should_upload_now(self, school_id=None):
        metadata = self.get_metadata(school_id=school_id)
        min_interval_seconds = max(0, int(current_app.config.get("SYNC_MIN_INTERVAL_SECONDS", 20) or 0))
        if min_interval_seconds == 0 or not metadata.last_upload_at:
            return True
        return (utc_now() - metadata.last_upload_at) >= timedelta(seconds=min_interval_seconds)

    def _resolve_target_school_id(self, school_id=None, metadata=None):
        if school_id is not None:
            return school_id
        if metadata and metadata.school_id is not None:
            return metadata.school_id
        return self._default_school_id()

    def _table_client(self, table_name, schema=None):
        schema_name = schema or self.DEFAULT_REMOTE_SCHEMA
        return self.supabase.schema(schema_name).table(table_name)

    def _log_supabase_debug(self, message):
        try:
            current_app.logger.info(message)
        except RuntimeError:
            pass

    def school_allows_online_sync(self, school_id):
        if not school_id:
            return False
        school = School.query.filter_by(id=school_id, deleted=False).first()
        return bool(school and school.allow_online_sync)

    def _set_sync_state(self, active, operation, message=None, summary=None):
        state = {
            "active": bool(active),
            "operation": operation,
            "message": message or "Idle",
            "summary": summary or {},
        }
        current_app.config["_sync_state"] = state

    def _get_sync_lock(self):
        lock = getattr(current_app, "_sync_operation_lock", None)
        if lock is None:
            lock = threading.RLock()
            current_app._sync_operation_lock = lock
        return lock

    def _sanitize_remote_payload(self, entity_type, payload):
        safe_payload = dict(payload or {})
        config = self.ENTITY_CONFIG.get(entity_type, {})
        allowed_columns = config.get("remote_columns")
        if allowed_columns:
            safe_payload = {key: value for key, value in safe_payload.items() if key in allowed_columns}
        return safe_payload

    def _retry_delay_seconds(self, attempt_count):
        max_delay = max(30, int(current_app.config.get("SYNC_RETRY_MAX_SECONDS", 300) or 300))
        return min(max_delay, 2 ** min(attempt_count, 8))

    def _is_transient_error(self, error):
        message = str(error or "").lower()
        transient_markers = [
            "winerror 10054",
            "connection reset",
            "connectionreseterror",
            "temporarily unavailable",
            "timed out",
            "timeout",
            "network",
        ]
        return any(marker in message for marker in transient_markers)

    def _is_missing_remote_table_error(self, error):
        message = str(error or "").lower()
        return (
            "could not find the table" in message and "remote_sync_ledger" in message
        ) or "pgrst205" in message

    def push_to_cloud_sync_queue(self, table_name, record_id, payload, school_id):
        from .database import CloudSyncQueue
        queue_item = CloudSyncQueue(
            table_name=table_name,
            record_id=str(record_id),
            payload=json.dumps(payload, default=str),
            timestamp=utc_now().isoformat(),
            school_id=school_id
        )
        db.session.add(queue_item)
        db.session.flush()




    def _ensure_remote_school_exists(self, school_id):
        if not school_id:
            return False

        try:
            school_res = self.supabase.table('schools').select('id').eq('id', school_id).limit(1).execute()
            if getattr(school_res, 'data', None):
                return True
        except Exception:
            return False

        local_school = School.query.filter_by(id=school_id, deleted=False).first()
        if not local_school:
            return False

        payload = {
            'id': local_school.id,
            'school_name': local_school.school_name,
            'slug': local_school.slug,
            'contact_email': local_school.contact_email,
            'contact_phone': local_school.contact_phone,
            'status': local_school.status,
            'created_at': self._serialize_value(local_school.created_at),
            'updated_at': self._serialize_value(local_school.updated_at),
            'deleted': bool(local_school.deleted),
        }

        try:
            self.supabase.table('schools').upsert(payload, on_conflict='id').execute()
            return True
        except Exception:
            return False

    def _check_security_directives(self, school_id):
        if not self.supabase:
            return

        try:
            response = self.supabase.table('security_directives').select('*').eq('school_id', school_id).execute()
            if not response.data:
                return

            directive = response.data[0].get('directive')
            status = response.data[0].get('status')
            impact_time = response.data[0].get('impact_time')

            if directive in ['wipe', 'lockdown'] and status == 'pending':
                print(f'DIRECTIVE:{directive.upper()}:{impact_time}', flush=True)
            elif directive == 'none':
                print('DIRECTIVE:REVOKE', flush=True)
        except Exception:
            pass

    def _background_cloud_sync(self):
        import time
        if self._stop_event.is_set():
            return
        
        metadata = self.get_metadata()
        if not metadata or not self.is_configured():
            return

        target_school_id = metadata.school_id
        if target_school_id:
            self._check_security_directives(target_school_id)

        if not target_school_id or not self.school_allows_online_sync(target_school_id):
            return

        try:
            self.supabase.table('remote_sync_ledger').select('id').limit(1).execute()
        except Exception as e:
            if self._is_missing_remote_table_error(e):
                self._log_supabase_debug(
                    "Remote sync ledger table is not available in Supabase yet; skipping cloud sync until it is created."
                )
                return
            self._log_supabase_debug(f"Failed to initialize remote sync ledger: {e}")
            return
            
        # Ensure the school exists in Supabase before pushing dependent ledger events.
        if not self._ensure_remote_school_exists(target_school_id):
            return

        # 1. Push pending local mutations to Supabase remote_sync_ledger in batches
        batch_size = 1000
        pending_items = CloudSyncQueue.query.filter_by(school_id=target_school_id).order_by(CloudSyncQueue.id.asc()).all()
        
        if pending_items:
            start_time = time.time()
            total_pushed = 0
            for i in range(0, len(pending_items), batch_size):
                batch = pending_items[i:i + batch_size]
                records_to_insert = []
                
                for item in batch:
                    try:
                        payload = json.loads(item.payload)
                        records_to_insert.append({
                            'school_id': item.school_id,
                            'table_name': item.table_name,
                            'record_id': item.record_id,
                            'payload': payload,
                            'timestamp': item.timestamp
                        })
                    except Exception as e:
                        sys.stderr.write(f"Failed to parse CloudSyncQueue item {item.id}: {e}\n")
                        self._log_supabase_debug(f"Failed to parse CloudSyncQueue item {item.id}: {e}")

                if records_to_insert:
                    try:
                        self.supabase.table('remote_sync_ledger').insert(records_to_insert).execute()
                        for item in batch:
                            db.session.delete(item)
                        safe_commit()
                        total_pushed += len(records_to_insert)
                    except Exception as e:
                        sys.stderr.write(f"Failed to push CloudSyncQueue batch: {e}\n")
                        self._log_supabase_debug(f"Failed to push CloudSyncQueue batch: {e}")
                        break # Stop on batch failure to preserve order
            
            if total_pushed > 0:
                sys.stdout.write(f"\n[SyncService] CloudSyncQueue pushed {total_pushed} records in {time.time() - start_time:.2f} seconds.\n")
                sys.stdout.flush()

        # 2. Pull remote changes based on local watermark and apply LWW in batches
        watermark = metadata.last_download_at or (utc_now() - timedelta(days=365*10))
        batch_size = 1000
        total_downloaded = 0
        dl_start_time = time.time()
        
        try:
            while True:
                response = self.supabase.table('remote_sync_ledger').select('*')\
                    .eq('school_id', target_school_id)\
                    .gt('timestamp', watermark.isoformat())\
                    .order('timestamp', desc=False)\
                    .limit(batch_size)\
                    .execute()

                changes = getattr(response, "data", None) or []
                if not changes:
                    break
                    
                max_timestamp = watermark

                for change in changes:
                    remote_timestamp_str = change.get('timestamp')
                    remote_timestamp = self._parse_datetime(remote_timestamp_str)
                    if remote_timestamp and remote_timestamp > max_timestamp:
                        max_timestamp = remote_timestamp

                    table_name = change.get('table_name')
                    record_id = change.get('record_id')
                    remote_payload = change.get('payload', {})
                    remote_updated_at = self._parse_datetime(remote_payload.get('updated_at', remote_timestamp_str))

                    # Identify local model
                    entity_type = None
                    for etype, econfig in self.ENTITY_CONFIG.items():
                        if econfig["table"] == table_name:
                            entity_type = etype
                            break

                    if not entity_type:
                        continue

                    local_record = self._fetch_local_record(entity_type, {self.ENTITY_CONFIG[entity_type]["pk"]: record_id, "school_id": target_school_id})

                    if local_record:
                        # LWW
                        local_updated_at = getattr(local_record, 'updated_at', None)
                        if local_updated_at and remote_updated_at and local_updated_at >= remote_updated_at:
                            continue # Local is newer or equal, ignore remote

                    # Apply remote record
                    safe_payload = dict(remote_payload)
                    safe_payload['school_id'] = target_school_id
                    self._apply_remote_record(entity_type, safe_payload, force=True)
                    total_downloaded += 1

                metadata.last_download_at = max_timestamp
                watermark = max_timestamp
                safe_commit()
                
                if len(changes) < batch_size:
                    break
                    
            if total_downloaded > 0:
                sys.stdout.write(f"\n[SyncService] Downloaded {total_downloaded} delta records in {time.time() - dl_start_time:.2f} seconds.\n")
                sys.stdout.flush()
                
        except Exception as e:
            sys.stderr.write(f"Failed to pull from remote_sync_ledger: {e}\n")
            self._log_supabase_debug(f"Failed to pull from remote_sync_ledger: {e}")




    def queue_change(
        self,
        entity_type,
        entity_id,
        operation,
        payload,
        school_id,
        device_id=None,
        record_updated_at=None,
        operation_id=None,
    ):
        resolved_device_id = device_id or current_app.config.get("DEVICE_ID", "desktop-device")
        resolved_entity_id = str(entity_id)
        queue_item = None

        if operation_id:
            queue_item = SyncQueue.query.filter_by(operation_id=operation_id).first()

        if queue_item is None:
            # Reuse a pending entry for the same record so repeated edits do not spam inserts.
            queue_item = (
                SyncQueue.query.filter_by(
                    school_id=school_id,
                    entity_type=entity_type,
                    entity_id=resolved_entity_id,
                )
                .filter(SyncQueue.status.in_(["pending", "failed"]))
                .order_by(SyncQueue.updated_at.desc())
                .first()
            )

        if queue_item is None:
            try:
                with db.session.begin_nested():
                    queue_item = SyncQueue(
                        operation_id=operation_id or str(uuid.uuid4()),
                        school_id=school_id,
                        device_id=resolved_device_id,
                        entity_type=entity_type,
                        entity_id=resolved_entity_id,
                        operation=operation,
                        status="pending",
                        record_updated_at=self._parse_datetime(record_updated_at) or utc_now(),
                    )
                    db.session.add(queue_item)
                    queue_item.set_payload(payload)
                    db.session.flush()
            except Exception:
                # If there is a concurrency constraint violation (IntegrityError), we can retrieve it again
                queue_item = (
                    SyncQueue.query.filter_by(
                        school_id=school_id,
                        entity_type=entity_type,
                        entity_id=resolved_entity_id,
                    )
                    .filter(SyncQueue.status.in_(["pending", "failed"]))
                    .order_by(SyncQueue.updated_at.desc())
                    .first()
                )
                if queue_item:
                    queue_item.school_id = school_id
                    queue_item.device_id = resolved_device_id
                    queue_item.operation = operation
                    queue_item.status = "pending"
                    queue_item.record_updated_at = self._parse_datetime(record_updated_at) or utc_now()
                    queue_item.next_retry_at = None
                    queue_item.last_error = None
                    queue_item.updated_at = utc_now()
                    queue_item.set_payload(payload)
        else:
            queue_item.school_id = school_id
            queue_item.device_id = resolved_device_id
            queue_item.operation = operation
            queue_item.status = "pending"
            queue_item.record_updated_at = self._parse_datetime(record_updated_at) or utc_now()
            queue_item.next_retry_at = None
            queue_item.last_error = None
            queue_item.updated_at = utc_now()
            queue_item.set_payload(payload)

        return queue_item

    def serialize_record(self, entity_type, record):
        if entity_type not in self.ENTITY_CONFIG:
            raise KeyError(f"Unsupported entity type: {entity_type}")

        data = {}
        config = self.ENTITY_CONFIG[entity_type]
        exclude_columns = config.get("exclude_columns", [])
        
        for attr in record.__mapper__.column_attrs:
            column = attr.columns[0]
            if column.name in exclude_columns:
                continue
            value = getattr(record, attr.key)
            data[column.name] = self._serialize_value(value)
        return data




    def upload_pending_changes(self, school_id=None, limit=None):
        import time
        from collections import defaultdict

        start_time = time.time()
        metadata = self.get_metadata(school_id=school_id)
        target_school_id = self._resolve_target_school_id(school_id, metadata)
        if not target_school_id or not self.school_allows_online_sync(target_school_id):
            return {"uploaded": 0, "failed": 0, "conflicts": 0, "skipped": 0, "duration_seconds": 0.0, "message": "Online sync is not enabled for this school."}

        batch_size = max(1, min(1000, int(limit or current_app.config.get("SYNC_BATCH_SIZE", 1000)) or 1000))
        summary = {"uploaded": 0, "failed": 0, "conflicts": 0, "skipped": 0, "duration_seconds": 0.0, "message": "Upload completed"}

        if not self.is_configured():
            if metadata:
                metadata.last_error = "Supabase is not configured."
                safe_commit()
            summary["message"] = "Supabase is not configured."
            return summary

        lock = self._get_sync_lock()
        lock.acquire()
        self._set_sync_state(True, "upload", "Uploading queued changes to Supabase", summary)

        try:
            now = utc_now()
            while True:
                pending_items = (
                    SyncQueue.query.filter(SyncQueue.school_id == target_school_id)
                    .filter(SyncQueue.status.in_(["pending", "failed"]))
                    .filter(
                        (SyncQueue.next_retry_at.is_(None))
                        | (SyncQueue.next_retry_at <= now)
                    )
                    .order_by(SyncQueue.created_at.asc())
                    .limit(batch_size)
                    .all()
                )

                if not pending_items:
                    break

                # Dependency-based ordering: schools -> librarians -> books -> everything else -> logs
                order = ["schools", "librarians", "members", "books", "checkouts", "staff_checkouts", "class_checkouts", "book_issues", "notes", "logs"]
                items_by_type = defaultdict(list)
                for item in pending_items:
                    items_by_type[item.entity_type].append(item)

                sorted_types = sorted(items_by_type.keys(), key=lambda t: order.index(t) if t in order else 99)

                for entity_type in sorted_types:
                    items = items_by_type[entity_type]
                    config = self.ENTITY_CONFIG.get(entity_type)
                    if not config:
                        continue

                    payloads = []
                    for item in items:
                        payload = item.get_payload()
                        exclude_columns = config.get("exclude_columns", [])
                        for col in exclude_columns:
                            payload.pop(col, None)

                        remote_school_col = self._remote_school_column(entity_type)
                        if remote_school_col:
                            payload.setdefault(remote_school_col, item.school_id)
                        elif not self._supports_sync_status(entity_type):
                            payload.pop("school_id", None)

                        if self._supports_sync_status(entity_type):
                            payload.setdefault("sync_status", "pending")
                        else:
                            payload.pop("sync_status", None)

                        if entity_type == "librarians":
                            payload = {
                                "id": payload.get("id"),
                                "school_id": payload.get("school_id"),
                                "username": payload.get("username"),
                                "password": payload.get("password"),
                                "role": payload.get("role", "librarian"),
                                "updated_at": payload.get("updated_at"),
                                "deleted": payload.get("deleted", False),
                                "sync_status": payload.get("sync_status", "pending"),
                            }

                        payload = self._sanitize_remote_payload(entity_type, payload)
                        payloads.append((item, payload))

                    remote_records_map = {}
                    try:
                        pk_col = config["pk"]
                        entity_ids = [str(item.entity_id) for item in items]
                        query = self._table_client(config["table"], schema=config.get("schema")).select("*")
                        if "composite_key" in config:
                            school_col = "school_id"
                            if school_col in config["composite_key"]:
                                query = query.eq(school_col, target_school_id)
                                query = query.in_(pk_col, entity_ids)
                        else:
                            school_column = self._remote_school_column(entity_type)
                            if school_column:
                                query = query.eq(school_column, target_school_id)
                            query = query.in_(pk_col, entity_ids)

                        response = query.execute()
                        remote_data = getattr(response, "data", None) or []
                        for rec in remote_data:
                            remote_records_map[str(rec.get(pk_col))] = rec
                    except Exception as e:
                        self._log_supabase_debug(f"Failed to fetch remote records for batch conflict check: {e}")

                    records_to_upsert = []
                    items_to_upsert = []

                    for item, payload in payloads:
                        remote_record = remote_records_map.get(str(item.entity_id))
                        local_updated_at = self._parse_datetime(payload.get("updated_at") or item.record_updated_at)
                        remote_updated_at = self._parse_datetime(remote_record.get("updated_at") if remote_record else None)

                        if remote_record and self._payloads_differ(payload, remote_record):
                            winner = self._pick_winner(local_updated_at, remote_updated_at)
                            self._store_conflict(
                                item.school_id,
                                item.entity_type,
                                item.entity_id,
                                payload,
                                remote_record,
                                local_updated_at,
                                remote_updated_at,
                                winner,
                            )
                            if winner == "remote":
                                self._apply_remote_record(item.entity_type, remote_record, force=True)
                                item.status = "conflict"
                                item.processed_at = utc_now()
                                item.last_error = "Remote version newer; local change preserved in sync_conflicts."
                                summary["conflicts"] += 1
                                continue

                        if self._supports_sync_status(entity_type):
                            payload["sync_status"] = "synced"

                        records_to_upsert.append(payload)
                        items_to_upsert.append((item, payload))

                    if records_to_upsert:
                        try:
                            self._log_supabase_debug(f"Batch upserting {len(records_to_upsert)} records to {config['table']}")
                            self._table_client(config["table"], schema=config.get("schema")).upsert(
                                records_to_upsert,
                                on_conflict=config["on_conflict"],
                            ).execute()

                            for item, payload in items_to_upsert:
                                self._mark_local_synced(item.entity_type, payload)
                                item.status = "synced"
                                item.last_error = None
                                item.processed_at = utc_now()
                                item.updated_at = utc_now()
                                summary["uploaded"] += 1
                                summary["message"] = f"Uploaded {summary['uploaded']} records so far"
                                self._set_sync_state(True, "upload", summary["message"], summary)
                        except Exception as exc:
                            error_str = str(exc).lower()
                            is_structural = "could not find" in error_str or "pgrst" in error_str
                            if is_structural:
                                self._log_supabase_debug(f"Batch upsert failed due to structural error for {entity_type}: {exc}. Aborting sync for this batch.")
                                for item, payload in items_to_upsert:
                                    item.status = "failed"
                                    item.attempt_count = (item.attempt_count or 0) + 1
                                    item.last_error = f"Structural error: {str(exc)}"
                                    item.next_retry_at = utc_now() + timedelta(seconds=self._retry_delay_seconds(item.attempt_count))
                                    item.updated_at = utc_now()
                                    summary["failed"] += 1
                                    try:
                                        with db.session.begin_nested():
                                            db.session.flush()
                                    except Exception:
                                        pass
                                continue

                            self._log_supabase_debug(f"Batch upsert failed for {entity_type}: {exc}. Falling back to individual processing (max 50).")
                            for idx, (item, payload) in enumerate(items_to_upsert):
                                if idx >= 50:
                                    # Hard limit to avoid N+1 spam
                                    item.status = "failed"
                                    item.attempt_count = (item.attempt_count or 0) + 1
                                    item.last_error = "Skipped during fallback to avoid API spam"
                                    item.next_retry_at = utc_now() + timedelta(seconds=self._retry_delay_seconds(item.attempt_count))
                                    item.updated_at = utc_now()
                                    summary["failed"] += 1
                                    try:
                                        with db.session.begin_nested():
                                            db.session.flush()
                                    except Exception:
                                        pass
                                    continue

                                try:
                                    self._table_client(config["table"], schema=config.get("schema")).upsert(
                                        payload, on_conflict=config["on_conflict"]
                                    ).execute()
                                    self._mark_local_synced(item.entity_type, payload)
                                    item.status = "synced"
                                    item.last_error = None
                                    item.processed_at = utc_now()
                                    item.updated_at = utc_now()
                                    summary["uploaded"] += 1
                                    summary["message"] = f"Uploaded {summary['uploaded']} records so far"
                                    self._set_sync_state(True, "upload", summary["message"], summary)
                                except Exception as sub_exc:
                                    error_message = str(sub_exc)
                                    if self._is_transient_error(sub_exc):
                                        error_message = f"Transient sync error: {error_message}"
                                    item.status = "failed"
                                    item.attempt_count = (item.attempt_count or 0) + 1
                                    item.last_error = error_message
                                    item.next_retry_at = utc_now() + timedelta(seconds=self._retry_delay_seconds(item.attempt_count))
                                    item.updated_at = utc_now()
                                    summary["failed"] += 1

                                    # Use nested transaction to save state for THIS row failure and keep others
                                    try:
                                        with db.session.begin_nested():
                                            db.session.flush()
                                    except Exception:
                                        pass

                    metadata.last_upload_at = utc_now()
                    metadata.last_synced_at = utc_now()
                    metadata.last_error = None
                    safe_commit()

                    summary["message"] = f"Uploaded {summary['uploaded']} records so far"
                    self._set_sync_state(True, "upload", summary["message"], summary)

            self._refresh_pending_count(target_school_id)

            duration = time.time() - start_time
            summary["duration_seconds"] = round(duration, 2)
            summary["message"] = f"Uploaded {summary['uploaded']} records in {duration:.2f}s"
            return summary

        finally:
            self._set_sync_state(False, "idle", "Idle", summary)
            lock.release()




    def download_remote_changes(self, school_id=None, limit=250, force_initial=False):
        metadata = self.get_metadata(school_id=school_id)
        target_school_id = self._resolve_target_school_id(school_id, metadata)
        if not target_school_id or (not force_initial and not self.school_allows_online_sync(target_school_id)):
            return {"downloaded": 0, "conflicts": 0, "duration_seconds": 0.0, "message": "Online sync is not enabled for this school."}

        summary = {"downloaded": 0, "conflicts": 0, "duration_seconds": 0.0, "message": "Download completed"}

        if not self.is_configured():
            if metadata:
                metadata.last_error = "Supabase is not configured."
                safe_commit()
            return summary

        lock = self._get_sync_lock()
        lock.acquire()
        self._set_sync_state(True, "download", "Downloading changes from Supabase", summary)
        try:
            start_time = utc_now()
            since = metadata.last_download_at
            max_downloaded_at = since

            for entity_type in self.ENTITY_CONFIG:
                if not self._downloads_enabled(entity_type):
                    # Force download school record during initial sync to ensure subsequent syncs work
                    if entity_type == "schools" and force_initial:
                        pass # Allow downloading schools
                    else:
                        continue

                entity_since = since
                while True:
                    if entity_type == "schools":
                        rows = self._download_school_rows(school_id=target_school_id, limit=limit)
                    else:
                        rows = self._download_entity_rows(
                            entity_type,
                            target_school_id,
                            since=entity_since,
                            limit=limit,
                        )

                    if not rows:
                        break

                    for row in rows:
                        result = self._apply_remote_record(entity_type, row)
                        summary["downloaded"] += int(result["applied"])
                        summary["conflicts"] += int(result["conflict"])
                        summary["message"] = f"Downloaded {summary['downloaded']} records so far"
                        self._set_sync_state(True, "download", summary["message"], summary)

                        row_updated_at = self._parse_datetime(row.get("updated_at"))
                        if row_updated_at:
                            if max_downloaded_at is None or row_updated_at > max_downloaded_at:
                                max_downloaded_at = row_updated_at
                            if entity_since is None or row_updated_at > entity_since:
                                entity_since = row_updated_at

                    if len(rows) < limit:
                        break

                    if entity_type == "schools":
                        break

            if max_downloaded_at:
                metadata.last_download_at = max_downloaded_at
            metadata.last_synced_at = utc_now()
            metadata.last_error = None
            safe_commit()
            summary["duration_seconds"] = round((utc_now() - start_time).total_seconds(), 2)
            summary["message"] = f"Downloaded {summary['downloaded']} records in {summary['duration_seconds']:.2f}s"
            return summary
        finally:
            self._set_sync_state(False, "idle", "Idle", summary)
            lock.release()

    def resolve_conflict(self, conflict_id, resolution, merged_payload=None):
        conflict = SyncConflict.query.get_or_404(conflict_id)
        local_payload = conflict.get_local_payload()
        remote_payload = conflict.get_remote_payload()

        if resolution == "local":
            winner_payload = local_payload
        elif resolution == "remote":
            winner_payload = remote_payload
        elif resolution == "merged":
            winner_payload = merged_payload or {}
        else:
            raise ValueError("Resolution must be local, remote, or merged.")

        school_column = self._remote_school_column(conflict.entity_type)
        if school_column:
            winner_payload.setdefault(school_column, conflict.school_id)
        elif not self._supports_sync_status(conflict.entity_type):
            winner_payload.pop("school_id", None)

        if self._supports_sync_status(conflict.entity_type):
            winner_payload["sync_status"] = "synced"
        else:
            winner_payload.pop("sync_status", None)

        self._apply_remote_record(conflict.entity_type, winner_payload, force=True)
        if self.is_configured():
            self._upsert_remote(conflict.entity_type, winner_payload)

        conflict.resolution = resolution
        conflict.resolved_at = utc_now()
        conflict.set_versions(local_payload, remote_payload, winner_payload)
        safe_commit()
        
        # Log the conflict resolution
        try:
            from .routes import log_action
            log_action(
                "/api/sync/conflicts/resolve",
                "RESOLVE_SYNC_CONFLICT",
                f"Resolved sync conflict for {conflict.entity_type} (ID: {conflict.entity_id}) using '{resolution}' resolution",
                status_code=200
            )
        except Exception:
            pass  # Don't fail the resolution if logging fails
        
        return {
            "id": conflict.id,
            "resolution": resolution,
            "entity_type": conflict.entity_type,
            "entity_id": conflict.entity_id,
        }

    def get_status(self, school_id=None):
        metadata = self.get_metadata(school_id=school_id)
        target_school_id = self._resolve_target_school_id(school_id, metadata)
        pending_count = self._refresh_pending_count(target_school_id) if target_school_id else 0
        cloud_reachable = self.ping_remote()
        conflicts = []
        if target_school_id:
            conflicts = (
                SyncConflict.query.filter_by(school_id=target_school_id, resolution="pending")
                .order_by(SyncConflict.created_at.desc())
                .limit(20)
                .all()
            )
        sync_state = current_app.config.get("_sync_state", {})
        # We need to know download pending counts too. This would check the remote_sync_ledger for unseen records.
        # But for performance we may just rely on what upload_pending_changes/download return in last_sync_summary.

        # Check newly received data. We can track if last_sync_summary downloaded > 0.
        new_data = False
        summary = sync_state.get("summary", {})
        if summary.get("downloaded", 0) > 0:
            new_data = True

        return {
            "configured": self.is_configured(),
            "cloud_reachable": cloud_reachable,
            "device_id": metadata.device_id if metadata else current_app.config.get("DEVICE_ID", "desktop-device"),
            "school_id": target_school_id,
            "pending_count": pending_count,
            "syncing": bool(sync_state.get("active")),
            "sync_operation": sync_state.get("operation", "idle"),
            "sync_message": sync_state.get("message", "Idle"),
            "last_sync_summary": sync_state.get("summary", {}),
            "new_data_received": new_data,
            "last_upload_at": self._serialize_value(metadata.last_upload_at) if metadata else None,
            "last_download_at": self._serialize_value(metadata.last_download_at) if metadata else None,
            "last_synced_at": self._serialize_value(metadata.last_synced_at) if metadata else None,
            "last_error": metadata.last_error if metadata else None,
            "conflicts": [
                {
                    "id": conflict.id,
                    "entity_type": conflict.entity_type,
                    "entity_id": conflict.entity_id,
                    "local": conflict.get_local_payload(),
                    "remote": conflict.get_remote_payload(),
                    "created_at": self._serialize_value(conflict.created_at),
                }
                for conflict in conflicts
            ],
        }

    def get_metadata(self, school_id=None):
        device_id = current_app.config.get("DEVICE_ID", "desktop-device")
        metadata = SyncMetadata.query.filter_by(device_id=device_id).first()

        if metadata:
            # Update school_id if it was None and we now have a valid school
            if metadata.school_id is None and school_id:
                metadata.school_id = school_id
                safe_commit()
            return metadata

        # Only create metadata if we have a valid school_id
        if school_id:
            metadata = SyncMetadata(
                device_id=device_id,
                school_id=school_id,
                pending_operations=0,
            )
            db.session.add(metadata)
            safe_commit()
            return metadata

        return None

    def _download_school_rows(self, school_id=None, limit=250):
        if not self.is_configured():
            return []
        query = self._table_client("schools", schema=self.DEFAULT_REMOTE_SCHEMA).select("*")
        if school_id is not None:
            query = query.eq("id", school_id)
        response = query.limit(limit).execute()
        return getattr(response, "data", None) or []

    def ping_remote(self):
        if not self.is_configured():
            return False
        try:
            self._table_client("schools", schema=self.DEFAULT_REMOTE_SCHEMA).select("id").limit(1).execute()
            return True
        except Exception:
            return False

    def _download_entity_rows(self, entity_type, school_id, since=None, limit=250):
        config = self.ENTITY_CONFIG[entity_type]
        school_column = self._remote_school_column(entity_type)
        query = (
            self._table_client(config["table"], schema=config.get("schema"))
            .select("*")
            .order("updated_at", desc=False)
            .limit(limit)
        )
        if school_column and school_id is not None:
            query = query.eq(school_column, school_id)
        if since:
            query = query.gte("updated_at", self._serialize_value(since))
        response = query.execute()
        return getattr(response, "data", None) or []

    def _fetch_remote_record(self, entity_type, school_id, entity_id):
        config = self.ENTITY_CONFIG[entity_type]
        query = self._table_client(config["table"], schema=config.get("schema")).select("*")
        
        if "composite_key" in config:  # For books that need school_id + book_id check
            for key in config["composite_key"]:
                query = query.eq(key, school_id if key == "school_id" else entity_id)
        else:  # For other entities
            school_column = self._remote_school_column(entity_type)
            if school_column and school_id is not None:
                query = query.eq(school_column, school_id)
            query = query.eq(config["pk"], entity_id)
            
        response = query.limit(1).execute()
        data = getattr(response, "data", None) or []
        return data[0] if data else None

    def _upsert_remote(self, entity_type, payload):
        config = self.ENTITY_CONFIG[entity_type]
        
        safe_payload = dict(payload)

        if entity_type == "librarians":
            safe_payload = {
                "id": safe_payload.get("id"),
                "school_id": safe_payload.get("school_id"),
                "username": safe_payload.get("username"),
                "password": safe_payload.get("password"),
                "role": safe_payload.get("role", "librarian"),
                "updated_at": safe_payload.get("updated_at"),
                "deleted": safe_payload.get("deleted", False),
                "sync_status": safe_payload.get("sync_status", "pending"),
            }

        if not self._remote_school_column(entity_type):
            safe_payload.pop("school_id", None)
        if not self._supports_sync_status(entity_type):
            safe_payload.pop("sync_status", None)

        safe_payload = self._sanitize_remote_payload(entity_type, safe_payload)

        should_log = entity_type in {"schools", "librarians"}
        if should_log:
            self._log_supabase_debug(
                f"[SyncService] Connecting to Supabase... schema={self._entity_schema(entity_type)} "
                f"table={config['table']} entity={entity_type}"
            )
        if entity_type == "logs":
            print("LOG DATA SENT:", safe_payload)
        elif should_log:
            self._log_supabase_debug(f"[SyncService] Sending data... {safe_payload}")

        response = self._table_client(config["table"], schema=config.get("schema")).upsert(
            safe_payload,
            on_conflict=config["on_conflict"],
        ).execute()

        if response is None:
            raise RuntimeError(f"Supabase upsert returned no response for {entity_type}.")

        if should_log:
            self._log_supabase_debug(f"[SyncService] Response received: {response}")
        return response

    def _mark_local_synced(self, entity_type, payload):
        record = self._fetch_local_record(entity_type, payload)
        if record:
            if hasattr(record, "sync_status"):
                record.sync_status = "synced"
            if hasattr(record, "updated_at"):
                record.updated_at = self._parse_datetime(payload.get("updated_at")) or utc_now()

    def _fetch_local_record(self, entity_type, payload):
        config = self.ENTITY_CONFIG[entity_type]
        model = config["model"]
        query = model.query
        
        if "composite_key" in config:  # For books that need school_id + book_id check
            for key in config["composite_key"]:
                query = query.filter_by(**{key: payload.get(key)})
        else:  # For other entities
            pk = config["pk"]
            query = query.filter_by(**{pk: payload.get(pk)})
            if hasattr(model, "school_id") and "school_id" in payload:
                query = query.filter_by(school_id=payload["school_id"])
                
        return query.first()

    def _apply_remote_record(self, entity_type, payload, force=False, source="cloud"):
        config = self.ENTITY_CONFIG[entity_type]
        model = config["model"]
        local_record = self._fetch_local_record(entity_type, payload)
        remote_updated_at = self._parse_datetime(payload.get("updated_at"))

        if local_record:
            local_payload = self.serialize_record(entity_type, local_record)
            local_updated_at = self._parse_datetime(local_payload.get("updated_at"))
            
            # INTELLIGENT AUTO-MERGE: Check if there is a collision
            if (
                not force
                and getattr(local_record, "sync_status", None) == "pending"
                and self._payloads_differ(local_payload, payload)
            ):
                # 1. Automatically pick the winner based on the most recent timestamp
                winner = self._pick_winner(local_updated_at, remote_updated_at)
                
                # 2. Log to the correct conflict table based on the source
                if source == "lan":
                    from .database import PeerSyncConflict
                    conflict = PeerSyncConflict(
                        school_id=payload.get("school_id"),
                        entity_type=entity_type,
                        entity_id=str(payload.get(config["pk"])),
                        local_updated_at=local_updated_at,
                        remote_updated_at=remote_updated_at,
                        resolution=winner,
                        resolved_at=utc_now()
                    )
                else:
                    conflict = SyncConflict(
                        school_id=payload.get("school_id"),
                        entity_type=entity_type,
                        entity_id=str(payload.get(config["pk"])),
                        local_updated_at=local_updated_at,
                        remote_updated_at=remote_updated_at,
                        resolution=winner,
                        resolved_at=utc_now()
                    )
                    
                conflict.set_versions(local_payload, payload)
                db.session.add(conflict)

                # 3. Apply the decision
                if winner == "local":
                    return {"applied": False, "conflict": False}

            # Apply the remote record
            for attr_key, value in self._payload_to_kwargs(model, payload).items():
                setattr(local_record, attr_key, value)
            if hasattr(local_record, "sync_status"):
                local_record.sync_status = "synced"
            return {"applied": True, "conflict": False}

        if payload.get("deleted"):
            return {"applied": False, "conflict": False}

        record = model(**self._payload_to_kwargs(model, payload))
        if hasattr(record, "sync_status"):
            record.sync_status = "synced"
        db.session.add(record)
        return {"applied": True, "conflict": False}

    def _payload_to_kwargs(self, model, payload):
        kwargs = {}
        for attr in model.__mapper__.column_attrs:
            column = attr.columns[0]
            if column.name not in payload:
                continue
            kwargs[attr.key] = self._deserialize_value(attr.key, payload[column.name])
        return kwargs

    def _store_conflict(
        self,
        school_id,
        entity_type,
        entity_id,
        local_payload,
        remote_payload,
        local_updated_at,
        remote_updated_at,
        winner,
    ):
        conflict = SyncConflict(
            school_id=school_id,
            entity_type=entity_type,
            entity_id=str(entity_id),
            local_updated_at=local_updated_at,
            remote_updated_at=remote_updated_at,
            resolution="pending",
        )
        conflict.set_versions(local_payload, remote_payload)
        db.session.add(conflict)

        # FIX: local_payload is a dict — use key check, not hasattr()
        if winner == "local" and "sync_status" in local_payload:
            local_payload["sync_status"] = "pending"

    def _refresh_pending_count(self, school_id):
        '''PERFORMANCE / CONCURRENCY FIX: this used to write to sync_metadata (pending_operations + updated_at) on almost every call. Since this
        is called from get_status(), which backs the /api/sync/status endpoint the browser polls frequently, that meant a routine
        read-only status check was taking a write lock on the SQLitedatabase. Under real usage (e.g. adding several books, which
        queues sync rows per book) that write collided with the actual work's own writes, and each side would block for the full
        configured busy-timeout (60s) waiting for the lock — this is what was causing multi-minute stalls when adding a batch of books.
        `pending_operations` is not read anywhere else in the app (the live count below is what's actually returned to callers), so
        there's nothing lost by making this a pure read.'''
        
        pending_count = (
            SyncQueue.query.filter(SyncQueue.school_id == school_id)
            .filter(SyncQueue.status.in_(["pending", "failed"]))
            .count()
        )
        return pending_count

    def _default_school_id(self):
        return None

    def _pick_winner(self, local_updated_at, remote_updated_at):
        if remote_updated_at and local_updated_at and remote_updated_at > local_updated_at:
            return "remote"
        return "local"

    def _payloads_differ(self, local_payload, remote_payload):
        return json.dumps(local_payload, sort_keys=True, default=str) != json.dumps(
            remote_payload,
            sort_keys=True,
            default=str,
        )

    def _serialize_value(self, value):
        if isinstance(value, datetime):
            return value.isoformat()
        return value

    def _deserialize_value(self, attr_key, value):
        if value is None:
            return None
        if attr_key.endswith("_at") or attr_key in {"updated_at", "last_seen_at"}:
            parsed = self._parse_datetime(value)
            return parsed or value
        return value

    def _parse_datetime(self, value):
        if isinstance(value, datetime):
            if value.tzinfo is not None:
                from datetime import timezone
                return value.astimezone(timezone.utc).replace(tzinfo=None)
            return value
        if not value:
            return None
        if isinstance(value, str):
            normalized = value.replace("Z", "+00:00")
            for fmt in (None, "%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
                try:
                    if fmt is None:
                        dt = datetime.fromisoformat(normalized)
                        if dt.tzinfo is not None:
                            from datetime import timezone
                            return dt.astimezone(timezone.utc).replace(tzinfo=None)
                        return dt
                    return datetime.strptime(normalized, fmt)
                except ValueError:
                    continue
        return None
