import os
import sys
import threading
import time
import secrets
from datetime import timedelta
from flask import Flask, redirect, request, url_for, flash
from flask_login import LoginManager, current_user
from sqlalchemy.exc import IntegrityError
from .utils import load_config, DB_PATH, UPLOAD_FOLDER, BACKUP_DIR, safe_commit, migrate_add_online_sync_flag
from .database import db, Admin, School
from .sync_service import SyncService

try:
    from flask_cors import CORS
except ImportError:
    CORS = None

login_manager = LoginManager()

# --- PYINSTALLER PATH FIX ---
def get_resource_path():
    """Get absolute path to resource; prefers live-updated install folder over _MEIPASS."""
    if getattr(sys, 'frozen', False):
        exe_dir = os.path.dirname(sys.executable)
        if os.path.isdir(os.path.join(exe_dir, 'app', 'templates')):
            return exe_dir
        return getattr(sys, '_MEIPASS', exe_dir)
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

WIZARD_SHOWN = False
_AUTO_BACKUP_THREAD_STARTED = False


def ensure_default_admin(app, default_school=None):
    """Create a deterministic fallback admin only when none exists yet."""
    existing_admin = Admin.query.filter_by(username='admin').first()
    if existing_admin:
        return existing_admin
    existing_admin = Admin.query.filter(Admin.deleted == False).order_by(Admin.id.asc()).first()
    if existing_admin:
        return existing_admin

    try:
        from .utils import hash_pw
        admin_user = Admin(
            username='admin',
            password=hash_pw('admin123'),
            role='admin',
            school_id=default_school.id if default_school else None,
            sync_status='synced'
        )
        db.session.add(admin_user)
        safe_commit()
        app.logger.warning("DEFAULT ADMIN CREATED - Username: admin, Password: admin123")
        return admin_user
    except IntegrityError:
        db.session.rollback()
        existing_admin = Admin.query.filter(Admin.username == 'admin').first()
        if existing_admin:
            return existing_admin
        raise


def _start_auto_backup_worker(app):
    global _AUTO_BACKUP_THREAD_STARTED
    if _AUTO_BACKUP_THREAD_STARTED or app.config.get("TESTING"):
        return
    _AUTO_BACKUP_THREAD_STARTED = True

    def worker():
        while True:
            try:
                with app.app_context():
                    from .utils import create_auto_backup_if_due
                    create_auto_backup_if_due()
            except Exception:
                app.logger.exception("Auto-backup check failed.")
            time.sleep(300)

    threading.Thread(target=worker, name="library-auto-backup", daemon=True).start()

def create_app(test_config=None):
    # Tell Flask exactly where templates are when frozen in an .exe
    base_path = get_resource_path()
    template_dir = os.path.join(base_path, 'app', 'templates')
    static_dir = os.path.join(base_path, 'app', 'static')

    app = Flask(__name__, template_folder=template_dir, static_folder=static_dir)

    # 1. Config (Added ?timeout=60 to prevent locking)
    system_config = load_config()
    database_url = system_config.get('database_url') or os.getenv('DATABASE_URL') or f'sqlite:///{DB_PATH}?timeout=60'

    # SECURITY: Generate strong secret key if not configured
    secret_key = os.getenv('FLASK_SECRET_KEY') or system_config.get('secret_key')
    if not secret_key or secret_key in ('strong_random_secret_key', 'dev-secret', ''):
        secret_key = secrets.token_urlsafe(32)
        if not app.config.get("TESTING"):
            app.logger.warning("Generated new SECRET_KEY - set FLASK_SECRET_KEY in production!")
    app.secret_key = secret_key
    app.config['SECRET_KEY'] = app.secret_key

    app.config['SQLALCHEMY_DATABASE_URI'] = database_url
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    # Optimize SQLAlchemy pooling for concurrent requests and batch writes
    if database_url.startswith("sqlite"):
        app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
            'pool_pre_ping': True,
        }
    else:
        app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
            'pool_size': 20,
            'max_overflow': 40,
            'pool_timeout': 60,
            'pool_pre_ping': True,
            'pool_recycle': 1800,
        }

    app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
    app.config['DEFAULT_BORROW_DAYS'] = system_config.get('default_borrow_days', 14)
    app.config['SUPABASE_URL'] = system_config.get('supabase_url', '')
    app.config['SUPABASE_KEY'] = system_config.get('supabase_service_role_key') or system_config.get('supabase_key', '')
    app.config['SUPABASE_ANON_KEY'] = system_config.get('supabase_key', '')

    # SECURITY: Require MASTER_KEY to be explicitly set, no empty default
    master_key = os.getenv('MASTER_KEY') or system_config.get('master_key')
    if not master_key:
        app.logger.warning("No MASTER_KEY set in environment or config. Master login disabled.")
    app.config['MASTER_KEY'] = master_key
    
    app.config['DEVICE_ID'] = system_config.get('device_id', 'desktop-device')
    app.config['SYNC_BATCH_SIZE'] = system_config.get('sync_batch_size', 100)
    app.config['SYNC_MIN_INTERVAL_SECONDS'] = system_config.get('sync_min_interval_seconds', 20)
    app.config['SYNC_POLL_INTERVAL_SECONDS'] = system_config.get('sync_poll_interval_seconds', 60)
    app.config['SYNC_RETRY_MAX_SECONDS'] = system_config.get('sync_retry_max_seconds', 300)

    # SECURITY: Configure secure session cookies
    is_electron = os.environ.get('ELECTRON_APP') == '1'
    is_production = not app.debug and not app.testing
    app.config.update(
        SESSION_COOKIE_SECURE=is_production and not is_electron,  # False for Electron (localhost HTTP)
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax" if is_electron else "Strict",
        SESSION_COOKIE_NAME='library_session',
        PERMANENT_SESSION_LIFETIME=timedelta(hours=8),  # 8 hours
        SESSION_REFRESH_EACH_REQUEST=True,
    )
    if test_config:
        app.config.update(test_config)

    # Ensure dirs exist
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
    os.makedirs(BACKUP_DIR, exist_ok=True)

    # 2. Init Extensions
    db.init_app(app)
    login_manager.init_app(app)
    login_manager.login_message_category = 'warning'
    
    # SECURITY: Configure restricted CORS
    if CORS:
        allowed_origins = []
        if is_electron:
            allowed_origins.extend(['http://localhost:5000', 'http://127.0.0.1:5000'])
        cors_origins = os.environ.get('CORS_ORIGINS', '')
        if cors_origins:
            allowed_origins.extend([o.strip() for o in cors_origins.split(',')])
        
        CORS(app, 
             origins=allowed_origins,
             supports_credentials=True,
             allow_headers=['Content-Type', 'Authorization', 'X-Requested-With'],
             methods=['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
             max_age=3600)
    
    SyncService(app)

    @login_manager.user_loader
    def load_user(user_id):
        return db.session.get(Admin,(user_id))

    # 3. Register Blueprints
    from .routes import main as main_blueprint
    from .auth import auth as auth_blueprint, login as auth_login

    app.register_blueprint(main_blueprint)
    app.register_blueprint(auth_blueprint, url_prefix='/auth')
    app.add_url_rule('/login', endpoint='login_alias', view_func=auth_login, methods=['GET', 'POST'])
    login_manager.login_view = 'login_alias'

    @app.before_request
    def validate_session_status():
        if app.config.get("TESTING"):
            return
            
        request_path = request.path or '/'
        if request_path.startswith('/static') or request_path.startswith('/welcome'):
            return
            
        if current_user.is_authenticated:
            # Check if admin is deleted
            if current_user.deleted:
                from flask_login import logout_user
                logout_user()
                flash("Your account has been deleted.", "danger")
                return redirect(url_for('auth.login'))
                
            # Check school status
            if current_user.school_id:
                from .database import School
                school = db.session.get(School, current_user.school_id)
                if school:
                    if school.deleted:
                        from flask_login import logout_user
                        logout_user()
                        flash("Your school account has been disabled.", "danger")
                        return redirect(url_for('auth.login'))
                        
                    from .auth import school_can_login
                    if not school_can_login(school.status):
                        from flask_login import logout_user
                        logout_user()
                        flash(f"School '{school.school_name}' is not approved for login.", "danger")
                        return redirect(url_for('auth.login'))

    @app.before_request
    def require_role_setup():
        if app.config.get("TESTING"):
            return

        exempt = {'main.role_wizard', 'main.role_wizard_save', 'static', 'auth.login', 'login_alias'}
        request_path = request.path or '/'

        # Allow the standalone welcome site, login, and API paths without forcing role setup
        if request_path.startswith('/welcome') or request_path.startswith('/static') or request_path.startswith('/api'):
            return
        if request_path in ('/login', '/auth/login') or request_path.startswith('/auth/'):
            return
        if request.endpoint in exempt:
            return

        # Guests should be allowed to reach the landing page or the login screen.
        if not current_user.is_authenticated:
            return

        cfg = load_config()
        from . import utils
        if not cfg.get("role") or (cfg.get("show_wizard_at_startup") and not utils.WIZARD_SHOWN):
            return redirect(url_for('main.role_wizard'))

    # 4. Create Tables and Enable WAL Mode
    with app.app_context():
        # ENABLE WAL MODE to prevent "Database is locked" errors
        if app.config['SQLALCHEMY_DATABASE_URI'].startswith('sqlite:'):
            from sqlalchemy import text
            try:
                db.session.execute(text('PRAGMA journal_mode=WAL;'))
                safe_commit()
            except Exception:
                db.session.rollback()

        db.create_all()

        if app.config['SQLALCHEMY_DATABASE_URI'].startswith('sqlite:'):
            try:
                from .utils import migrate_add_book_category, migrate_add_note_title, migrate_recovery_schema, migrate_sync_schema, migrate_add_performance_indexes, migrate_add_custom_fields
                migrate_add_book_category()
                migrate_add_note_title()
                migrate_recovery_schema()
                migrate_sync_schema()
                migrate_add_online_sync_flag()
                migrate_add_performance_indexes()
                migrate_add_custom_fields()
                db.session.remove()
                db.engine.dispose()
            except Exception:
                pass


        # Ensure newer registration columns exist on join_requests for older installs
        try:
            from sqlalchemy import text, inspect
            inspector = inspect(db.engine)
            cols = [c['name'] for c in inspector.get_columns('join_requests')]
            if 'full_name' not in cols:
                db.session.execute(text("ALTER TABLE join_requests ADD COLUMN full_name VARCHAR(255)"))
            if 'email' not in cols:
                db.session.execute(text("ALTER TABLE join_requests ADD COLUMN email VARCHAR(255)"))
            safe_commit()
        except Exception:
            # ignore migration errors; not critical
            db.session.rollback()

    # 5. Add security headers to all responses
    @app.after_request
    def add_security_headers(response):
        # Content Security Policy
        if is_electron:
            # Electron needs more permissive CSP for local resources
            response.headers['Content-Security-Policy'] = (
                "default-src 'self' 'unsafe-inline' 'unsafe-eval' data: blob: "
                "http://localhost:* http://127.0.0.1:*;"
            )
        else:
            response.headers['Content-Security-Policy'] = (
                "default-src 'self'; "
                "script-src 'self' 'unsafe-inline'; "
                "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
                "img-src 'self' data: blob:; "
                "font-src 'self' data: https://fonts.gstatic.com; "
                "connect-src 'self' https://fonts.googleapis.com https://fonts.gstatic.com;"
            )
        
        # Security headers
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'DENY'
        response.headers['X-XSS-Protection'] = '1; mode=block'
        response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
        response.headers['Permissions-Policy'] = 'geolocation=(), microphone=(), camera=()'
        
        # HSTS for production HTTPS
        if is_production and request.is_secure:
            response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
        
        return response

    _start_auto_backup_worker(app)

    return app
