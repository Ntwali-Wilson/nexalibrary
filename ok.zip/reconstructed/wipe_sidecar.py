import os
import sys
import psutil
import requests
import sqlite3
import time

def execute_wipe(supabase_url, supabase_key, school_id):
    # 1. Force-kill the main Flask process
    parent_pid = os.getppid()
    if parent_pid > 1:
        try:
            p = psutil.Process(parent_pid)
            p.kill()
            print(f"Sidecar: Killed parent process {parent_pid}")
        except Exception as e:
            print(f"Sidecar: Failed to kill parent: {e}")

    # 2. Delete the SQLite DB File
    db_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'library.db')
    if os.path.exists(db_path):
        try:
            # Overwrite with random data to prevent simple recovery
            with open(db_path, "wb") as f:
                f.write(os.urandom(os.path.getsize(db_path)))
            os.remove(db_path)
            print("Sidecar: DB file shredded and deleted.")
        except Exception as e:
            print(f"Sidecar: Failed to delete DB file: {e}")

    # 3. Send final API beacon back to Supabase directly
    headers = {
        "apikey": supabase_key,
        "Authorization": f"Bearer {supabase_key}",
        "Content-Type": "application/json"
    }

    url = f"{supabase_url}/rest/v1/security_directives?school_id=eq.{school_id}"
    data = {"status": "executed"}

    try:
        res = requests.patch(url, headers=headers, json=data)
        if res.status_code in [200, 204]:
            print("Sidecar: Successfully reported executed status to Supabase.")
        else:
            print(f"Sidecar: Failed to report status. {res.status_code} {res.text}")
    except Exception as e:
        print(f"Sidecar: Error sending final beacon: {e}")

    print("Sidecar: System wipe protocol complete.")

if __name__ == "__main__":
    time.sleep(2)  # Give run.py a moment to finish launching us

    supabase_url = os.environ.get("SUPABASE_URL")
    supabase_key = os.environ.get("SUPABASE_SERVICE_ROLE_KEY") or os.environ.get("SUPABASE_SERVICE_KEY") or os.environ.get("SUPABASE_KEY")
    school_id = os.environ.get("WIPE_SCHOOL_ID")

    if not supabase_url or not supabase_key or not school_id:
        print("Sidecar: Missing required environment variables. Aborting wipe.")
        sys.exit(1)

    execute_wipe(supabase_url, supabase_key, school_id)