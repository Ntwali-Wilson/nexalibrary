"""
peer_sync.py  —  Unified LAN Sync Engine  (v2 — fixed)
========================================================
Fixes from v1:
  - Minor now uses saved major_ip as fallback when UDP broadcast fails
  - Eliminated recv/send deadlock: Major PUSHES first every cycle
  - Full-state bundled inside auth_ok (one round trip on connect)
  - TCP probe confirms Major is reachable before spending time on auth
"""

import socket
import threading
import json
import zlib
import time
import base64
import uuid
import random
import logging
import ssl
import os
from datetime import datetime

logger = logging.getLogger("peer_sync")

TCP_PORT        = 9000
BROADCAST_PORT  = 9001
SERVICE_TAG     = "LibraryPeerSync_v2"
BUFFER_SIZE     = 131072
MAX_PEERS       = 8

class SyncStateManager:
    def __init__(self):
        self._lock = threading.Lock()
        self._state = {
            "role": None, "running": False, "peers": {},
            "pending_count": 0, "conflicts": [], "last_sync": None,
            "major_ip": None, "my_ip": None, "sync_interval": 5, "error": None,
            "session_token": "", "connected": False,
        }

    def set(self, key, value):
        with self._lock:
            self._state[key] = value

    def get(self, key, default=None):
        with self._lock:
            return self._state.get(key, default)

    def update(self, **kwargs):
        with self._lock:
            self._state.update(kwargs)

    def get_all(self):
        with self._lock:
            return {k: (dict(v) if isinstance(v, dict) else list(v) if isinstance(v, list) else v)
                    for k, v in self._state.items()}

    def append_conflict(self, conflict):
        with self._lock:
            self._state["conflicts"].append(conflict)
            self._state["conflicts"] = self._state["conflicts"][-50:]

    def pop_conflict(self, index):
        with self._lock:
            if 0 <= index < len(self._state["conflicts"]):
                self._state["conflicts"].pop(index)

    def update_peer(self, device_id, **kwargs):
        with self._lock:
            if device_id in self._state["peers"]:
                self._state["peers"][device_id].update(kwargs)

    def add_peer(self, device_id, data):
        with self._lock:
            self._state["peers"][device_id] = data

    def remove_peer(self, device_id):
        with self._lock:
            self._state["peers"].pop(device_id, None)

    def get_peers(self):
        with self._lock:
            return dict(self._state["peers"])

    def get_conflicts_len(self):
        with self._lock:
            return len(self._state["conflicts"])

    def has_peers(self):
        with self._lock:
            return len(self._state["peers"]) > 0

_state_manager = SyncStateManager()
_server_sock = None
_flask_app   = None
_stop_event  = threading.Event()
_retry_event = threading.Event()

# ── Public API ────────────────────────────────────────────────────────────────

def start(role, flask_app, sync_interval=5):
    global _flask_app
    _flask_app = flask_app
    _state_manager.update(role=role, sync_interval=sync_interval, my_ip=_local_ip(), running=True, connected=False)
    _stop_event.clear()
    _retry_event.clear()
    if role == "major":
        threading.Thread(target=_major_server_loop, daemon=True).start()
        threading.Thread(target=_broadcast_loop,    daemon=True).start()
    else:
        try:
            with flask_app.app_context():
                from app.utils import load_config
                cfg = load_config()
                saved = cfg.get("major_ip", "")
                if saved:
                    _state_manager.set("major_ip", saved)
                _state_manager.set("session_token", cfg.get("session_token", ""))
        except Exception as e:
            logger.debug(f"[PEER] Ignored error: {e}")
        threading.Thread(target=_minor_client_loop, daemon=True).start()
    logger.info(f"[PEER] Started as {role.upper()} — {_state_manager.get('my_ip')}")

def stop():
    _stop_event.set()
    _retry_event.set()
    _state_manager.update(running=False, connected=False)
    if _server_sock:
        try: _server_sock.close()
        except Exception as e: logger.debug(f"[PEER] Ignored error: {e}")

def stop_immediately():
    stop()

def get_status():
    status = _state_manager.get_all()
    status["pending_count"] = _pending_count()
    role = status.get("role")
    peers_dict = status.get("peers", {}) or {}
    if role == "major":
        status["connected"] = bool(status.get("running")) and not status.get("error") and (
            len(peers_dict) > 0
        )
        status["lan_peers_count"] = len(peers_dict)
    elif role == "minor":
        status["connected"] = bool(status.get("major_ip")) and not status.get("error")
        status["lan_peers_count"] = 1 if status["connected"] else 0
    else:
        status["connected"] = False
        status["lan_peers_count"] = 0
    status["lan_connected"] = status["connected"]
    return status

def set_sync_interval(seconds):
    _state_manager.set("sync_interval", max(1, int(seconds)))

def dismiss_conflict(index):
    _state_manager.pop_conflict(index)

def disconnect_peer(device_id):
    with _flask_app.app_context():
        from app.database import db, PeerSession
        PeerSession.query.filter_by(device_id=device_id).delete()
        db.session.commit()
    _state_manager.remove_peer(device_id)

def generate_otp():
    return str(random.randint(100000, 999999))

def _wait_or_retry(seconds):
    deadline = time.time() + max(0, seconds)
    while not _stop_event.is_set():
        remaining = deadline - time.time()
        if remaining <= 0:
            return
        if _retry_event.wait(timeout=min(remaining, 0.5)):
            _retry_event.clear()
            return

# ── SSL Certificates ──────────────────────────────────────────────────────────

def _ensure_ssl_certs():
    cert_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "instance")
    os.makedirs(cert_dir, exist_ok=True)
    cert_path = os.path.join(cert_dir, "peer_sync.crt")
    key_path = os.path.join(cert_dir, "peer_sync.key")

    if not os.path.exists(cert_path) or not os.path.exists(key_path):
        try:
            from cryptography import x509
            from cryptography.x509.oid import NameOID
            from cryptography.hazmat.primitives import hashes
            from cryptography.hazmat.primitives.asymmetric import rsa
            from cryptography.hazmat.primitives import serialization
            from datetime import datetime, timedelta, timezone

            key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
            subject = issuer = x509.Name([
                x509.NameAttribute(NameOID.COMMON_NAME, u"localhost")
            ])
            cert = x509.CertificateBuilder().subject_name(
                subject
            ).issuer_name(
                issuer
            ).public_key(
                key.public_key()
            ).serial_number(
                x509.random_serial_number()
            ).not_valid_before(
                datetime.now(timezone.utc)
            ).not_valid_after(
                datetime.now(timezone.utc) + timedelta(days=3650)
            ).sign(key, hashes.SHA256())

            with open(key_path, "wb") as f:
                f.write(key.private_bytes(
                    encoding=serialization.Encoding.PEM,
                    format=serialization.PrivateFormat.TraditionalOpenSSL,
                    encryption_algorithm=serialization.NoEncryption()
                ))
            with open(cert_path, "wb") as f:
                f.write(cert.public_bytes(serialization.Encoding.PEM))
            logger.info("[PEER] Generated self-signed SSL certificates for local sync.")
        except Exception as e:
            logger.error(f"[PEER] Failed to generate SSL certificates: {e}")

    return cert_path, key_path


def _get_ssl_context(role="major"):
    cert_path, key_path = _ensure_ssl_certs()
    if role == "major":
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        try:
            context.load_cert_chain(certfile=cert_path, keyfile=key_path)
        except Exception as e:
            logger.error(f"[PEER] Failed to load cert chain: {e}")
        return context
    else:
        context = ssl.create_default_context()
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
        return context


# ── Network ───────────────────────────────────────────────────────────────────

def _local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]; s.close(); return ip
    except Exception:
        try:
            return socket.gethostbyname(socket.gethostname())
        except Exception:
            return "0.0.0.0"

def _send(sock, payload):
    data = json.dumps(payload, default=str).encode("utf-8")
    compressed = zlib.compress(data, level=6)
    encoded = base64.b64encode(compressed) + b"<END>"
    total = 0
    while total < len(encoded):
        sent = sock.send(encoded[total:])
        if sent == 0: raise RuntimeError("Socket broken")
        total += sent

def _recv(sock, timeout=60):
    sock.settimeout(timeout)
    buf = b""
    try:
        while True:
            chunk = sock.recv(BUFFER_SIZE)
            if not chunk: break
            buf += chunk
            if b"<END>" in buf: break
    except socket.timeout:
        logger.debug(f"[PEER] Socket timeout in recv")
        return None
    except ConnectionResetError as e:
        logger.debug(f"[PEER] Connection reset in recv: {e}")
        return None
    except Exception as e:
        logger.debug(f"[PEER] Ignored error in recv: {e}")
        return None
    if not buf: return None
    try:
        compressed = buf.split(b"<END>")[0]
        try:
            b64_decoded = base64.b64decode(compressed)
            dec = zlib.decompress(b64_decoded).decode("utf-8")
        except Exception:
            try:
                dec = zlib.decompress(compressed).decode("utf-8")
            except zlib.error:
                dec = compressed.decode("utf-8")
        return json.loads(dec)
    except Exception:
        return None

def _tcp_probe(ip, timeout=2):
    if not ip or not str(ip).strip() or ip == "0.0.0.0":
        return False
    try:
        raw_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        raw_sock.settimeout(timeout)
        raw_sock.connect((ip, TCP_PORT))
        raw_sock.close() 
        return True
    except (socket.gaierror, ConnectionRefusedError, socket.timeout):
        # Silently catch unreachable IPs to stop console spam
        return False
    except Exception:
        return False

# ── OTP ───────────────────────────────────────────────────────────────────────

_active_otps = {}
_otp_lock    = threading.Lock()

def create_otp(device_id=None):
    code = generate_otp()
    with _otp_lock:
        _active_otps[code] = {"device_id": device_id, "expires": time.time() + 300}
    return code

def _consume_otp(code):
    with _otp_lock:
        e = _active_otps.get(code)
        if not e or time.time() > e["expires"]:
            _active_otps.pop(code, None); return None
        del _active_otps[code]; return e.get("device_id") or "auto"

def get_active_otps():
    now = time.time()
    with _otp_lock:
        return {k: v for k, v in _active_otps.items() if v["expires"] > now}

# ── Sessions ──────────────────────────────────────────────────────────────────

def _load_session(device_id):
    try:
        with _flask_app.app_context():
            from app.database import PeerSession
            s = PeerSession.query.filter_by(device_id=device_id).first()
            if s and s.trusted: return s.token
    except Exception as e: logger.debug(f"[PEER] Ignored error: {e}")
    return None

def _save_session(device_id, label, token, trusted=True):
    try:
        with _flask_app.app_context():
            from app.database import db, PeerSession
            s = PeerSession.query.filter_by(device_id=device_id).first()
            if s:
                s.token = token; s.label = label; s.trusted = trusted; s.last_seen = _now()
            else:
                db.session.add(PeerSession(device_id=device_id, token=token,
                    label=label, trusted=trusted, last_seen=_now()))
            db.session.commit()
    except Exception as e:
        logger.error(f"[PEER] Session save: {e}")

def _my_device_identity():
    try:
        with _flask_app.app_context():
            from app.utils import load_config, save_config
            cfg = load_config()
            did, tok = cfg.get("device_id",""), cfg.get("session_token","")
            if not did:
                did = "minor_" + uuid.uuid4().hex[:8]
                cfg["device_id"] = did; save_config(cfg)
            return did, tok
    except Exception:
        return "minor_" + uuid.uuid4().hex[:8], ""

def _load_saved_identity():
    try:
        with _flask_app.app_context():
            from app.utils import load_config
            cfg = load_config()
            return cfg.get("device_id", ""), cfg.get("session_token", ""), cfg.get("major_ip", "")
    except Exception:
        return "", "", ""

def _minor_label():
    try:
        with _flask_app.app_context():
            from app.utils import load_config
            return load_config().get("device_label", socket.gethostname())
    except Exception:
        return socket.gethostname()

# ── Delta helpers ─────────────────────────────────────────────────────────────

def _get_pending_deltas():
    try:
        with _flask_app.app_context():
            from app.database import PeerSyncQueue
            rows = PeerSyncQueue.query.filter(PeerSyncQueue.delivered == False, PeerSyncQueue.attempt_count < 15)\
                       .order_by(PeerSyncQueue.timestamp).limit(200).all()
            return [{"change_id":r.change_id,"action":r.action,"table_name":r.table_name,
                     "record_id":r.record_id,"payload":r.payload,
                     "performed_by":r.performed_by,"timestamp":r.timestamp} for r in rows]
    except Exception as e:
        logger.error(f"[PEER] get_pending: {e}"); return []

def _increment_retry_counts(ids):
    if not ids: return
    try:
        with _flask_app.app_context():
            from app.database import db, PeerSyncQueue
            for change_id in ids:
                q = PeerSyncQueue.query.filter_by(change_id=change_id).first()
                if q:
                    q.attempt_count += 1
                    if q.attempt_count >= 15:
                        logger.error(f"[PEER] Delta {change_id} exceeded 15 retries. Marking failed.")
            db.session.commit()
    except Exception as e:
        logger.error(f"[PEER] increment_retry: {e}")

def _mark_delivered(ids):
    if not ids: return
    try:
        with _flask_app.app_context():
            from app.database import db, PeerSyncQueue
            PeerSyncQueue.query.filter(PeerSyncQueue.change_id.in_(ids))\
                .update({"delivered": True}, synchronize_session=False)
            db.session.commit()
    except Exception as e:
        logger.error(f"[PEER] mark_delivered: {e}")

def _pending_count():
    try:
        from flask import has_app_context
        if has_app_context():
            from app.database import PeerSyncQueue
            return PeerSyncQueue.query.filter_by(delivered=False).count()
        with _flask_app.app_context():
            from app.database import PeerSyncQueue
            return PeerSyncQueue.query.filter_by(delivered=False).count()
    except Exception:
        return 0

def _apply_delta(delta, source):
    try:
        with _flask_app.app_context():
            from app.database import db, PeerSyncQueue
            
            with db.session.no_autoflush:
                # 1. Prevent processing if we ACTUALLY already processed it successfully
                if PeerSyncQueue.query.filter_by(change_id=delta["change_id"]).first():
                    return {"status": "duplicate"}

                action  = delta.get("action")
                table   = delta.get("table_name")
                payload = json.loads(delta.get("payload", "{}"))

                # 2. Try applying the database change inside a safe nested transaction
                try:
                    with db.session.begin_nested():
                        result = _apply_action(action, table, payload)

                        if result.get("status") in ("ok", "conflict"):
                            if result.get("status") == "conflict":
                                _state_manager.append_conflict({"from": source, "action": action,
                                    "table": table, "message": result["message"], "timestamp": _now()})

                            db.session.add(PeerSyncQueue(
                                change_id=delta["change_id"], action=action, table_name=table,
                                record_id=delta.get("record_id",""), payload=delta.get("payload","{}"),
                                performed_by=delta.get("performed_by", source),
                                timestamp=delta.get("timestamp", _now()), delivered=True))
                            
                            # 3. THE FIX: Force SQLite to write NOW to catch Foreign Key / Integrity errors.
                            # If this fails, it jumps to the except block and rolls back ONLY this record.
                            db.session.flush()
                        else:
                            return result
                            
                except Exception as nested_e:
                    # SQLite rejected the record (e.g. locked, missing school_id).
                    # begin_nested() automatically rolls back to the savepoint, saving the session.
                    logger.warning(f"[PEER] Record rejected by database during flush: {nested_e}")
                    return {"status": "error", "message": f"Database rejected record: {nested_e}"}

            # Return success to the caller so it can be added to the ACK list
            return result

    except Exception as e:
        logger.error(f"[PEER] apply_delta fatal error: {e}")
        from app.database import db
        db.session.rollback()
        return {"status": "error", "message": str(e)}



def _apply_action(action, table, payload):
    from flask import current_app

    table_to_entity = {
        "bookstable": "books",
        "students": "members",
        "borrowed_books": "checkouts",
        "teacher_borrowed_books": "staff_checkouts",
        "class_borrowing": "class_checkouts",
        "book_issues": "book_issues",
        "admin": "librarians",
        "logs": "logs",
        "notes": "notes",
        "graduates_borrowed_books": "graduates_borrowed",
        "graduates_class_borrowing": "graduates_class",
        "update_history": "update_history",
        "schools": "schools",
        "join_requests": "join_requests"
    }

    # Check if table is actually an entity_type already
    if table in table_to_entity.values():
        entity_type = table
    else:
        entity_type = table_to_entity.get(table)

    if not entity_type: return {"status": "error", "message": f"Unknown table: {table}"}

    sync_service = current_app.extensions.get('sync_service')
    if not sync_service:
        return {"status": "error", "message": "SyncService not initialized"}

    try:
        if action == "delete":
            payload["deleted"] = True

        # BUG 2 FIX: Patch the stripped cloud columns so SQLite doesn't reject the insert
        if entity_type == "books" and "added_at" not in payload:
            payload["added_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        if entity_type == "librarians" and "profile_image" not in payload:
            payload["profile_image"] = "default_profile.png"

        result = sync_service._apply_remote_record(entity_type, payload,source="lan")

        # Inform the online sync service about this change too
        if result.get("applied") or result.get("conflict"):
            config = sync_service.ENTITY_CONFIG[entity_type]
            pk_col = config["pk"]
            pk_val = payload.get(pk_col)

            op = "delete" if action == "delete" else "upsert"

            sync_service.queue_change(
                entity_type=entity_type,
                entity_id=pk_val,
                operation=op,
                payload=payload,
                school_id=payload.get('school_id')
            )

        if result.get("conflict"):
            return {"status": "conflict", "message": "Conflict resolved by SyncService"}
        elif result.get("applied"):
            return {"status": "ok"}
        else:
            return {"status": "error", "message": result.get("message", "SyncService rejected the record.")}
            
    except Exception as e:
        return {"status": "error", "message": str(e)}


def _safe_fields(model, payload):
    cols = {c.name for c in model.__table__.columns}
    return {k: v for k, v in payload.items() if k in cols}

def _build_full_state():
    try:
        with _flask_app.app_context():
            from flask import current_app
            sync_service = current_app.extensions.get('sync_service')

            # STRICT ORDER: Parents (Schools) must go before Children (Books, Loans)
            ordered_entities = [
                "schools",
                "librarians",
                "members",
                "books",
                "notes",
                "logs",
                "checkouts",
                "staff_checkouts",
                "class_checkouts",
                "book_issues",
                "graduates_borrowed",
                "graduates_class",
                "update_history",
                "join_requests"
            ]

            state = {}
            for entity_type in ordered_entities:
                config = sync_service.ENTITY_CONFIG.get(entity_type)
                if not config:
                    continue
                model = config["model"]
                records = model.query.all()
                state[config["table"]] = [sync_service.serialize_record(entity_type, r) for r in records]

            return state
    except Exception as e:
        logger.error(f"[MAJOR] build_full_state: {e}")
        return {}

# ── MAJOR server ──────────────────────────────────────────────────────────────

def _major_server_loop():
    global _server_sock
    _server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    _server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        _server_sock.bind(("0.0.0.0", TCP_PORT))
        _server_sock.listen(MAX_PEERS)
        _server_sock.settimeout(1.0)
        ssl_context = _get_ssl_context(role="major")
        _state_manager.set("error", None)
        logger.info(f"[MAJOR] Listening on :{TCP_PORT} (SSL)")
        while not _stop_event.is_set():
            try:
                conn, addr = _server_sock.accept()
                try:
                    ssl_conn = ssl_context.wrap_socket(conn, server_side=True)
                except ssl.SSLError as e:
                    # Filter out harmless TCP probes
                    err_str = str(e)
                    if "UNEXPECTED_EOF_WHILE_READING" not in err_str and "EOF occurred in violation of protocol" not in err_str:
                        logger.warning(f"[MAJOR] SSL handshake failed with {addr}: {e}")
                    conn.close()
                    continue
            except socket.timeout: continue
            except Exception as e:
                logger.warning(f"[MAJOR] Accept error: {e}")
                continue
            threading.Thread(target=_major_handle_peer, args=(ssl_conn, addr), daemon=True).start()
    except Exception as e:
        _state_manager.set("error", f"Server error: {e}")
    finally:
        try: _server_sock.close()
        except Exception as e: logger.debug(f"[PEER] Ignored error: {e}")

def _major_handle_peer(conn, addr):
    peer_ip = addr[0]; device_id = None; peer_label = peer_ip
    try:
        # 1. Recv hello
        hello = _recv(conn, timeout=15)
        if not hello: return
        device_id  = hello.get("device_id", peer_ip)
        peer_label = hello.get("label",      peer_ip)
        token      = hello.get("token",      "")
        otp        = hello.get("otp",        "")

        # 2. Auth
        trusted = _load_session(device_id)
        otp_claim = _consume_otp(otp) if otp else None
        
        is_new_pairing = False
        if trusted and token == trusted:
            pass  # token OK
        elif otp_claim is not None:
            token = uuid.uuid4().hex
            _save_session(device_id, peer_label, token, trusted=True)
            is_new_pairing = True
        else:
            _send(conn, {"type": "auth_fail" if otp else "auth_required",
                         "message": "Invalid OTP" if otp else "OTP required"})
            return

        # 3. Send auth_ok + full state ONLY if it's a brand new pairing
        auth_response = {"type": "auth_ok", "token": token}
        if is_new_pairing:
            auth_response["full_state"] = _build_full_state()
        _send(conn, auth_response)

        _state_manager.add_peer(device_id, {"label": peer_label, "ip": peer_ip, "last_seen": _now()})
        _state_manager.set("connected", True)
        logger.info(f"[MAJOR] {peer_label} connected")

        # 4. Push-first sync loop
        peer_seen_ids = set()
        while not _stop_event.is_set():
            interval = _state_manager.get("sync_interval", 5)
            # PUSH our deltas to Minor
            our = [d for d in _get_pending_deltas() if d["change_id"] not in peer_seen_ids]

            try:
                _send(conn, {"type": "push", "deltas": our})
            except Exception as e:
                logger.warning(f"[MAJOR] Push error: {e}")
                break

            # RECV Minor's response
            try:
                msg = _recv(conn, timeout=interval * 3 + 30)
                if msg is None: break
            except Exception as e:
                logger.warning(f"[MAJOR] Recv error: {e}")
                break

            if msg.get("type") == "push_ack":
                # 1. NEW: Process the Minor's receipt and officially mark them delivered
                ack_ids = msg.get("ack_ids", [])
                if ack_ids:
                    _mark_delivered(ack_ids)

                # 2. Process the Minor's incoming deltas
                minor_deltas = msg.get("deltas", [])
                results = []
                with _flask_app.app_context():
                    from app.database import db, PeerSyncQueue
                    for d in minor_deltas:
                        r = _apply_delta(d, peer_label)
                        results.append({"change_id": d["change_id"], **r})
                        peer_seen_ids.add(d["change_id"])
                    
                    try:
                        db.session.commit()
                    except Exception as e:
                        logger.error(f"[MAJOR] Final batch commit failed: {e}")
                        db.session.rollback()
                        # Mark all results as errors so the Minor PC retries them
                        for res in results:
                            res["status"] = "error"
                            res["message"] = "Server batch commit failed"

                _send(conn, {"type": "ack", "results": results})

            _state_manager.update_peer(device_id, last_seen=_now())
            _state_manager.set("last_sync", _now())
            if _stop_event.wait(timeout=interval): break

    except Exception as e:
        logger.warning(f"[MAJOR] {peer_label} disconnected: {e}")
    finally:
        conn.close()
        _state_manager.remove_peer(device_id)
        _state_manager.set("connected", _state_manager.has_peers())
        
def _broadcast_loop():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    beacon = json.dumps({"service": SERVICE_TAG, "ip": _state_manager.get("my_ip", "0.0.0.0"), "port": TCP_PORT}).encode()
    while not _stop_event.is_set():
        try: sock.sendto(beacon, ("<broadcast>", BROADCAST_PORT))
        except Exception as e: logger.debug(f"[PEER] Ignored error: {e}")
        if _stop_event.wait(timeout=3): break
    sock.close()

# ── MINOR client ──────────────────────────────────────────────────────────────

def _resolve_major_ip():
    """saved state → saved config → UDP broadcast"""
    known = str(_state_manager.get("major_ip", "") or "").strip()
    if known and _tcp_probe(known):
        return known
    if known:
        _state_manager.set("major_ip", None)
    try:
        with _flask_app.app_context():
            from app.utils import load_config
            saved = str(load_config().get("major_ip", "") or "").strip()
            if saved and _tcp_probe(saved):
                _state_manager.set("major_ip", saved)
                return saved
    except Exception: 
        pass

    found = _discover_major(timeout=5)
    if found:
        _state_manager.set("major_ip", found)
    return found

def _discover_major(timeout=5):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.settimeout(timeout)
    try:
        sock.bind(("", BROADCAST_PORT))
        data, addr = sock.recvfrom(1024)
        b = json.loads(data.decode())
        if b.get("service") == SERVICE_TAG:
            return b.get("ip", addr[0])
    except Exception as e: logger.debug(f"[PEER] Ignored error: {e}")
    finally: sock.close()
    return None

def _minor_client_loop():
    device_id, my_token = _my_device_identity()
    backoff = 2
    while not _stop_event.is_set():
        from app.utils import load_config
        if load_config().get('sa_directive') == 'lockdown':
            import time
            if _stop_event.wait(timeout=60): break
            continue

        saved_device_id, saved_token, saved_major_ip = _load_saved_identity()
        if saved_device_id:
            device_id = saved_device_id
        if saved_token is not None:
            my_token = saved_token
            _state_manager.set("session_token", saved_token)
        if saved_major_ip:
            _state_manager.set("major_ip", saved_major_ip)

        major_ip = _resolve_major_ip()
        if not major_ip:
            _state_manager.update(error="Major PC not found. Check network or enter IP on Peers page.", pending_count=_pending_count(), connected=False)
            _wait_or_retry(backoff)
            backoff = min(backoff * 2, 30)
            continue

        _state_manager.update(major_ip=major_ip, error=None, connected=False)
        backoff = 2

        raw_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        ssl_context = _get_ssl_context(role="minor")
        try:
            raw_sock.settimeout(10)
            raw_sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            raw_sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
            raw_sock.connect((major_ip, TCP_PORT))

            sock = ssl_context.wrap_socket(raw_sock, server_hostname=major_ip)

            # Send hello
            _send(sock, {"device_id": device_id, "label": _minor_label(), "token": my_token})

            # Recv auth
            resp = _recv(sock, timeout=20)
            if not resp: raise ConnectionError("No response from Major")

            t = resp.get("type")
            if t == "auth_fail":
                _state_manager.update(error=resp.get("message","Auth failed — enter OTP on Peers page."), connected=False)
                _wait_or_retry(10); continue
            if t == "auth_required":
                _state_manager.update(error="OTP required — go to Peers & Sync.", connected=False)
                _wait_or_retry(10); continue
            if t != "auth_ok":
                raise ConnectionError(f"Unexpected: {t}")

            # Save new token
            new_tok = resp.get("token", my_token)
            if new_tok and new_tok != my_token:
                my_token = new_tok
                try:
                    with _flask_app.app_context():
                        from app.utils import load_config, save_config
                        cfg = load_config()
                        cfg["session_token"]=my_token
                        cfg["major_ip"]=major_ip
                        cfg["device_id"] = device_id
                        save_config(cfg)
                except Exception as e: logger.debug(f"[PEER] Ignored error: {e}")
                _state_manager.set("session_token", my_token)

            # Apply full state ONLY if it exists
            fs = resp.get("full_state")
            if fs: _apply_full_state(fs)

            _state_manager.update(error=None, last_sync=_now(), connected=True)
            logger.info(f"[MINOR] Auth OK — sync loop starting")

            # Sync loop: Major pushes, we respond
            while not _stop_event.is_set():
                interval = _state_manager.get("sync_interval", 5)

                try:
                    msg = _recv(sock, timeout=interval * 3 + 30)
                except Exception as e:
                    logger.warning(f"[MINOR] Recv error: {e}")
                    break

                if msg is None:
                    logger.warning("[MINOR] Major stopped responding — reconnecting")
                    break
                if msg.get("type") != "push": continue

                # Apply Major's deltas
                applied_ids = []
                with _flask_app.app_context():
                    from app.database import db
                    for d in msg.get("deltas", []):
                        res = _apply_delta(d, "major")
                        if res.get("status") in ("ok", "duplicate", "conflict"):
                            applied_ids.append(d["change_id"])
                    
                    try:
                        # Final commit for the successful batch
                        db.session.commit()
                    except Exception as e:
                        logger.error(f"[MINOR] Final batch commit failed: {e}")
                        db.session.rollback()
                        # CRITICAL: If the batch commit fails, clear the ACKs so the Major retries later
                        applied_ids = []

                # Send our pending deltas + the ACK receipt for Major's data
                our = _get_pending_deltas()
                try:
                    _send(sock, {"type": "push_ack", "deltas": our, "ack_ids": applied_ids})
                except Exception as e:
                    logger.warning(f"[MINOR] Send error: {e}")
                    break

                # ALWAYS Recv ack to keep TCP buffer perfectly aligned
                try:
                    ack = _recv(sock, timeout=15)
                    if ack and ack.get("type") == "ack" and our:
                        confirmed = {r["change_id"] for r in ack.get("results",[])
                                     if r.get("status") in ("ok","duplicate")}
                        failed = {r["change_id"] for r in ack.get("results",[])
                                  if r.get("status") not in ("ok", "conflict", "duplicate")}
                        _mark_delivered(list(confirmed))
                        _increment_retry_counts(list(failed))
                except Exception as e:
                    logger.warning(f"[MINOR] Ack recv error: {e}")
                    break

                _state_manager.update(last_sync=_now(), pending_count=_pending_count(), error=None, connected=True)

        except ConnectionRefusedError:
            _state_manager.update(error=f"Major at {major_ip} refused — is it running?", connected=False)
        except Exception as e:
            logger.warning(f"[MINOR] {e}")
            _state_manager.update(error=f"Sync interrupted: {e}", connected=False)
        finally:
            try: sock.close()
            except Exception as e: logger.debug(f"[PEER] Ignored error: {e}")
        _wait_or_retry(backoff)



def _apply_full_state(snap):
    try:
        with _flask_app.app_context():
            from flask import current_app
            from app.database import db
            sync_service = current_app.extensions.get('sync_service')

            table_to_entity = {
                "bookstable": "books",
                "students": "members",
                "borrowed_books": "checkouts",
                "teacher_borrowed_books": "staff_checkouts",
                "class_borrowing": "class_checkouts",
                "book_issues": "book_issues",
                "admin": "librarians",
                "logs": "logs",
                "notes": "notes",
                "graduates_borrowed_books": "graduates_borrowed",
                "graduates_class_borrowing": "graduates_class",
                "update_history": "update_history",
                "schools": "schools",
                "join_requests": "join_requests"
            }

            # Disable autoflush to stop SQLAlchemy from prematurely validating constraints mid-loop
            with db.session.no_autoflush:
                for table, records in snap.items():
                    entity_type = table_to_entity.get(table)
                    if not entity_type:
                        continue

                    for r in records:
                        try:
                            # Use a nested savepoint so a single duplicate (like Admin ID=1) 
                            # doesn't crash the entire bootstrap process
                            with db.session.begin_nested():
                                sync_service._apply_remote_record(entity_type, r)
                        except Exception as e:
                            logger.debug(f"[MINOR] Skipped colliding record in {entity_type}: {e}")

            db.session.commit()
            logger.info("[MINOR] Full state applied and baseline bootstrap completed")
    except Exception as e:
        logger.error(f"[MINOR] apply_full_state: {e}")

def submit_otp_and_connect(otp, major_ip=None):
    target = major_ip
    if not target:
        target = _state_manager.get("major_ip")
    if not target: 
        target = _discover_major(timeout=6)
    if not target: 
        return {"status": "error", "message": "Major PC not found. Enter its IP manually."}
        
    device_id, _ = _my_device_identity()
    raw_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    raw_sock.settimeout(15)
    ssl_context = _get_ssl_context(role="minor")
    sock = None
    
    try:
        raw_sock.connect((target, TCP_PORT))
        sock = ssl_context.wrap_socket(raw_sock, server_hostname=target)
        _send(sock, {"device_id": device_id, "label": _minor_label(), "token": "", "otp": str(otp)})
        resp = _recv(sock, timeout=15)
        
        if resp and resp.get("type") == "auth_ok":
            tok = resp.get("token", "")
            try:
                with _flask_app.app_context():
                    from app.utils import load_config, save_config
                    cfg = load_config()
                    cfg["device_id"] = device_id
                    cfg["session_token"] = tok
                    cfg["major_ip"] = target
                    save_config(cfg)
            except Exception as e: 
                logger.debug(f"[PEER] Ignored error: {e}")
                
            fs = resp.get("full_state")
            if fs:
                _apply_full_state(fs)
                
                # BUG 1 FIX: Immediately link the local librarian to the incoming Major School ID
                # so the data is actually visible on the dashboard!
                try:
                    with _flask_app.app_context():
                        from flask_login import current_user
                        from app.database import db
                        if current_user and current_user.is_authenticated:
                            schools = fs.get("schools", [])
                            if schools:
                                current_user.school_id = schools[0].get("id")
                                db.session.commit()
                except Exception as e:
                    logger.error(f"[MINOR] Failed to link admin to school: {e}")
                
            _state_manager.update(major_ip=target, session_token=tok, error=None, last_sync=_now(), connected=True)
            _retry_event.set()
            return {"status": "ok", "message": f"Connected to Major at {target}. Live sync is now active."}
            
        return {"status": "error", "message": (resp or {}).get("message", "Wrong PIN / OTP expired.")}
        
    except socket.gaierror:
        return {"status": "error", "message": f"Invalid network address provided: {target}"}
    except Exception as e:
        return {"status": "error", "message": str(e)}
    finally:
        if sock:
            try: sock.close()
            except Exception: pass
        else:
            try: raw_sock.close()
            except Exception: pass

def _now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def queue(action, table, record_id, data, performed_by="system"):
    try:
        from flask import has_app_context
        from app.database import db, PeerSyncQueue

        def _add_record():
            db.session.add(PeerSyncQueue(
                change_id=str(uuid.uuid4()), action=action, table_name=table,
                record_id=str(record_id), payload=json.dumps(data, default=str),
                performed_by=performed_by, timestamp=_now(), delivered=False))

        if has_app_context():
            # Already inside an active request/transaction (e.g. the bulk
            # "Add Books" flow) — reuse that same session instead of opening
            # a second, competing one. The caller's own commit (safe_commit())
            # will persist this row along with everything else in the batch.
            _add_record()
        else:
            # No outer request/transaction to piggyback on (e.g. called from
            # a background peer-sync thread) — this needs its own context
            # and must commit immediately.
            with _flask_app.app_context():
                _add_record()
                db.session.commit()

        _state_manager.set("pending_count", _pending_count())
    except Exception as e:
        logger.error(f"[PEER] queue: {e}")
