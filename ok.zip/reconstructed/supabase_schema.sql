-- Unified schema for the Smart Library sync stack
-- Safe to execute repeatedly against a fresh or existing Supabase PostgreSQL database.

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;

-- 1. Schools
CREATE TABLE IF NOT EXISTS public.schools (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    school_name VARCHAR(120) NOT NULL,
    slug VARCHAR(120) NOT NULL,
    contact_email VARCHAR(120),
    contact_phone VARCHAR(50),
    status VARCHAR(20) NOT NULL DEFAULT 'active',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted BOOLEAN NOT NULL DEFAULT FALSE
);
ALTER TABLE public.schools ALTER COLUMN slug SET NOT NULL;
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname = 'schools_slug_key'
    ) THEN
        ALTER TABLE public.schools
            ADD CONSTRAINT schools_slug_key UNIQUE (slug);
    END IF;
END
$$;
ALTER TABLE public.schools ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Schools access" ON public.schools;
CREATE POLICY "Schools access" ON public.schools FOR ALL USING (true) WITH CHECK (true);

-- 2. Librarians (must be created before admin due to policy reference)
CREATE TABLE IF NOT EXISTS public.librarians (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    school_id UUID REFERENCES public.schools(id) ON DELETE CASCADE,
    username VARCHAR(80) NOT NULL,
    is_main_librarian BOOLEAN DEFAULT FALSE,
    password VARCHAR(200),
    role VARCHAR(20) DEFAULT 'librarian',
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted BOOLEAN NOT NULL DEFAULT FALSE,
    sync_status VARCHAR(20) NOT NULL DEFAULT 'pending',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'librarians_school_id_username_key'
    ) THEN
        ALTER TABLE public.librarians
            ADD CONSTRAINT librarians_school_id_username_key UNIQUE (school_id, username);
    END IF;
END
$$;
ALTER TABLE public.librarians ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Librarians isolate by school" ON public.librarians;
CREATE POLICY "Librarians isolate by school" ON public.librarians FOR ALL
USING (school_id = (auth.jwt() -> 'user_metadata' ->> 'school_id')::uuid OR (auth.jwt() ->> 'email' = username))
WITH CHECK (school_id = (auth.jwt() -> 'user_metadata' ->> 'school_id')::uuid OR (auth.jwt() ->> 'email' = username));

-- 3. Admin / librarians
CREATE TABLE IF NOT EXISTS public.admin (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    school_id UUID REFERENCES public.schools(id) ON DELETE CASCADE,
    username VARCHAR(80) NOT NULL,
    password VARCHAR(200) NOT NULL,
    role VARCHAR(20) NOT NULL DEFAULT 'admin',
    email1 VARCHAR(120),
    email2 VARCHAR(120),
    email3 VARCHAR(120),
    profile_image VARCHAR(120) DEFAULT 'default_profile.png',
    recovery_codes TEXT,
    local_only BOOLEAN NOT NULL DEFAULT FALSE,
    question1 VARCHAR(200),
    answer1 VARCHAR(200),
    question2 VARCHAR(200),
    answer2 VARCHAR(200),
    question3 VARCHAR(200),
    answer3 VARCHAR(200),
    pending_recovery_password VARCHAR(200),
    pending_recovery_expires_at TIMESTAMPTZ,
    textbee_device_id VARCHAR(100),
    textbee_api_key VARCHAR(200),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted BOOLEAN NOT NULL DEFAULT FALSE,
    sync_status VARCHAR(20) NOT NULL DEFAULT 'pending'
);
ALTER TABLE public.admin ALTER COLUMN username SET NOT NULL;
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'admin_username_key'
    ) THEN
        ALTER TABLE public.admin ADD CONSTRAINT admin_username_key UNIQUE (username);
    END IF;
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'admin_school_id_id_key'
    ) THEN
        ALTER TABLE public.admin ADD CONSTRAINT admin_school_id_id_key UNIQUE (school_id, id);
    END IF;
END
$$;
ALTER TABLE public.admin ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Admin isolate by school" ON public.admin;
CREATE POLICY "Admin isolate by school" ON public.admin FOR ALL
USING (school_id = (auth.jwt() -> 'user_metadata' ->> 'school_id')::uuid OR (auth.jwt() ->> 'email' IN (SELECT username FROM public.librarians WHERE public.librarians.school_id = admin.school_id)))
WITH CHECK (school_id = (auth.jwt() -> 'user_metadata' ->> 'school_id')::uuid OR (auth.jwt() ->> 'email' IN (SELECT username FROM public.librarians WHERE public.librarians.school_id = admin.school_id)));

-- 4. Join requests
CREATE TABLE IF NOT EXISTS public.join_requests (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    school_name VARCHAR(255) NOT NULL,
    username VARCHAR(80) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'pending',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
ALTER TABLE public.join_requests ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Join requests access" ON public.join_requests;
CREATE POLICY "Join requests access" ON public.join_requests FOR ALL USING (true) WITH CHECK (true);

-- 5. Platform announcements
CREATE TABLE IF NOT EXISTS public.announcements (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    author_username VARCHAR(80),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
ALTER TABLE public.announcements ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Announcements viewable by everyone" ON public.announcements;
CREATE POLICY "Announcements viewable by everyone" ON public.announcements FOR SELECT USING (true);

-- Remote sync ledger
CREATE TABLE IF NOT EXISTS public.remote_sync_ledger (
    id BIGSERIAL PRIMARY KEY,
    school_id UUID NOT NULL REFERENCES public.schools(id) ON DELETE CASCADE,
    table_name VARCHAR(100) NOT NULL,
    record_id VARCHAR(100) NOT NULL,
    payload JSONB NOT NULL DEFAULT '{}'::jsonb,
    timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
ALTER TABLE public.remote_sync_ledger ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Remote sync ledger isolate by school" ON public.remote_sync_ledger;
CREATE POLICY "Remote sync ledger isolate by school" ON public.remote_sync_ledger FOR ALL
USING (school_id = (auth.jwt() -> 'user_metadata' ->> 'school_id')::uuid OR (auth.jwt() ->> 'email' IN (SELECT username FROM public.librarians WHERE public.librarians.school_id = remote_sync_ledger.school_id)))
WITH CHECK (school_id = (auth.jwt() -> 'user_metadata' ->> 'school_id')::uuid OR (auth.jwt() ->> 'email' IN (SELECT username FROM public.librarians WHERE public.librarians.school_id = remote_sync_ledger.school_id)));

-- 5. Students
CREATE TABLE IF NOT EXISTS public.students (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    school_id UUID REFERENCES public.schools(id) ON DELETE CASCADE,
    name VARCHAR(100),
    "class" VARCHAR(20),
    combination VARCHAR(50),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted BOOLEAN NOT NULL DEFAULT FALSE,
    sync_status VARCHAR(20) NOT NULL DEFAULT 'pending'
);
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'students_school_id_id_key'
    ) THEN
        ALTER TABLE public.students ADD CONSTRAINT students_school_id_id_key UNIQUE (school_id, id);
    END IF;
END
$$;
ALTER TABLE public.students ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Students isolate by school" ON public.students;
CREATE POLICY "Students isolate by school" ON public.students FOR ALL
USING (school_id = (auth.jwt() -> 'user_metadata' ->> 'school_id')::uuid OR (auth.jwt() ->> 'email' IN (SELECT username FROM public.librarians WHERE public.librarians.school_id = students.school_id)))
WITH CHECK (school_id = (auth.jwt() -> 'user_metadata' ->> 'school_id')::uuid OR (auth.jwt() ->> 'email' IN (SELECT username FROM public.librarians WHERE public.librarians.school_id = students.school_id)));

-- 6. Books
CREATE TABLE IF NOT EXISTS public.bookstable (
    book_id VARCHAR(50) PRIMARY KEY,
    school_id UUID REFERENCES public.schools(id) ON DELETE CASCADE,
    title VARCHAR(200),
    author VARCHAR(100),
    category VARCHAR(100) DEFAULT 'Uncategorized',
    added_at VARCHAR(50),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted BOOLEAN NOT NULL DEFAULT FALSE,
    sync_status VARCHAR(20) NOT NULL DEFAULT 'pending'
);
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'bookstable_school_id_book_id_key'
    ) THEN
        ALTER TABLE public.bookstable ADD CONSTRAINT bookstable_school_id_book_id_key UNIQUE (school_id, book_id);
    END IF;
END
$$;
ALTER TABLE public.bookstable ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Books isolate by school" ON public.bookstable;
CREATE POLICY "Books isolate by school" ON public.bookstable FOR ALL
USING (school_id = (auth.jwt() -> 'user_metadata' ->> 'school_id')::uuid OR (auth.jwt() ->> 'email' IN (SELECT username FROM public.librarians WHERE public.librarians.school_id = bookstable.school_id)))
WITH CHECK (school_id = (auth.jwt() -> 'user_metadata' ->> 'school_id')::uuid OR (auth.jwt() ->> 'email' IN (SELECT username FROM public.librarians WHERE public.librarians.school_id = bookstable.school_id)));

-- 7. Borrowed books
CREATE TABLE IF NOT EXISTS public.borrowed_books (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    school_id UUID REFERENCES public.schools(id) ON DELETE CASCADE,
    book_id VARCHAR(50),
    book_title VARCHAR(200),
    student_name VARCHAR(100),
    student_class VARCHAR(20),
    notes TEXT,
    condition VARCHAR(50),
    timestamp VARCHAR(50),
    due_date VARCHAR(20),
    return_date VARCHAR(20),
    returned BOOLEAN DEFAULT FALSE,
    performed_by VARCHAR(100),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted BOOLEAN NOT NULL DEFAULT FALSE,
    sync_status VARCHAR(20) NOT NULL DEFAULT 'pending'
);
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'borrowed_books_school_id_id_key'
    ) THEN
        ALTER TABLE public.borrowed_books ADD CONSTRAINT borrowed_books_school_id_id_key UNIQUE (school_id, id);
    END IF;
END
$$;
ALTER TABLE public.borrowed_books ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Borrowed books isolate by school" ON public.borrowed_books;
CREATE POLICY "Borrowed books isolate by school" ON public.borrowed_books FOR ALL
USING (school_id = (auth.jwt() -> 'user_metadata' ->> 'school_id')::uuid OR (auth.jwt() ->> 'email' IN (SELECT username FROM public.librarians WHERE public.librarians.school_id = borrowed_books.school_id)))
WITH CHECK (school_id = (auth.jwt() -> 'user_metadata' ->> 'school_id')::uuid OR (auth.jwt() ->> 'email' IN (SELECT username FROM public.librarians WHERE public.librarians.school_id = borrowed_books.school_id)));

-- 8. Logs
CREATE TABLE IF NOT EXISTS public.logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    school_id UUID REFERENCES public.schools(id) ON DELETE CASCADE,
    username VARCHAR(80),
    librarian_username VARCHAR(80),
    route VARCHAR(255),
    method VARCHAR(20),
    status_code INTEGER DEFAULT 200,
    details VARCHAR(300),
    timestamp VARCHAR(50),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted BOOLEAN NOT NULL DEFAULT FALSE,
    sync_status VARCHAR(20) NOT NULL DEFAULT 'pending'
);
ALTER TABLE public.logs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Logs isolate by school" ON public.logs;
CREATE POLICY "Logs isolate by school" ON public.logs FOR ALL
USING (school_id = (auth.jwt() -> 'user_metadata' ->> 'school_id')::uuid OR (auth.jwt() ->> 'email' IN (SELECT username FROM public.librarians WHERE public.librarians.school_id = logs.school_id)))
WITH CHECK (school_id = (auth.jwt() -> 'user_metadata' ->> 'school_id')::uuid OR (auth.jwt() ->> 'email' IN (SELECT username FROM public.librarians WHERE public.librarians.school_id = logs.school_id)));

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'logs_school_id_id_key'
    ) THEN
        ALTER TABLE public.logs ADD CONSTRAINT logs_school_id_id_key UNIQUE (school_id, id);
    END IF;
END
$$;

-- 9. Class borrowing
CREATE TABLE IF NOT EXISTS public.class_borrowing (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    school_id UUID REFERENCES public.schools(id) ON DELETE CASCADE,
    class_name VARCHAR(20),
    responsibles VARCHAR(200),
    book_title VARCHAR(200),
    book_ids VARCHAR(200),
    quantity INTEGER DEFAULT 1,
    condition VARCHAR(50),
    borrow_time VARCHAR(50),
    return_date VARCHAR(20),
    returned BOOLEAN DEFAULT FALSE,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted BOOLEAN NOT NULL DEFAULT FALSE,
    sync_status VARCHAR(20) NOT NULL DEFAULT 'pending'
);
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'class_borrowing_school_id_id_key'
    ) THEN
        ALTER TABLE public.class_borrowing ADD CONSTRAINT class_borrowing_school_id_id_key UNIQUE (school_id, id);
    END IF;
END
$$;
ALTER TABLE public.class_borrowing ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Class borrowing isolate by school" ON public.class_borrowing;
CREATE POLICY "Class borrowing isolate by school" ON public.class_borrowing FOR ALL
USING (school_id = (auth.jwt() -> 'user_metadata' ->> 'school_id')::uuid OR (auth.jwt() ->> 'email' IN (SELECT username FROM public.librarians WHERE public.librarians.school_id = class_borrowing.school_id)))
WITH CHECK (school_id = (auth.jwt() -> 'user_metadata' ->> 'school_id')::uuid OR (auth.jwt() ->> 'email' IN (SELECT username FROM public.librarians WHERE public.librarians.school_id = class_borrowing.school_id)));

-- 10. Graduate borrowing records
CREATE TABLE IF NOT EXISTS public.graduates_borrowed_books (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    school_id UUID REFERENCES public.schools(id) ON DELETE CASCADE,
    promotion_name VARCHAR(50),
    student_name VARCHAR(100),
    original_class VARCHAR(20),
    book_id VARCHAR(50),
    book_title VARCHAR(200),
    notes TEXT,
    timestamp VARCHAR(50),
    due_date VARCHAR(20),
    contact VARCHAR(50),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted BOOLEAN NOT NULL DEFAULT FALSE,
    sync_status VARCHAR(20) NOT NULL DEFAULT 'pending'
);
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'graduates_borrowed_books_school_id_id_key'
    ) THEN
        ALTER TABLE public.graduates_borrowed_books ADD CONSTRAINT graduates_borrowed_books_school_id_id_key UNIQUE (school_id, id);
    END IF;
END
$$;
ALTER TABLE public.graduates_borrowed_books ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Graduates borrowing isolate by school" ON public.graduates_borrowed_books;
CREATE POLICY "Graduates borrowing isolate by school" ON public.graduates_borrowed_books FOR ALL
USING (school_id = (auth.jwt() -> 'user_metadata' ->> 'school_id')::uuid OR (auth.jwt() ->> 'email' IN (SELECT username FROM public.librarians WHERE public.librarians.school_id = graduates_borrowed_books.school_id)))
WITH CHECK (school_id = (auth.jwt() -> 'user_metadata' ->> 'school_id')::uuid OR (auth.jwt() ->> 'email' IN (SELECT username FROM public.librarians WHERE public.librarians.school_id = graduates_borrowed_books.school_id)));

-- 11. Graduate class borrowing
CREATE TABLE IF NOT EXISTS public.graduates_class_borrowing (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    school_id UUID REFERENCES public.schools(id) ON DELETE CASCADE,
    promotion_name VARCHAR(50),
    class_name VARCHAR(20),
    responsibles VARCHAR(200),
    book_title VARCHAR(200),
    book_ids VARCHAR(200),
    quantity INTEGER,
    condition VARCHAR(50),
    borrow_time VARCHAR(50),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted BOOLEAN NOT NULL DEFAULT FALSE,
    sync_status VARCHAR(20) NOT NULL DEFAULT 'pending'
);
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'graduates_class_borrowing_school_id_id_key'
    ) THEN
        ALTER TABLE public.graduates_class_borrowing ADD CONSTRAINT graduates_class_borrowing_school_id_id_key UNIQUE (school_id, id);
    END IF;
END
$$;
ALTER TABLE public.graduates_class_borrowing ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Graduates class borrowing isolate by school" ON public.graduates_class_borrowing;
CREATE POLICY "Graduates class borrowing isolate by school" ON public.graduates_class_borrowing FOR ALL
USING (school_id = (auth.jwt() -> 'user_metadata' ->> 'school_id')::uuid OR (auth.jwt() ->> 'email' IN (SELECT username FROM public.librarians WHERE public.librarians.school_id = graduates_class_borrowing.school_id)))
WITH CHECK (school_id = (auth.jwt() -> 'user_metadata' ->> 'school_id')::uuid OR (auth.jwt() ->> 'email' IN (SELECT username FROM public.librarians WHERE public.librarians.school_id = graduates_class_borrowing.school_id)));

-- 12. Teacher borrowed books
CREATE TABLE IF NOT EXISTS public.teacher_borrowed_books (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    school_id UUID REFERENCES public.schools(id) ON DELETE CASCADE,
    book_id VARCHAR(50),
    book_title VARCHAR(200),
    teacher_name VARCHAR(100),
    notes TEXT,
    condition VARCHAR(50),
    timestamp VARCHAR(50),
    returned BOOLEAN DEFAULT FALSE,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted BOOLEAN NOT NULL DEFAULT FALSE,
    sync_status VARCHAR(20) NOT NULL DEFAULT 'pending'
);
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'teacher_borrowed_books_school_id_id_key'
    ) THEN
        ALTER TABLE public.teacher_borrowed_books ADD CONSTRAINT teacher_borrowed_books_school_id_id_key UNIQUE (school_id, id);
    END IF;
END
$$;
ALTER TABLE public.teacher_borrowed_books ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Teacher borrowed books isolate by school" ON public.teacher_borrowed_books;
CREATE POLICY "Teacher borrowed books isolate by school" ON public.teacher_borrowed_books FOR ALL
USING (school_id = (auth.jwt() -> 'user_metadata' ->> 'school_id')::uuid OR (auth.jwt() ->> 'email' IN (SELECT username FROM public.librarians WHERE public.librarians.school_id = teacher_borrowed_books.school_id)))
WITH CHECK (school_id = (auth.jwt() -> 'user_metadata' ->> 'school_id')::uuid OR (auth.jwt() ->> 'email' IN (SELECT username FROM public.librarians WHERE public.librarians.school_id = teacher_borrowed_books.school_id)));

-- 13. Notes (Fixed with notes_school_id_id_key unique constraint matching on_conflict)
CREATE TABLE IF NOT EXISTS public.notes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    school_id UUID REFERENCES public.schools(id) ON DELETE CASCADE,
    title VARCHAR(255),
    content TEXT,
    timestamp VARCHAR(50),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted BOOLEAN NOT NULL DEFAULT FALSE,
    sync_status VARCHAR(20) NOT NULL DEFAULT 'pending'
);
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'notes_school_id_id_key'
    ) THEN
        ALTER TABLE public.notes ADD CONSTRAINT notes_school_id_id_key UNIQUE (school_id, id);
    END IF;
END
$$;
ALTER TABLE public.notes ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Notes isolate by school" ON public.notes;
CREATE POLICY "Notes isolate by school" ON public.notes FOR ALL
USING (school_id = (auth.jwt() -> 'user_metadata' ->> 'school_id')::uuid OR (auth.jwt() ->> 'email' IN (SELECT username FROM public.librarians WHERE public.librarians.school_id = notes.school_id)))
WITH CHECK (school_id = (auth.jwt() -> 'user_metadata' ->> 'school_id')::uuid OR (auth.jwt() ->> 'email' IN (SELECT username FROM public.librarians WHERE public.librarians.school_id = notes.school_id)));

-- 14. Update history
CREATE TABLE IF NOT EXISTS public.update_history (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    school_id UUID REFERENCES public.schools(id) ON DELETE CASCADE,
    version VARCHAR(20),
    changelog TEXT,
    status VARCHAR(20),
    timestamp VARCHAR(50),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted BOOLEAN NOT NULL DEFAULT FALSE,
    sync_status VARCHAR(20) NOT NULL DEFAULT 'pending'
);
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'update_history_school_id_id_key'
    ) THEN
        ALTER TABLE public.update_history ADD CONSTRAINT update_history_school_id_id_key UNIQUE (school_id, id);
    END IF;
END
$$;
ALTER TABLE public.update_history ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Update history isolate by school" ON public.update_history;
CREATE POLICY "Update history isolate by school" ON public.update_history FOR ALL
USING (school_id = (auth.jwt() -> 'user_metadata' ->> 'school_id')::uuid OR (auth.jwt() ->> 'email' IN (SELECT username FROM public.librarians WHERE public.librarians.school_id = update_history.school_id)))
WITH CHECK (school_id = (auth.jwt() -> 'user_metadata' ->> 'school_id')::uuid OR (auth.jwt() ->> 'email' IN (SELECT username FROM public.librarians WHERE public.librarians.school_id = update_history.school_id)));

-- 15. Book issues
CREATE TABLE IF NOT EXISTS public.book_issues (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    school_id UUID REFERENCES public.schools(id) ON DELETE CASCADE,
    loan_id UUID NOT NULL,
    loan_type VARCHAR(50),
    issue_description TEXT NOT NULL,
    repair_cost DOUBLE PRECISION DEFAULT 0.0,
    status VARCHAR(20) DEFAULT 'Pending',
    created_at VARCHAR(50),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted BOOLEAN NOT NULL DEFAULT FALSE,
    sync_status VARCHAR(20) NOT NULL DEFAULT 'pending'
);
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'book_issues_school_id_id_key'
    ) THEN
        ALTER TABLE public.book_issues ADD CONSTRAINT book_issues_school_id_id_key UNIQUE (school_id, id);
    END IF;
END
$$;
ALTER TABLE public.book_issues ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Book issues isolate by school" ON public.book_issues;
CREATE POLICY "Book issues isolate by school" ON public.book_issues FOR ALL
USING (school_id = (auth.jwt() -> 'user_metadata' ->> 'school_id')::uuid OR (auth.jwt() ->> 'email' IN (SELECT username FROM public.librarians WHERE public.librarians.school_id = book_issues.school_id)))
WITH CHECK (school_id = (auth.jwt() -> 'user_metadata' ->> 'school_id')::uuid OR (auth.jwt() ->> 'email' IN (SELECT username FROM public.librarians WHERE public.librarians.school_id = book_issues.school_id)));

-- 16. Sync metadata and queue tables used by the Flask sync service
CREATE TABLE IF NOT EXISTS public.sync_metadata (
    id BIGSERIAL PRIMARY KEY,
    device_id VARCHAR(100) NOT NULL,
    school_id UUID NOT NULL REFERENCES public.schools(id) ON DELETE CASCADE,
    last_upload_at TIMESTAMPTZ,
    last_download_at TIMESTAMPTZ,
    last_synced_at TIMESTAMPTZ,
    last_error TEXT,
    pending_operations INTEGER NOT NULL DEFAULT 0,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'sync_metadata_device_id_key'
    ) THEN
        ALTER TABLE public.sync_metadata ADD CONSTRAINT sync_metadata_device_id_key UNIQUE (device_id);
    END IF;
END
$$;
ALTER TABLE public.sync_metadata ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Sync metadata school isolate" ON public.sync_metadata;
CREATE POLICY "Sync metadata school isolate" ON public.sync_metadata FOR ALL
USING (school_id = (auth.jwt() -> 'user_metadata' ->> 'school_id')::uuid OR (auth.jwt() ->> 'email' IN (SELECT username FROM public.librarians WHERE public.librarians.school_id = sync_metadata.school_id)))
WITH CHECK (school_id = (auth.jwt() -> 'user_metadata' ->> 'school_id')::uuid OR (auth.jwt() ->> 'email' IN (SELECT username FROM public.librarians WHERE public.librarians.school_id = sync_metadata.school_id)));

CREATE TABLE IF NOT EXISTS public.sync_queue (
    id BIGSERIAL PRIMARY KEY,
    operation_id VARCHAR(36) NOT NULL,
    school_id UUID NOT NULL REFERENCES public.schools(id) ON DELETE CASCADE,
    device_id VARCHAR(100) NOT NULL,
    entity_type VARCHAR(50) NOT NULL,
    entity_id VARCHAR(100) NOT NULL,
    operation VARCHAR(20) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'pending',
    payload TEXT NOT NULL DEFAULT '{}',
    record_updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    attempt_count INTEGER NOT NULL DEFAULT 0,
    next_retry_at TIMESTAMPTZ,
    last_error TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    processed_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'sync_queue_operation_id_key'
    ) THEN
        ALTER TABLE public.sync_queue ADD CONSTRAINT sync_queue_operation_id_key UNIQUE (operation_id);
    END IF;
END
$$;
ALTER TABLE public.sync_queue ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Sync queue school isolate" ON public.sync_queue;
CREATE POLICY "Sync queue school isolate" ON public.sync_queue FOR ALL
USING (school_id = (auth.jwt() -> 'user_metadata' ->> 'school_id')::uuid OR (auth.jwt() ->> 'email' IN (SELECT username FROM public.librarians WHERE public.librarians.school_id = sync_queue.school_id)))
WITH CHECK (school_id = (auth.jwt() -> 'user_metadata' ->> 'school_id')::uuid OR (auth.jwt() ->> 'email' IN (SELECT username FROM public.librarians WHERE public.librarians.school_id = sync_queue.school_id)));

CREATE TABLE IF NOT EXISTS public.sync_conflicts (
    id BIGSERIAL PRIMARY KEY,
    school_id UUID NOT NULL REFERENCES public.schools(id) ON DELETE CASCADE,
    entity_type VARCHAR(50) NOT NULL,
    entity_id VARCHAR(100) NOT NULL,
    local_payload TEXT NOT NULL,
    remote_payload TEXT NOT NULL,
    resolved_payload TEXT,
    local_updated_at TIMESTAMPTZ,
    remote_updated_at TIMESTAMPTZ,
    resolution VARCHAR(20) NOT NULL DEFAULT 'pending',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    resolved_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
ALTER TABLE public.sync_conflicts ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Sync conflicts school isolate" ON public.sync_conflicts;
CREATE POLICY "Sync conflicts school isolate" ON public.sync_conflicts FOR ALL
USING (school_id = (auth.jwt() -> 'user_metadata' ->> 'school_id')::uuid OR (auth.jwt() ->> 'email' IN (SELECT username FROM public.librarians WHERE public.librarians.school_id = sync_conflicts.school_id)))
WITH CHECK (school_id = (auth.jwt() -> 'user_metadata' ->> 'school_id')::uuid OR (auth.jwt() ->> 'email' IN (SELECT username FROM public.librarians WHERE public.librarians.school_id = sync_conflicts.school_id)));

CREATE TABLE IF NOT EXISTS public.cloud_sync_queue (
    id BIGSERIAL PRIMARY KEY,
    table_name VARCHAR(50) NOT NULL,
    record_id VARCHAR(100) NOT NULL,
    payload TEXT NOT NULL,
    timestamp VARCHAR(50) NOT NULL,
    school_id UUID NOT NULL REFERENCES public.schools(id) ON DELETE CASCADE
);
ALTER TABLE public.cloud_sync_queue ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Cloud sync queue school isolate" ON public.cloud_sync_queue;
CREATE POLICY "Cloud sync queue school isolate" ON public.cloud_sync_queue FOR ALL
USING (school_id = (auth.jwt() -> 'user_metadata' ->> 'school_id')::uuid OR (auth.jwt() ->> 'email' IN (SELECT username FROM public.librarians WHERE public.librarians.school_id = cloud_sync_queue.school_id)))
WITH CHECK (school_id = (auth.jwt() -> 'user_metadata' ->> 'school_id')::uuid OR (auth.jwt() ->> 'email' IN (SELECT username FROM public.librarians WHERE public.librarians.school_id = cloud_sync_queue.school_id)));

CREATE TABLE IF NOT EXISTS public.peer_sync_queue (
    id BIGSERIAL PRIMARY KEY,
    change_id VARCHAR(100) NOT NULL,
    action VARCHAR(20) NOT NULL,
    table_name VARCHAR(50) NOT NULL,
    record_id VARCHAR(100),
    payload TEXT,
    performed_by VARCHAR(100),
    timestamp VARCHAR(50),
    delivered BOOLEAN NOT NULL DEFAULT FALSE
);
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'peer_sync_queue_change_id_key'
    ) THEN
        ALTER TABLE public.peer_sync_queue ADD CONSTRAINT peer_sync_queue_change_id_key UNIQUE (change_id);
    END IF;
END
$$;
ALTER TABLE public.peer_sync_queue ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Peer sync queue access" ON public.peer_sync_queue;
CREATE POLICY "Peer sync queue access" ON public.peer_sync_queue FOR ALL USING (true) WITH CHECK (true);

CREATE TABLE IF NOT EXISTS public.sync_logs (
    id BIGSERIAL PRIMARY KEY,
    change_id VARCHAR(100) UNIQUE,
    device_id VARCHAR(50),
    device_label VARCHAR(100),
    performed_by VARCHAR(100),
    action VARCHAR(50),
    status VARCHAR(20),
    error VARCHAR(300),
    timestamp VARCHAR(50)
);
ALTER TABLE public.sync_logs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Sync logs access" ON public.sync_logs;
CREATE POLICY "Sync logs access" ON public.sync_logs FOR ALL USING (true) WITH CHECK (true);

CREATE TABLE IF NOT EXISTS public.peer_sessions (
    id BIGSERIAL PRIMARY KEY,
    device_id VARCHAR(100) NOT NULL,
    token VARCHAR(100),
    label VARCHAR(100),
    trusted BOOLEAN NOT NULL DEFAULT TRUE,
    last_seen VARCHAR(50)
);
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'peer_sessions_device_id_key'
    ) THEN
        ALTER TABLE public.peer_sessions ADD CONSTRAINT peer_sessions_device_id_key UNIQUE (device_id);
    END IF;
END
$$;
ALTER TABLE public.peer_sessions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Peer sessions access" ON public.peer_sessions;
CREATE POLICY "Peer sessions access" ON public.peer_sessions FOR ALL USING (true) WITH CHECK (true);

-- Reusable updated_at triggers for tables that carry the column
DROP TRIGGER IF EXISTS trg_schools_updated_at ON public.schools;
CREATE TRIGGER trg_schools_updated_at
BEFORE UPDATE ON public.schools
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trg_admin_updated_at ON public.admin;
CREATE TRIGGER trg_admin_updated_at
BEFORE UPDATE ON public.admin
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trg_librarians_updated_at ON public.librarians;
CREATE TRIGGER trg_librarians_updated_at
BEFORE UPDATE ON public.librarians
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trg_students_updated_at ON public.students;
CREATE TRIGGER trg_students_updated_at
BEFORE UPDATE ON public.students
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trg_bookstable_updated_at ON public.bookstable;
CREATE TRIGGER trg_bookstable_updated_at
BEFORE UPDATE ON public.bookstable
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trg_borrowed_books_updated_at ON public.borrowed_books;
CREATE TRIGGER trg_borrowed_books_updated_at
BEFORE UPDATE ON public.borrowed_books
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trg_logs_updated_at ON public.logs;
CREATE TRIGGER trg_logs_updated_at
BEFORE UPDATE ON public.logs
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trg_class_borrowing_updated_at ON public.class_borrowing;
CREATE TRIGGER trg_class_borrowing_updated_at
BEFORE UPDATE ON public.class_borrowing
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trg_graduates_borrowed_books_updated_at ON public.graduates_borrowed_books;
CREATE TRIGGER trg_graduates_borrowed_books_updated_at
BEFORE UPDATE ON public.graduates_borrowed_books
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trg_graduates_class_borrowing_updated_at ON public.graduates_class_borrowing;
CREATE TRIGGER trg_graduates_class_borrowing_updated_at
BEFORE UPDATE ON public.graduates_class_borrowing
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trg_teacher_borrowed_books_updated_at ON public.teacher_borrowed_books;
CREATE TRIGGER trg_teacher_borrowed_books_updated_at
BEFORE UPDATE ON public.teacher_borrowed_books
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trg_notes_updated_at ON public.notes;
CREATE TRIGGER trg_notes_updated_at
BEFORE UPDATE ON public.notes
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trg_update_history_updated_at ON public.update_history;
CREATE TRIGGER trg_update_history_updated_at
BEFORE UPDATE ON public.update_history
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trg_book_issues_updated_at ON public.book_issues;
CREATE TRIGGER trg_book_issues_updated_at
BEFORE UPDATE ON public.book_issues
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trg_sync_metadata_updated_at ON public.sync_metadata;
CREATE TRIGGER trg_sync_metadata_updated_at
BEFORE UPDATE ON public.sync_metadata
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trg_sync_queue_updated_at ON public.sync_queue;
CREATE TRIGGER trg_sync_queue_updated_at
BEFORE UPDATE ON public.sync_queue
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trg_sync_conflicts_updated_at ON public.sync_conflicts;
CREATE TRIGGER trg_sync_conflicts_updated_at
BEFORE UPDATE ON public.sync_conflicts
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Indexes for the app's common lookup paths
CREATE INDEX IF NOT EXISTS idx_schools_slug ON public.schools(slug);
CREATE INDEX IF NOT EXISTS idx_schools_deleted ON public.schools(deleted);
CREATE INDEX IF NOT EXISTS idx_admin_school_id ON public.admin(school_id);
CREATE INDEX IF NOT EXISTS idx_admin_username ON public.admin(username);
CREATE INDEX IF NOT EXISTS idx_admin_deleted ON public.admin(deleted);
CREATE INDEX IF NOT EXISTS idx_librarians_school_id ON public.librarians(school_id);
CREATE INDEX IF NOT EXISTS idx_librarians_deleted ON public.librarians(deleted);
CREATE INDEX IF NOT EXISTS idx_students_school_id ON public.students(school_id);
CREATE INDEX IF NOT EXISTS idx_students_deleted ON public.students(deleted);
CREATE INDEX IF NOT EXISTS idx_students_class ON public.students("class");
CREATE INDEX IF NOT EXISTS idx_bookstable_school_id ON public.bookstable(school_id);
CREATE INDEX IF NOT EXISTS idx_bookstable_book_id ON public.bookstable(book_id);
CREATE INDEX IF NOT EXISTS idx_bookstable_deleted ON public.bookstable(deleted);
CREATE INDEX IF NOT EXISTS idx_borrowed_books_school_id ON public.borrowed_books(school_id);
CREATE INDEX IF NOT EXISTS idx_borrowed_books_book_id ON public.borrowed_books(book_id);
CREATE INDEX IF NOT EXISTS idx_borrowed_books_returned ON public.borrowed_books(returned);
CREATE INDEX IF NOT EXISTS idx_borrowed_books_deleted ON public.borrowed_books(deleted);
CREATE INDEX IF NOT EXISTS idx_logs_school_id ON public.logs(school_id);
CREATE INDEX IF NOT EXISTS idx_logs_deleted ON public.logs(deleted);
CREATE INDEX IF NOT EXISTS idx_logs_username ON public.logs(username);
CREATE INDEX IF NOT EXISTS idx_class_borrowing_school_id ON public.class_borrowing(school_id);
CREATE INDEX IF NOT EXISTS idx_class_borrowing_returned ON public.class_borrowing(returned);
CREATE INDEX IF NOT EXISTS idx_class_borrowing_deleted ON public.class_borrowing(deleted);
CREATE INDEX IF NOT EXISTS idx_graduates_borrowed_books_school_id ON public.graduates_borrowed_books(school_id);
CREATE INDEX IF NOT EXISTS idx_graduates_borrowed_books_deleted ON public.graduates_borrowed_books(deleted);
CREATE INDEX IF NOT EXISTS idx_graduates_class_borrowing_school_id ON public.graduates_class_borrowing(school_id);
CREATE INDEX IF NOT EXISTS idx_graduates_class_borrowing_deleted ON public.graduates_class_borrowing(deleted);
CREATE INDEX IF NOT EXISTS idx_teacher_borrowed_books_school_id ON public.teacher_borrowed_books(school_id);
CREATE INDEX IF NOT EXISTS idx_teacher_borrowed_books_returned ON public.teacher_borrowed_books(returned);
CREATE INDEX IF NOT EXISTS idx_teacher_borrowed_books_deleted ON public.teacher_borrowed_books(deleted);
CREATE INDEX IF NOT EXISTS idx_notes_school_id ON public.notes(school_id);
CREATE INDEX IF NOT EXISTS idx_notes_deleted ON public.notes(deleted);
CREATE INDEX IF NOT EXISTS idx_update_history_school_id ON public.update_history(school_id);
CREATE INDEX IF NOT EXISTS idx_update_history_deleted ON public.update_history(deleted);
CREATE INDEX IF NOT EXISTS idx_book_issues_school_id ON public.book_issues(school_id);
CREATE INDEX IF NOT EXISTS idx_book_issues_deleted ON public.book_issues(deleted);
CREATE INDEX IF NOT EXISTS idx_remote_sync_ledger_school_id ON public.remote_sync_ledger(school_id);
CREATE INDEX IF NOT EXISTS idx_remote_sync_ledger_timestamp ON public.remote_sync_ledger(timestamp);
CREATE INDEX IF NOT EXISTS idx_sync_metadata_school_id ON public.sync_metadata(school_id);
CREATE INDEX IF NOT EXISTS idx_sync_queue_school_id ON public.sync_queue(school_id);
CREATE INDEX IF NOT EXISTS idx_sync_queue_status ON public.sync_queue(status);
CREATE INDEX IF NOT EXISTS idx_sync_conflicts_school_id ON public.sync_conflicts(school_id);
CREATE INDEX IF NOT EXISTS idx_sync_conflicts_resolution ON public.sync_conflicts(resolution);
CREATE INDEX IF NOT EXISTS idx_cloud_sync_queue_school_id ON public.cloud_sync_queue(school_id);
CREATE INDEX IF NOT EXISTS idx_cloud_sync_queue_table_name ON public.cloud_sync_queue(table_name);
CREATE INDEX IF NOT EXISTS idx_peer_sync_queue_delivered ON public.peer_sync_queue(delivered);
CREATE INDEX IF NOT EXISTS idx_peer_sessions_device_id ON public.peer_sessions(device_id);

-- Grants for the service role used by the Flask sync integration
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'service_role') THEN
        GRANT USAGE ON SCHEMA public TO service_role;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.schools TO service_role;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.admin TO service_role;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.librarians TO service_role;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.join_requests TO service_role;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.students TO service_role;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.bookstable TO service_role;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.borrowed_books TO service_role;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.logs TO service_role;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.class_borrowing TO service_role;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.graduates_borrowed_books TO service_role;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.graduates_class_borrowing TO service_role;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.teacher_borrowed_books TO service_role;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.notes TO service_role;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.update_history TO service_role;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.book_issues TO service_role;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.remote_sync_ledger TO service_role;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.sync_metadata TO service_role;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.sync_queue TO service_role;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.sync_conflicts TO service_role;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.cloud_sync_queue TO service_role;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.peer_sync_queue TO service_role;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.sync_logs TO service_role;
        GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.peer_sessions TO service_role;
        GRANT USAGE, SELECT, UPDATE ON ALL SEQUENCES IN SCHEMA public TO service_role;
    END IF;
END
$$;
-- ==========================================
-- 25. SECURITY DIRECTIVES
-- ==========================================
CREATE TABLE IF NOT EXISTS public.security_directives (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    school_id UUID NOT NULL REFERENCES public.schools(id) ON DELETE CASCADE,
    directive TEXT NOT NULL, -- 'wipe', 'lockdown', 'none'
    status TEXT DEFAULT 'pending', -- 'pending', 'executed'
    impact_time TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

ALTER TABLE public.security_directives ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow read access for own school"
    ON public.security_directives FOR SELECT
    USING (school_id = (current_setting('request.jwt.claims', true)::json->>'school_id')::uuid);

CREATE POLICY "Allow all access for superadmin"
    ON public.security_directives FOR ALL
    USING (auth.uid() IN (SELECT user_id FROM public.admin WHERE role = 'superadmin'));

