# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_data_files, collect_submodules

# Collect required data files for SSL certs, timezones, and webview JS bridges
datas = [
    ('app', 'app'),
    ('updater.py', '.'),
    ('logo.ico', '.'),
    ('supabase_schema.sql', '.'),
]
datas += collect_data_files('certifi')
datas += collect_data_files('tzdata')
datas += collect_data_files('webview')

# Ensure all local scripts and dynamic dependencies are bundled
hiddenimports = [
    # Your top-level scripts loaded dynamically
    'run',
    'peer_sync',
    'updater',
    'wipe_sidecar',
    
    # PyWebView & Windows .NET bridge
    'webview',
    'webview.platforms.winforms',
    'webview.platforms.win32',
    'webview.platforms.edgechromium',
    'webview.platforms.mshtml',
    'clr',
    'clr_loader',
    'pythonnet',
    'proxy_tools',
    
    # Flask ecosystem
    'flask',
    'flask_cors',
    'flask_login',
    'flask_sqlalchemy',
    'werkzeug',
    'jinja2',
    
    # Database, Data & Reporting
    'sqlalchemy',
    'sqlalchemy.sql.default_comparator',
    'sqlalchemy.ext.baked',
    'greenlet',
    'pandas',
    'numpy',
    'openpyxl',
    'et_xmlfile',
    'reportlab',
    'PIL',
    
    # Supabase, Networking & System
    'supabase',
    'postgrest',
    'realtime',
    'supabase_auth',
    'supabase_functions',
    'httpx',
    'httpcore',
    'h2',
    'websockets',
    'requests',
    'packaging',
    'packaging.version',
    'dotenv',
    'psutil',
    'cryptography',
] + collect_submodules('app') + collect_submodules('reportlab.graphics.barcode')

a = Analysis(
    ['desktop.py'],
    pathex=['.'],
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=['webviewcheck.py'],
    excludes=[],
    noarchive=False,
    optimize=0,
)

pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='Edraze-library-system',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['logo.ico'],
)

coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='Edraze-library-system',
)
