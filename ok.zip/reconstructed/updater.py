"""Background silent updater for Edraze Library System.

Safely waits for the running Flask backend to exit, validates the staged
update.zip archive, creates a rollback backup of existing code files,
extracts & replaces updated files while protecting user data (SQLite DB,
config, uploads, backups), removes obsolete files listed in an optional
removed_files.txt manifest, clears stale __pycache__ bytecode, cleans up
staging, and silently restarts the Flask backend on the exact same port.
"""

from __future__ import annotations

import logging
import os
import shutil
import socket
import sqlite3
import subprocess
import sys
import time
import zipfile
from datetime import datetime
from pathlib import Path

# Top-level directories and filenames that must NEVER be overwritten or deleted
PROTECTED_NAMES = {
    "library.db",
    "library.db-wal",
    "library.db-shm",
    "config.json",
    "backups",
    "uploads",
    "staging",
    ".metadata",
    "instance",
    "webview_cache",
    "updater.log",
}

CODE_BACKUP_ROOT_EXTENSIONS = {".py", ".spec", ".iss", ".sql", ".json"}


def _setup_logger(app_root: Path) -> logging.Logger:
    logger = logging.getLogger("edraze_updater")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()

    log_candidates = []
    appdata = os.environ.get("APPDATA")
    if appdata:
        log_candidates.append(Path(appdata) / "LibraryManager" / "updater.log")
    log_candidates.append(app_root / "updater.log")

    for log_path in log_candidates:
        try:
            log_path.parent.mkdir(parents=True, exist_ok=True)
            handler = logging.FileHandler(log_path, mode="a", encoding="utf-8")
            handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
            logger.addHandler(handler)
            break
        except OSError:
            continue

    if not logger.handlers:
        logger.addHandler(logging.NullHandler())
    return logger


def _is_port_open(port: int, host: str = "127.0.0.1") -> bool:
    try:
        with socket.create_connection((host, port), timeout=0.5):
            return True
    except OSError:
        return False


def _wait_for_server_exit(port: int, timeout: float = 20.0, logger: logging.Logger | None = None) -> None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if not _is_port_open(port):
            time.sleep(0.8)
            if logger:
                logger.info("Backend port %s is now free.", port)
            return
        time.sleep(0.4)
    if logger:
        logger.warning("Timed out waiting for port %s to close; proceeding carefully.", port)


def _is_protected(rel_path: str) -> bool:
    norm = rel_path.replace("\\", "/").lstrip("/")
    if not norm:
        return True
    parts = [p for p in norm.split("/") if p]
    if not parts:
        return True
    top = parts[0].lower()
    if top in PROTECTED_NAMES:
        return True
    if any(part == ".." for part in parts):
        return True
    return False


def _detect_strip_prefix(members: list[str]) -> str:
    """Detect wrapper folders (e.g. 'reconstructed/' or 'repo-main/reconstructed/') in a zip."""
    clean_files = [
        m.replace("\\", "/").lstrip("/")
        for m in members
        if m and not m.endswith("/") and not m.startswith("__MACOSX/")
    ]
    if not clean_files:
        return ""

    # Look for a directory prefix that directly contains 'app/' or 'run.py'
    for candidate_marker in ("app/routes.py", "app/__init__.py", "run.py"):
        for path in clean_files:
            if path == candidate_marker:
                return ""
            suffix = "/" + candidate_marker
            if path.endswith(suffix):
                return path[: -len(candidate_marker)]

    # Fallback: if every file shares a single top-level directory, strip it
    top_dirs = {p.split("/", 1)[0] for p in clean_files if "/" in p}
    if len(top_dirs) == 1 and all("/" in p for p in clean_files):
        return next(iter(top_dirs)) + "/"
    return ""


def _create_rollback_backup(app_root: Path, backup_dir: Path, logger: logging.Logger) -> Path | None:
    backup_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_zip = backup_dir / f"pre_update_code_{ts}.zip"

    try:
        with zipfile.ZipFile(backup_zip, "w", zipfile.ZIP_DEFLATED) as zf:
            app_dir = app_root / "app"
            if app_dir.is_dir():
                for root, dirs, files in os.walk(app_dir):
                    dirs[:] = [d for d in dirs if d != "__pycache__"]
                    for fname in files:
                        fpath = Path(root) / fname
                        rel = fpath.relative_to(app_root).as_posix()
                        zf.write(fpath, rel)

            for item in app_root.iterdir():
                if item.is_file() and item.name.lower() not in PROTECTED_NAMES:
                    if item.suffix.lower() in CODE_BACKUP_ROOT_EXTENSIONS:
                        zf.write(item, item.name)
        logger.info("Created pre-update rollback backup: %s", backup_zip)
        return backup_zip
    except Exception as exc:
        logger.error("Failed to create rollback backup: %s", exc)
        return None


def _restore_rollback_backup(backup_zip: Path | None, app_root: Path, logger: logging.Logger) -> None:
    if not backup_zip or not backup_zip.exists():
        logger.warning("No rollback backup archive available.")
        return
    try:
        with zipfile.ZipFile(backup_zip, "r") as zf:
            for member in zf.infolist():
                if member.is_dir() or _is_protected(member.filename):
                    continue
                target = (app_root / member.filename).resolve()
                if not str(target).startswith(str(app_root.resolve())):
                    continue
                target.parent.mkdir(parents=True, exist_ok=True)
                with zf.open(member, "r") as src, open(target, "wb") as dst:
                    shutil.copyfileobj(src, dst)
        logger.info("Rollback restored successfully from %s", backup_zip)
    except Exception as exc:
        logger.error("Rollback restore failed: %s", exc)


def _atomic_write(target: Path, data: bytes, retries: int = 8) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = target.with_suffix(target.suffix + ".upd_tmp")
    with open(tmp_path, "wb") as f:
        f.write(data)
    for attempt in range(retries):
        try:
            os.replace(tmp_path, target)
            return
        except PermissionError:
            if attempt == retries - 1:
                try:
                    tmp_path.unlink(missing_ok=True)
                except OSError:
                    pass
                raise
            time.sleep(0.5)


def _clear_pycache(app_root: Path, logger: logging.Logger) -> None:
    removed = 0
    for root, dirs, _ in os.walk(app_root):
        if "__pycache__" in dirs:
            cache_dir = Path(root) / "__pycache__"
            try:
                shutil.rmtree(cache_dir, ignore_errors=True)
                removed += 1
            except OSError:
                pass
            dirs.remove("__pycache__")
    logger.info("Cleared %d __pycache__ directories.", removed)


def _update_history_status(status: str, logger: logging.Logger) -> None:
    """Update the most recent Pending UpdateHistory record without touching schema."""
    db_candidates = []
    appdata = os.environ.get("APPDATA")
    if appdata:
        db_candidates.append(Path(appdata) / "LibraryManager" / "library.db")
    db_candidates.append(Path(__file__).resolve().parent / "library.db")

    for db_path in db_candidates:
        if not db_path.exists():
            continue
        try:
            conn = sqlite3.connect(str(db_path), timeout=5)
            cur = conn.cursor()
            cur.execute(
                "UPDATE update_history SET status = ? WHERE id = ("
                "SELECT id FROM update_history ORDER BY rowid DESC LIMIT 1"
                ") AND status = 'Pending'",
                (status,),
            )
            conn.commit()
            conn.close()
            logger.info("Updated update_history status to '%s' in %s", status, db_path)
            return
        except Exception as exc:
            logger.debug("Could not update update_history in %s: %s", db_path, exc)


def _restart_backend(app_root: Path, port: int, logger: logging.Logger) -> None:
    """Silently relaunch ONLY the Flask backend on the exact port (no console/GUI)."""
    creationflags = 0
    if sys.platform == "win32":
        creationflags = (
            getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
            | getattr(subprocess, "DETACHED_PROCESS", 0x00000008)
        )

    if getattr(sys, "frozen", False):
        cmd = [sys.executable, "--backend", str(port)]
    else:
        run_py = app_root / "run.py"
        cmd = [sys.executable, str(run_py), str(port)]

    env = os.environ.copy()
    env["ELECTRON_APP"] = "1"

    logger.info("Relaunching backend silently: %s", cmd)
    subprocess.Popen(
        cmd,
        cwd=str(app_root),
        env=env,
        creationflags=creationflags,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        close_fds=(sys.platform != "win32"),
    )


def apply_update(staging_file: Path, app_root: Path, backup_dir: Path, port: int) -> int:
    logger = _setup_logger(app_root)
    logger.info("=== Update started: staging=%s, app_root=%s, port=%s ===", staging_file, app_root, port)

    _wait_for_server_exit(port, timeout=20.0, logger=logger)

    if not staging_file.exists() or not zipfile.is_zipfile(staging_file):
        logger.error("Staging archive missing or invalid: %s", staging_file)
        _update_history_status("Failed", logger)
        _restart_backend(app_root, port, logger)
        return 1

    # Verify archive integrity before touching any files
    try:
        with zipfile.ZipFile(staging_file, "r") as zf:
            corrupt_member = zf.testzip()
            if corrupt_member is not None:
                raise zipfile.BadZipFile(f"Corrupt member in zip: {corrupt_member}")
            raw_names = zf.namelist()
    except Exception as exc:
        logger.error("Archive integrity verification failed: %s", exc)
        _update_history_status("Failed", logger)
        _restart_backend(app_root, port, logger)
        return 1

    backup_zip = _create_rollback_backup(app_root, backup_dir, logger)
    strip_prefix = _detect_strip_prefix(raw_names)
    logger.info("Detected zip prefix to strip: %r", strip_prefix)

    removed_manifest_entries: list[str] = []
    replaced_count = 0

    try:
        app_root_resolved = app_root.resolve()
        with zipfile.ZipFile(staging_file, "r") as zf:
            for member in zf.infolist():
                if member.is_dir():
                    continue
                raw_name = member.filename.replace("\\", "/").lstrip("/")
                if raw_name.startswith("__MACOSX/"):
                    continue
                rel_name = raw_name[len(strip_prefix):] if strip_prefix and raw_name.startswith(strip_prefix) else raw_name
                rel_name = rel_name.lstrip("/")
                if not rel_name:
                    continue

                if rel_name.lower() == "removed_files.txt":
                    manifest_text = zf.read(member).decode("utf-8", errors="ignore")
                    for line in manifest_text.splitlines():
                        entry = line.strip()
                        if entry and not entry.startswith("#"):
                            removed_manifest_entries.append(entry)
                    continue

                if _is_protected(rel_name):
                    logger.info("Skipping protected path: %s", rel_name)
                    continue

                target = (app_root / rel_name).resolve()
                if not str(target).startswith(str(app_root_resolved)):
                    logger.warning("Blocked path traversal entry: %s", raw_name)
                    continue

                # Avoid attempting to overwrite the currently executing Windows binary
                if getattr(sys, "frozen", False) and target == Path(sys.executable).resolve():
                    logger.info("Skipping active executable replacement: %s", rel_name)
                    continue

                data = zf.read(member)
                _atomic_write(target, data)
                replaced_count += 1

        # Delete obsolete files listed in removed_files.txt
        deleted_count = 0
        for rel_del in removed_manifest_entries:
            if _is_protected(rel_del):
                continue
            del_target = (app_root / rel_del).resolve()
            if not str(del_target).startswith(str(app_root_resolved)):
                continue
            if del_target.is_file():
                del_target.unlink(missing_ok=True)
                deleted_count += 1
            elif del_target.is_dir():
                shutil.rmtree(del_target, ignore_errors=True)
                deleted_count += 1

        _clear_pycache(app_root, logger)
        logger.info("Update applied successfully: %d file(s) replaced, %d obsolete path(s) deleted.", replaced_count, deleted_count)

        # Clean up staged archive
        try:
            staging_file.unlink(missing_ok=True)
        except OSError:
            pass

        _update_history_status("Success", logger)

    except Exception as exc:
        logger.exception("Update failed during extraction/replacement; rolling back: %s", exc)
        _restore_rollback_backup(backup_zip, app_root, logger)
        _update_history_status("Failed", logger)
        _restart_backend(app_root, port, logger)
        return 1

    _restart_backend(app_root, port, logger)
    logger.info("=== Update complete ===")
    return 0


def main(argv: list[str] | None = None) -> int:
    args = list(sys.argv[1:] if argv is None else argv)
    if len(args) < 4:
        return 1
    staging_file = Path(args[0])
    app_root = Path(args[1])
    backup_dir = Path(args[2])
    try:
        port = int(args[3])
    except ValueError:
        port = 5000
    return apply_update(staging_file, app_root, backup_dir, port)


if __name__ == "__main__":
    raise SystemExit(main())
