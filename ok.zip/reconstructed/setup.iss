#define AppName "Edraze Library System"
#define AppVersion "1.0.0"
#define AppPublisher "Nexalabs"
#define AppExeName "Edraze-library-system.exe"

[Setup]
AppId={{5FDE16FC-C79C-43AA-B39B-05B05D44BA8E}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher={#AppPublisher}
DefaultDirName={autopf}\{#AppName}
DefaultGroupName={#AppName}
OutputDir=installer-output
OutputBaseFilename=Edraze-Library-System-Setup
SetupIconFile=logo.ico
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ArchitecturesInstallIn64BitMode=x64compatible
UninstallDisplayIcon={app}\{#AppExeName}
CloseApplications=force

[Tasks]
Name: "desktopicon"; Description: "Create a &desktop shortcut"; GroupDescription: "Additional shortcuts:"; Flags: unchecked

[Dirs]
Name: "{app}"; Permissions: users-modify
Name: "{app}\staging"; Permissions: users-modify
Name: "{app}\backups"; Permissions: users-modify
Name: "{app}\uploads"; Permissions: users-modify
Name: "{app}\.metadata"; Permissions: users-modify

[Files]
Source: "dist\Edraze-library-system\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\{#AppName}"; Filename: "{app}\{#AppExeName}"
Name: "{autodesktop}\{#AppName}"; Filename: "{app}\{#AppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#AppExeName}"; Description: "Launch {#AppName}"; Flags: nowait postinstall skipifsilent
